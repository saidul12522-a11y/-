import {FPS} from './theme';

/** SRT থেকে নেওয়া Scene টাইমিং (সেকেন্ড). SRT-এর সময় অপরিবর্তিত. */
export const SCENE_TIMES: Array<[number, number]> = [
  [0, 8], [8, 15], [15, 23], [23, 32], [32, 40], [40, 48],
  [48, 57], [57, 66], [66, 74], [74, 83], [83, 91], [91, 99],
  [99, 108], [108, 117], [117, 126], [126, 134], [134, 143], [143, 151],
  [151, 160], [160, 168], [168, 176], [176, 185], [185, 194],
];

/** দুই Scene-এর মাঝের Dissolve (ফ্রেম) */
export const OV = 12;

export const TOTAL_FRAMES = SCENE_TIMES[SCENE_TIMES.length - 1][1] * FPS;

export const sceneFrom = (n: number) => Math.max(0, SCENE_TIMES[n - 1][0] * FPS - (n > 1 ? OV : 0));
export const sceneDur = (n: number) => (SCENE_TIMES[n - 1][1] - SCENE_TIMES[n - 1][0]) * FPS + (n > 1 ? OV : 0);

/** Scene n-এর local সেকেন্ড → ভিডিওর absolute সেকেন্ড (SFX সিঙ্কের জন্য) */
export const at = (n: number, localSec: number) => sceneFrom(n) / FPS + localSec;
