import React from 'react';
import {AbsoluteFill, Sequence, useCurrentFrame} from 'remotion';
import {OV, SCENE_TIMES, TOTAL_FRAMES, sceneDur, sceneFrom} from './timing';
import {SfxTrack} from './components/SfxTrack';
import {Scene01, Scene02, Scene03, Scene04, Scene05, Scene06} from './scenes/Act1';
import {Scene07, Scene08, Scene09, Scene10, Scene11, Scene12} from './scenes/Act2';
import {Scene13, Scene14, Scene15, Scene16, Scene17, Scene18} from './scenes/Act3';
import {Scene19, Scene20, Scene21, Scene22, Scene23} from './scenes/Act4';

const SCENES: React.FC[] = [
  Scene01, Scene02, Scene03, Scene04, Scene05, Scene06, Scene07, Scene08, Scene09, Scene10, Scene11, Scene12,
  Scene13, Scene14, Scene15, Scene16, Scene17, Scene18, Scene19, Scene20, Scene21, Scene22, Scene23,
];

/** Scene শুরুর OV ফ্রেমে আগের Scene-এর ওপর Dissolve */
const Dissolve: React.FC<{enabled: boolean; children: React.ReactNode}> = ({enabled, children}) => {
  const f = useCurrentFrame();
  const o = enabled ? Math.min(1, f / OV) : 1;
  return <AbsoluteFill style={{opacity: o}}>{children}</AbsoluteFill>;
};

/** শেষ ১.৫ সেকেন্ডে Fade to Black */
const FinalFade: React.FC = () => {
  const f = useCurrentFrame();
  const start = TOTAL_FRAMES - 45;
  const o = f < start ? 0 : (f - start) / 45;
  return <AbsoluteFill style={{backgroundColor: '#000', opacity: Math.min(1, o), pointerEvents: 'none'}} />;
};

export const RafiVideo: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: '#000'}}>
    {SCENES.map((C, i) => (
      <Sequence key={i} from={sceneFrom(i + 1)} durationInFrames={sceneDur(i + 1)} name={`Scene ${String(i + 1).padStart(2, '0')}`}>
        <Dissolve enabled={i > 0}>
          <C />
        </Dissolve>
      </Sequence>
    ))}
    <SfxTrack />
    <FinalFade />
  </AbsoluteFill>
);
