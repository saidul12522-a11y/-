import {at, TOTAL_FRAMES} from '../timing';
import {FPS} from '../theme';
import manifest from './manifest.json';

/** একটি Sound Effect cue. to থাকলে লুপ হয়ে `to` সেকেন্ড পর্যন্ত চলে (bed). */
export interface Cue {s: keyof typeof manifest; t: number; vol: number; to?: number; dur?: number}

const END = TOTAL_FRAMES / FPS;
const steps = (scene: number, f0: number, f1: number, omega = 0.16, vol = 0.5): Cue[] => {
  const out: Cue[] = [];
  for (let k = Math.ceil((f0 * omega) / Math.PI); (k * Math.PI) / omega <= f1; k++) {
    out.push({s: 'step', t: at(scene, (k * Math.PI) / omega / FPS), vol});
  }
  return out;
};

export const CUES: Cue[] = [
  // ঘরের পরিবেশ ও লুপ
  {s: 'room_tone', t: 0, to: END, vol: 0.5},
  {s: 'fan_loop', t: 0, to: at(4, 0), vol: 0.35},
  {s: 'fan_loop', t: at(5, 0), to: at(15, 1.4), vol: 0.35},
  {s: 'fan_loop', t: at(19, 0.4), to: END, vol: 0.32},
  {s: 'clock_tick', t: 0, to: at(3, 0), vol: 0.35},
  {s: 'clock_tick', t: at(6, 0), to: at(7, 0), vol: 0.35},
  {s: 'clock_tick', t: at(12, 0), to: at(15, 1.4), vol: 0.3},
  {s: 'clock_tick', t: at(20, 0), to: at(20, 3.0), vol: 0.3},
  {s: 'street_loop', t: at(4, 0), to: at(5, 0.6), vol: 0.5},
  {s: 'tv_murmur', t: at(4, 0.5), to: at(5, 0.6), vol: 0.28},
  {s: 'wind_soft', t: at(4, 0), to: at(5, 0.6), vol: 0.22},
  {s: 'birds', t: at(4, 0.3), to: at(5, 0), vol: 0.22},
  {s: 'wind_soft', t: at(9, 0), to: at(10, 0.4), vol: 0.3},
  {s: 'kids_far', t: at(9, 0), to: at(10, 0.4), vol: 0.4},
  {s: 'heartbeat', t: at(13, 0), to: at(14, 5), vol: 0.35},
  {s: 'crackle', t: at(15, 7.4), to: at(19, 0), vol: 0.4},
  {s: 'birds', t: at(21, 0), to: at(21, 3.2), vol: 0.25},
  {s: 'birds', t: at(22, 0), to: at(23, 8), vol: 0.35},
  {s: 'wind_soft', t: at(22, 0), to: at(23, 4), vol: 0.25},

  // Scene 04 — রাস্তা
  {s: 'rickshaw_bell', t: at(4, 1.2), vol: 0.55}, {s: 'rickshaw_bell', t: at(4, 5.8), vol: 0.5},
  {s: 'crow', t: at(4, 2.8), vol: 0.5}, {s: 'crow', t: at(4, 7.0), vol: 0.45},

  // Scene 03 — ল্যাম্প নেভানো, শুয়ে পড়া
  {s: 'switch_click', t: at(3, 2.9), vol: 0.8}, {s: 'sheet_rustle', t: at(3, 4.6), vol: 0.5},

  // Scene 07 — ফোন
  {s: 'sheet_rustle', t: at(7, 1.8), vol: 0.4}, {s: 'phone_ping', t: at(7, 4.0), vol: 0.5},
  {s: 'phone_tap', t: at(7, 6.0), vol: 0.5}, {s: 'phone_tap', t: at(7, 6.8), vol: 0.5}, {s: 'phone_tap', t: at(7, 7.7), vol: 0.5},
  {s: 'sigh', t: at(7, 8.1), vol: 0.35},
  {s: 'sigh', t: at(8, 6.6), vol: 0.3},
  {s: 'sigh', t: at(10, 5.2), vol: 0.35},

  // Scene 11 — চা বানানো
  {s: 'thunk', t: at(11, 1.1), vol: 0.5},
  {s: 'water_pour', t: at(11, 1.55), dur: 1.35, vol: 0.5},
  {s: 'thunk', t: at(11, 3.5), vol: 0.45},
  {s: 'cup_clink', t: at(11, 5.8), vol: 0.5},
  ...steps(11, 112, 150, 0.16, 0.35), ...steps(11, 188, 282, 0.16, 0.4),

  // Scene 12
  {s: 'thunk', t: at(12, 0.3), vol: 0.3}, {s: 'phone_ping', t: at(12, 5.5), vol: 0.35},

  // Scene 13 — Subtle Cinematic Impact
  {s: 'impact', t: at(13, 0.4), vol: 0.6},

  // Scene 14 — এপাশ-ওপাশ
  {s: 'sheet_rustle', t: at(14, 1.4), vol: 0.5}, {s: 'sheet_rustle', t: at(14, 3.9), vol: 0.5},
  {s: 'sheet_rustle', t: at(14, 6.2), vol: 0.5}, {s: 'sigh', t: at(14, 5.0), vol: 0.4},

  // Scene 15 — বিদ্যুৎ গেল
  {s: 'power_down', t: at(15, 1.4), vol: 0.7},
  {s: 'thunk', t: at(15, 4.6), vol: 0.45},
  {s: 'match_strike', t: at(15, 7.5), vol: 0.55},

  // Scene 16 — খাতা খোলা
  {s: 'page_turn', t: at(16, 1.5), vol: 0.5},

  // Scene 17 — Flashback
  {s: 'pen_scratch', t: at(17, 0.6), vol: 0.35}, {s: 'pen_scratch', t: at(17, 3.0), vol: 0.35},
  {s: 'thunk', t: at(17, 6.6), vol: 0.35}, {s: 'sigh', t: at(17, 7.2), vol: 0.3},

  // Scene 18
  {s: 'sigh', t: at(18, 3.2), vol: 0.3},

  // Scene 19 — ফোন রেখে আসা
  {s: 'phone_tap', t: at(19, 0.6), vol: 0.4},
  ...steps(19, 34, 160, 0.16, 0.45), ...steps(19, 172, 236, 0.16, 0.45),
  {s: 'door_creak', t: at(19, 5.0), vol: 0.45}, {s: 'door_creak', t: at(19, 5.9), vol: 0.35},
  {s: 'chair_scrape', t: at(19, 8.0), vol: 0.45},

  // Scene 20
  {s: 'pen_scratch', t: at(20, 0.4), vol: 0.25},
  {s: 'alarm_beeps', t: at(20, 2.7), vol: 0.45},
  {s: 'chair_scrape', t: at(20, 4.1), vol: 0.4},
  {s: 'marker_scratch', t: at(20, 5.7), vol: 0.5}, {s: 'marker_scratch', t: at(20, 6.6), vol: 0.5},

  // Scene 21 — আরও ক্রস
  {s: 'page_turn', t: at(21, 0.8), vol: 0.3}, {s: 'marker_scratch', t: at(21, 2.0), vol: 0.45},
  {s: 'page_turn', t: at(21, 3.9), vol: 0.3}, {s: 'marker_scratch', t: at(21, 5.1), vol: 0.45},
  {s: 'page_turn', t: at(21, 7.0), vol: 0.3}, {s: 'marker_scratch', t: at(21, 8.2), vol: 0.45},

  // Scene 22–23
  {s: 'page_turn', t: at(22, 2.4), vol: 0.35}, {s: 'page_turn', t: at(22, 6.4), vol: 0.35},
  {s: 'page_turn', t: at(23, 1.8), vol: 0.35},
];

export const durationOf = (c: Cue) => Math.max(0.05, c.dur ?? (c.to !== undefined ? c.to - c.t : manifest[c.s]));
