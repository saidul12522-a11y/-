export const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
export const rad = (d: number) => (d * Math.PI) / 180;
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const easeInOut = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
export const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
export const lin = (t: number) => t;
export const T = (sec: number) => Math.round(sec * 30);

/** Keyframe interpolation: kf(frame, [[frame, value], ...]) */
export function kf(frame: number, keys: Array<[number, number]>, ease: (t: number) => number = easeInOut): number {
  if (frame <= keys[0][0]) return keys[0][1];
  for (let i = 1; i < keys.length; i++) {
    const [f1, v1] = keys[i];
    const [f0, v0] = keys[i - 1];
    if (frame <= f1) return lerp(v0, v1, ease((frame - f0) / (f1 - f0 || 1)));
  }
  return keys[keys.length - 1][1];
}

const h2 = (h: string): [number, number, number] => {
  const n = parseInt(h.replace('#', ''), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};
const toHex = (c: number[]) =>
  '#' + c.map((v) => Math.round(clamp(v, 0, 255)).toString(16).padStart(2, '0')).join('');

export function mix(a: string, b: string, t: number): string {
  const x = h2(a), y = h2(b);
  return toHex([lerp(x[0], y[0], t), lerp(x[1], y[1], t), lerp(x[2], y[2], t)]);
}
export const lum = (c: string) => {
  const [r, g, b] = h2(c);
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255;
};

export function seeded(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** সিলিং ফ্যানের কোণ (ডিগ্রি). cut ফ্রেমে বিদ্যুৎ গেলে ধীরে থামে. */
export function fanAngle(f: number, cut = Infinity, speed = 14): number {
  if (f <= cut) return f * speed;
  const tau = 70;
  return cut * speed + speed * tau * (1 - Math.exp(-(f - cut) / tau));
}

export const pulse = (f: number, period = 36) => 0.5 + 0.5 * Math.sin((f / period) * Math.PI);
