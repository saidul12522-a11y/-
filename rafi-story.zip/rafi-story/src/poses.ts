import {clamp, easeInOut, lerp, rad} from './utils';
import {CHAR_SCALE, FLOOR} from './theme';

export type Limb = [number, number]; // [উপরের হাড়ের কোণ, নিচের হাড়ের কোণ] — নিচ থেকে মাপা, সামনে (+x) ধনাত্মক
export type V2 = [number, number];

export interface Pose {
  torso: number; head: number;
  armN: Limb; armF: Limb; legN: Limb; legF: Limb;
  eye: number; brow: number; mouth: number;
}

export const L = {torso: 140, upper: 62, fore: 58, thigh: 88, shin: 86, neckHead: 30};
const SC = CHAR_SCALE;

/** hip-এর y মান (মাটি থেকে) */
export const HIP_Y = {stand: FLOOR - 186 * SC, sit: FLOOR - 98 * SC};

export const shoulder = (torso: number): V2 => [Math.sin(rad(torso)) * (L.torso - 14), -Math.cos(rad(torso)) * (L.torso - 14)];

export function pts(o: V2, l1: number, l2: number, a1: number, a2: number) {
  const e: V2 = [o[0] + l1 * Math.sin(rad(a1)), o[1] + l1 * Math.cos(rad(a1))];
  const h: V2 = [e[0] + l2 * Math.sin(rad(a2)), e[1] + l2 * Math.cos(rad(a2))];
  return {e, h};
}

/** দুই-হাড়ের IK: target (hip-local) এ হাত পৌঁছাতে কোণ বের করে */
export function armTo(torso: number, target: V2, bend = 1): Limb {
  const s = shoulder(torso);
  const dx = target[0] - s[0], dy = target[1] - s[1];
  const raw = Math.hypot(dx, dy) || 1;
  const d = clamp(raw, Math.abs(L.upper - L.fore) + 1, L.upper + L.fore - 0.5);
  const base = Math.atan2(dx, dy);
  const A = Math.acos(clamp((L.upper * L.upper + d * d - L.fore * L.fore) / (2 * L.upper * d), -1, 1));
  const a1 = base - bend * A;
  const ex = s[0] + L.upper * Math.sin(a1), ey = s[1] + L.upper * Math.cos(a1);
  const tx = s[0] + (dx / raw) * d, ty = s[1] + (dy / raw) * d;
  const a2 = Math.atan2(tx - ex, ty - ey);
  return [(a1 * 180) / Math.PI, (a2 * 180) / Math.PI];
}

/** দাঁড়ানো অবস্থায় world → hip-local */
export const loc = (hip: V2, w: V2, sc = SC): V2 => [(w[0] - hip[0]) / sc, (w[1] - hip[1]) / sc];
/** চিত হয়ে শোয়া (rotate -90) অবস্থায় world → hip-local */
export const locLie = (hip: V2, w: V2, sc = SC): V2 => [(hip[1] - w[1]) / sc, (w[0] - hip[0]) / sc];

export function lerpPose(a: Pose, b: Pose, t: number): Pose {
  const l2 = (x: Limb, y: Limb): Limb => [lerp(x[0], y[0], t), lerp(x[1], y[1], t)];
  return {
    torso: lerp(a.torso, b.torso, t), head: lerp(a.head, b.head, t),
    armN: l2(a.armN, b.armN), armF: l2(a.armF, b.armF),
    legN: l2(a.legN, b.legN), legF: l2(a.legF, b.legF),
    eye: lerp(a.eye, b.eye, t), brow: lerp(a.brow, b.brow, t), mouth: lerp(a.mouth, b.mouth, t),
  };
}

export interface PoseKey {f: number; p: Pose}
export function poseAt(keys: PoseKey[], f: number, ease: (t: number) => number = easeInOut): Pose {
  if (f <= keys[0].f) return keys[0].p;
  for (let i = 1; i < keys.length; i++) {
    if (f <= keys[i].f) {
      const a = keys[i - 1], b = keys[i];
      return lerpPose(a.p, b.p, ease((f - a.f) / (b.f - a.f || 1)));
    }
  }
  return keys[keys.length - 1].p;
}
export const K = (f: number, p: Pose): PoseKey => ({f, p});

const mk = (o: Partial<Pose>): Pose => ({
  torso: 3, head: 2, armN: [7, 12], armF: [-3, 5], legN: [1, 1], legF: [-4, -4],
  eye: 0.85, brow: 0.3, mouth: -0.15, ...o,
});
export const withFace = (p: Pose, o: Partial<Pose>): Pose => ({...p, ...o});

export const STAND = mk({});
export const STAND_TIRED = mk({torso: 6, head: 14, eye: 0.55, brow: 0.6, mouth: -0.4, armN: [9, 16], armF: [-2, 8]});
export const SIT = mk({
  torso: 4, head: 3, legN: [88, 2], legF: [92, -2],
  armN: armTo(4, [84, -18]), armF: armTo(4, [66, -18]),
});
export const SLUMP = mk({
  torso: 24, head: 22, legN: [88, 3], legF: [93, -1], eye: 0.6, brow: 0.7, mouth: -0.5,
  armN: armTo(24, [88, -16]), armF: armTo(24, [70, -16]),
});
export const LIE = mk({
  torso: 0, head: -4, armN: [3, 5], armF: [1, 3], legN: [12, -6], legF: [8, -10], eye: 0.8,
});

/** হাঁটার ভঙ্গি. phase = রেডিয়ান */
export function walk(phase: number, base: Pose = STAND): Pose {
  const s = Math.sin(phase), c = Math.cos(phase);
  const thN = 28 * s, thF = -28 * s;
  const bendN = 34 * Math.max(0, c), bendF = 34 * Math.max(0, -c);
  return {
    ...base,
    torso: base.torso + 2,
    legN: [thN, thN - bendN], legF: [thF, thF - bendF],
    armN: [-20 * s + 4, -20 * s + 18], armF: [20 * s, 20 * s + 14],
  };
}
/** হাঁটার গতি (px/frame) — পা মাটিতে না পিছলানোর জন্য */
export const walkSpeed = (omega: number) => omega * 51.2 * SC;
export const WALK_OMEGA = 0.16;

export function rig(p: Pose) {
  const t = rad(p.torso);
  const ax: V2 = [Math.sin(t), -Math.cos(t)];
  const neck: V2 = [ax[0] * L.torso, ax[1] * L.torso];
  const sh = shoulder(p.torso);
  const h = rad(p.torso + p.head);
  const headC: V2 = [neck[0] + Math.sin(h) * L.neckHead, neck[1] - Math.cos(h) * L.neckHead];
  const aN = pts(sh, L.upper, L.fore, p.armN[0], p.armN[1]);
  const aF = pts([sh[0] - 5, sh[1] + 1], L.upper, L.fore, p.armF[0], p.armF[1]);
  const lN = pts([0, 0], L.thigh, L.shin, p.legN[0], p.legN[1]);
  const lF = pts([0, 0], L.thigh, L.shin, p.legF[0], p.legF[1]);
  return {ax, neck, sh, headC, aN, aF, lN, lF};
}
export type Rig = ReturnType<typeof rig>;
