import React, {createContext, useContext} from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {H, Mood, MOODS, W} from '../theme';
import {easeInOut, lerp} from '../utils';

const MoodCtx = createContext<Mood>(MOODS.night);
export const useMood = () => useContext(MoodCtx);

const CamCtx = createContext({x: W / 2, y: H / 2, s: 1});
export const useCam = () => useContext(CamCtx);

export interface CamKey {f: number; x: number; y: number; s: number; r?: number}
export const ck = (f: number, x: number, y: number, s: number, r = 0): CamKey => ({f, x, y, s, r});

function camAt(keys: CamKey[], f: number) {
  if (f <= keys[0].f) return keys[0];
  for (let i = 1; i < keys.length; i++) {
    if (f <= keys[i].f) {
      const a = keys[i - 1], b = keys[i];
      const t = easeInOut((f - a.f) / (b.f - a.f || 1));
      return {f, x: lerp(a.x, b.x, t), y: lerp(a.y, b.y, t), s: lerp(a.s, b.s, t), r: lerp(a.r || 0, b.r || 0, t)};
    }
  }
  return keys[keys.length - 1];
}

/** Parallax: factor<1 দূরের স্তর (কম নড়ে), factor>1 সামনের স্তর (বেশি নড়ে) */
export const Parallax: React.FC<{factor: number; children?: React.ReactNode}> = ({factor, children}) => {
  const c = useCam();
  return <g transform={`translate(${(c.x - W / 2) * (1 - factor)} ${(c.y - H / 2) * (1 - factor)})`}>{children}</g>;
};

export const Stage: React.FC<{
  mood: Mood; cam: CamKey[]; grain?: number; overlay?: React.ReactNode; children?: React.ReactNode;
}> = ({mood, cam, grain = 0.07, overlay, children}) => {
  const f = useCurrentFrame();
  const c = camAt(cam, f);
  const seed = Math.floor(f / 2) % 50;
  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{display: 'block'}}>
        <defs>
          <radialGradient id="vig" cx="50%" cy="50%" r="72%">
            <stop offset="42%" stopColor="#000" stopOpacity="0" />
            <stop offset="100%" stopColor="#000" stopOpacity={mood.vignette} />
          </radialGradient>
          <filter id="grain" x="0" y="0" width="100%" height="100%">
            <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="1" seed={seed} />
            <feColorMatrix type="saturate" values="0" />
          </filter>
        </defs>
        <MoodCtx.Provider value={mood}>
          <CamCtx.Provider value={{x: c.x, y: c.y, s: c.s}}>
            <g transform={`translate(${W / 2} ${H / 2}) rotate(${c.r || 0}) scale(${c.s}) translate(${-c.x} ${-c.y})`}>
              {children}
            </g>
          </CamCtx.Provider>
        </MoodCtx.Provider>
        <rect width={W} height={H} fill={mood.ambient} opacity={mood.ambientA * 0.45} />
        <rect width={W} height={H} fill="url(#vig)" />
        <rect width={W} height={H} filter="url(#grain)" opacity={grain} />
        {overlay}
      </svg>
    </AbsoluteFill>
  );
};
