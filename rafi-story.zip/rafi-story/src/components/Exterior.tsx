import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Parallax, useMood} from './Stage';
import {lum, mix, seeded} from '../utils';

/** ঢাকার পুরনো বাড়ির বাইরের দৃশ্য — রাস্তা, রিকশা, কাক, তিনতলার জানালা */
export const Exterior: React.FC = () => {
  const f = useCurrentFrame();
  const m = useMood();
  const rnd = seeded(3);
  const wall = mix('#6b7488', m.skyBot, 0.18);
  const dk = (c: string, t = 0.5) => mix(c, '#000000', t * (1 - m.charLight * 0.5));
  const wallC = dk(wall, 0.35), neigh = dk('#4d566e', 0.35), road = dk('#2b2f3a', 0.3), side = dk('#555b6b', 0.3);
  const night = lum(m.skyTop) < 0.3;
  const rx = -380 + f * 7.2;
  const wob = Math.sin(f * 0.5);
  const tv = 0.55 + 0.45 * Math.abs(Math.sin(f * 0.37) * Math.sin(f * 0.11));
  const crow = Math.sin(f / 18) > 0.8 ? 7 : 0;

  const win = (x: number, y: number, lit: boolean, w = 120, h = 150, key?: string) => (
    <g key={key}>
      <rect x={x - 8} y={y - 8} width={w + 16} height={h + 16} fill={dk('#7d8499', 0.3)} />
      <rect x={x} y={y} width={w} height={h} fill={lit ? '#f4c26b' : dk('#1b2236', 0.2)} />
      {lit && <rect x={x} y={y} width={w} height={h} fill="url(#winGlow)" />}
      <line x1={x + w / 2} y1={y} x2={x + w / 2} y2={y + h} stroke={dk('#7d8499', 0.4)} strokeWidth={5} />
      <line x1={x} y1={y + h * 0.42} x2={x + w} y2={y + h * 0.42} stroke={dk('#7d8499', 0.4)} strokeWidth={4} />
    </g>
  );

  return (
    <g>
      <defs>
        <linearGradient id="exSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={m.skyTop} /><stop offset="1" stopColor={m.skyBot} /></linearGradient>
        <radialGradient id="winGlow"><stop offset="0" stopColor="#fff2c4" stopOpacity="0.6" /><stop offset="1" stopColor="#f4c26b" stopOpacity="0" /></radialGradient>
        <radialGradient id="lampPost"><stop offset="0" stopColor="#ffd488" stopOpacity="0.7" /><stop offset="1" stopColor="#ffd488" stopOpacity="0" /></radialGradient>
        <linearGradient id="mist" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#c9d4ea" stopOpacity="0" /><stop offset="1" stopColor="#c9d4ea" stopOpacity="0.22" /></linearGradient>
      </defs>
      <rect x={-1400} y={-1400} width={4800} height={2200} fill="url(#exSky)" />
      {night && Array.from({length: 40}, (_, i) => <circle key={i} cx={-300 + rnd() * 2600} cy={-700 + rnd() * 900} r={1 + rnd() * 1.4} fill="#fff" opacity={0.5} />)}
      {/* দূরের স্কাইলাইন */}
      <Parallax factor={0.85}>
        {Array.from({length: 18}, (_, i) => <rect key={i} x={-200 + i * 140} y={300 - ((i * 53) % 190)} width={110} height={600} fill={dk(m.skyBot, 0.65)} />)}
      </Parallax>

      {/* পাশের বাড়ি */}
      <rect x={-300} y={-300} width={860} height={1100} fill={neigh} />
      {win(60, 330, false, 110, 140, 'n1')}
      <g>
        <rect x={236} y={322} width={140} height={156} fill={dk('#7d8499', 0.3)} />
        <rect x={244} y={330} width={124} height={140} fill="#6aa0ff" opacity={tv} />
        <rect x={244} y={330} width={124} height={140} fill="url(#winGlow)" opacity={tv * 0.5} />
      </g>
      {win(60, 60, false, 110, 140, 'n2')}{win(236, 60, true, 110, 140, 'n3')}

      {/* মূল বাড়ি */}
      <rect x={620} y={-900} width={900} height={1700} fill={wallC} />
      {Array.from({length: 24}, (_, i) => <rect key={i} x={640 + ((i * 97) % 860)} y={-700 + ((i * 331) % 1400)} width={6 + (i % 4) * 4} height={120 + (i % 5) * 40} fill="#000" opacity={0.06} />)}
      {[-250, 30, 310].map((y, fi) => (
        <g key={y}>
          <rect x={620} y={y + 250} width={900} height={24} fill={dk('#8a91a6', 0.35)} />
          {win(690, y, false, 110, 160, `a${fi}`)}
          {win(985, y, fi === 1, 120, 160, `b${fi}`)}
          {win(1290, y, false, 110, 160, `c${fi}`)}
          <rect x={970} y={y + 168} width={150} height={12} fill={dk('#7d8499', 0.4)} />
          {Array.from({length: 7}, (_, k) => <rect key={k} x={976 + k * 22} y={y + 180} width={4} height={48} fill={dk('#7d8499', 0.45)} />)}
        </g>
      ))}
      {/* কাপড় শুকাচ্ছে */}
      <g>
        <line x1={640} y1={110} x2={900} y2={90} stroke={dk('#999', 0.5)} strokeWidth={2} />
        {[0, 1, 2].map((i) => <path key={i} d={`M${680 + i * 70} 108 l${40 + (i % 2) * 8} 0 l0 ${62 + i * 6} l-${40 + (i % 2) * 8} 0 Z`} fill={['#a45a5a', '#5a7ea4', '#c9b46a'][i]} opacity={0.65 + Math.sin(f / 30 + i) * 0.05} />)}
      </g>
      {/* ইনস্টল করা এসি/ট্যাংক */}
      <rect x={1380} y={470} width={90} height={60} fill={dk('#8a91a6', 0.4)} />
      {/* নিচতলার দোকান */}
      <rect x={620} y={560} width={900} height={240} fill={dk('#6a5a52', 0.45)} />
      <rect x={700} y={590} width={300} height={210} fill={dk('#3d3d44', 0.4)} />
      {Array.from({length: 10}, (_, i) => <line key={i} x1={700} y1={604 + i * 20} x2={1000} y2={604 + i * 20} stroke="#000" strokeOpacity={0.25} strokeWidth={2} />)}
      <rect x={1090} y={610} width={140} height={190} fill={dk('#2a2a30', 0.3)} />

      {/* রাস্তা ও ফুটপাত */}
      <rect x={-1400} y={800} width={4800} height={80} fill={side} />
      <rect x={-1400} y={880} width={4800} height={700} fill={road} />
      {Array.from({length: 8}, (_, i) => <rect key={i} x={-300 + i * 300 + ((f * 0) % 300)} y={1020} width={150} height={9} fill="#cfcfcf" opacity={0.25} />)}

      {/* ল্যাম্পপোস্ট */}
      <g transform="translate(540 0)">
        <ellipse cx={0} cy={470} rx={300} ry={330} fill="url(#lampPost)" opacity={night ? 1 : 0.35} />
        <rect x={-6} y={380} width={12} height={420} fill={dk('#444', 0.5)} />
        <path d="M-6 384 q0 -40 50 -44 l0 12 q-36 2 -38 32Z" fill={dk('#444', 0.5)} /><rect x={36} y={340} width={34} height={12} rx={5} fill="#ffe3a6" />
      </g>
      {/* বিদ্যুতের খুঁটি, তার ও কাক */}
      <g>
        <rect x={1660} y={140} width={14} height={680} fill={dk('#3a3a40', 0.4)} />
        <rect x={1620} y={170} width={100} height={8} fill={dk('#3a3a40', 0.4)} />
        <path d="M1520 140 Q1590 190 1660 172 M1520 160 Q1600 214 1660 176 M1660 174 Q1800 214 2000 160" stroke={dk('#222', 0.4)} strokeWidth={2.4} fill="none" />
        <g transform={`translate(1590 ${176 + 8}) scale(-1 1)`} fill="#0c0d12">
          <ellipse cx={0} cy={-10} rx={16} ry={9} /><circle cx={-14} cy={-17 - crow * 0.2} r={6} /><path d={`M-19 -17 l-9 ${2 - crow * 0.2} l9 3Z`} />
          <path d="M14 -10 l18 6 l-16 2Z" /><rect x={-4} y={-3} width={2} height={9} /><rect x={4} y={-3} width={2} height={9} />
        </g>
      </g>

      {/* ফুটপাতে দূরের মানুষ */}
      {[0, 1].map((k) => {
        const px = ((300 + k * 700 + f * (0.9 + k * 0.4)) % 2600) - 300;
        return (
          <g key={k} transform={`translate(${px} 830) scale(0.78)`} fill={dk(k ? '#6b3b3b' : '#2f4a6b', 0.5)}>
            <circle cx={0} cy={-132} r={13} /><rect x={-14} y={-118} width={28} height={66} rx={10} />
            <rect x={-12} y={-54} width={10} height={52} rx={4} transform={`rotate(${Math.sin(f / 6 + k) * 18} -7 -54)`} />
            <rect x={2} y={-54} width={10} height={52} rx={4} transform={`rotate(${-Math.sin(f / 6 + k) * 18} 7 -54)`} />
          </g>
        );
      })}

      {/* রিকশা */}
      <g transform={`translate(${rx} ${930 + wob * 1.5}) scale(1.35)`}>
        {[0, 1].map((w) => (
          <g key={w} transform={`translate(${w ? 118 : -6} 0)`}>
            <circle r={46} fill="none" stroke="#0d0e13" strokeWidth={5} />
            {[0, 45, 90, 135].map((a) => <line key={a} x1={-44} y1={0} x2={44} y2={0} stroke="#0d0e13" strokeWidth={1.6} transform={`rotate(${a + f * 6})`} />)}
          </g>
        ))}
        <path d="M-6 0 L42 -40 L112 -40 L118 0 M42 -40 L56 0" stroke="#0d0e13" strokeWidth={5} fill="none" />
        <path d="M-12 -34 Q-12 -128 52 -138 Q92 -140 100 -88 L52 -46 Z" fill={dk('#7a2f3a', 0.45)} />
        <rect x={-14} y={-50} width={52} height={12} rx={4} fill="#0d0e13" />
        <g fill="#0d0e13" transform="translate(88 -52)"><circle cx={0} cy={-78} r={11} /><rect x={-11} y={-68} width={22} height={40} rx={8} transform="rotate(-8)" /><rect x={-9} y={-30} width={9} height={32} rx={4} transform={`rotate(${Math.sin(f * 0.3) * 24 + 10} -4 -30)`} /></g>
      </g>

      {/* ভোরের কুয়াশা */}
      <rect x={-1400} y={600} width={4800} height={500} fill="url(#mist)" />
    </g>
  );
};
