import React from 'react';
import {useCurrentFrame} from 'remotion';
import {useMood} from './Stage';
import {CHAR_SCALE} from '../theme';
import {L, Pose, rig, Rig} from '../poses';
import {mix} from '../utils';

const C = {
  skin: '#c28a62', skinD: '#9a684a', hair: '#14161c',
  shirt: '#3d4863', shirtD: '#2a3248', pants: '#4b505b', pantsD: '#353943', shoe: '#14161b',
};
const Z = (p: number[]) => `${p[0].toFixed(1)},${p[1].toFixed(1)}`;

export interface RafiProps {
  x: number; y: number; scale?: number; flip?: boolean; rotate?: number;
  pose: Pose; tear?: number; opacity?: number; seed?: number;
  /** rig-local স্থানাঙ্কে অতিরিক্ত বস্তু আঁকার জন্য (ফোন, কলম ইত্যাদি) */
  overlay?: (r: Rig) => React.ReactNode;
}

export const Rafi: React.FC<RafiProps> = ({x, y, scale = CHAR_SCALE, flip = false, rotate = 0, pose, tear = 0, opacity = 1, seed = 0, overlay}) => {
  const f = useCurrentFrame();
  const m = useMood();
  const col = (c: string) => mix(mix(c, m.ambient, m.ambientA * 0.7), '#000000', 1 - m.charLight);

  const breath = 0.7 * Math.sin(f / 20 + seed);
  const p: Pose = {...pose, torso: pose.torso + breath, head: pose.head - breath * 0.4};
  const r = rig(p);
  const bc = (f + seed * 37) % 132;
  const blink = bc < 6 ? Math.abs(bc - 3) / 3 : 1;
  const eye = p.eye * blink;

  // ধড়: প্রোফাইল অনুযায়ী পিছন/সামনের প্রস্থ
  const prof: Array<[number, number, number]> = [[0, 29, 27], [0.3, 26, 25], [0.65, 30, 32], [0.9, 28, 27], [1, 20, 17]];
  const t = (p.torso * Math.PI) / 180;
  const nrm = [Math.cos(t), Math.sin(t)];
  const at = (s: number, off: number): number[] => [r.ax[0] * L.torso * s + nrm[0] * off, r.ax[1] * L.torso * s + nrm[1] * off];
  const back = prof.map(([s, b]) => at(s, -b));
  const front = prof.map(([s, , fr]) => at(s, fr)).reverse();
  const body = 'M' + back.map(Z).join('L') + 'L' + front.map(Z).join('L') + 'Z';
  const shade = 'M' + back.map(Z).join('L') + 'L' + prof.map(([s, b]) => Z(at(s, -b * 0.15))).reverse().join('L') + 'Z';

  const shirt = col(C.shirt), shirtD = col(C.shirtD), skin = col(C.skin), skinD = col(C.skinD);
  const pants = col(C.pants), pantsD = col(C.pantsD), shoe = col(C.shoe), hair = col(C.hair);

  const leg = (l: {e: number[]; h: number[]}, a2: number, near: boolean) => (
    <g>
      <line x1={0} y1={0} x2={l.e[0]} y2={l.e[1]} stroke={near ? pants : pantsD} strokeWidth={36} strokeLinecap="round" />
      <line x1={l.e[0]} y1={l.e[1]} x2={l.h[0]} y2={l.h[1]} stroke={near ? pants : pantsD} strokeWidth={30} strokeLinecap="round" />
      <g transform={`translate(${l.h[0]} ${l.h[1]}) rotate(${-a2 * 0.35})`}>
        <path d="M-12 -6 L8 -6 C26 -4 40 4 40 12 L40 16 L-12 16 Z" fill={shoe} />
      </g>
    </g>
  );
  const arm = (a: {e: number[]; h: number[]}, s: number[], near: boolean) => (
    <g>
      <line x1={s[0]} y1={s[1]} x2={a.e[0]} y2={a.e[1]} stroke={near ? shirt : shirtD} strokeWidth={26} strokeLinecap="round" />
      <line x1={a.e[0]} y1={a.e[1]} x2={a.h[0]} y2={a.h[1]} stroke={near ? skin : skinD} strokeWidth={18} strokeLinecap="round" />
      <circle cx={a.h[0]} cy={a.h[1]} r={10.5} fill={near ? skin : skinD} />
    </g>
  );

  const headAbs = p.torso + p.head;
  const lid = Math.max(0, eye);
  const browBackY = -15 + p.brow * 2, browFrontY = -17 - p.brow * 5;
  const mouthC = 22 + p.mouth * 5;

  return (
    <g opacity={opacity} transform={`translate(${x} ${y}) rotate(${rotate}) scale(${flip ? -scale : scale} ${scale})`}>
      {arm(r.aF, [r.sh[0] - 5, r.sh[1] + 1], false)}
      {leg(r.lF, p.legF[1], false)}
      <path d={body} fill={shirt} stroke={shirt} strokeWidth={10} strokeLinejoin="round" />
      <path d={shade} fill={shirtD} opacity={0.55} />
      <ellipse cx={-1} cy={-2} rx={27} ry={24} fill={pants} />
      {leg(r.lN, p.legN[1], true)}
      <line x1={r.neck[0]} y1={r.neck[1]} x2={r.headC[0]} y2={r.headC[1]} stroke={skin} strokeWidth={22} strokeLinecap="round" />
      <g transform={`translate(${r.headC[0]} ${r.headC[1]}) rotate(${headAbs})`}>
        <ellipse cx={-6} cy={4} rx={7} ry={10} fill={skinD} />
        <ellipse cx={0} cy={0} rx={33} ry={39} fill={skin} />
        <ellipse cx={10} cy={20} rx={22} ry={17} fill={skin} />
        <ellipse cx={-14} cy={6} rx={14} ry={26} fill={skinD} opacity={0.22} />
        <path d="M32 -3 Q43 5 33 12" fill={skin} stroke={skinD} strokeWidth={1.4} />
        {lid > 0.14 ? (
          <ellipse cx={17} cy={-4} rx={4.2} ry={5 * lid} fill="#15171c" />
        ) : (
          <path d="M12 -3 Q17 0 22 -3" stroke="#15171c" strokeWidth={2.4} fill="none" strokeLinecap="round" />
        )}
        {lid > 0.14 && <circle cx={18.4} cy={-5.4} r={1.1} fill="#fff" opacity={0.7} />}
        <path d="M10 5 Q17 10.5 24 5" stroke="#2a1410" strokeWidth={2.4} fill="none" opacity={0.28} strokeLinecap="round" />
        <path d={`M7 ${browBackY} L28 ${browFrontY}`} stroke={hair} strokeWidth={3.4} strokeLinecap="round" />
        <path d={`M14 22 Q22 ${mouthC} 30 22`} stroke="#4a2820" strokeWidth={2.3} fill="none" strokeLinecap="round" />
        <path
          d="M-35 8 C-43 -26 -22 -47 4 -46 C27 -46 39 -30 34 -13 C28 -19 22 -25 13 -22 C3 -20 -1 -13 -4 -4 C-6 6 -8 12 -13 16 C-21 21 -31 19 -35 8 Z"
          fill={hair}
        />
        <path d="M6 -45 C16 -52 26 -49 30 -40 C24 -43 14 -43 6 -45Z" fill={hair} />
        {tear > 0 && (
          <g opacity={Math.sin(Math.min(1, tear) * Math.PI)}>
            <path d={`M21 ${8 + tear * 30} q-3 5 0 7 q3 -2 0 -7z`} fill="#d5e9ff" />
          </g>
        )}
        {lid > 0.5 && p.brow > 0.5 && <ellipse cx={18} cy={1} rx={5} ry={1.6} fill="#fff" opacity={0.18} />}
      </g>
      {arm(r.aN, r.sh, true)}
      {overlay && overlay(r)}
    </g>
  );
};
