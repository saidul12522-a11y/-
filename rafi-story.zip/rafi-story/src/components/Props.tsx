import React from 'react';
import {useCurrentFrame} from 'remotion';
import {useMood} from './Stage';
import {clamp, mix, seeded} from '../utils';

/** মুডের আলো অনুযায়ী রঙ বদলানো */
export const useLit = () => {
  const m = useMood();
  return (c: string) => mix(mix(c, m.ambient, m.ambientA * 0.6), '#000000', 1 - m.charLight * 0.9 - 0.08);
};

/** মোবাইল ফোন (সামনে থেকে) */
export const Phone: React.FC<{x: number; y: number; rot?: number; glow?: number; scroll?: number; scale?: number}> = ({x, y, rot = 0, glow = 1, scroll = 0, scale = 1}) => {
  const rnd = seeded(7);
  const rows = Array.from({length: 14}, (_, i) => ({w: 20 + rnd() * 34, h: 5 + rnd() * 20, c: rnd() > 0.7}));
  let acc = 0;
  const off = (scroll * 0.6) % 160;
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${scale})`}>
      {glow > 0 && <circle r={190} fill="url(#phoneGlow)" opacity={0.55 * glow} />}
      <rect x={-20} y={-38} width={40} height={76} rx={6} fill="#0b0d12" stroke="#2a2f3a" strokeWidth={1} />
      <clipPath id="scr"><rect x={-17} y={-34} width={34} height={68} rx={3} /></clipPath>
      <g clipPath="url(#scr)">
        <rect x={-17} y={-34} width={34} height={68} fill={glow > 0 ? '#9ec5ff' : '#050608'} opacity={glow > 0 ? 0.92 * glow + 0.08 : 1} />
        <g transform={`translate(0 ${-off})`}>
          {[0, 160].map((o) => (
            <g key={o} transform={`translate(0 ${o})`}>
              {rows.map((r, i) => {
                const y = -30 + (acc = i === 0 ? 0 : acc) + i * 12;
                return <rect key={i} x={-14} y={y} width={r.w} height={r.h * 0.5 + 3} rx={2} fill={r.c ? '#3a68c8' : '#e8f1ff'} opacity={0.75} />;
              })}
            </g>
          ))}
        </g>
      </g>
    </g>
  );
};

/** সামনে থেকে দেখা হাত (Close-up) */
export const Hand: React.FC<{x: number; y: number; rot?: number; scale?: number; curl?: number; sleeve?: boolean}> = ({x, y, rot = 0, scale = 1, curl = 0, sleeve = true}) => {
  const lit = useLit();
  const s = lit('#c28a62'), sd = lit('#9a684a'), sh = lit('#3d4863');
  const fingers = [[-18, 40], [-6, 46], [7, 44], [19, 36]];
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${scale})`}>
      {sleeve && <rect x={-30} y={30} width={60} height={200} rx={14} fill={sh} />}
      <rect x={-22} y={-16} width={46} height={56} rx={16} fill={s} />
      {fingers.map(([fx, fl], i) => (
        <rect key={i} x={fx - 6} y={-16 - fl * (1 - curl * 0.75)} width={12} height={fl * (1 - curl * 0.75) + 14} rx={6} fill={i % 2 ? s : sd} />
      ))}
      <rect x={-40} y={-4} width={12} height={34} rx={6} fill={sd} transform="rotate(-30 -34 -4)" />
    </g>
  );
};

export const Pen: React.FC<{x: number; y: number; rot?: number; len?: number; color?: string}> = ({x, y, rot = 0, len = 70, color = '#a83232'}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot})`}>
    <rect x={-3} y={0} width={6} height={len} rx={3} fill={color} />
    <path d="M-3 0 L0 -12 L3 0 Z" fill="#222" />
  </g>
);

/** চায়ের কাপ (পাশ থেকে) + ধোঁয়া */
export const Cup: React.FC<{x: number; y: number; steam?: number; fill?: number; scale?: number}> = ({x, y, steam = 1, fill = 1, scale = 1}) => {
  const f = useCurrentFrame();
  const lit = useLit();
  return (
    <g transform={`translate(${x} ${y}) scale(${scale})`}>
      <ellipse cx={0} cy={0} rx={34} ry={4} fill={lit('#c9c2b0')} />
      <path d="M-24 -44 L24 -44 L19 -4 Q0 2 -19 -4 Z" fill={lit('#d8d2c2')} />
      <path d="M24 -36 q16 2 12 16 q-3 8 -14 8" fill="none" stroke={lit('#d8d2c2')} strokeWidth={5} />
      <ellipse cx={0} cy={-44} rx={24} ry={4} fill={lit('#8a5a34')} opacity={fill > 0 ? 1 : 0} />
      {[0, 1, 2].map((i) => {
        const ph = ((f * 0.7 + i * 30) % 90) / 90;
        return (
          <path key={i} d={`M${-8 + i * 8} ${-48 - ph * 60} q10 -12 0 -24 q-10 -12 0 -24`} stroke="#e9e3d6" strokeWidth={3} fill="none" strokeLinecap="round" opacity={steam * 0.5 * Math.sin(ph * Math.PI)} />
        );
      })}
    </g>
  );
};

/** মোমবাতি + শিখা + উষ্ণ আলো */
export const Candle: React.FC<{x: number; y: number; lit?: number}> = ({x, y, lit = 1}) => {
  const f = useCurrentFrame();
  const fl = 1 + 0.12 * Math.sin(f * 0.9) + 0.08 * Math.sin(f * 2.3 + 1);
  const sway = 2.2 * Math.sin(f * 0.37);
  return (
    <g transform={`translate(${x} ${y})`}>
      {lit > 0 && <circle cx={0} cy={-86} r={620} fill="url(#candleGlow)" opacity={lit * (0.8 + 0.2 * fl)} />}
      <rect x={-13} y={-70} width={26} height={70} rx={3} fill="#e8dcc0" />
      <rect x={-13} y={-70} width={9} height={70} fill="#b9a982" opacity={0.4} />
      <ellipse cx={0} cy={-70} rx={13} ry={3} fill="#f3ead2" />
      <line x1={0} y1={-70} x2={0} y2={-77} stroke="#222" strokeWidth={1.6} />
      {lit > 0 && (
        <g transform={`translate(${sway * 0.5} -78) scale(${fl * lit} ${fl * lit})`}>
          <path d="M0 -26 C9 -12 8 0 0 3 C-8 0 -9 -12 0 -26Z" fill="#ffb347" />
          <path d="M0 -14 C4 -7 4 -1 0 2 C-4 -1 -4 -7 0 -14Z" fill="#fff2c2" />
        </g>
      )}
    </g>
  );
};

/** খাবারের প্লেট */
export const Plate: React.FC<{x: number; y: number}> = ({x, y}) => {
  const lit = useLit();
  return (
    <g transform={`translate(${x} ${y})`}>
      <ellipse cx={0} cy={-2} rx={52} ry={6} fill={lit('#d9d4c6')} />
      <path d="M-30 -4 Q-10 -26 14 -14 Q30 -8 34 -4 Z" fill={lit('#e8e2d0')} />
      <path d="M16 -4 Q26 -16 36 -4 Z" fill={lit('#a85a32')} />
    </g>
  );
};

/** কম্বল (শোয়া অবস্থায় ওপরে টানা) */
export const Blanket: React.FC<{pull?: number}> = ({pull = 1}) => {
  const lit = useLit();
  const x0 = 640 - 300 * pull - 20;
  return (
    <g opacity={Math.min(1, pull * 3)}>
      <path d={`M${x0} 700 C${x0 + 20} 662 ${x0 + 120} 650 ${x0 + 220} 662 C${x0 + 300} 668 ${x0 + 340} 690 ${660} 705 L660 740 L${x0 + 10} 740 Z`} fill={lit('#2f4272')} />
      <path d={`M${x0 + 60} 676 q60 -8 120 6`} stroke={lit('#1f2d52')} strokeWidth={3} fill="none" opacity={0.7} />
      <path d={`M${x0 + 150} 690 q80 -10 170 8`} stroke={lit('#1f2d52')} strokeWidth={3} fill="none" opacity={0.7} />
    </g>
  );
};

/** খাতা (পাশ থেকে দেখা, ডেস্কে রাখা) */
export const NotebookSide: React.FC<{x: number; y: number; w?: number}> = ({x, y, w = 70}) => {
  const lit = useLit();
  return (
    <g transform={`translate(${x} ${y})`}>
      <rect x={-w / 2} y={-14} width={w} height={14} rx={2} fill={lit('#6b3b3b')} />
      <rect x={-w / 2 + 3} y={-11} width={w - 6} height={6} fill={lit('#e6dfc9')} />
    </g>
  );
};

export const Gradients: React.FC = () => (
  <defs>
    <radialGradient id="phoneGlow"><stop offset="0%" stopColor="#8fb8ff" stopOpacity="0.7" /><stop offset="100%" stopColor="#8fb8ff" stopOpacity="0" /></radialGradient>
    <radialGradient id="candleGlow"><stop offset="0%" stopColor="#ffb25a" stopOpacity="0.6" /><stop offset="45%" stopColor="#ff8a3a" stopOpacity="0.2" /><stop offset="100%" stopColor="#ff8a3a" stopOpacity="0" /></radialGradient>
    <radialGradient id="lampGlow"><stop offset="0%" stopColor="#ffc47a" stopOpacity="0.75" /><stop offset="50%" stopColor="#ffa94d" stopOpacity="0.22" /><stop offset="100%" stopColor="#ffa94d" stopOpacity="0" /></radialGradient>
  </defs>
);
export {clamp};

/** অ্যালার্ম ঘড়ি (ডেস্কে). ring: বাজছে কি না */
export const AlarmClock: React.FC<{x: number; y: number; ring?: boolean}> = ({x, y, ring = false}) => {
  const f = useCurrentFrame();
  const lit = useLit();
  const sh = ring ? Math.sin(f * 2.2) * 2.2 : 0;
  return (
    <g transform={`translate(${x + sh} ${y - 26})`}>
      <circle cx={-14} cy={-24} r={9} fill={lit('#8f98a8')} transform={`rotate(${ring ? Math.sin(f * 2.2) * 12 : 0})`} />
      <circle cx={14} cy={-24} r={9} fill={lit('#8f98a8')} />
      <circle r={26} fill={lit('#a8b0c0')} />
      <circle r={20} fill={lit('#e8e4d6')} />
      <line x1={0} y1={0} x2={0} y2={-12} stroke="#222" strokeWidth={2.4} strokeLinecap="round" />
      <line x1={0} y1={0} x2={9} y2={4} stroke="#222" strokeWidth={2} strokeLinecap="round" />
      <rect x={-18} y={26} width={8} height={5} fill={lit('#6b7384')} /><rect x={10} y={26} width={8} height={5} fill={lit('#6b7384')} />
    </g>
  );
};

/** খোলা বই (ডেস্কে, পাশ থেকে) */
export const OpenBook: React.FC<{x: number; y: number}> = ({x, y}) => {
  const lit = useLit();
  return (
    <g transform={`translate(${x} ${y})`}>
      <path d="M-52 0 L-52 -6 Q-26 -14 0 -6 Q26 -14 52 -6 L52 0 Z" fill={lit('#e8e2cf')} stroke={lit('#8a8470')} strokeWidth={1.4} />
      <path d="M-52 0 L52 0 L50 4 L-50 4 Z" fill={lit('#4a5b7a')} />
      <line x1={0} y1={-6} x2={0} y2={0} stroke={lit('#8a8470')} strokeWidth={1.4} />
    </g>
  );
};

/** হাতে ধরা মার্কার (Rig overlay-র জন্য) */
export const Marker: React.FC<{x: number; y: number; rot?: number}> = ({x, y, rot = 30}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot})`}>
    <rect x={-3.5} y={-4} width={7} height={46} rx={3.5} fill="#2a2d36" />
    <rect x={-3.5} y={-4} width={7} height={12} rx={3} fill="#c0392b" />
    <path d="M-2.5 -4 L0 -12 L2.5 -4Z" fill="#c0392b" />
  </g>
);
