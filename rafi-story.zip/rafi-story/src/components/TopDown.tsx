import React from 'react';
import {useCurrentFrame} from 'remotion';
import {useMood} from './Stage';
import {mix} from '../utils';

/** বিছানায় এপাশ-ওপাশ করা রাফি — ওপর থেকে দেখা (Top shot) */
export const TopDownBed: React.FC<{toss: number}> = ({toss}) => {
  const f = useCurrentFrame();
  const m = useMood();
  const lit = (c: string) => mix(mix(c, m.ambient, m.ambientA * 0.6), '#000', 1 - m.charLight * 0.85);
  const roll = toss; // -1..1
  const bx = 960, by = 540;
  return (
    <g>
      <defs><linearGradient id="tdFloor" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor={lit('#1a2236')} /><stop offset="1" stopColor={lit('#0d1220')} /></linearGradient></defs>
      <rect x={-800} y={-600} width={3600} height={2400} fill="url(#tdFloor)" />
      {Array.from({length: 14}, (_, i) => <line key={i} x1={-800} y1={-300 + i * 140} x2={2800} y2={-300 + i * 140} stroke="#000" strokeOpacity={0.18} strokeWidth={2} />)}
      <rect x={bx - 380} y={by - 250} width={760} height={500} rx={16} fill={lit('#26385e')} stroke={lit('#4b5f8c')} strokeWidth={3} />
      <rect x={bx - 360} y={by - 232} width={724} height={464} rx={10} fill={lit('#33466f')} />
      <rect x={bx - 340} y={by - 90} width={140} height={180} rx={26} fill={lit('#b9c2dc')} />
      {/* শরীর */}
      <g transform={`rotate(${roll * 7} ${bx - 140} ${by})`}>
        <rect x={bx - 190} y={by - 70 - roll * 8} width={420} height={140} rx={60} fill={lit('#2a3a66')} />
        <path d={`M${bx - 140} ${by - 8} Q${bx + 80} ${by - 30 + roll * 14} ${bx + 330} ${by + 6 + roll * 26} L${bx + 330} ${by + 70} Q${bx + 80} ${by + 90} ${bx - 140} ${by + 50} Z`} fill={lit('#233152')} opacity={0.8} />
        <ellipse cx={bx - 230} cy={by - 4} rx={62} ry={66} fill={lit('#c28a62')} />
        <path d={`M${bx - 288} ${by - 14} C${bx - 292} ${by - 66} ${bx - 220} ${by - 72} ${bx - 190} ${by - 40} C${bx - 176} ${by - 8} ${bx - 190} ${by + 40} ${bx - 224} ${by + 56} C${bx - 262} ${by + 62} ${bx - 290} ${by + 30} ${bx - 288} ${by - 14} Z`} fill={lit('#14161c')} />
        <ellipse cx={bx - 176} cy={by + 6} rx={9} ry={14} fill={lit('#9a684a')} />
        <rect x={bx - 130} y={by + 26} width={150} height={32} rx={16} fill={lit('#c28a62')} transform={`rotate(${-10 + roll * 8} ${bx - 130} ${by + 40})`} />
      </g>
    </g>
  );
};

/** খাতার প্রথম পাতা — Macro (উপর থেকে) */
export const NotebookMacro: React.FC<{open: number; candle: number}> = ({open, candle}) => {
  const f = useCurrentFrame();
  const th = open * 180;
  const cos = Math.cos((th * Math.PI) / 180);
  const fl = 1 + 0.06 * Math.sin(f * 0.9) + 0.04 * Math.sin(f * 2.3);
  const spine = 960;
  return (
    <g>
      <defs>
        <radialGradient id="nmGlow" cx="62%" cy="30%"><stop offset="0" stopColor="#ffbe70" stopOpacity={0.55 * fl * candle} /><stop offset="0.6" stopColor="#ff8a3a" stopOpacity={0.12 * candle} /><stop offset="1" stopColor="#000" stopOpacity="0" /></radialGradient>
      </defs>
      <rect x={-600} y={-400} width={3200} height={2000} fill="#120c0a" />
      {Array.from({length: 12}, (_, i) => <line key={i} x1={-600} y1={-300 + i * 150} x2={2600} y2={-280 + i * 150} stroke="#2a1c14" strokeWidth={3} opacity={0.6} />)}
      <rect x={spine - 20} y={160} width={780} height={780} rx={10} fill="#e6dcc0" />
      {Array.from({length: 17}, (_, i) => <line key={i} x1={spine + 50} y1={250 + i * 38} x2={spine + 730} y2={250 + i * 38} stroke="#9fb2c8" strokeWidth={2} opacity={0.7} />)}
      <line x1={spine + 90} y1={160} x2={spine + 90} y2={940} stroke="#c97a7a" strokeWidth={2} opacity={0.7} />
      {/* এক লাইনের হাতের লেখা (পড়া যায় না, শুধু আকার) */}
      <path d={`M${spine + 120} 306 q20 -26 40 0 t40 0 q8 -28 26 -2 t36 0 q14 -26 30 0 t34 0 q12 -22 28 0 t30 0 q10 -20 24 0 t26 0`} stroke="#243a78" strokeWidth={5} fill="none" strokeLinecap="round" />
      <path d={`M${spine + 120} 322 q30 8 70 -2`} stroke="#243a78" strokeWidth={4} fill="none" strokeLinecap="round" opacity={0.8} />
      <rect x={spine - 780 - 20} y={160} width={760} height={780} rx={10} fill="#d9cfb3" opacity={open > 0.5 ? 1 : 0} />
      {/* কভার — মেরুদণ্ড ধরে ঘুরছে */}
      <g transform={`translate(${spine} 0) scale(${cos} 1)`}>
        <rect x={0} y={150} width={800} height={800} rx={12} fill={cos >= 0 ? '#6b3b3b' : '#4a2a2a'} />
        {cos >= 0 && <rect x={60} y={230} width={400} height={200} rx={8} fill="#e6dcc0" opacity={0.9} />}
        {cos >= 0 && <rect x={90} y={260} width={240} height={14} rx={5} fill="#6b3b3b" opacity={0.5} />}
      </g>
      <rect x={spine - 10} y={150} width={20} height={800} fill="#2a1414" opacity={0.6} />
      <rect x={-600} y={-400} width={3200} height={2000} fill="url(#nmGlow)" />
    </g>
  );
};
