import React from 'react';
import {Audio, Sequence, staticFile} from 'remotion';
import {CUES, durationOf} from '../audio/sfx';
import {FPS} from '../theme';

/** শুধু Sound Effect — ভিডিওতে Voiceover বা Music নেই */
export const SfxTrack: React.FC = () => (
  <>
    {CUES.map((c, i) => {
      const frames = Math.max(2, Math.round(durationOf(c) * FPS));
      const isBed = c.to !== undefined;
      return (
        <Sequence key={i} from={Math.max(0, Math.round(c.t * FPS))} durationInFrames={frames}>
          <Audio
            src={staticFile(`sfx/${c.s}.wav`)}
            loop={isBed}
            volume={(f) => c.vol * Math.max(0, Math.min(1, isBed ? Math.min(f / 24, (frames - f) / 24) : 1))}
          />
        </Sequence>
      );
    })}
  </>
);
