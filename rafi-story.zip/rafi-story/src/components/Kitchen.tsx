import React from 'react';
import {useCurrentFrame} from 'remotion';
import {useMood} from './Stage';
import {FLOOR} from '../theme';
import {mix} from '../utils';

export const COUNTER_TOP = 548;

/** ছোট রান্নাঘর — কাউন্টার, চুলা, কেটলি, তাক, ফ্রিজ. kettleTilt: ডিগ্রি, cupFill 0..1 */
export const Kitchen: React.FC<{kettleTilt?: number; cupFill?: number; cupGone?: boolean; kettleLift?: number}> = ({kettleTilt = 0, cupFill = 0, cupGone = false, kettleLift = 0}) => {
  const f = useCurrentFrame();
  const m = useMood();
  const ink = m.ink, hi = m.furnHi, furn = m.furn;
  const tile = mix(m.wallBot, '#ffffff', 0.12);
  const kx = 735, ky = COUNTER_TOP - 6 - kettleLift;
  return (
    <g>
      <defs>
        <linearGradient id="kWall" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={m.wallTop} /><stop offset="1" stopColor={m.wallBot} /></linearGradient>
        <radialGradient id="kGlow"><stop offset="0" stopColor="#ffb25a" stopOpacity="0.7" /><stop offset="1" stopColor="#ffb25a" stopOpacity="0" /></radialGradient>
      </defs>
      <rect x={-1200} y={-900} width={4400} height={900 + FLOOR} fill="url(#kWall)" />
      <rect x={-1200} y={FLOOR} width={4400} height={700} fill={mix(m.floor, '#000', 0.2)} />
      <line x1={-1200} y1={FLOOR} x2={3200} y2={FLOOR} stroke={ink} strokeWidth={2} opacity={0.6} />
      {/* টাইলস */}
      <g opacity={0.55}>
        {Array.from({length: 18}, (_, i) => <line key={'v' + i} x1={300 + i * 60} y1={380} x2={300 + i * 60} y2={COUNTER_TOP} stroke={ink} strokeWidth={1.2} />)}
        {Array.from({length: 4}, (_, i) => <line key={'h' + i} x1={300} y1={380 + i * 56} x2={1380} y2={380 + i * 56} stroke={ink} strokeWidth={1.2} />)}
        <rect x={300} y={380} width={1080} height={COUNTER_TOP - 380} fill={tile} opacity={0.25} />
      </g>
      {/* ঝোলানো তাক */}
      <rect x={380} y={260} width={460} height={12} fill={hi} stroke={ink} strokeWidth={1.6} />
      {[0, 1, 2, 3].map((i) => <rect key={i} x={400 + i * 70} y={206} width={44} height={54} rx={8} fill={mix(furn, ['#7a4a3a', '#4a5b44', '#6b5a3a', '#3c4f6b'][i], 0.5)} stroke={ink} strokeWidth={1.4} />)}
      {[0, 1, 2].map((i) => <line key={i} x1={900 + i * 50} y1={170} x2={900 + i * 50} y2={250 + i * 14} stroke={ink} strokeWidth={4} strokeLinecap="round" />)}
      {/* জানালা */}
      <rect x={1180} y={230} width={200} height={240} fill={mix(m.skyTop, m.skyBot, 0.5)} stroke={hi} strokeWidth={8} />
      <line x1={1280} y1={230} x2={1280} y2={470} stroke={hi} strokeWidth={4} />
      {/* কাউন্টার */}
      <ellipse cx={740} cy={FLOOR + 6} rx={430} ry={9} fill="#000" opacity={0.35} />
      <rect x={300} y={COUNTER_TOP} width={900} height={22} rx={3} fill={hi} stroke={ink} strokeWidth={2} />
      <rect x={306} y={COUNTER_TOP + 22} width={888} height={FLOOR - COUNTER_TOP - 22} fill={furn} stroke={ink} strokeWidth={2} />
      {[0, 1, 2].map((i) => <g key={i}><rect x={322 + i * 292} y={COUNTER_TOP + 40} width={268} height={190} rx={3} fill="none" stroke={ink} strokeWidth={1.6} /><rect x={440 + i * 292} y={COUNTER_TOP + 52} width={30} height={5} rx={2} fill={ink} /></g>)}
      {/* চুলা */}
      <rect x={660} y={COUNTER_TOP - 10} width={150} height={12} rx={3} fill={mix(furn, '#000', 0.4)} stroke={ink} strokeWidth={1.6} />
      <g fill="#6aa8ff" opacity={0.85}>{[0, 1, 2, 3, 4].map((i) => <path key={i} d={`M${690 + i * 22} ${COUNTER_TOP - 10} q4 -${10 + 3 * Math.sin(f * 0.8 + i)} 8 0Z`} />)}</g>
      {/* কেটলি */}
      <g transform={`translate(${kx} ${ky}) rotate(${kettleTilt} 30 -10)`}>
        <path d="M-40 0 L40 0 L34 -62 Q0 -76 -34 -62 Z" fill={mix('#aeb6c6', m.ambient, m.ambientA * 0.6)} stroke={ink} strokeWidth={2} />
        <path d="M40 -12 L72 -40 L66 -46 L34 -34 Z" fill={mix('#aeb6c6', m.ambient, m.ambientA * 0.6)} stroke={ink} strokeWidth={2} />
        <path d="M-38 -48 q-30 0 -30 24 q0 22 30 20" fill="none" stroke={ink} strokeWidth={6} />
        <rect x={-8} y={-80} width={16} height={8} rx={3} fill={ink} />
      </g>
      {/* ধোঁয়া */}
      {[0, 1, 2].map((i) => {
        const ph = ((f * 0.8 + i * 26) % 80) / 80;
        return <path key={i} d={`M${kx + 70 + i * 6} ${ky - 56 - ph * 90} q10 -14 0 -28`} stroke="#eee" strokeWidth={3} fill="none" opacity={0.4 * Math.sin(ph * Math.PI)} strokeLinecap="round" />;
      })}
      {/* জল ঢালার কাপ */}
      {!cupGone && (
        <g transform={`translate(818 ${COUNTER_TOP})`}>
          <path d="M-22 -40 L22 -40 L17 -2 L-17 -2 Z" fill={mix('#d8d2c2', m.ambient, m.ambientA * 0.6)} stroke={ink} strokeWidth={1.4} />
          <path d={`M-20 ${-2 - 36 * cupFill} L20 ${-2 - 36 * cupFill} L17 -2 L-17 -2 Z`} fill="#8a5a34" opacity={cupFill > 0 ? 0.95 : 0} />
          <path d="M22 -32 q14 2 10 14 q-3 7 -12 6" fill="none" stroke={mix('#d8d2c2', m.ambient, 0.2)} strokeWidth={4} />
        </g>
      )}
      {/* ফ্রিজ */}
      <ellipse cx={1620} cy={FLOOR + 6} rx={150} ry={8} fill="#000" opacity={0.35} />
      <rect x={1500} y={300} width={240} height={500} rx={10} fill={mix(furn, '#aab4c8', 0.25)} stroke={ink} strokeWidth={2.4} />
      <line x1={1500} y1={500} x2={1740} y2={500} stroke={ink} strokeWidth={2} /><rect x={1712} y={340} width={8} height={90} rx={4} fill={ink} /><rect x={1712} y={530} width={8} height={90} rx={4} fill={ink} />
      {/* উষ্ণ আলো */}
      <ellipse cx={760} cy={430} rx={600} ry={420} fill="url(#kGlow)" opacity={0.35} />
    </g>
  );
};
