import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Parallax, useMood} from './Stage';
import {Calendar, CAL_POS} from './Calendar';
import {Gradients} from './Props';
import {BED_TOP, DESK_TOP, FLOOR, TABLE_TOP} from '../theme';
import {lum, mix, seeded} from '../utils';

export interface RoomProps {
  fan?: number;            // ফ্যানের কোণ (ডিগ্রি)
  dust?: number;           // 0..1 বইয়ের ধুলো
  lamp?: number;           // বেডসাইড ল্যাম্পের আলো 0..1
  deskLamp?: number;
  clock?: number;          // দেয়াল ঘড়ি (মিনিট, 12:00 থেকে)
  cal?: {today?: number; crosses?: number; crossStart?: number; pulse?: number};
  kids?: boolean;
  curtain?: number;        // পর্দার দোল
  beam?: number;           // জানালার আলোর গুণক
  hideBed?: boolean;
  motes?: boolean;
}

const BIG = {x: -1200, w: 4400};

const WindowView: React.FC<{kids: boolean}> = ({kids}) => {
  const m = useMood();
  const f = useCurrentFrame();
  const L = lum(m.skyTop) * 0.5 + lum(m.skyBot) * 0.5;
  const dark = L < 0.3;
  const ground = mix('#000000', '#4d7142', 0.22 + 0.78 * L);
  const bld = mix(m.skyBot, '#000000', 0.62);
  const rnd = seeded(5);
  const blds = Array.from({length: 9}, (_, i) => ({x: 860 + i * 40 + rnd() * 10, w: 30 + rnd() * 24, h: 50 + rnd() * 80}));
  const trees = [905, 960, 1138, 1186];
  const kidList = [0, 1, 2].map((k) => ({
    x: 980 + ((f * (0.5 + k * 0.25) + k * 60) % 220), y: 506 + k * 10, s: 0.8 + k * 0.12,
  }));
  return (
    <g>
      <defs>
        <linearGradient id="skyg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={m.skyTop} /><stop offset="1" stopColor={m.skyBot} /></linearGradient>
      </defs>
      <rect x={860} y={150} width={360} height={430} fill="url(#skyg)" />
      {dark ? (
        <g><circle cx={1120} cy={250} r={46} fill="#8fa8d8" opacity={0.18} /><circle cx={1120} cy={250} r={20} fill="#dbe6ff" opacity={0.85} /></g>
      ) : (
        <circle cx={1100} cy={260} r={34} fill="#fff7dc" opacity={0.7} />
      )}
      {blds.map((b, i) => (
        <g key={i}>
          <rect x={b.x} y={470 - b.h} width={b.w} height={b.h + 30} fill={bld} />
          {dark && i % 2 === 0 && <rect x={b.x + 8} y={470 - b.h + 12} width={6} height={8} fill="#ffcf7a" opacity={0.8} />}
        </g>
      ))}
      <rect x={860} y={478} width={360} height={110} fill={ground} />
      <rect x={860} y={478} width={360} height={5} fill={mix(ground, '#000', 0.3)} />
      {trees.map((tx, i) => (
        <g key={i}><rect x={tx - 2} y={450} width={4} height={34} fill={mix(ground, '#000', 0.6)} /><circle cx={tx} cy={444} r={20 + (i % 2) * 6} fill={mix(ground, '#000', 0.45)} /></g>
      ))}
      {kids && kidList.map((k, i) => (
        <g key={i} transform={`translate(${k.x} ${k.y}) scale(${k.s})`} fill={mix(ground, '#000', 0.7)}>
          <circle cx={0} cy={-26} r={5.5} /><rect x={-5} y={-20} width={10} height={20} rx={4} />
          <rect x={-5} y={-2} width={4} height={13} rx={2} transform={`rotate(${Math.sin(f / 4 + i) * 22} -3 -2)`} />
          <rect x={1} y={-2} width={4} height={13} rx={2} transform={`rotate(${-Math.sin(f / 4 + i) * 22} 3 -2)`} />
        </g>
      ))}
    </g>
  );
};

export const Room: React.FC<RoomProps> = ({fan = 0, dust = 0.8, lamp = 0, deskLamp = 0, clock = 0, cal = {}, kids = false, curtain = 0.25, beam = 1, hideBed = false, motes = true}) => {
  const m = useMood();
  const f = useCurrentFrame();
  const ink = m.ink, furn = m.furn, hi = m.furnHi;
  const stroke = {stroke: ink, strokeWidth: 2.2, strokeLinejoin: 'round' as const};
  const sway = Math.sin(f / 55) * 7 * curtain;
  const rnd = seeded(21);
  const mote = Array.from({length: 40}, () => ({x: 640 + rnd() * 1000, y: 120 + rnd() * 720, s: 0.5 + rnd() * 1.6, p: rnd() * 6.28}));
  const beamOp = m.beamA * beam;

  const book = (x: number, y: number, w: number, h: number, c: string, i: number) => (
    <g key={i}><rect x={x} y={y - h} width={w} height={h} rx={2} fill={mix(c, m.ambient, m.ambientA * 0.5)} stroke={ink} strokeWidth={1.4} /><rect x={x + 4} y={y - h + 4} width={w - 8} height={3} fill="#e6dfc9" opacity={0.35} /></g>
  );

  return (
    <g>
      <Gradients />
      <defs>
        <linearGradient id="wallg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={m.wallTop} /><stop offset="1" stopColor={m.wallBot} /></linearGradient>
        <linearGradient id="beamg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={m.beam} stopOpacity={beamOp} /><stop offset="1" stopColor={m.beam} stopOpacity={beamOp * 0.25} /></linearGradient>
        <linearGradient id="floorg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={mix(m.floor, '#000', 0)} /><stop offset="1" stopColor={mix(m.floor, '#000', 0.5)} /></linearGradient>
      </defs>
      {/* দেয়াল ও মেঝে */}
      <rect x={BIG.x} y={-900} width={BIG.w} height={900 + FLOOR} fill="url(#wallg)" />
      <rect x={BIG.x} y={FLOOR} width={BIG.w} height={700} fill="url(#floorg)" />
      <rect x={BIG.x} y={FLOOR - 16} width={BIG.w} height={16} fill={mix(m.wallBot, '#000', 0.25)} />
      <line x1={BIG.x} y1={FLOOR} x2={BIG.x + BIG.w} y2={FLOOR} stroke={ink} strokeWidth={2} opacity={0.6} />
      {[0, 1, 2, 3].map((i) => <line key={i} x1={BIG.x} y1={FLOOR + 40 + i * 60} x2={BIG.x + BIG.w} y2={FLOOR + 40 + i * 60} stroke={ink} strokeWidth={1} opacity={0.18} />)}
      {/* দেয়ালের দাগ */}
      <rect x={1010} y={-100} width={40} height={900} fill="#000" opacity={0.04} />
      <rect x={300} y={-100} width={90} height={900} fill="#fff" opacity={0.012} />

      {/* ছবির ফ্রেম */}
      <g {...stroke}><rect x={290} y={230} width={110} height={90} fill={mix(m.wallBot, '#000', 0.3)} /><path d="M298 312 L330 270 L352 296 L372 276 L392 312 Z" fill={mix(m.furnHi, '#000', 0.2)} stroke="none" /></g>

      {/* জানালা */}
      <Parallax factor={0.93}><WindowView kids={kids} /></Parallax>
      <g fill="none" stroke={hi} strokeWidth={9}><rect x={878} y={168} width={324} height={394} /></g>
      <g stroke={hi} strokeWidth={5}><line x1={1040} y1={170} x2={1040} y2={560} /><line x1={880} y1={365} x2={1200} y2={365} /></g>
      <rect x={862} y={560} width={356} height={14} fill={hi} stroke={ink} strokeWidth={1.5} />
      {/* পর্দা */}
      <g fill={mix(furn, '#5a2f3c', 0.35)} stroke={ink} strokeWidth={1.5}>
        <path d={`M846 150 L930 150 L${916 + sway} 600 L${838 + sway * 0.4} 600 Z`} />
        <path d={`M1152 150 L1236 150 L${1244 - sway * 0.4} 600 L${1166 - sway} 600 Z`} />
      </g>
      <line x1={820} y1={146} x2={1262} y2={146} stroke={hi} strokeWidth={6} strokeLinecap="round" />

      {/* জানালার আলোর রেখা */}
      <polygon points={`882,566 1198,566 ${1090 - 260},${FLOOR} ${760 - 260},${FLOOR}`} fill="url(#beamg)" />
      <polygon points={`882,170 1198,170 ${1330},${FLOOR} ${1010},${FLOOR}`} fill={m.beam} opacity={beamOp * 0.06} />

      {/* দেয়াল ঘড়ি */}
      <g transform="translate(760 240)">
        <circle r={52} fill={mix(m.furnHi, '#fff', 0.18)} stroke={ink} strokeWidth={4} />
        <circle r={44} fill={mix(m.wallBot, '#fff', 0.2)} />
        {Array.from({length: 12}, (_, i) => <line key={i} x1={0} y1={-38} x2={0} y2={i % 3 === 0 ? -31 : -34} stroke={ink} strokeWidth={i % 3 === 0 ? 3 : 1.5} transform={`rotate(${i * 30})`} />)}
        <line x1={0} y1={4} x2={0} y2={-26} stroke={ink} strokeWidth={4} strokeLinecap="round" transform={`rotate(${clock / 2})`} />
        <line x1={0} y1={6} x2={0} y2={-36} stroke={ink} strokeWidth={2.4} strokeLinecap="round" transform={`rotate(${clock * 6})`} />
        <circle r={3.5} fill={ink} />
      </g>

      {/* ক্যালেন্ডার */}
      <Calendar x={CAL_POS.x} y={CAL_POS.y} {...cal} />

      {/* দরজা */}
      <g>
        <rect x={1790} y={330} width={140} height={470} fill="#03050a" stroke={hi} strokeWidth={8} />
        <polygon points="1798,336 1850,346 1850,800 1798,800" fill={mix(furn, '#000', 0.4)} stroke={ink} strokeWidth={2} />
        <circle cx={1840} cy={580} r={4} fill={hi} />
      </g>

      {/* বিছানা */}
      {!hideBed && (
        <g>
          <ellipse cx={350} cy={FLOOR + 8} rx={330} ry={12} fill="#000" opacity={0.35} />
          <rect x={64} y={560} width={26} height={216} rx={4} fill={furn} {...stroke} />
          <rect x={62} y={BED_TOP + 36} width={590} height={30} rx={4} fill={furn} {...stroke} />
          <rect x={72} y={FLOOR - 36} width={14} height={36} fill={furn} {...stroke} />
          <rect x={626} y={FLOOR - 36} width={14} height={36} fill={furn} {...stroke} />
          <rect x={86} y={BED_TOP} width={560} height={38} rx={10} fill={mix(furn, '#9aa8c8', 0.22)} {...stroke} />
          <path d="M130 704 Q130 676 200 676 Q276 676 276 704 Z" fill={mix(furn, '#d6dcf0', 0.42)} {...stroke} />
        </g>
      )}

      {/* বেডসাইড টেবিল ও ল্যাম্প */}
      <g>
        <ellipse cx={728} cy={FLOOR + 6} rx={78} ry={8} fill="#000" opacity={0.35} />
        <rect x={668} y={TABLE_TOP} width={120} height={14} rx={3} fill={hi} {...stroke} />
        <rect x={676} y={TABLE_TOP + 14} width={104} height={136} fill={furn} {...stroke} />
        <rect x={688} y={TABLE_TOP + 30} width={80} height={44} rx={3} fill="none" stroke={ink} strokeWidth={1.6} />
        <circle cx={728} cy={TABLE_TOP + 52} r={4} fill={hi} />
        <rect x={722} y={TABLE_TOP - 46} width={12} height={46} fill={ink} />
        <path d={`M696 ${TABLE_TOP - 46} L760 ${TABLE_TOP - 46} L748 ${TABLE_TOP - 96} L708 ${TABLE_TOP - 96} Z`} fill={lamp > 0 ? mix('#f2c58a', m.furn, 0.3) : mix(furn, '#fff', 0.12)} stroke={ink} strokeWidth={2} />
        {lamp > 0 && (
          <g>
            <ellipse cx={728} cy={TABLE_TOP - 70} rx={360} ry={300} fill="url(#lampGlow)" opacity={lamp} />
            <polygon points={`700,${TABLE_TOP - 46} 756,${TABLE_TOP - 46} 900,${FLOOR} 560,${FLOOR}`} fill="#ffb86b" opacity={0.1 * lamp} />
          </g>
        )}
      </g>

      {/* ডেস্ক */}
      <g>
        <ellipse cx={1540} cy={FLOOR + 6} rx={290} ry={9} fill="#000" opacity={0.35} />
        <rect x={1280} y={DESK_TOP} width={520} height={20} rx={3} fill={hi} {...stroke} />
        <rect x={1290} y={DESK_TOP + 20} width={14} height={FLOOR - DESK_TOP - 20} fill={furn} {...stroke} />
        <rect x={1586} y={DESK_TOP + 20} width={204} height={170} fill={furn} {...stroke} />
        <rect x={1598} y={DESK_TOP + 34} width={180} height={64} rx={3} fill="none" stroke={ink} strokeWidth={1.6} />
        <rect x={1598} y={DESK_TOP + 108} width={180} height={64} rx={3} fill="none" stroke={ink} strokeWidth={1.6} />
        <rect x={1676} y={DESK_TOP + 62} width={24} height={5} rx={2} fill={ink} /><rect x={1676} y={DESK_TOP + 136} width={24} height={5} rx={2} fill={ink} />
        <rect x={1780} y={DESK_TOP + 190} width={12} height={FLOOR - DESK_TOP - 190} fill={furn} {...stroke} />
        {/* বইয়ের স্তূপ */}
        {[
          [1642, 118, 24, '#5b3b3b'], [1650, 106, 20, '#3c4f6b'], [1640, 124, 18, '#4a5b44'], [1648, 96, 22, '#6b5a3a'], [1644, 112, 16, '#3d3d55'],
        ].reduce<{els: React.ReactNode[]; y: number}>((a, [x, w, h, c], i) => {
          a.els.push(book(x as number, a.y, w as number, h as number, c as string, i));
          a.y -= h as number;
          return a;
        }, {els: [], y: DESK_TOP}).els}
        {/* ধুলো */}
        <g opacity={dust}>
          <ellipse cx={1696} cy={DESK_TOP - 90 - 0} rx={50} ry={4} fill="#c9c4b4" opacity={0.55} />
          <ellipse cx={1696} cy={DESK_TOP - 1} rx={110} ry={3} fill="#c9c4b4" opacity={0.28} />
          <ellipse cx={1372} cy={DESK_TOP - 1} rx={58} ry={3} fill="#c9c4b4" opacity={0.3} />
        </g>
        {/* একটি বই (বন্ধ) */}
        {book(1330, DESK_TOP, 84, 18, '#7a4a3a', 20)}
        {book(1334, DESK_TOP - 18, 76, 14, '#34506f', 21)}
        <g opacity={dust}><ellipse cx={1372} cy={DESK_TOP - 33} rx={34} ry={3} fill="#c9c4b4" opacity={0.6} /></g>
        {/* ডেস্ক ল্যাম্প */}
        <g transform={`translate(1560 ${DESK_TOP})`}>
          <rect x={-14} y={-6} width={28} height={6} rx={2} fill={ink} />
          <line x1={0} y1={-6} x2={-6} y2={-70} stroke={ink} strokeWidth={5} /><line x1={-6} y1={-70} x2={26} y2={-96} stroke={ink} strokeWidth={5} />
          <path d="M14 -104 L50 -88 L40 -76 L8 -92 Z" fill={deskLamp > 0 ? '#f2c58a' : mix(furn, '#fff', 0.12)} stroke={ink} strokeWidth={2} />
          {deskLamp > 0 && <ellipse cx={40} cy={-40} rx={230} ry={170} fill="url(#lampGlow)" opacity={deskLamp} />}
        </g>
      </g>

      {/* চেয়ার */}
      <g {...stroke}>
        <rect x={1116} y={500} width={14} height={216} rx={5} fill={furn} />
        <rect x={1116} y={BED_TOP} width={150} height={14} rx={4} fill={hi} />
        <rect x={1124} y={BED_TOP + 14} width={10} height={FLOOR - BED_TOP - 14} fill={furn} />
        <rect x={1248} y={BED_TOP + 14} width={10} height={FLOOR - BED_TOP - 14} fill={furn} />
      </g>

      {/* ঘরের ছোট জিনিস */}
      <g transform="translate(560 788)"><ellipse rx={30} ry={8} fill={mix(furn, '#fff', 0.1)} /><ellipse cx={44} rx={26} ry={7} fill={mix(furn, '#fff', 0.08)} /></g>

      {/* ফ্যান (সিলিং) */}
      <g>
        <line x1={960} y1={-300} x2={960} y2={84} stroke={ink} strokeWidth={5} />
        <rect x={938} y={78} width={44} height={20} rx={8} fill={hi} stroke={ink} strokeWidth={2} />
        <g transform="translate(960 104) scale(1 0.17)">
          <ellipse rx={300} ry={300} fill={m.furn} opacity={0.25} />
          <g transform={`rotate(${fan})`}>
            {[0, 120, 240].map((a) => <rect key={a} x={26} y={-26} width={270} height={52} rx={26} fill={hi} stroke={ink} strokeWidth={5} transform={`rotate(${a})`} />)}
          </g>
        </g>
      </g>

      {/* সামনের স্তর: ধুলোর কণা (Parallax) */}
      {motes && (
        <Parallax factor={1.25}>
          {mote.map((d, i) => {
            const y = ((d.y - f * 0.25 * d.s + 2000) % 720) + 120;
            const x = d.x + Math.sin(f / 40 + d.p) * 14;
            const inBeam = x > 700 && x < 1500;
            return <circle key={i} cx={x} cy={y} r={d.s} fill={m.beam} opacity={(inBeam ? 0.5 : 0.12) * Math.min(1, beamOp * 3 + 0.1)} />;
          })}
        </Parallax>
      )}
    </g>
  );
};
