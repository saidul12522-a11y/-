import React from 'react';
import {useLit} from './Props';
import {clamp, seeded} from '../utils';

export const EXAM_IDX = 33;

/** দেয়াল ক্যালেন্ডার. today = আজকের ঘর, crosses = ক্রস দেওয়া দিনের সংখ্যা (দশমিক = আঁকার অগ্রগতি) */
export const Calendar: React.FC<{x: number; y: number; today?: number; crosses?: number; crossStart?: number; pulse?: number}> = ({x, y, today = -1, crosses = 0, crossStart = 24, pulse = 0}) => {
  const lit = useLit();
  const rnd = seeded(11);
  const cells = Array.from({length: 42}, (_, i) => ({w: 5 + rnd() * 7, i}));
  const cx = (i: number) => 14 + (i % 7) * 19 + 9.5;
  const cy = (i: number) => 64 + Math.floor(i / 7) * 19 + 9.5;
  return (
    <g transform={`translate(${x} ${y})`}>
      <rect x={3} y={5} width={160} height={226} fill="#000" opacity={0.35} />
      <rect x={0} y={0} width={160} height={226} fill={lit('#d9d0b6')} />
      <rect x={0} y={0} width={160} height={46} fill={lit('#7a2e2e')} />
      <rect x={14} y={14} width={70} height={9} rx={3} fill={lit('#e8dcc6')} opacity={0.85} />
      <rect x={14} y={29} width={40} height={5} rx={2} fill={lit('#e8dcc6')} opacity={0.5} />
      <circle cx={80} cy={-6} r={5} fill={lit('#5a5148')} />
      {cells.map((c) => (
        <rect key={c.i} x={cx(c.i) - c.w / 2} y={cy(c.i) - 2.2} width={c.w} height={4.4} rx={1.2} fill={lit('#5a5148')} opacity={0.75} />
      ))}
      {today >= 0 && (
        <rect x={cx(Math.floor(today)) - 9} y={cy(Math.floor(today)) - 9} width={18} height={18} rx={3} fill="#3a68c8" opacity={0.28} />
      )}
      {/* ক্রস */}
      {Array.from({length: Math.ceil(crosses)}, (_, k) => {
        const i = crossStart + k;
        const pr = clamp(crosses - k, 0, 1);
        const a = clamp(pr * 2, 0, 1), b = clamp(pr * 2 - 1, 0, 1);
        return (
          <g key={k} stroke={lit('#16181d')} strokeWidth={2.6} strokeLinecap="round">
            <line x1={cx(i) - 8} y1={cy(i) - 8} x2={cx(i) - 8 + 16 * a} y2={cy(i) - 8 + 16 * a} />
            {b > 0 && <line x1={cx(i) + 8} y1={cy(i) - 8} x2={cx(i) + 8 - 16 * b} y2={cy(i) - 8 + 16 * b} />}
          </g>
        );
      })}
      {/* লাল গোল দাগ (পরীক্ষার দিন) */}
      <ellipse cx={cx(EXAM_IDX)} cy={cy(EXAM_IDX)} rx={13} ry={11} fill="none" stroke="#c0392b" strokeWidth={3} transform={`rotate(-12 ${cx(EXAM_IDX)} ${cy(EXAM_IDX)})`} strokeDasharray="78 4" />
      <ellipse cx={cx(EXAM_IDX)} cy={cy(EXAM_IDX)} rx={15} ry={12} fill="none" stroke="#e24a3a" strokeWidth={2} opacity={0.5 + 0.5 * pulse} transform={`rotate(10 ${cx(EXAM_IDX)} ${cy(EXAM_IDX)})`} strokeDasharray="70 6" />
      <circle cx={cx(EXAM_IDX)} cy={cy(EXAM_IDX)} r={22 + 10 * pulse} fill="#c0392b" opacity={0.1 * pulse} />
    </g>
  );
};
export const CAL_POS = {x: 1330, y: 195};
export const calCell = (i: number): [number, number] => [CAL_POS.x + 14 + (i % 7) * 19 + 9.5, CAL_POS.y + 64 + Math.floor(i / 7) * 19 + 9.5];
