import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Stage, ck} from '../components/Stage';
import {Room} from '../components/Room';
import {Rafi} from '../components/Rafi';
import {Kitchen, COUNTER_TOP} from '../components/Kitchen';
import {Cup, Plate} from '../components/Props';
import {DESK_TOP, MOODS, lerpMood} from '../theme';
import {HIP_Y, K, LIE, SIT, STAND, STAND_TIRED, WALK_OMEGA, armTo, loc, locLie, poseAt, walk, walkSpeed, withFace} from '../poses';
import {fanAngle, kf, rad} from '../utils';
import {BED_HIP, CHAIR_HIP, LIE_HIP, READ_AT, sitAt} from './common';

/** 07 — সকালে ঘুম ভেঙে ফোনই প্রথম সঙ্গী (Close-up হাত ও ফোন) */
export const Scene07: React.FC = () => {
  const f = useCurrentFrame();
  const onBed: [number, number] = [352, 696];
  const raised = locLie(LIE_HIP, [238, 556]);
  const grab = withFace(LIE, {armN: armTo(0, locLie(LIE_HIP, onBed)), eye: 0.8});
  const up = withFace(LIE, {armN: armTo(0, raised, -1), eye: 0.75, brow: 0.5, mouth: -0.3});
  const asleep = withFace(LIE, {eye: 0});
  const pose = poseAt([K(0, asleep), K(40, asleep), K(60, withFace(LIE, {eye: 0.7})), K(95, grab), K(125, grab), K(185, up), K(282, up)], f);
  const holding = f >= 125;
  const glow = kf(f, [[0, 0], [100, 0.1], [140, 1]]);
  return (
    <Stage mood={MOODS.morning} cam={[ck(0, 430, 600, 1.5), ck(150, 300, 610, 2.3), ck(282, 360, 600, 1.55)]}>
      <Room fan={fanAngle(f)} dust={0.9} clock={kf(f, [[0, 410], [282, 425]])} cal={{today: 11}} beam={0.8} />
      {!holding && <rect x={326} y={692} width={52} height={7} rx={3} fill="#0d0f14" />}
      <Rafi
        x={LIE_HIP[0]} y={LIE_HIP[1]} rotate={-90} pose={pose}
        overlay={(r) => holding && (
          <g transform={`translate(${r.aN.h[0]} ${r.aN.h[1]})`}>
            <circle cx={-34} cy={0} r={190} fill="url(#phoneGlow)" opacity={0.7 * glow} />
            <rect x={-3.5} y={-27} width={7} height={54} rx={2} fill="#0b0d12" />
            <rect x={-4.5} y={-25} width={2.5} height={50} fill="#9ec5ff" opacity={glow} />
          </g>
        )}
      />
    </Stage>
  );
};

const sitHead = (torso: number, head: number, eye: number, hipY = CHAIR_HIP) => sitAt(hipY, torso, head, [1292, 603], {eye, brow: 0.45, mouth: -0.3});

/** 08 — দুপুরের খাবারের পর ঢুলুনি (Slow Zoom In) */
export const Scene08: React.FC = () => {
  const f = useCurrentFrame();
  const pose = poseAt([
    K(0, sitHead(10, 12, 0.6)), K(80, sitHead(14, 26, 0.35)), K(120, sitHead(8, 10, 0.55)),
    K(190, sitHead(20, 38, 0.1)), K(240, sitHead(22, 42, 0.02)), K(282, sitHead(24, 45, 0)),
  ], f);
  return (
    <Stage mood={MOODS.afternoon} cam={[ck(0, 1260, 520, 1.45), ck(282, 1230, 500, 2.2)]}>
      <Room fan={fanAngle(f, Infinity, 9)} dust={0.9} clock={kf(f, [[0, 750], [282, 790]])} cal={{today: 12}} beam={0.9} />
      <Plate x={1420} y={DESK_TOP} />
      <Rafi x={CHAIR_HIP[0]} y={CHAIR_HIP[1]} pose={pose} />
    </Stage>
  );
};

/** 09 — বিকেলে ফাঁকা মাঠ রাফিকে টানে (জানালার POV → Wide) */
export const Scene09: React.FC = () => {
  const f = useCurrentFrame();
  const hip: [number, number] = [790, HIP_Y.stand];
  const pose = poseAt([
    K(0, withFace(STAND, {torso: 8, head: -4, armN: armTo(8, loc(hip, [850, 556])), eye: 0.8})),
    K(282, withFace(STAND, {torso: 12, head: -8, armN: armTo(12, loc(hip, [852, 556])), eye: 0.9, brow: 0.1, mouth: 0.15})),
  ], f);
  return (
    <Stage mood={MOODS.golden} cam={[ck(0, 1040, 400, 2.6), ck(120, 1020, 430, 2.3), ck(282, 930, 480, 1.5)]}>
      <Room fan={fanAngle(f, Infinity, 8)} dust={0.9} clock={kf(f, [[0, 940], [282, 990]])} cal={{today: 13}} kids curtain={0.6} beam={1.1} />
      <Rafi x={hip[0]} y={hip[1]} pose={pose} />
    </Stage>
  );
};

/** 10 — অজুহাতের পর অজুহাত, সন্ধ্যা থেকে রাত (Medium, Slow Zoom Out) */
export const Scene10: React.FC = () => {
  const f = useCurrentFrame();
  const mood = lerpMood(MOODS.dusk, MOODS.night, kf(f, [[0, 0], [260, 1]]));
  const hand = (t: number, h: number): [number, number] => [0, 0];
  const headOn = (torso: number, head: number) => {
    const hc: [number, number] = [Math.sin(rad(torso)) * 140 + Math.sin(rad(torso + head)) * 30, -Math.cos(rad(torso)) * 140 - Math.cos(rad(torso + head)) * 30];
    return sitAt(CHAIR_HIP, torso, head, [CHAIR_HIP[0] + hc[0] * 1.2 + 14, CHAIR_HIP[1] + hc[1] * 1.2 + 34], {eye: 0.5, brow: 0.55, mouth: -0.4});
  };
  const back = withFace(SIT, {torso: -4, head: -14, eye: 0.7, brow: 0.3, mouth: -0.2});
  const pose = poseAt([K(0, headOn(16, 22)), K(70, headOn(16, 22)), K(100, back), K(150, back), K(180, headOn(20, 26)), K(282, headOn(22, 30))], f);
  return (
    <Stage mood={mood} cam={[ck(0, 1250, 540, 1.75), ck(282, 1120, 520, 1.2)]}>
      <Room fan={fanAngle(f, Infinity, 10)} dust={0.9} clock={kf(f, [[0, 1020], [282, 1200]])} cal={{today: kf(f, [[0, 15], [282, 17]])}} deskLamp={kf(f, [[150, 0], [165, 1]])} beam={kf(f, [[0, 1], [260, 0.3]])} />
      <Rafi x={CHAIR_HIP[0]} y={CHAIR_HIP[1]} pose={pose} />
    </Stage>
  );
};

/** 11 — রাফি নিজেই চা বানায় (রান্নাঘর, Tracking Shot) */
export const Scene11: React.FC = () => {
  const f = useCurrentFrame();
  const hipY = HIP_Y.stand;
  const x = kf(f, [[0, 620], [112, 620], [150, 770], [188, 770], [282, 770 + 94 * walkSpeed(WALK_OMEGA)]], (t) => t);
  const walking = (f > 112 && f < 150) || f > 188;
  const phase = f * WALK_OMEGA;
  const lift = kf(f, [[8, 0], [34, 70], [84, 70], [104, 0]]);
  const tilt = kf(f, [[34, 0], [56, 38], [82, 38], [92, 0]]);
  const kx = 735, ky = COUNTER_TOP - 6 - lift;
  const rot = (px: number, py: number, d: number) => [px * Math.cos(rad(d)) - py * Math.sin(rad(d)), px * Math.sin(rad(d)) + py * Math.cos(rad(d))];
  const [hx, hy] = rot(-98, -14, tilt);
  const handleW: [number, number] = [kx + 30 + hx, ky - 10 + hy];
  const tip = rot(42, -30, tilt);
  const tipW: [number, number] = [kx + 30 + tip[0], ky - 10 + tip[1]];
  const pouring = f > 46 && f < 84;
  const fill = kf(f, [[48, 0], [82, 1]]);
  const cupW: [number, number] = [818, COUNTER_TOP - 22];
  const holdCup = f >= 176;

  let pose;
  if (f < 112) {
    const t = f < 104 ? loc([620, hipY], handleW) : loc([620, hipY], [kx - 66, COUNTER_TOP - 26]);
    pose = withFace(STAND_TIRED, {torso: 8, head: 10, armN: armTo(8, t), eye: 0.6});
  } else if (f < 150) {
    pose = walk(phase, STAND_TIRED);
  } else if (f < 188) {
    const reach = withFace(STAND_TIRED, {torso: 12, head: 16, armN: armTo(12, loc([770, hipY], cupW)), eye: 0.7});
    pose = poseAt([K(150, STAND_TIRED), K(170, reach), K(188, withFace(STAND_TIRED, {torso: 6, armN: armTo(6, [62, -70], -1), eye: 0.75}))], f);
  } else {
    const w = walk(phase, STAND_TIRED);
    pose = {...w, armN: armTo(w.torso, [58, -78], -1)};
  }
  return (
    <Stage mood={MOODS.amber} cam={[ck(0, 760, 470, 1.5), ck(130, 800, 480, 1.5), ck(282, 1500, 470, 1.35)]}>
      <Kitchen kettleTilt={tilt} kettleLift={lift} cupFill={fill} cupGone={holdCup} />
      {pouring && <path d={`M${tipW[0]} ${tipW[1]} L${tipW[0] + 1} ${COUNTER_TOP - 40 - (1 - fill) * 0}`} stroke="#e4efff" strokeWidth={4} opacity={0.75} strokeDasharray="10 5" strokeDashoffset={-f * 4} />}
      <Rafi
        x={x} y={hipY + (walking ? -3 * Math.abs(Math.sin(phase)) : 0)} pose={pose}
        overlay={(r) => holdCup && <Cup x={r.aN.h[0] + 6} y={r.aN.h[1] + 22} scale={0.8} steam={1} />}
      />
    </Stage>
  );
};

/** 12 — চা জুড়িয়ে গেল, বই খোলা হলো না (Close-up কাপ, আলো উষ্ণ→ঠান্ডা) */
export const Scene12: React.FC = () => {
  const f = useCurrentFrame();
  const mood = lerpMood(MOODS.amber, MOODS.night, kf(f, [[20, 0], [270, 1]]));
  const pose = poseAt([
    K(0, sitAt(CHAIR_HIP, 16, 20, [1296, 602], {eye: 0.65, brow: 0.4, mouth: -0.3})),
    K(120, sitAt(CHAIR_HIP, 20, 28, [1296, 602], {eye: 0.6, brow: 0.5, mouth: -0.4})),
    K(282, sitAt(CHAIR_HIP, 22, 32, [1296, 602], {eye: 0.5, brow: 0.6, mouth: -0.5})),
  ], f);
  return (
    <Stage mood={mood} cam={[ck(0, 1345, 560, 3.2), ck(110, 1330, 545, 2.4), ck(282, 1170, 510, 1.4)]}>
      <Room fan={fanAngle(f + 40, Infinity, 10)} dust={0.9} clock={kf(f, [[0, 1230], [282, 1330]])} cal={{today: 18}} deskLamp={kf(f, [[100, 0], [140, 1]])} beam={0.3} />
      <rect x={1272} y={DESK_TOP - 7} width={46} height={7} rx={3} fill="#0d0f14" />
      <ellipse cx={1295} cy={DESK_TOP - 12} rx={60} ry={22} fill="#8fb8ff" opacity={0.28 * kf(f, [[0, 0.2], [60, 1]])} />
      <Rafi x={CHAIR_HIP[0]} y={CHAIR_HIP[1]} pose={pose} />
      <Cup x={1352} y={DESK_TOP} steam={kf(f, [[0, 1], [140, 0]])} />
    </Stage>
  );
};
