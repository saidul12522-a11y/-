import {HIP_Y, K, Pose, SIT, V2, armTo, loc, withFace} from '../poses';

export const BED_HIP: V2 = [565, HIP_Y.sit];
export const CHAIR_HIP: V2 = [1185, HIP_Y.sit];
export const LIE_HIP: V2 = [430, 661];
export {K};

/** বসা অবস্থায় হাত ডেস্কের নির্দিষ্ট বিন্দুতে */
export function sitAt(hip: V2, torso: number, head: number, target: V2, extra: Partial<Pose> = {}): Pose {
  return withFace(
    {
      ...SIT,
      torso,
      head,
      armN: armTo(torso, loc(hip, target)),
      armF: armTo(torso, loc(hip, [target[0] - 26, target[1] + 2])),
    },
    extra,
  );
}
export const READ_AT: V2 = [1342, 600];
export const read = (torso = 14, head = 22, extra: Partial<Pose> = {}) => sitAt(CHAIR_HIP, torso, head, READ_AT, {eye: 0.7, brow: 0.2, mouth: 0, ...extra});
