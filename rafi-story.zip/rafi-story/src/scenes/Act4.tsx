import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Stage, ck} from '../components/Stage';
import {Room} from '../components/Room';
import {Rafi} from '../components/Rafi';
import {calCell} from '../components/Calendar';
import {AlarmClock, Marker, OpenBook, Phone} from '../components/Props';
import {DESK_TOP, MOODS, lerpMood} from '../theme';
import {HIP_Y, K, SIT, STAND, STAND_TIRED, WALK_OMEGA, armTo, lerpPose, loc, poseAt, walk, walkSpeed, withFace} from '../poses';
import {easeInOut, fanAngle, kf} from '../utils';
import {BED_HIP, CHAIR_HIP, read, sitAt} from './common';

/** 19 — বড় প্রতিজ্ঞা নয়: ফোন পাশের ঘরে রেখে এসে, অ্যালার্ম দিয়ে পড়ার টেবিলে */
export const Scene19: React.FC = () => {
  const f = useCurrentFrame();
  const v = walkSpeed(WALK_OMEGA);
  const phase = f * WALK_OMEGA;
  const mood = lerpMood(MOODS.dawn, MOODS.morning, kf(f, [[0, 0], [270, 1]]));
  let x = BED_HIP[0], y = HIP_Y.sit, flip = false, opacity = 1, pose = SIT, phone = false;
  const getUp = easeInOut(kf(f, [[8, 0], [34, 1]]));
  if (f < 34) {
    pose = lerpPose(withFace(SIT, {torso: 16, head: 16, armN: armTo(16, [80, -10]), eye: 0.7}), withFace(STAND, {armN: armTo(3, [30, -50], -1)}), getUp);
    y = HIP_Y.sit + (HIP_Y.stand - HIP_Y.sit) * getUp; phone = true;
  } else if (f < 160) {
    x = BED_HIP[0] + v * (f - 34); y = HIP_Y.stand - 3 * Math.abs(Math.sin(phase));
    const w = walk(phase, STAND); pose = {...w, armN: armTo(w.torso, [34, -52], -1)}; phone = true;
    opacity = kf(f, [[146, 1], [160, 0]]);
  } else if (f < 172) {
    opacity = 0; x = 1830; y = HIP_Y.stand; flip = true;
  } else if (f < 236) {
    flip = true; x = 1830 - v * (f - 172); y = HIP_Y.stand - 3 * Math.abs(Math.sin(phase));
    pose = walk(-phase, STAND); opacity = kf(f, [[172, 0], [182, 1]]);
    x = Math.max(x, CHAIR_HIP[0]);
  } else {
    x = CHAIR_HIP[0];
    const sitT = easeInOut(kf(f, [[238, 0], [264, 1]]));
    y = HIP_Y.stand + (HIP_Y.sit - HIP_Y.stand) * sitT;
    pose = lerpPose(STAND, withFace(SIT, {armN: armTo(8, loc(CHAIR_HIP, [1330, 596])), torso: 8, eye: 0.8, mouth: 0.1}), sitT);
  }
  const camX = f < 34 ? 700 : f < 160 ? Math.min(1500, BED_HIP[0] + v * (f - 34) + 120) : f < 236 ? Math.min(1500, Math.max(1250, 1830 - v * (f - 172))) : 1250;
  return (
    <Stage mood={mood} cam={[ck(0, 700, 500, 1.5), ck(150, 1500, 500, 1.4), ck(176, 1500, 500, 1.4), ck(240, 1260, 520, 1.5), ck(282, 1255, 530, 1.8)]}>
      <Room fan={fanAngle(f)} dust={0.9} clock={kf(f, [[0, 360], [282, 366]])} cal={{today: 24}} beam={kf(f, [[0, 0.5], [270, 1]])} />
      <AlarmClock x={1330} y={DESK_TOP} />
      <Rafi
        x={x} y={y} flip={flip} opacity={opacity} pose={pose}
        overlay={(r) => phone && <g transform={`translate(${r.aN.h[0] + 8} ${r.aN.h[1] - 8}) rotate(14)`}><rect x={-6} y={-14} width={12} height={26} rx={2} fill="#0b0d12" /><rect x={-4.5} y={-12} width={9} height={22} fill="#9ec5ff" opacity={0.85} /></g>}
      />
    </Stage>
  );
};

/** 20 — প্রথম দিন টিকল মাত্র পঁচিশ মিনিট; ক্যালেন্ডারে প্রথম ক্রস */
export const Scene20: React.FC = () => {
  const f = useCurrentFrame();
  const stand = easeInOut(kf(f, [[122, 0], [150, 1]]));
  const hipStand: [number, number] = [1330, HIP_Y.stand];
  const cell = calCell(24);
  const draw = kf(f, [[170, 0], [225, 1]], (t) => t);
  const studying = read(14, 24, {mood: 0});
  const sitPoseUp = withFace(studying, {armN: armTo(14, loc(CHAIR_HIP, [1330, 570]))});
  const toAlarm = withFace(SIT, {torso: 8, head: 14, armN: armTo(8, loc(CHAIR_HIP, [1330, 580])), eye: 0.7});
  const markerPose = withFace(STAND, {torso: 0, head: -4, armN: armTo(0, loc(hipStand, [cell[0] + Math.sin(f * 0.8) * 2 * (draw > 0 && draw < 1 ? 1 : 0), cell[1] + (draw > 0 ? (draw < 0.5 ? draw * 12 : 12 - (draw - 0.5) * 12) : 0)])), eye: 0.85, mouth: 0.1});
  const sitting = poseAt([K(0, studying), K(70, withFace(studying, {head: 28})), K(98, withFace(studying, {head: 18})), K(106, toAlarm), K(118, toAlarm), K(124, withFace(SIT, {torso: 6, head: 6, eye: 0.7}))], f);
  const isStanding = f >= 122;
  const pose = isStanding ? lerpPose(withFace(SIT, {torso: 6, head: 6}), markerPose, stand) : sitting;
  const px = isStanding ? CHAIR_HIP[0] + (hipStand[0] - CHAIR_HIP[0]) * stand : CHAIR_HIP[0];
  const py = isStanding ? HIP_Y.sit + (HIP_Y.stand - HIP_Y.sit) * stand : HIP_Y.sit;
  return (
    <Stage mood={MOODS.morning} cam={[ck(0, 1260, 520, 1.7), ck(110, 1270, 520, 1.9), ck(150, 1360, 430, 1.5), ck(282, 1400, 330, 2.7)]}>
      <Room fan={fanAngle(f)} dust={0.5} clock={kf(f, [[0, 420], [95, 445]])} cal={{crosses: draw}} beam={1} />
      <OpenBook x={1372} y={DESK_TOP} />
      <AlarmClock x={1330} y={DESK_TOP - 0} ring={f > 80 && f < 112} />
      <Rafi
        x={px} y={py} pose={pose}
        overlay={(r) => f >= 140 && f < 232 && <g transform={`translate(${r.aN.h[0]} ${r.aN.h[1]})`}><Marker x={4} y={-6} rot={-12} /></g>}
      />
    </Stage>
  );
};

/** 21 — তারপর আরেকটা, তারপর আরেকটা (তিন দিনের Dissolve) */
export const Scene21: React.FC = () => {
  const f = useCurrentFrame();
  const seg = Math.min(2, Math.floor(f / 94));
  const moods = [MOODS.morning, MOODS.afternoon, MOODS.dusk];
  const mood = moods[seg];
  const crosses = 1 + kf(f, [[0, 0], [58, 0], [88, 1], [94, 1], [152, 1], [182, 2], [188, 2], [246, 2], [276, 3]], (t) => t);
  const fadeBlack = Math.max(kf(f, [[84, 0], [94, 1], [100, 0]], (t) => t), kf(f, [[178, 0], [188, 1], [194, 0]], (t) => t), 0);
  const local = f % 94;
  const pose = poseAt([K(0, read(14, 22)), K(30, read(14, 26)), K(50, read(12, 18, {armN: armTo(12, loc(CHAIR_HIP, [1400, 590]))})), K(94, read(14, 22))], local);
  return (
    <Stage mood={mood} cam={[ck(0, 1200, 500, 1.45), ck(282, 1290, 480, 1.7)]} overlay={<rect width={1920} height={1080} fill="#000" opacity={Math.min(1, fadeBlack)} />}>
      <Room fan={fanAngle(f)} dust={0.35} clock={kf(f, [[0, 480], [94, 540], [95, 780], [188, 900], [189, 1080], [282, 1200]], (t) => t)} cal={{crosses}} beam={seg === 2 ? 0.5 : 1} deskLamp={seg === 2 ? 1 : 0} />
      <OpenBook x={1372} y={DESK_TOP} />
      <Rafi x={CHAIR_HIP[0]} y={CHAIR_HIP[1]} pose={pose} seed={seg} />
    </Stage>
  );
};

/** 22 — ধুলো মুছে গেল, ঘরের বাতাস হালকা (Wide, Pan Right) */
export const Scene22: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage mood={MOODS.morning} cam={[ck(0, 700, 500, 1.25), ck(282, 1230, 500, 1.3)]}>
      <Room fan={fanAngle(f)} dust={0} clock={kf(f, [[0, 520], [282, 560]])} cal={{crosses: 4}} curtain={1} beam={1.2} />
      <OpenBook x={1372} y={DESK_TOP} />
      <Rafi x={CHAIR_HIP[0]} y={CHAIR_HIP[1]} pose={poseAt([K(0, read(14, 22, {mouth: 0.1})), K(140, read(14, 26, {mouth: 0.15})), K(282, read(12, 20, {mouth: 0.2}))], f)} />
    </Stage>
  );
};

/** 23 — কাল কখনোই আসে না, যে সময়টা আসে সেটা শুধুই আজ (Wide, Zoom Out → Fade) */
export const Scene23: React.FC = () => {
  const f = useCurrentFrame();
  const pose = poseAt([K(0, read(14, 22, {mouth: 0.2})), K(130, read(14, 22, {mouth: 0.2})), K(190, withFace(SIT, {torso: 2, head: -8, eye: 0.95, brow: 0, mouth: 0.6, armN: armTo(2, loc(CHAIR_HIP, [1320, 598]))})), K(282, withFace(SIT, {torso: 2, head: -8, eye: 0.95, brow: 0, mouth: 0.6, armN: armTo(2, loc(CHAIR_HIP, [1320, 598]))}))], f);
  return (
    <Stage mood={MOODS.morning} cam={[ck(0, 1220, 480, 1.75), ck(282, 960, 520, 1.0)]}>
      <Room fan={fanAngle(f)} dust={0} clock={kf(f, [[0, 560], [282, 600]])} cal={{crosses: 8}} curtain={0.8} beam={1.3} />
      <OpenBook x={1372} y={DESK_TOP} />
      <Rafi x={CHAIR_HIP[0]} y={CHAIR_HIP[1]} pose={pose} />
    </Stage>
  );
};
