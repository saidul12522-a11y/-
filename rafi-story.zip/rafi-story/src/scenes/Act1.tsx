import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Stage, ck} from '../components/Stage';
import {Room} from '../components/Room';
import {Rafi} from '../components/Rafi';
import {Exterior} from '../components/Exterior';
import {Blanket} from '../components/Props';
import {MOODS, lerpMood} from '../theme';
import {HIP_Y, K, LIE, SLUMP, STAND, STAND_TIRED, armTo, lerpPose, loc, locLie, poseAt, withFace} from '../poses';
import {easeInOut, fanAngle, kf, pulse} from '../utils';
import {BED_HIP, LIE_HIP} from './common';

/** 01 — রাত বারোটা, ক্যালেন্ডারের লাল দাগ (Close-up → Wide, Slow Zoom Out) */
export const Scene01: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage mood={MOODS.night} cam={[ck(0, 1400, 300, 3.0), ck(250, 1090, 480, 1.1)]}>
      <Room fan={fanAngle(f)} lamp={0.7} dust={0.9} clock={kf(f, [[0, 0], [250, 0.7]])} cal={{today: 2, pulse: pulse(f, 45)}} />
      <Rafi x={BED_HIP[0]} y={BED_HIP[1]} pose={poseAt([K(0, SLUMP), K(130, withFace(SLUMP, {head: 32})), K(260, SLUMP)], f)} />
    </Stage>
  );
};

/** 02 — পরীক্ষার দিন প্রতিদিন কাছে আসছে (Object Close-up, ধীর Push-in) */
export const Scene02: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage mood={MOODS.night} cam={[ck(0, 1405, 318, 3.3), ck(222, 1402, 300, 4.6)]}>
      <Room fan={fanAngle(f + 300)} dust={0.9} clock={kf(f, [[0, 4], [222, 40]])} cal={{today: kf(f, [[0, 3], [200, 8]], (t) => t), pulse: pulse(f, 30)}} />
    </Stage>
  );
};

/** 03 — "কাল থেকে শুরু করব": ল্যাম্প নিভিয়ে শুয়ে পড়া (Pan Left) */
export const Scene03: React.FC = () => {
  const f = useCurrentFrame();
  const lamp = kf(f, [[86, 0.7], [92, 0]]);
  const mood = lerpMood(MOODS.night, MOODS.deep, kf(f, [[88, 0], [120, 1]]));
  const lay = kf(f, [[112, 0], [170, 1]]);
  const reach = withFace(SLUMP, {torso: 20, head: 14, armN: armTo(20, loc(BED_HIP, [738, 604]))});
  const sit = poseAt([K(0, SLUMP), K(55, withFace(SLUMP, {head: 30})), K(78, reach), K(100, reach), K(112, SLUMP)], f);
  const pose = lerpPose(sit, withFace(LIE, {eye: kf(f, [[170, 0.8], [240, 0.05]])}), lay);
  const hx = BED_HIP[0] + (LIE_HIP[0] - BED_HIP[0]) * easeInOut(lay);
  const hy = BED_HIP[1] + (LIE_HIP[1] - BED_HIP[1]) * easeInOut(lay);
  return (
    <Stage mood={mood} cam={[ck(0, 930, 470, 1.3), ck(110, 700, 520, 1.5), ck(270, 470, 560, 1.75)]}>
      <Room fan={fanAngle(f + 600)} lamp={lamp} dust={0.9} clock={5} cal={{today: 8}} />
      <Rafi x={hx} y={hy} rotate={-90 * easeInOut(lay)} pose={pose} />
      <Blanket pull={kf(f, [[175, 0], [225, 1]])} />
    </Stage>
  );
};

/** 04 — ঢাকার পুরনো বাড়ি, রিকশার ঘণ্টা, কাক, টিভি (Establishing Wide, Pan Up) */
export const Scene04: React.FC = () => (
  <Stage mood={MOODS.dawn} cam={[ck(0, 900, 700, 1.0), ck(290, 1040, 150, 1.45)]}>
    <Exterior />
  </Stage>
);

/** 05 — রাফি, ধুলোজমা বই (Medium → Close-up) */
export const Scene05: React.FC = () => {
  const f = useCurrentFrame();
  const hip: [number, number] = [1225, HIP_Y.stand];
  const reachP = withFace(STAND_TIRED, {torso: 18, head: 24, eye: 0.6, armN: armTo(18, loc(hip, [1318, 596]))});
  const pose = poseAt([K(0, STAND_TIRED), K(85, withFace(STAND_TIRED, {head: 22})), K(135, reachP), K(190, reachP), K(262, STAND_TIRED)], f);
  return (
    <Stage mood={MOODS.dawn} cam={[ck(0, 1240, 480, 1.25), ck(125, 1330, 520, 2.2), ck(262, 1345, 565, 2.8)]}>
      <Room fan={fanAngle(f + 900, Infinity, 10)} dust={0.95} clock={kf(f, [[0, 20], [260, 40]])} cal={{today: 9}} beam={0.9} />
      <Rafi x={hip[0]} y={hip[1]} pose={pose} />
    </Stage>
  );
};

/** 06 — একঘেয়ে ফ্যান, ঘড়ির কাঁটা এগোয় (Tilt Down: ফ্যান → ঘড়ি → রাফি) */
export const Scene06: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage mood={MOODS.noon} cam={[ck(0, 960, 140, 2.3), ck(100, 770, 255, 2.4), ck(255, 470, 600, 1.5)]}>
      <Room fan={f * 9} dust={0.9} clock={kf(f, [[0, 120], [260, 300]], (t) => t)} cal={{today: 10}} beam={0.8} />
      <Rafi x={LIE_HIP[0]} y={LIE_HIP[1]} rotate={-90} pose={withFace(LIE, {eye: 0.75, brow: 0.4, mouth: -0.3})} />
    </Stage>
  );
};
