import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Stage, ck} from '../components/Stage';
import {Room} from '../components/Room';
import {Rafi} from '../components/Rafi';
import {TopDownBed, NotebookMacro} from '../components/TopDown';
import {Hand, Candle, NotebookSide} from '../components/Props';
import {DESK_TOP, MOODS, TABLE_TOP, lerpMood} from '../theme';
import {K, SLUMP, SIT, armTo, loc, poseAt, withFace} from '../poses';
import {fanAngle, kf, pulse} from '../utils';
import {BED_HIP, CHAIR_HIP, sitAt} from './common';

/** 13 — লাল দাগটা এখন আর দূরে নেই (Close-up, Dark Red Accent) */
export const Scene13: React.FC = () => {
  const f = useCurrentFrame();
  const p = pulse(f, 24);
  return (
    <Stage
      mood={MOODS.night}
      cam={[ck(0, 1405, 322, 3.0), ck(282, 1408, 322, 4.5)]}
      overlay={<rect width={1920} height={1080} fill="#8b1a14" opacity={0.05 + 0.07 * p} />}
    >
      <Room fan={fanAngle(f + 200)} dust={0.9} clock={kf(f, [[0, 1400], [282, 1480]])} cal={{today: kf(f, [[0, 14], [250, 23]], (t) => t), pulse: p}} />
    </Stage>
  );
};

/** 14 — ঘুম আসে না, পড়তেও ইচ্ছে করে না (Top Shot, ধীর Rotate) */
export const Scene14: React.FC = () => {
  const f = useCurrentFrame();
  const toss = Math.sin(f / 46) * 0.9;
  return (
    <Stage mood={MOODS.deep} cam={[ck(0, 960, 540, 1.0, -3), ck(282, 960, 540, 1.14, 3)]}>
      <TopDownBed toss={toss} />
    </Stage>
  );
};

/** 15 — বিদ্যুৎ গেল, অন্ধকারে মোমবাতি খুঁজতে গিয়ে পুরনো খাতা */
export const Scene15: React.FC = () => {
  const f = useCurrentFrame();
  const CUT = 42;
  const mood = f < CUT ? MOODS.night : lerpMood(lerpMood(MOODS.night, MOODS.blackout, kf(f, [[CUT, 0], [CUT + 6, 1]])), MOODS.candle, kf(f, [[236, 0], [270, 1]]));
  const lamp = f < CUT ? 0.65 : 0;
  const sweepX = 690 + 40 * Math.sin(f * 0.09);
  const found = f >= 180;
  const tgt = (): [number, number] =>
    f < 150 ? [sweepX, TABLE_TOP - 8]
    : f < 180 ? [742, TABLE_TOP - 8]
    : f < 215 ? [kf(f, [[180, 742], [215, 612]]), kf(f, [[180, TABLE_TOP - 8], [215, 690]])]
    : [612, 690];
  const lean = kf(f, [[0, 24], [CUT + 14, 30], [215, 22]]);
  const pose = withFace(SLUMP, {torso: lean, head: kf(f, [[0, 22], [60, 6]]), eye: 0.6, armN: armTo(lean, loc(BED_HIP, tgt()))});
  const flare = kf(f, [[232, 0], [244, 1], [282, 0.85]]);
  return (
    <Stage mood={mood} cam={[ck(0, 760, 520, 1.3), ck(70, 690, 600, 1.9), ck(215, 650, 640, 2.4), ck(282, 625, 650, 2.9)]}>
      <Room fan={fanAngle(f, CUT)} lamp={lamp} dust={0.9} clock={30} cal={{today: 23}} />
      {!found && f > CUT && <NotebookSide x={742} y={TABLE_TOP} w={64} />}
      <Rafi
        x={BED_HIP[0]} y={BED_HIP[1]} pose={pose}
        overlay={(r) => (
          <g>
            {found && <g transform={`translate(${r.aN.h[0] + 4} ${r.aN.h[1] + 8}) rotate(${-14})`}><NotebookSide x={0} y={0} w={64} /></g>}
            {flare > 0 && (
              <g transform={`translate(${r.aF.h[0] + 18} ${r.aF.h[1] - 8})`}>
                <circle r={260 * flare} fill="url(#candleGlow)" opacity={0.9 * flare} />
                <path d="M0 -18 C6 -8 5 0 0 3 C-5 0 -6 -8 0 -18Z" fill="#ffd36b" />
              </g>
            )}
          </g>
        )}
      />
    </Stage>
  );
};

/** 16 — খাতার প্রথম পাতা, নিজের হাতের মাত্র একটি লাইন (Macro) */
export const Scene16: React.FC = () => {
  const f = useCurrentFrame();
  const open = kf(f, [[44, 0], [120, 1]]);
  const edge = 960 + 800 * Math.cos(open * Math.PI);
  const handX = kf(f, [[0, 1900], [44, edge + 24]]);
  return (
    <Stage mood={MOODS.candle} cam={[ck(0, 960, 540, 1.0), ck(282, 1120, 500, 1.25)]}>
      <NotebookMacro open={open} candle={1} />
      {f < 150 && <Hand x={f < 44 ? handX : edge + 24} y={820} rot={-8} scale={1.7} curl={0.55} />}
    </Stage>
  );
};

/** 17 — Flashback: কয়েক মাস আগের উৎসাহ, তারপর খাতা বন্ধ */
export const Scene17: React.FC = () => {
  const f = useCurrentFrame();
  const writing = f < 170;
  const wx = 1352 + 10 * Math.sin(f * 0.55) + (f % 60) * 0.1;
  const happy = {eye: 0.9, brow: 0.0, mouth: 0.55};
  const sad = {eye: 0.6, brow: 0.5, mouth: -0.3};
  const pose = poseAt([
    K(0, sitAt(CHAIR_HIP, 14, 24, [wx, 598], happy)),
    K(170, sitAt(CHAIR_HIP, 14, 24, [1360, 598], happy)),
    K(200, sitAt(CHAIR_HIP, 6, 8, [1340, 590], sad)),
    K(282, sitAt(CHAIR_HIP, 4, 6, [1300, 560], {...sad, mouth: -0.4})),
  ], f);
  const nbY = kf(f, [[0, DESK_TOP], [186, DESK_TOP], [222, DESK_TOP - 34]]);
  const nbX = kf(f, [[0, 1372], [186, 1372], [222, 1372]]);
  const jitter = 0.03 * Math.sin(f * 1.7);
  return (
    <Stage
      mood={MOODS.flash}
      cam={[ck(0, 1250, 500, 1.7), ck(282, 1300, 500, 2.0)]}
      overlay={<g><rect width={1920} height={1080} fill="#c9a96b" opacity={0.1 + jitter} /><rect width={1920} height={1080} fill="#000" opacity={Math.max(0, jitter)} /></g>}
    >
      <Room fan={f * 12} dust={kf(f, [[0, 0.05], [200, 0.1], [282, 0.95]])} clock={kf(f, [[0, 0], [282, 40]])} cal={{}} deskLamp={1} beam={0.8} motes={false} />
      <NotebookSide x={nbX} y={nbY} w={70} />
      <Rafi
        x={CHAIR_HIP[0]} y={CHAIR_HIP[1]} pose={pose}
        overlay={(r) => writing && <g transform={`translate(${r.aN.h[0]} ${r.aN.h[1]}) rotate(25)`}><rect x={-2} y={-2} width={4} height={30} rx={2} fill="#a83232" /></g>}
      />
    </Stage>
  );
};

/** 18 — মোমের আলোয় অনেকক্ষণ তাকিয়ে থাকা (Extreme Close-up) */
export const Scene18: React.FC = () => {
  const f = useCurrentFrame();
  const pose = sitAt(CHAIR_HIP, 14, 20, [1296, 596], {eye: 0.72, brow: 0.85, mouth: -0.45});
  return (
    <Stage mood={MOODS.candle} cam={[ck(0, 1245, 500, 3.5), ck(282, 1255, 508, 4.7)]}>
      <Room fan={0} dust={0.9} clock={30} cal={{}} motes={false} />
      <Rafi x={CHAIR_HIP[0]} y={CHAIR_HIP[1]} pose={pose} tear={kf(f, [[110, 0], [270, 1]], (t) => t)} />
      <Candle x={1296} y={DESK_TOP} lit={1} />
    </Stage>
  );
};
