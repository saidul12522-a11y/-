import React from 'react';
import {Composition} from 'remotion';
import {RafiVideo} from './Video';
import {FPS, H, W} from './theme';
import {TOTAL_FRAMES} from './timing';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="RafiStory"
    component={RafiVideo}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={W}
    height={H}
  />
);
