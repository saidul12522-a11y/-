import {lerp, mix} from './utils';

export const W = 1920;
export const H = 1080;
export const FPS = 30;
export const FLOOR = 800;
export const CHAR_SCALE = 1.2;
export const BED_TOP = 703;
export const DESK_TOP = 610;
export const TABLE_TOP = 650;

export interface Mood {
  wallTop: string; wallBot: string; floor: string;
  furn: string; furnHi: string; ink: string;
  beam: string; beamA: number;
  skyTop: string; skyBot: string;
  ambient: string; ambientA: number;
  vignette: number; charLight: number;
}

export const MOODS: Record<string, Mood> = {
  night: {wallTop: '#0a101d', wallBot: '#16223b', floor: '#0b1220', furn: '#18243f', furnHi: '#26385e', ink: '#3f5179', beam: '#7b9be0', beamA: 0.16, skyTop: '#040816', skyBot: '#14234a', ambient: '#1b2d5e', ambientA: 0.3, vignette: 0.8, charLight: 0.66},
  deep: {wallTop: '#070a12', wallBot: '#0f1524', floor: '#080b13', furn: '#111827', furnHi: '#1b263b', ink: '#2f3c5b', beam: '#5f7cb8', beamA: 0.1, skyTop: '#03060e', skyBot: '#0d1630', ambient: '#14214a', ambientA: 0.38, vignette: 0.88, charLight: 0.52},
  dawn: {wallTop: '#1b2540', wallBot: '#2f3b5c', floor: '#171d30', furn: '#27324f', furnHi: '#3b4a70', ink: '#5a6c98', beam: '#b9c6e6', beamA: 0.22, skyTop: '#2a3a63', skyBot: '#e9a98c', ambient: '#3a4d7a', ambientA: 0.22, vignette: 0.6, charLight: 0.8},
  morning: {wallTop: '#d9ceb9', wallBot: '#c5b79c', floor: '#7a6a58', furn: '#9c8b73', furnHi: '#b5a58b', ink: '#6b5b48', beam: '#fff3cf', beamA: 0.5, skyTop: '#a9cde6', skyBot: '#f4eedf', ambient: '#ffecc4', ambientA: 0.08, vignette: 0.35, charLight: 1},
  noon: {wallTop: '#cfc4af', wallBot: '#b8ab92', floor: '#6f6252', furn: '#8f7e68', furnHi: '#a8977e', ink: '#5d5041', beam: '#fff1c4', beamA: 0.38, skyTop: '#9fc3dc', skyBot: '#e6edf0', ambient: '#fff2d6', ambientA: 0.06, vignette: 0.4, charLight: 0.98},
  afternoon: {wallTop: '#bda581', wallBot: '#a38a66', floor: '#5e4d3c', furn: '#85704f', furnHi: '#9d8662', ink: '#4f4030', beam: '#ffd68e', beamA: 0.45, skyTop: '#e9c987', skyBot: '#f6e3b3', ambient: '#ffd48a', ambientA: 0.14, vignette: 0.5, charLight: 0.95},
  golden: {wallTop: '#7d5a46', wallBot: '#654636', floor: '#3d2a22', furn: '#5b4033', furnHi: '#7b5a47', ink: '#33231c', beam: '#ffb066', beamA: 0.55, skyTop: '#f2a65c', skyBot: '#6f4f78', ambient: '#ff9d52', ambientA: 0.2, vignette: 0.55, charLight: 0.9},
  dusk: {wallTop: '#252844', wallBot: '#363a5c', floor: '#171a2c', furn: '#2b3052', furnHi: '#3d4470', ink: '#59629a', beam: '#d98b7a', beamA: 0.25, skyTop: '#3a3e72', skyBot: '#c4756f', ambient: '#4a4a85', ambientA: 0.25, vignette: 0.65, charLight: 0.75},
  amber: {wallTop: '#2a1e1a', wallBot: '#45322a', floor: '#1c1410', furn: '#3c2b22', furnHi: '#58402f', ink: '#7a5a42', beam: '#ffb86b', beamA: 0.08, skyTop: '#1a1220', skyBot: '#3a2430', ambient: '#ffa95a', ambientA: 0.16, vignette: 0.7, charLight: 0.88},
  blackout: {wallTop: '#04060b', wallBot: '#070a12', floor: '#04060a', furn: '#090d17', furnHi: '#0e1424', ink: '#1a2336', beam: '#4b66a0', beamA: 0.07, skyTop: '#02040a', skyBot: '#0a1228', ambient: '#0e1838', ambientA: 0.45, vignette: 0.9, charLight: 0.34},
  candle: {wallTop: '#05070c', wallBot: '#0c0e14', floor: '#06080d', furn: '#12141c', furnHi: '#1d1c22', ink: '#3a2f2a', beam: '#4b66a0', beamA: 0.04, skyTop: '#02040a', skyBot: '#0a1228', ambient: '#ff9a4a', ambientA: 0.1, vignette: 0.92, charLight: 0.55},
  flash: {wallTop: '#4c4538', wallBot: '#5d5442', floor: '#2b261e', furn: '#6e6350', furnHi: '#85796a', ink: '#2f2a22', beam: '#f4e2b0', beamA: 0.4, skyTop: '#b9a98a', skyBot: '#e6d9b8', ambient: '#e0c690', ambientA: 0.15, vignette: 0.65, charLight: 0.9},
};

export function lerpMood(a: Mood, b: Mood, t: number): Mood {
  const o: any = {};
  (Object.keys(a) as Array<keyof Mood>).forEach((k) => {
    const x: any = a[k], y: any = b[k];
    o[k] = typeof x === 'string' ? mix(x, y, t) : lerp(x, y, t);
  });
  return o as Mood;
}
