# কাল থেকে — রাফির গল্প (Remotion)

Cinematic 2D Animated Short · 1920×1080 · 30fps · ১৯৪ সেকেন্ড (৫৮২০ ফ্রেম)
ভিডিওতে **কোনো ক্যাপশন নেই, কোনো Voiceover/Music নেই** — শুধু Sound Effect।
Voiceover পরে এডিটরে বসালে SRT-এর টাইমিং হুবহু মিলবে।

## চালানোর নিয়ম
```
npm install
npx remotion studio src/index.ts     # Preview
npx remotion render src/index.ts RafiStory out/rafi-story.mp4   # Final Render
```
SFX নতুন করে বানাতে: `python3 tools/generate_sfx.py` (numpy, scipy লাগে)

## কাঠামো
- `src/timing.ts` — SRT থেকে ২৩টি Scene-এর সময়, Dissolve (12 ফ্রেম)
- `src/scenes/Act1–4.tsx` — Scene 01–23 (প্রতিটি আলাদা Component)
- `src/components/` — Rafi (rig), Room, Exterior, Kitchen, Calendar, Props, Stage (Camera/Light/Grain)
- `src/audio/sfx.ts` — ৮৯টি SFX cue (সময় Scene-এর সঙ্গে সিঙ্ক করা)
- `public/sfx/` — সিন্থেসাইজ করা ৩০টি .wav

## Character — রাফি
বয়স ~১৯–২০, রোগাটে, ছোট এলোমেলো কালো চুল, গাঢ় ধূসর-নীল টি-শার্ট, ধূসর ট্র্যাক প্যান্ট, চোখের নিচে হালকা ক্লান্তির ছায়া।

## Revision
কোনো Scene বদলাতে হলে শুধু সংশ্লিষ্ট `SceneNN` Component বদলান।
