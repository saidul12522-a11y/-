#!/usr/bin/env python3
"""Sound effect synthesizer — কোনো বাইরের ফাইল/কপিরাইট ছাড়া নিজেই SFX বানায়.
Usage: python3 tools/generate_sfx.py   (numpy + scipy দরকার)
Output: public/sfx/*.wav  এবং  src/audio/manifest.json (প্রতিটির দৈর্ঘ্য সেকেন্ডে)
"""
import json, os, wave
import numpy as np
from scipy.signal import butter, sosfilt

SR = 44100
rng = np.random.default_rng(7)
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'public', 'sfx')
os.makedirs(OUT, exist_ok=True)
manifest = {}

def t(d): return np.arange(int(SR * d)) / SR
def noise(d): return rng.standard_normal(int(SR * d))
def bp(x, lo, hi, o=2): return sosfilt(butter(o, [lo, hi], 'band', fs=SR, output='sos'), x)
def lp(x, fc, o=2): return sosfilt(butter(o, fc, 'low', fs=SR, output='sos'), x)
def hp(x, fc, o=2): return sosfilt(butter(o, fc, 'high', fs=SR, output='sos'), x)
def env(n, a=0.01, r=0.1):
    e = np.ones(n); na, nr = max(1, int(a * SR)), max(1, int(r * SR))
    e[:na] = np.linspace(0, 1, na); e[-nr:] = np.linspace(1, 0, nr) if nr < n else e[-nr:]
    return e
def decay(n, tau): return np.exp(-np.arange(n) / (tau * SR))
def norm(x, peak=0.8): return x / (np.max(np.abs(x)) + 1e-9) * peak
def loop(x, xf=0.5):
    n = int(xf * SR); body = x[:-n].copy()
    w = np.linspace(0, 1, n); body[:n] = body[:n] * w + x[-n:] * (1 - w)
    return body
def save(name, x, peak=0.8):
    x = norm(x, peak)
    with wave.open(os.path.join(OUT, name + '.wav'), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((x * 32767).astype(np.int16).tobytes())
    manifest[name] = round(len(x) / SR, 3)
def place(buf, snd, at):
    i = int(at * SR); buf[i:i + len(snd)] += snd[:len(buf) - i]

# ---------- বেড/লুপ ----------
save('room_tone', loop(lp(noise(9), 260) * 1.0 + 0.3 * lp(noise(9), 70), 1.0), 0.35)
n = noise(5)
fan = lp(n, 420) * (1 + 0.35 * np.sin(2 * np.pi * 3.2 * t(5))) + 0.5 * lp(noise(5), 120)
save('fan_loop', loop(fan, 0.8), 0.5)
tk = np.zeros(int(SR * 5))
for k in range(4):
    for j, (f0, a) in enumerate([(1900, 1.0), (1300, 0.7)]):
        tt = t(0.05); s = np.sin(2 * np.pi * f0 * tt) * decay(len(tt), 0.008) * a + hp(noise(0.05), 2500) * decay(len(tt), 0.004) * 0.6
        place(tk, s, k * 1.0 + j * 0.5)
save('clock_tick', tk[: int(SR * 4)], 0.5)
save('street_loop', loop(lp(noise(11), 500) * (1 + 0.5 * np.sin(2 * np.pi * 0.17 * t(11))) + 0.25 * bp(noise(11), 800, 2500), 1.0), 0.4)
syl = (np.sin(2 * np.pi * 3.1 * t(7)) > -0.2) * (0.6 + 0.4 * np.sin(2 * np.pi * 1.3 * t(7)))
save('tv_murmur', loop(bp(noise(7), 250, 1800) * syl, 0.6), 0.4)
save('wind_soft', loop(bp(noise(10), 120, 900) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.2 * t(10) + 1)), 1.0), 0.4)
b = np.zeros(int(SR * 9))
for _ in range(26):
    d = rng.uniform(0.08, 0.2); tt = t(d); f0 = rng.uniform(2800, 5200)
    s = np.sin(2 * np.pi * (f0 + 900 * np.sin(2 * np.pi * rng.uniform(12, 30) * tt)) * tt) * np.sin(np.pi * tt / d) * 0.5
    place(b, s, rng.uniform(0, 8.5))
save('birds', b, 0.5)
kd = bp(noise(7), 400, 3000) * (0.4 + 0.6 * (rng.random(7 * 12).repeat(SR // 12)[: int(SR * 7)] if True else 1))
save('kids_far', loop(kd, 0.6), 0.3)
cr = np.zeros(int(SR * 7))
for _ in range(34):
    s = hp(noise(0.02), 1500) * decay(int(SR * 0.02), 0.004) * rng.uniform(0.3, 1.0)
    place(cr, s, rng.uniform(0, 6.9))
cr += 0.12 * lp(noise(7), 200)
save('crackle', loop(cr, 0.5), 0.4)
hb = np.zeros(int(SR * 5))
for k in range(5):
    for off, a in [(0, 1.0), (0.24, 0.65)]:
        tt = t(0.22); s = np.sin(2 * np.pi * 52 * tt) * decay(len(tt), 0.07) * a
        place(hb, s, k * 1.0 + off)
save('heartbeat', hb[: int(SR * 4)], 0.7)

# ---------- ওয়ান-শট ----------
def bell(): 
    tt = t(1.8); s = sum(np.sin(2 * np.pi * f * tt) * a for f, a in [(2100, 1), (3150, 0.5), (4400, 0.3)]) * decay(len(tt), 0.35)
    return s * (0.5 + 0.5 * (np.sin(2 * np.pi * 9 * tt) > 0))
save('rickshaw_bell', bell(), 0.6)
tt = t(1.3); caw = np.zeros(len(tt))
for k in range(3):
    seg = t(0.3); f0 = 520 - 80 * k
    w = np.sign(np.sin(2 * np.pi * (f0 + 120 * np.sin(2 * np.pi * 25 * seg)) * seg)) * 0.4 + 0.6 * noise(0.3) * 0.2
    w = bp(w, 400, 2600) * np.sin(np.pi * seg / 0.3) ** 0.7
    place(caw, w, k * 0.4)
save('crow', caw, 0.6)
save('switch_click', hp(noise(0.12), 1200) * decay(int(SR * 0.12), 0.01) + np.sin(2 * np.pi * 900 * t(0.12)) * decay(int(SR * 0.12), 0.012) * 0.5, 0.6)
tt = t(0.9); save('phone_ping', (np.sin(2 * np.pi * 1320 * tt) * (tt < 0.15) + np.sin(2 * np.pi * 1760 * tt) * (tt >= 0.15) * decay(len(tt), 0.3)) * decay(len(tt), 0.4), 0.5)
save('phone_tap', hp(noise(0.08), 900) * decay(int(SR * 0.08), 0.012), 0.5)
sp = np.zeros(int(SR * 0.3)); tt = t(0.2)
sp[: len(tt)] = lp(noise(0.2), 500) * decay(len(tt), 0.04) + 0.5 * np.sin(2 * np.pi * 70 * tt) * decay(len(tt), 0.05)
save('step', sp, 0.55)
tt = t(1.8); save('door_creak', bp(np.sign(np.sin(2 * np.pi * (180 + 160 * tt / 1.8) * tt * (1 + 0.3 * np.sin(2 * np.pi * 14 * tt)))) * 0.5 + noise(1.8) * 0.15, 200, 1800) * np.sin(np.pi * tt / 1.8), 0.4)
save('water_pour', bp(noise(3.5), 600, 5000) * (0.7 + 0.3 * np.sin(2 * np.pi * 7 * t(3.5))) * env(int(SR * 3.5), 0.1, 0.3), 0.5)
tt = t(0.7); save('cup_clink', (np.sin(2 * np.pi * 3400 * tt) + 0.5 * np.sin(2 * np.pi * 5100 * tt)) * decay(len(tt), 0.12), 0.5)
tt = t(0.4); save('thunk', (np.sin(2 * np.pi * 95 * tt) * decay(len(tt), 0.06) + lp(noise(0.4), 700) * decay(len(tt), 0.03) * 0.8), 0.7)
d = 3.8; tt = t(d); f = 220 * np.exp(-tt / 0.9) + 30
pd = lp(noise(d), 500) * decay(len(tt), 1.0) * 0.6 + np.sin(2 * np.pi * np.cumsum(f) / SR) * decay(len(tt), 0.8)
pd[: int(SR * 0.02)] += 0.8
save('power_down', pd, 0.7)
tt = t(1.6); ms = hp(noise(1.6), 800) * np.where(tt < 0.35, np.sin(np.pi * tt / 0.35) ** 2, 0) + lp(noise(1.6), 900) * np.where(tt >= 0.35, 0.5 * np.exp(-(tt - 0.35) / 0.35), 0)
save('match_strike', ms, 0.5)
tt = t(1.0); save('page_turn', bp(noise(1.0), 1500, 7000) * np.sin(np.pi * tt) ** 2 * (0.6 + 0.4 * np.sin(2 * np.pi * 18 * tt)), 0.45)
ps = bp(noise(2.5), 2500, 7500) * (0.5 + 0.5 * np.abs(np.sin(2 * np.pi * 5.5 * t(2.5)))) * env(int(SR * 2.5), 0.05, 0.2)
save('pen_scratch', ps, 0.35)
save('marker_scratch', bp(noise(0.9), 1800, 6000) * (0.5 + 0.5 * np.abs(np.sin(2 * np.pi * 7 * t(0.9)))) * env(int(SR * 0.9), 0.03, 0.15), 0.4)
tt = t(2.5); a = np.zeros(len(tt))
for k in range(8):
    seg = t(0.09); place(a, np.sin(2 * np.pi * 2400 * seg) * np.sin(np.pi * seg / 0.09), 0.1 + (k % 4) * 0.12 + (k // 4) * 1.1)
save('alarm_beeps', a, 0.45)
tt = t(0.9); save('chair_scrape', bp(noise(0.9), 150, 1200) * env(int(SR * 0.9), 0.05, 0.3) * (0.6 + 0.4 * np.sin(2 * np.pi * 30 * tt)), 0.4)
tt = t(1.3); save('sheet_rustle', bp(noise(1.3), 400, 4000) * np.sin(np.pi * tt / 1.3) ** 2 * (0.5 + 0.5 * np.abs(np.sin(2 * np.pi * 6 * tt))), 0.3)
tt = t(1.9); save('sigh', bp(noise(1.9), 300, 2400) * np.sin(np.pi * tt / 1.9) ** 2 * (1 - 0.5 * tt / 1.9), 0.35)
d = 2.8; tt = t(d); save('impact', (np.sin(2 * np.pi * 42 * tt) + 0.5 * np.sin(2 * np.pi * 63 * tt)) * decay(len(tt), 0.8) + lp(noise(d), 200) * decay(len(tt), 0.3) * 0.5, 0.8)

json.dump(manifest, open(os.path.join(ROOT, 'src', 'audio', 'manifest.json'), 'w'), indent=1)
print(f'{len(manifest)} sound files -> {OUT}')
