# PROGRESS - ShitKenoAshe (শীত কেন আসে)

## 1. Project / version
- Project name: ShitKenoAshe (zip prefix: ShitKenoAsheExplainer). Current version: v01 (not rendered yet).
- 16:9, 1920x1080, 30 FPS, MP4, composition id `ShitKenoAshe`, entry `src/index.ts`.

## 2. Inputs
- Audio: শ_ত-ক_ন-আস_.mp3 (stored as public/voice.mp3), duration 310.674 s, peak about -1.3 dB (no clipping).
- SRT: 121212.srt (stored as public/subtitles/original.srt), 76 cues, last cue ends 05:10.540.
- Logo: channels4_profile.jpg (public/logo.jpg). Reference style: ChatGPTIndiaExplainer_Backup_01_100pct.zip (no SFX inside).

## 3. SRT status
- Original kept untouched. Corrected SRT: public/subtitles/corrected.srt (76 cues, same timing).
- Fixes (src/corrections.json): digits -> Bengali numerals (14/70, 15/20, 50, 3, 23, 13/36); "torchের" -> "torch-এর" (broken combining mark).
- Suspects kept as in SRT: "কর্কটক্রান্ত রেখার", "degree", "torch/torchটি", "ঘন্টা".

## 4. Color / font
- Color scheme: Frosty light (same as the supplied zip, so not asked again): bg #EEF4FA, primary #2B6CB0, accent #E07A1F, text #10233A.
- Font: Hind Siliguri (bundled).

## 5. Animation / motion decisions
- Clean flat 2D icon style: Sun, tilted Globe, orbit, torch beam, ray/footprint geometry, thermometers, day-arc with sun, Dhaka skyline, balance scale, people (winter gear / sunglasses).
- Soft spring pops only for key reveals; calm sweeps for data scenes. Word-synced captions bottom, SUL logo top-right (hidden in outro, large in outro).
- Geometry is physically consistent (axis tilt 23.5 deg, parallel axis along the orbit, beam footprint = beam / cos(angle)).

## 6. SFX
- None. The supplied zip contains no sound effects and none were invented. Voiceover is unchanged.

## 7. Scenes (23)
01 hook, 02 near, 03 tiltTease, 04 distances, 05 three, 06 australia, 07 tilt, 08 orbit, 09 junDec, 10 torch, 11 slant, 12 square, 13 winterDay, 14 summerDay, 15 balance, 16 bdGlobe, 17 dhakaJune, 18 dhakaDec, 19 australiaWhy, 20 recap, 21 truth, 22 stayed, 23 outro.
- Completed: all 23 (coded, type-checked, sampled with preview frames).
- Partial: none. Remaining: none (only the final MP4 render, waiting for the user's permission).

## 8. Workflow
- Last completed workflow step: project finished and verified, waiting for render permission.
- Done: inventory, audio/SRT analysis, storyboard, project, all scenes, type-check, smoke test (all 9351 frames, 0 errors), preview frames for every scene, fixes after visual review.
- Next: wait for the user's "রেন্ডার করো", then render, then verify MP4 (duration, resolution, fps, integrity).

## 9. Code testing
- npm install OK, `tsc --noEmit` OK, smoke test OK (9351 frames, 0 errors).
- About 60 preview stills checked visually. Two stills (251.5 s, 309.8 s) showed a faded duplicated band; re-rendering 251.5 s was clean, so it is a one-off compositing glitch of the headless test browser, not a code bug. After the final render, sample frames will be checked again.
- Not done: MP4 render (needs permission), audio-vs-subtitle check by speech recognition (not available offline).

## 10. Backups
- ShitKenoAsheExplainer_Backup_01_60pct.zip (all scenes coded, before final visual fixes).
- ShitKenoAsheExplainer_Backup_02_100pct.zip (final project, all checks done, MP4 not rendered yet).
- ShitKenoAsheExplainer_Final_v01.zip (same project as Backup 02, for running on Windows).

## 10b. Revision v02
- Added `.github/workflows/render.yml` (GitHub Actions: manual run, renders out/shit-keno-ashe.mp4 and uploads it as an artifact) and a README section. YAML syntax checked locally; the workflow itself has NOT been run on GitHub from here.
- Files: ShitKenoAsheExplainer_Final_v02.zip, ShitKenoAsheExplainer_Backup_03_100pct.zip.

## 11. Known issues
- Word-level caption timing is estimated from cue times (no speech recognition offline).
