# Shit Keno Ashe (Why does winter come?) - Remotion explainer (SUL channel)

16:9, 1920x1080, 30 FPS, MP4. Bengali voiceover (310.67 s) + in-video word-synced captions + 23 animated 2D diagram scenes + SUL channel logo.
Theme: light "Frosty" (same look as the supplied ChatGPTIndiaExplainer / WinterDawnExplainer projects): bg #EEF4FA, primary #2B6CB0, accent #E07A1F, text #10233A.
Font: Hind Siliguri (bundled in `public/fonts`, no internet needed for the font).

## Windows PC setup
1. Install Node.js LTS (v20 or v22) from https://nodejs.org . Chrome/Chromium is found or downloaded by Remotion automatically
   (internet is needed on the first run for `npm install` and, if no Chrome is found, for Remotion's own browser download).
2. Open a terminal (PowerShell or cmd) in this folder (the one that contains `package.json`).

First time only:

    npm install

Preview in Remotion Studio:

    npm run dev

Render the MP4 (output: `out/shit-keno-ashe.mp4`):

    npm run render

Composition id: `ShitKenoAshe`, entry point: `src/index.ts`.
Render a single check frame: `npm run still` (writes `out/frame.png`).

## Structure
- `public/voice.mp3` voiceover, `public/logo.jpg` SUL logo, `public/fonts/` Hind Siliguri (OFL license included)
- `public/subtitles/original.srt` (untouched) and `corrected.srt` (fixed)
- `src/sceneList.ts` scene timings + storyboard, `src/scenes/a1..a5.tsx` the 23 scenes
- `src/art/space.tsx` Sun / Globe / Thermometer / Torch / City ... , `src/art/art.tsx` people and basic icons
- `src/components/` Caption, Background, kit (Chip, Card, Ring, Cross, ...), `src/timing.json` word timing, `src/corrections.json` SRT fix log
- `scripts/build-timing.mjs` rebuilds corrected SRT + word timing from original.srt (`npm run timing`; uses `scripts/silences.json`)
- `scripts/preview-frames.mjs`, `scripts/smoke-test.tsx` optional developer checks
- `PROGRESS.md` full work log

## Original input file names
- Voiceover: `শ_ত-ক_ন-আস_.mp3` (stored as `public/voice.mp3`), SRT: `121212.srt` (stored as `public/subtitles/original.srt`), logo: `channels4_profile.jpg` (stored as `public/logo.jpg`).

## Notes
- Captions: word timing = SRT cue time spread over the speech part of each cue (pauses from ffmpeg silencedetect are skipped). No speech recognition was available, so word times are estimates; cue starts match the audio.
- SRT fixes: digits -> Bengali numerals, and "torchের" -> "torch-এর" (the original glued a Bengali vowel sign to a Latin letter, which renders as a broken dotted circle). Details in `src/corrections.json`.
- "কর্কটক্রান্ত" is kept exactly as in the SRT (the usual spelling is "কর্কটক্রান্তি"; the spoken form could not be verified).
- No sound effects were supplied, so none are used. The voiceover is untouched.

## Render on GitHub (no PC needed)
1. Create a new GitHub repository and upload the **contents** of this folder to the repository root (`package.json` and the `.github` folder must be at the top level; `node_modules` and `out` are not needed).
2. Open the repository -> **Actions** tab -> **Render video** -> **Run workflow**.
3. When the run is green, open it and download the artifact **shit-keno-ashe-mp4** (the MP4 is inside a small zip). It is kept for 30 days.
The workflow file is `.github/workflows/render.yml` (Node 22, installs the Chrome libraries, runs `npm ci`, a type check and `npm run render`).
