import React from "react";
import { theme as C } from "../theme";
import { FONT } from "../fonts";
import { cl, hash } from "../motion";

const OUT = C.text;
export const rad = (d: number) => (d * Math.PI) / 180;

/** Sun: glowing disc with slowly rotating rays. Origin = centre. */
export const Sun: React.FC<{ x: number; y: number; r?: number; t?: number; glow?: number; opacity?: number; rays?: number }> = ({
  x, y, r = 90, t = 0, glow = 1, opacity = 1, rays = 14,
}) => (
  <g transform={`translate(${x} ${y})`} opacity={opacity}>
    {glow > 0 && <circle r={r * 2.2 + Math.sin(t * 2) * r * 0.05} fill={C.gold} opacity={0.16 * glow} />}
    {glow > 0 && <circle r={r * 1.6} fill={C.gold} opacity={0.22 * glow} />}
    <g transform={`rotate(${t * 12})`}>
      {Array.from({ length: rays }).map((_, i) => (
        <path key={i} transform={`rotate(${(360 / rays) * i})`} d={`M ${-r * 0.17} ${-r * 1.1} L 0 ${-r * 1.5} L ${r * 0.17} ${-r * 1.1} Z`} fill={C.warn} stroke={OUT} strokeWidth={3} strokeLinejoin="round" />
      ))}
    </g>
    <circle r={r} fill={C.gold} stroke={OUT} strokeWidth={4} />
    <circle r={r * 0.7} fill={C.warn} opacity={0.3} />
  </g>
);

/** Projects (lat, lon) in degrees on a globe of radius r, then applies the axis tilt (deg, + = top leans right). */
export const globePoint = (r: number, lat: number, lon: number, tilt: number) => {
  const x0 = r * Math.cos(rad(lat)) * Math.sin(rad(lon));
  const y0 = -r * Math.sin(rad(lat));
  const a = rad(tilt);
  return { x: x0 * Math.cos(a) - y0 * Math.sin(a), y: x0 * Math.sin(a) + y0 * Math.cos(a) };
};

/** Teardrop map pin. Tip at (0,0). */
export const PinMarker: React.FC<{ x: number; y: number; s?: number; color?: string }> = ({ x, y, s = 1, color = C.accent }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <path d="M 0 0 C -6 -14 -22 -26 -22 -44 A 22 22 0 0 1 22 -44 C 22 -26 6 -14 0 0 Z" fill={color} stroke={OUT} strokeWidth={4} strokeLinejoin="round" />
    <circle cx={0} cy={-44} r={8} fill="#fff" />
  </g>
);

export type GlobeProps = {
  x: number; y: number; r?: number; tilt?: number; id: string; t?: number; spin?: number;
  axis?: number; shade?: "left" | "right" | null; view?: number; lines?: number[]; opacity?: number;
  pins?: { lat: number; lon: number; color?: string; s?: number; p?: number }[];
  face?: number | null;
};

/** Icon-style globe: ocean ball, grid, tilted axis, optional night side and map pins. Origin = centre. */
export const Globe: React.FC<GlobeProps> = ({ x, y, r = 120, tilt = 0, id, t = 0, spin = 0, axis = 0, shade = null, view = 0.24, lines = [], opacity = 1, pins = [], face = null }) => {
  const lat = [-60, -30, 30, 60];
  const merid = [0, 1, 2, 3, 4, 5];
  return (
    <g transform={`translate(${x} ${y})`} opacity={opacity}>
      <defs><clipPath id={`gc-${id}`}><circle r={r} /></clipPath></defs>
      <g transform={`rotate(${tilt})`}>
        <circle r={r} fill={C.flow} stroke={OUT} strokeWidth={5} />
        <g clipPath={`url(#gc-${id})`}>
          <ellipse cx={-r * 0.32} cy={-r * 0.34} rx={r * 0.55} ry={r * 0.36} fill="#fff" opacity={0.16} transform={`rotate(-30 ${-r * 0.32} ${-r * 0.34})`} />
          <g fill="none" stroke="#fff" strokeWidth={2.5} opacity={0.55}>
            <ellipse cx={0} cy={0} rx={r} ry={r * view} />
            {lat.map((la) => {
              const rx = r * Math.cos(rad(la));
              return <ellipse key={la} cx={0} cy={-r * Math.sin(rad(la))} rx={rx} ry={rx * view} />;
            })}
            {merid.map((k) => {
              const phi = rad(((t * spin + k * 30) % 180) * 1);
              return <ellipse key={k} cx={0} cy={0} rx={Math.abs(Math.sin(phi)) * r} ry={r} />;
            })}
          </g>
          {lines.map((la) => {
            const rx = r * Math.cos(rad(la));
            return <ellipse key={la} cx={0} cy={-r * Math.sin(rad(la))} rx={rx} ry={rx * view} fill="none" stroke={C.accent} strokeWidth={5} strokeDasharray="14 9" />;
          })}
        </g>
        <circle r={r} fill="none" stroke={OUT} strokeWidth={5} />
        {axis > 0 && (
          <g opacity={axis}>
            <line x1={0} y1={-r * 1.42} x2={0} y2={r * 1.42} stroke={C.accent} strokeWidth={6} strokeDasharray="16 10" strokeLinecap="round" />
            <circle cx={0} cy={-r * 1.42} r={9} fill={C.accent} stroke={OUT} strokeWidth={3} />
            <circle cx={0} cy={r * 1.42} r={9} fill={C.accent} stroke={OUT} strokeWidth={3} />
          </g>
        )}
      </g>
      {shade && (
        <g clipPath={`url(#gc-${id})`}>
          <path d={shade === "right" ? `M 0 ${-r} A ${r} ${r} 0 0 1 0 ${r} A ${r * 0.4} ${r} 0 0 0 0 ${-r} Z` : `M 0 ${-r} A ${r} ${r} 0 0 0 0 ${r} A ${r * 0.4} ${r} 0 0 1 0 ${-r} Z`} fill={C.night} opacity={0.3} />
        </g>
      )}
      {face !== null && (
        <g>
          <circle cx={-r * 0.3 + face * r * 0.5} cy={-r * 0.1} r={r * 0.09} fill={OUT} />
          <circle cx={r * 0.16 + face * r * 0.5} cy={-r * 0.1} r={r * 0.09} fill={OUT} />
          <path d={`M ${-r * 0.08 + face * r * 0.5} ${r * 0.14} q ${r * 0.12} ${r * 0.12} ${r * 0.24} 0`} stroke={OUT} strokeWidth={5} fill="none" strokeLinecap="round" />
        </g>
      )}
      {pins.map((p, i) => {
        const q = globePoint(r, p.lat, p.lon, tilt);
        const pp = p.p ?? 1;
        if (pp <= 0) return null;
        return <PinMarker key={i} x={x * 0 + q.x} y={q.y - (1 - pp) * 40} s={(p.s ?? 1) * pp} color={p.color} />;
      })}
    </g>
  );
};

/** Thermometer. Origin = bottom centre of the bulb. level 0..1. */
export const Thermo: React.FC<{ x: number; y: number; h?: number; level: number; color?: string; s?: number; opacity?: number }> = ({ x, y, h = 260, level, color, s = 1, opacity = 1 }) => {
  const col = color ?? (level > 0.55 ? C.bad : C.flow);
  const tube = h - 40;
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} opacity={opacity}>
      <rect x={-16} y={-h} width={32} height={h - 20} rx={16} fill="#fff" stroke={OUT} strokeWidth={4} />
      <circle cx={0} cy={-22} r={32} fill="#fff" stroke={OUT} strokeWidth={4} />
      <rect x={-8} y={-(tube * cl(level) + 30)} width={16} height={tube * cl(level) + 30} rx={8} fill={col} />
      <circle cx={0} cy={-22} r={22} fill={col} />
      {[0.25, 0.5, 0.75].map((q) => <line key={q} x1={16} y1={-30 - tube * q} x2={30} y2={-30 - tube * q} stroke={OUT} strokeWidth={3} strokeLinecap="round" />)}
    </g>
  );
};

export const Snowflake: React.FC<{ x: number; y: number; r?: number; rot?: number; opacity?: number; color?: string }> = ({ x, y, r = 26, rot = 0, opacity = 1, color = "#fff" }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot})`} opacity={opacity} stroke={color} strokeWidth={Math.max(3, r / 6)} strokeLinecap="round" fill="none">
    {[0, 60, 120].map((a) => (
      <g key={a} transform={`rotate(${a})`}>
        <line x1={0} y1={-r} x2={0} y2={r} />
        <path d={`M ${-r * 0.3} ${-r * 0.7} L 0 ${-r * 0.42} L ${r * 0.3} ${-r * 0.7}`} />
        <path d={`M ${-r * 0.3} ${r * 0.7} L 0 ${r * 0.42} L ${r * 0.3} ${r * 0.7}`} />
      </g>
    ))}
  </g>
);

/** Snowflake with dark outline so it reads on a light background. */
export const SnowIcon: React.FC<{ x: number; y: number; r?: number; rot?: number; opacity?: number }> = ({ x, y, r = 26, rot = 0, opacity = 1 }) => (
  <g opacity={opacity}>
    <Snowflake x={x} y={y} r={r} rot={rot} color={OUT} />
    <Snowflake x={x} y={y} r={r * 0.98} rot={rot} color={C.flow} />
  </g>
);

/** Torch (flashlight) pointing along +x. Pivot / handle end at (0,0). Length ~170. */
export const Torch: React.FC<{ x: number; y: number; rot?: number; s?: number; on?: boolean }> = ({ x, y, rot = 0, s = 1, on = true }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <rect x={0} y={-20} width={110} height={40} rx={12} fill={C.night} stroke={OUT} strokeWidth={4} />
    <rect x={26} y={-20} width={10} height={40} fill={C.muted} />
    <path d="M 108 -22 L 150 -38 L 150 38 L 108 22 Z" fill={C.warn} stroke={OUT} strokeWidth={4} strokeLinejoin="round" />
    <ellipse cx={150} cy={0} rx={9} ry={38} fill={on ? C.gold : C.tint} stroke={OUT} strokeWidth={4} />
  </g>
);

/** Brick wall. x,y = top-left. */
export const Wall: React.FC<{ x: number; y: number; w: number; h: number }> = ({ x, y, w, h }) => {
  const rows = Math.floor(h / 56);
  return (
    <g>
      <rect x={x} y={y} width={w} height={h} fill={C.tint} stroke={OUT} strokeWidth={5} />
      {Array.from({ length: rows }).map((_, i) => (
        <g key={i} stroke={C.muted} strokeWidth={3} opacity={0.55}>
          <line x1={x} y1={y + (i + 1) * 56} x2={x + w} y2={y + (i + 1) * 56} />
          <line x1={x + (i % 2 ? w * 0.3 : w * 0.65)} y1={y + i * 56} x2={x + (i % 2 ? w * 0.3 : w * 0.65)} y2={y + (i + 1) * 56} />
        </g>
      ))}
    </g>
  );
};

/** Generic city skyline standing on y (ground). Buildings between x0..x1. */
export const City: React.FC<{ y: number; x0?: number; x1?: number; seed?: number; t?: number; opacity?: number }> = ({ y, x0 = 120, x1 = 1000, seed = 3, t = 0, opacity = 1 }) => {
  const items: React.ReactNode[] = [];
  let cx = x0, i = 0;
  while (cx < x1 - 40) {
    const w = 80 + hash(i + seed) * 70;
    const h = 120 + hash(i * 2 + seed + 7) * 200;
    if (hash(i + seed * 3) > 0.78) {
      // tree
      items.push(<g key={i}><rect x={cx + w / 2 - 7} y={y - 70} width={14} height={70} fill={C.skin} stroke={OUT} strokeWidth={3} /><circle cx={cx + w / 2} cy={y - 100} r={46} fill={C.good} stroke={OUT} strokeWidth={4} /></g>);
      cx += w * 0.9;
    } else {
      const cols = Math.max(1, Math.floor(w / 40)), rows = Math.max(2, Math.floor((h - 50) / 54));
      items.push(
        <g key={i}>
          <rect x={cx} y={y - h} width={w} height={h} fill={i % 2 ? C.surface : C.tint} stroke={OUT} strokeWidth={4} />
          {Array.from({ length: cols * rows }).map((_, k) => {
            const c = k % cols, rr = Math.floor(k / cols);
            const lit = hash(k * 5 + i * 11 + seed) > 0.8 + Math.sin(t) * 0.0;
            return <rect key={k} x={cx + 12 + c * ((w - 24) / cols)} y={y - h + 18 + rr * 54} width={(w - 24) / cols - 10} height={30} rx={4} fill={lit ? C.gold : "#fff"} stroke={OUT} strokeWidth={2} />;
          })}
        </g>,
      );
      cx += w + 14;
    }
    i++;
  }
  return <g opacity={opacity}>{items}</g>;
};

/** Spinning top (লাটিম). Origin = tip on the ground. */
export const Top: React.FC<{ x: number; y: number; s?: number; t?: number }> = ({ x, y, s = 1, t = 0 }) => (
  <g transform={`translate(${x} ${y}) scale(${s}) rotate(${Math.sin(t * 5) * 4})`}>
    <ellipse cx={0} cy={4} rx={70} ry={10} fill="rgba(16,35,58,0.14)" />
    <path d="M -80 -150 L 80 -150 L 0 0 Z" fill={C.accent} stroke={OUT} strokeWidth={5} strokeLinejoin="round" />
    <path d={`M ${-56 + Math.sin(t * 9) * 14} -150 L ${-36 + Math.sin(t * 9) * 14} -80`} stroke="#fff" strokeWidth={8} strokeLinecap="round" opacity={0.7} />
    <rect x={-80} y={-170} width={160} height={26} rx={13} fill={C.warn} stroke={OUT} strokeWidth={5} />
    <rect x={-9} y={-232} width={18} height={66} rx={9} fill={C.night} stroke={OUT} strokeWidth={4} />
  </g>
);

/** Scarf + woolly hat drawn over a Person at the same transform (person local space). */
export const WinterGear: React.FC = () => (
  <g>
    <path d="M -40 -250 Q 0 -232 40 -250 L 40 -228 Q 0 -212 -40 -228 Z" fill={C.accent} stroke={OUT} strokeWidth={4} strokeLinejoin="round" />
    <rect x={10} y={-236} width={22} height={64} rx={9} fill={C.accent} stroke={OUT} strokeWidth={4} />
    <path d="M -40 -290 A 40 38 0 0 1 40 -290 L 40 -276 L -40 -276 Z" fill={C.bad} stroke={OUT} strokeWidth={4} strokeLinejoin="round" />
    <rect x={-44} y={-282} width={88} height={14} rx={7} fill={C.surface} stroke={OUT} strokeWidth={3} />
    <circle cx={0} cy={-332} r={12} fill={C.surface} stroke={OUT} strokeWidth={3} />
  </g>
);

/** Sunglasses overlay for a summer Person. */
export const Shades: React.FC = () => (
  <g>
    <rect x={-24} y={-282} width={22} height={14} rx={5} fill={OUT} />
    <rect x={2} y={-282} width={22} height={14} rx={5} fill={OUT} />
    <line x1={-2} y1={-276} x2={2} y2={-276} stroke={OUT} strokeWidth={4} />
  </g>
);

/** Soft energy dots moving along a straight line from (x1,y1) to (x2,y2). */
export const Flow: React.FC<{ x1: number; y1: number; x2: number; y2: number; t: number; n?: number; speed?: number; r?: number; color?: string; opacity?: number }> = ({
  x1, y1, x2, y2, t, n = 6, speed = 0.5, r = 7, color = C.accent, opacity = 1,
}) => (
  <g opacity={opacity}>
    {Array.from({ length: n }).map((_, i) => {
      const p = (t * speed + i / n) % 1;
      return <circle key={i} cx={x1 + (x2 - x1) * p} cy={y1 + (y2 - y1) * p} r={r} fill={color} stroke={OUT} strokeWidth={2} opacity={Math.min(1, p * 5, (1 - p) * 5)} />;
    })}
  </g>
);

/** A day arc over the horizon (half-ellipse). */
export const dayArcPath = (cx: number, base: number, rw: number, h: number) => `M ${cx - rw} ${base} A ${rw} ${h} 0 0 1 ${cx + rw} ${base}`;
export const sunOnArc = (cx: number, base: number, rw: number, h: number, u: number) => ({ x: cx + u * rw, y: base - h * Math.sqrt(Math.max(0, 1 - u * u)) });

/** Pie clock: ring with a coloured arc covering `frac` (0..1) of the circle, starting at 12 o'clock. */
export const PieClock: React.FC<{ x: number; y: number; r?: number; frac: number; color?: string }> = ({ x, y, r = 56, frac, color = C.accent }) => {
  const f = cl(frac, 0, 0.999);
  const a = f * Math.PI * 2;
  const ex = r * Math.sin(a), ey = -r * Math.cos(a);
  return (
    <g transform={`translate(${x} ${y})`}>
      <circle r={r + 8} fill="#fff" stroke={OUT} strokeWidth={5} />
      <circle r={r} fill={C.tint} />
      {f > 0.002 && <path d={`M 0 0 L 0 ${-r} A ${r} ${r} 0 ${f > 0.5 ? 1 : 0} 1 ${ex} ${ey} Z`} fill={color} />}
      <circle r={5} fill={OUT} />
    </g>
  );
};

export const Txt: React.FC<{ x: number; y: number; text: string; size?: number; color?: string; anchor?: "start" | "middle" | "end" }> = ({ x, y, text, size = 34, color = C.text, anchor = "middle" }) => (
  <text x={x} y={y} textAnchor={anchor} fontFamily={FONT} fontWeight={700} fontSize={size} fill={color}>{text}</text>
);
