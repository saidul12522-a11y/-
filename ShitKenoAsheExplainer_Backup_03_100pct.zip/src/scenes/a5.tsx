import React from "react";
import { staticFile } from "remotion";
import { FONT } from "../fonts";
import { theme as C } from "../theme";
import { Svg, SceneProps, W, GROUND, Measure } from "./common";
import { In, Chip, Ring, Cross, Check, Card, Label } from "../components/kit";
import { Sun, Globe, Thermo, Flow, PieClock, dayArcPath, Txt, rad } from "../art/space";
import { prog, pop, lerp, INOUT } from "../motion";
import { Dressed } from "./a2";

/** 256.0-272.9  Australia: in December the south leans toward the sun -> summer there */
export const SceneAustraliaWhy: React.FC<SceneProps> = ({ t }) => {
  const tAus = W("অস্ট্রেলিয়ার"), tDec = W("ডিসেম্বর", 259), tSouth = W("দক্ষিণ", 260), tStraight = W("সোজা", 265), tBig = W("বড়", 267), tBd = W("বাংলাদেশে", 268), tAusEnd = W("অস্ট্রেলিয়ায়", 270);
  const CX = 1000, CY = 490, R = 250, SX = 400;
  const edgeX = (y: number) => CX - Math.sqrt(Math.max(0, R * R - (y - CY) * (y - CY)));
  const ys = [CY - 45, CY, CY + 45];
  const p = prog(t, tStraight - 0.4, tStraight + 0.6);
  return (
    <Svg>
      <Sun x={210} y={CY} r={100} t={t} />
      <In t={t} cue={256.2}><Globe x={CX} y={CY} r={R} tilt={23.5} axis={1} shade="right" id="au" t={t}
        pins={[{ lat: 24, lon: -12, p: pop(t, tBd - 0.5, "snap") }, { lat: -27, lon: 20, p: pop(t, tAus + 0.2, "snap") }]} /></In>
      <In t={t} cue={tAus}><line x1={1050} y1={620} x2={1215} y2={690} stroke={C.data} strokeWidth={4} strokeDasharray="8 8" /><Chip x={1340} y={700} text="অস্ট্রেলিয়া" color={C.data} size={28} /></In>
      <In t={t} cue={tDec}><Chip x={560} y={200} text="ডিসেম্বর" color={C.flow} size={28} /></In>
      <In t={t} cue={tSouth}><Chip x={560} y={290} text="দক্ষিণ গোলার্ধ সূর্যের দিকে" color={C.accent} size={26} /></In>
      <g opacity={p}>
        {ys.map((y, i) => <line key={i} x1={SX} y1={y} x2={SX + (edgeX(y) - SX) * p} y2={y} stroke={C.warn} strokeWidth={6} strokeLinecap="round" />)}
        <Flow x1={SX} y1={CY} x2={edgeX(CY)} y2={CY} t={t} n={5} />
        <line x1={edgeX(ys[0])} y1={ys[0]} x2={edgeX(ys[2])} y2={ys[2]} stroke={C.accent} strokeWidth={14} strokeLinecap="round" />
      </g>
      <In t={t} cue={tStraight}><Chip x={620} y={600} text="সোজা আলো" color={C.warn} size={28} /></In>
      <In t={t} cue={tBig}><Chip x={1400} y={500} text="দিন বড়" color={C.accent} size={28} /></In>
      <In t={t} cue={tBd}><Chip x={1620} y={215} text="বাংলাদেশে শীত" color={C.flow} size={28} /></In>
      <In t={t} cue={tBd + 0.2}><Dressed x={1620} y={440} s={0.62} kind="cold" t={t} /></In>
      <In t={t} cue={tAusEnd}><Chip x={1620} y={545} text="অস্ট্রেলিয়ায় গ্রীষ্ম" color={C.accent} size={28} /></In>
      <In t={t} cue={tAusEnd + 0.2}><Dressed x={1620} y={780} s={0.62} kind="sun" t={t} /></In>
    </Svg>
  );
};

/** 272.9-281.0  Recap: tilt, angle of light, length of day */
export const SceneRecap: React.FC<SceneProps> = ({ t }) => {
  const t1 = W("অক্ষের", 275), t2 = W("আলোর", 277), t3 = W("দিনের", 278.5);
  const cards = [{ x: 100, c: t1 }, { x: 700, c: t2 }, { x: 1300, c: t3 }];
  const Y = 230, H = 450, Wd = 520;
  return (
    <Svg>
      {cards.map((c, i) => (
        <In key={i} t={t} cue={273.3 + i * 0.15} dy={40}>
          <Card x={c.x} y={Y} w={Wd} h={H} color={C.border} />
        </In>
      ))}
      {/* 1: tilt */}
      <In t={t} cue={t1}><Globe x={360} y={Y + 190} r={100} tilt={23.5} axis={1} id="rc1" t={t} /></In>
      <In t={t} cue={t1}><Txt x={360} y={Y + 410} text="অক্ষের হেলে থাকা" size={36} /></In>
      {/* 2: light angle */}
      <In t={t} cue={t2}>
        <line x1={780} y1={Y + 340} x2={1140} y2={Y + 340} stroke={C.text} strokeWidth={5} />
        <rect x={900} y={Y + 340} width={120} height={26} fill={C.accent} stroke={C.text} strokeWidth={4} />
        <Sun x={800} y={Y + 80} r={34} t={t} glow={0} />
        {[0, 1, 2].map((i) => <Flow key={i} x1={860 + i * 36} y1={Y + 90 + i * 20 - 40} x2={900 + i * 56} y2={Y + 335} t={t + i * 0.2} n={3} speed={0.4} />)}
      </In>
      <In t={t} cue={t2}><Txt x={960} y={Y + 410} text="সূর্যের আলোর কোণ" size={36} /></In>
      {/* 3: day length */}
      <In t={t} cue={t3}>
        <path d={dayArcPath(1560, Y + 340, 190, 220)} fill="none" stroke={C.muted} strokeWidth={5} strokeDasharray="4 14" strokeLinecap="round" />
        <path d={dayArcPath(1560, Y + 340, 120, 110)} fill="none" stroke={C.accent} strokeWidth={9} strokeLinecap="round" />
        <line x1={1340} y1={Y + 340} x2={1780} y2={Y + 340} stroke={C.text} strokeWidth={5} />
      </In>
      <In t={t} cue={t3}><Txt x={1560} y={Y + 410} text="দিনের দৈর্ঘ্যের পরিবর্তন" size={34} /></In>
    </Svg>
  );
};

/** 281.0-294.6  Not "the sun went away": the north leans away -> weaker heating and shorter days */
export const SceneTruth: React.FC<SceneProps> = ({ t }) => {
  const tNo = W("আসে", 282), tNot = W("না", 282.5), tBorong = W("বরং"), tLean = W("হেলে", 288), tLess = W("কম", 290), tDay = W("দিনও", 292), tOk = W("যায়।", 293);
  return (
    <Svg>
      <In t={t} cue={281.3}><Card x={100} y={200} w={820} h={540} color={C.border} /></In>
      <In t={t} cue={281.6}>
        <Sun x={250} y={470} r={60} t={t} glow={0.5} />
        <Measure x1={340} x2={650} y={470} p={prog(t, 283.3, 284.3, INOUT)} color={C.data} dash />
      </In>
      <In t={t} cue={283.3}><Globe x={760} y={470} r={60} id="tr1" t={t} /></In>
      <In t={t} cue={281.6}><Chip x={510} y={290} text="সূর্য দূরে চলে যাওয়া" color={C.muted} size={28} /></In>
      <Cross x={510} y={600} t={t} cue={tNot} s={2.2} />
      <In t={t} cue={tBorong - 0.3}><Card x={1000} y={200} w={820} h={540} color={C.border} /></In>
      <In t={t} cue={tBorong}><Sun x={1100} y={450} r={46} t={t} glow={0} /></In>
      <In t={t} cue={tBorong}><Globe x={1370} y={450} r={110} tilt={23.5 * pop(t, tLean - 0.3, "soft")} axis={1} shade="right" id="tr2" t={t} /></In>
      <In t={t} cue={tBorong}><Chip x={1410} y={285} text="উত্তর অংশ বিপরীতে হেলে" color={C.accent} size={26} /></In>
      <In t={t} cue={tLess}><Thermo x={1660} y={680} h={220} level={0.2} /></In>
      <In t={t} cue={tLess}><Chip x={1520} y={650} text="কম তাপ" color={C.flow} size={28} /></In>
      <In t={t} cue={tDay}><PieClock x={1130} y={620} r={46} frac={0.3} /></In>
      <In t={t} cue={tDay}><Chip x={1290} y={650} text="ছোট দিন" color={C.flow} size={28} /></In>
      <Check x={1740} y={250} t={t} cue={tOk} s={1.3} />
    </Svg>
  );
};

/** 294.6-301.5  The sun did not leave; the earth just turns its face away for a while */
export const SceneStayed: React.FC<SceneProps> = ({ t }) => {
  const tStay = W("ছেড়ে"), tTime = W("নির্দিষ্ট"), tFace = W("মুখ");
  const turn = prog(t, tFace - 0.2, tFace + 1.0, INOUT);
  const ex = 1250;
  return (
    <Svg>
      <Sun x={330} y={490} r={130} t={t} glow={1.2} />
      <Measure x1={500} x2={ex - 170} y={490} p={prog(t, 295.0, 295.8)} color={C.data} dash />
      <Flow x1={500} y1={490} x2={ex - 170} y2={490} t={t} n={6} opacity={prog(t, 295.4, 296)} />
      <In t={t} cue={tStay} dy={20}><Chip x={820} y={400} text="ছেড়ে যায়নি" color={C.good} size={32} /></In>
      <In t={t} cue={295.0}><Globe x={ex} y={490} r={150} id="st" t={t} tilt={23.5 * turn} axis={turn} shade="right" face={lerp(-0.45, 0.6, turn)} /></In>
      <In t={t} cue={tTime}><Chip x={ex} y={270} text="নির্দিষ্ট সময়ে" color={C.flow} size={28} /></In>
      <In t={t} cue={tFace}><Chip x={ex} y={730} text="একটু মুখ ফিরিয়ে" color={C.accent} size={30} /></In>
    </Svg>
  );
};

/** 301.5-end  Outro: logo, like, comment, subscribe */
export const SceneOutro: React.FC<SceneProps> = ({ t }) => {
  const tLike = W("লাইক"), tCom = W("কমেন্ট"), tSub = W("সাবস্ক্রাইব");
  const bell = Math.sin(t * 18) * 10 * (prog(t, tSub + 0.1, tSub + 0.3) * (1 - prog(t, tSub + 1.8, tSub + 2.0)));
  return (
    <Svg>
      <In t={t} cue={301.7} dy={40}>
        <rect x={150} y={220} width={560} height={560} rx={48} fill="#fff" stroke={C.border} strokeWidth={3} />
        <image href={staticFile("logo.jpg")} x={160} y={230} width={540} height={540} preserveAspectRatio="xMidYMid meet" />
      </In>
      <In t={t} cue={tLike} dy={50}>
        <rect x={860} y={250} width={380} height={120} rx={60} fill={C.surface} stroke={C.data} strokeWidth={4} />
        <path d="M 920 335 L 920 295 L 950 295 L 965 262 Q 985 262 982 285 L 982 295 L 1020 295 Q 1034 296 1030 312 L 1022 335 Z" fill={C.data} stroke={C.text} strokeWidth={3} strokeLinejoin="round" />
        <Label x={1135} y={332} text="লাইক" size={42} color={C.text} />
      </In>
      <In t={t} cue={tCom} dy={50}>
        <rect x={860} y={420} width={380} height={120} rx={60} fill={C.surface} stroke={C.good} strokeWidth={4} />
        <path d="M 915 475 Q 915 440 950 440 L 995 440 Q 1030 440 1030 475 Q 1030 505 995 505 L 960 505 L 935 525 L 940 505 Q 915 505 915 475 Z" fill={C.good} stroke={C.text} strokeWidth={3} strokeLinejoin="round" />
        <Label x={1135} y={492} text="কমেন্ট" size={42} color={C.text} />
      </In>
      <In t={t} cue={tSub - 0.4} dy={50}>
        <rect x={860} y={590} width={640} height={130} rx={65} fill={C.bad} stroke={C.text} strokeWidth={4} />
        <g transform={`translate(950 655) rotate(${bell})`}>
          <path d="M -26 14 Q -26 -34 0 -34 Q 26 -34 26 14 L 36 26 L -36 26 Z" fill="#fff" stroke={C.text} strokeWidth={3} />
          <circle cx={0} cy={36} r={8} fill="#fff" stroke={C.text} strokeWidth={3} />
        </g>
        <text x={1215} y={668} textAnchor="middle" fontSize={50} fontWeight={700} fontFamily={FONT} fill="#fff">সাবস্ক্রাইব</text>
      </In>
      <In t={t} cue={302.2}><Sun x={1640} y={440} r={80} t={t} glow={0.8} /></In>
    </Svg>
  );
};
