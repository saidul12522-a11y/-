import React from "react";
import { FONT } from "../fonts";
import { theme as C } from "../theme";
import { Svg, SceneProps, W, Measure, Tick, track } from "./common";
import { In, Chip, Ring, Cross, Label, bn } from "../components/kit";
import { Sun, Globe, SnowIcon, Thermo, Txt } from "../art/space";
import { Magnifier } from "../art/art";
import { prog, pop, lerp, INOUT, SMOOTH } from "../motion";

/** a ring of snowflakes around a globe centre */
const SnowRing: React.FC<{ x: number; y: number; r: number; t: number; cue: number }> = ({ x, y, r, t, cue }) => (
  <g>
    {[0, 1, 2, 3, 4].map((i) => {
      const a = (i / 5) * Math.PI * 2 - 0.6;
      const p = pop(t, cue + i * 0.12, "snap");
      if (p <= 0) return null;
      return <SnowIcon key={i} x={x + Math.cos(a) * r * 1.5} y={y + Math.sin(a) * r * 1.4 + Math.sin(t * 2 + i) * 5} r={22 * p} rot={t * 20 + i * 30} />;
    })}
  </g>
);

/** 0-8.9  Hook: why does winter come? myth = the sun moves away */
export const SceneHook: React.FC<SceneProps> = ({ t }) => {
  const tMany = W("অনেকেই"), tAway = W("দূরে", 4), tCold = W("ঠান্ডা", 5), tOk = W("যুক্তিসঙ্গত");
  const ex = lerp(880, 1500, prog(t, tAway, tAway + 1.5, INOUT));
  const q = Math.sin(t * 5) * 8;
  const thermo = track(t, [tCold, tCold + 1.6], [0.75, 0.15]);
  return (
    <Svg>
      <Sun x={300} y={480} r={130} t={t} />
      <In t={t} cue={0.25} out={2.5}>
        <text x={1250} y={560 + q} textAnchor="middle" fontSize={280} fontWeight={700} fontFamily={FONT} fill={C.accent} stroke={C.text} strokeWidth={6}>?</text>
      </In>
      <In t={t} cue={tMany} dy={30}><Chip x={960} y={250} text="অনেকের ধারণা" color={C.muted} size={28} /></In>
      <In t={t} cue={2.9} dx={0} dy={30}><Globe x={ex} y={480} r={88} id="h1" t={t} /></In>
      <Measure x1={540} x2={ex - 110} y={480} p={prog(t, tAway - 0.2, tAway + 1.5, INOUT)} color={C.data} dash />
      <In t={t} cue={tAway}><Chip x={(540 + ex - 110) / 2} y={580} text="দূরে চলে যায়" color={C.data} size={26} /></In>
      {t >= tCold && <SnowRing x={ex} y={480} r={88} t={t} cue={tCold} />}
      <In t={t} cue={tCold}><Thermo x={1740} y={760} h={300} level={thermo} /></In>
      <In t={t} cue={tOk}><Chip x={960} y={800} text="শুনতে যুক্তিসঙ্গত" color={C.warn} size={26} icon={<Tick x={0} y={0} s={0.9} />} /></In>
    </Svg>
  );
};

/** 8.9-20.4  Truth: in winter we are NEAREST to the sun, so why is it cold? */
export const SceneNear: React.FC<SceneProps> = ({ t }) => {
  const tBut = W("কিন্তু", 8), tWinter = W("শীতকাল,", 10), tThen = W("তখন", 11.5), tNear = W("সবচেয়ে", 13), tWhy = W("কেন?", 19);
  const ex = lerp(1500, 860, prog(t, tThen, tThen + 1.8, INOUT));
  const gl = track(t, [15.5, 17.5], [1, 1.5]);
  return (
    <Svg>
      <Sun x={300} y={480} r={130} t={t} glow={gl} />
      <In t={t} cue={tBut - 0.3} out={10.6} dy={0}>
        <Chip x={1100} y={250} text="সূর্য দূরে চলে যায়" color={C.muted} size={28} />
        <Cross x={1100} y={250} t={t} cue={tBut + 0.2} s={1.5} />
      </In>
      <Globe x={ex} y={480} r={88} id="n1" t={t} />
      <Measure x1={540} x2={ex - 110} y={480} p={1} color={C.data} dash />
      <In t={t} cue={tWinter}><Chip x={ex} y={265} text="শীতকাল" color={C.flow} size={28} /></In>
      {t >= tWinter && <SnowRing x={ex} y={480} r={88} t={t} cue={tWinter} />}
      {t >= tNear && t < tNear + 0.3 + 1.2 && <Ring x={ex} y={480} t={t} cue={tNear + 0.4} r={90} />}
      <In t={t} cue={tNear}><Chip x={(540 + ex - 110) / 2} y={580} text="সবচেয়ে কাছে" color={C.accent} size={28} /></In>
      <In t={t} cue={17.6}><Thermo x={1580} y={760} h={300} level={0.15} /></In>
      <In t={t} cue={tWhy} out={20.4}>
        <text x={1260} y={560 + Math.sin(t * 5) * 8} textAnchor="middle" fontSize={280} fontWeight={700} fontFamily={FONT} fill={C.accent} stroke={C.text} strokeWidth={6}>?</text>
      </In>
    </Svg>
  );
};

/** 20.4-32.9  The answer hides in the tilt; first we check how much the distance matters */
export const SceneTiltTease: React.FC<SceneProps> = ({ t }) => {
  const tTilt = W("হেলে", 22), tSun = W("সূর্য", 27), tDist = W("দূরত্ব", 28), tWhat = W("কতটা", 29), tLook = W("দেখে", 31.5);
  const tilt = 23.5 * pop(t, tTilt, "soft");
  const mv = prog(t, 24.5, 26.3, INOUT);
  const gx = lerp(960, 1500, mv), gr = lerp(190, 90, mv);
  const axis = prog(t, 21.2, 21.8);
  const ruler = prog(t, tDist - 0.2, tDist + 0.9, INOUT);
  return (
    <Svg>
      <Globe x={gx} y={480} r={gr} tilt={tilt} id="t1" t={t} axis={axis * (1 - prog(t, 24.5, 25.2))} />
      <In t={t} cue={tTilt} out={24.6}><Chip x={1330} y={290} text="হেলে থাকা" color={C.accent} size={30} /></In>
      <In t={t} cue={tSun}><Sun x={250} y={480} r={100} t={t} /></In>
      <Measure x1={400} x2={gx - gr - 20} y={480} p={ruler} color={C.data} />
      <In t={t} cue={tDist}><Chip x={(400 + gx - gr) / 2} y={400} text="দূরত্ব" color={C.data} size={30} /></In>
      <In t={t} cue={tWhat}><Chip x={(400 + gx - gr) / 2} y={600} text="কতটা গুরুত্বপূর্ণ?" color={C.accent} size={28} /></In>
      <In t={t} cue={tLook}><Magnifier x={900} y={500} s={2.2} rot={-10} /></In>
    </Svg>
  );
};

/** 32.9-48.2  January vs July distance */
export const SceneDistances: React.FC<SceneProps> = ({ t }) => {
  const tJan = W("জানুয়ারিতে"), tJanV = W("১৪"), tJul = W("জুলাইয়ে"), tJulV = W("১৫"), tDiff = W("পার্থক্য", 45), tDiffV = W("৫০");
  const rowJ = 350, rowL = 600;
  const jx = 330 + 1208, lx = 330 + 1250;
  const pJ = prog(t, tJan, tJan + 1.6, INOUT), pL = prog(t, tJul, tJul + 1.6, INOUT);
  return (
    <Svg>
      <Sun x={170} y={475} r={150} t={t} />
      {/* January row */}
      <In t={t} cue={tJan - 0.1}><Chip x={470} y={rowJ - 62} text="জানুয়ারি" color={C.flow} size={28} /></In>
      <Measure x1={300} x2={jx - 70} y={rowJ} p={pJ} color={C.data} dash />
      {pJ > 0.8 && <g opacity={prog(t, tJan + 1.2, tJan + 1.5)}><Globe x={jx} y={rowJ} r={62} id="d1" t={t} /></g>}
      <In t={t} cue={tJanV}><Chip x={960} y={rowJ - 62} text="১৪ কোটি ৭০ লাখ কিলোমিটার" color={C.data} size={28} /></In>
      {/* July row */}
      <In t={t} cue={tJul - 0.1}><Chip x={470} y={rowL - 62} text="জুলাই" color={C.warn} size={28} /></In>
      <Measure x1={300} x2={lx - 70} y={rowL} p={pL} color={C.data} dash />
      {pL > 0.8 && <g opacity={prog(t, tJul + 1.2, tJul + 1.5)}><Globe x={lx} y={rowL} r={62} id="d2" t={t} /></g>}
      <In t={t} cue={tJulV}><Chip x={960} y={rowL - 62} text="১৫ কোটি ২০ লাখ কিলোমিটার" color={C.data} size={28} /></In>
      {/* difference */}
      {t >= tDiff - 0.3 && (
        <g opacity={prog(t, tDiff - 0.3, tDiff + 0.2)}>
          <line x1={jx} y1={rowJ + 66} x2={jx} y2={rowL - 66} stroke={C.accent} strokeWidth={4} strokeDasharray="10 8" />
          <line x1={lx} y1={rowJ + 66} x2={lx} y2={rowL - 66} stroke={C.accent} strokeWidth={4} strokeDasharray="10 8" />
          <Measure x1={jx} x2={lx} y={475} p={prog(t, tDiff, tDiff + 0.6)} color={C.accent} w={9} cap={22} />
        </g>
      )}
      <In t={t} cue={tDiffV}><Chip x={1150} y={475} text="পার্থক্য ৫০ লাখ কিলোমিটার" color={C.accent} size={28} /></In>
      {t >= tDiffV + 0.2 && t < tDiffV + 1.6 && <Ring x={(jx + lx) / 2} y={475} t={t} cue={tDiffV + 0.2} r={30} />}
    </Svg>
  );
};

/** 48.2-55.4  The gap is only about 3 percent of the whole distance */
export const SceneThree: React.FC<SceneProps> = ({ t }) => {
  const tTotal = W("মোট", 50), tDiff = W("পার্থক্য", 52), tNum = W("৩", 54);
  const c = Math.round(3 * prog(t, tNum - 0.1, tNum + 0.8));
  const barP = prog(t, 49.0, 50.6, INOUT);
  const x0 = 300, w = 1320;
  const slice = prog(t, tDiff, tDiff + 0.5);
  return (
    <Svg>
      <In t={t} cue={48.4}><Sun x={190} y={470} r={62} t={t} glow={0.6} /></In>
      <rect x={x0} y={434} width={w * barP} height={72} rx={36} fill={C.tint} stroke={C.text} strokeWidth={5} />
      <In t={t} cue={49.2}><Globe x={1730} y={470} r={52} id="p1" t={t} /></In>
      <In t={t} cue={tTotal}><Chip x={960} y={360} text="মোট দূরত্ব" color={C.data} size={30} /></In>
      <g opacity={slice}>
        <rect x={x0 + w - 44} y={434} width={44} height={72} rx={16} fill={C.accent} stroke={C.text} strokeWidth={5} />
        <line x1={x0 + w - 22} y1={520} x2={x0 + w - 22} y2={590} stroke={C.accent} strokeWidth={6} strokeLinecap="round" />
      </g>
      <In t={t} cue={tDiff}><Chip x={x0 + w - 130} y={625} text="পার্থক্য" color={C.accent} size={28} /></In>
      {t >= tNum && t < tNum + 1.5 && <Ring x={x0 + w - 22} y={470} t={t} cue={tNum} r={46} />}
      {t >= tNum - 0.1 && (
        <g opacity={prog(t, tNum - 0.1, tNum + 0.2)} transform={`translate(0 ${(1 - pop(t, tNum - 0.1)) * 30})`}>
          <text x={900} y={740} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={190} fill={C.accent} stroke={C.text} strokeWidth={5}>{bn(c)}%</text>
        </g>
      )}
    </Svg>
  );
};
