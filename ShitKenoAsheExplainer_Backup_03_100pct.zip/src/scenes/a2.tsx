import React from "react";
import { FONT } from "../fonts";
import { theme as C } from "../theme";
import { Svg, SceneProps, W, Measure, track } from "./common";
import { In, Chip, Ring, Cross, Arrow } from "../components/kit";
import { Sun, Globe, SnowIcon, Thermo, Top, WinterGear, Shades, Flow, globePoint } from "../art/space";
import { Person } from "../art/art";
import { prog, pop, lerp, INOUT } from "../motion";

/** Person with winter gear (shivering) or sunglasses, standing at (x,y) feet. */
export const Dressed: React.FC<{ x: number; y: number; s?: number; kind: "cold" | "sun"; t: number }> = ({ x, y, s = 1, kind, t }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <ellipse cx={0} cy={4} rx={66} ry={9} fill="rgba(16,35,58,0.14)" />
    <g transform={`translate(${kind === "cold" ? Math.sin(t * 40) * 2 : 0} 0)`}>
      <Person x={0} y={0} s={1} pose="stand" t={t} cloth={kind === "cold" ? C.cloth : C.warn} mood={kind === "cold" ? "flat" : "smile"} />
      {kind === "cold" ? <WinterGear /> : <Shades />}
    </g>
  </g>
);

/** 55.4-70.8  Australia is in summer while we are in winter: distance cannot be the main cause */
export const SceneAustralia: React.FC<SceneProps> = ({ t }) => {
  const tGlobe = W("শুধু", 55), tBd = W("আমাদের", 56), tWin = W("শীতকাল", 57), tAus = W("অস্ট্রেলিয়ায়", 58), tSum = W("গ্রীষ্মকাল।", 58.5);
  const tDist = W("দূরত্ব", 60.5), tBoth = W("দুই", 64), tReal = W("বাস্তবে", 67), tWhy = W("কী?", 70);
  const hypo = Math.min(prog(t, tBoth + 0.3, tBoth + 0.8), 1 - prog(t, tReal + 0.1, tReal + 0.5));
  return (
    <Svg>
      <In t={t} cue={tGlobe}><Globe x={960} y={520} r={190} id="a1" t={t} pins={[
        { lat: 24, lon: -15, p: pop(t, tBd, "snap") },
        { lat: -27, lon: 22, p: pop(t, tAus, "snap") },
      ]} /></In>
      <In t={t} cue={tBd}><Chip x={330} y={270} text="বাংলাদেশ" color={C.data} size={30} /></In>
      <In t={t} cue={tWin}><Dressed x={330} y={750} s={0.85} kind="cold" t={t} /></In>
      <In t={t} cue={tWin}><Chip x={330} y={820} text="শীতকাল" color={C.flow} size={28} /></In>
      <In t={t} cue={tWin + 0.3}>{[0, 1, 2].map((i) => <SnowIcon key={i} x={230 + i * 100} y={390 + (i % 2) * 30 + Math.sin(t * 2 + i) * 6} r={24} rot={t * 20 + i * 40} />)}</In>
      <In t={t} cue={tAus}><Chip x={1590} y={270} text="অস্ট্রেলিয়া" color={C.data} size={30} /></In>
      <In t={t} cue={tSum}><Dressed x={1590} y={750} s={0.85} kind="sun" t={t} /></In>
      <In t={t} cue={tSum}><Chip x={1590} y={820} text="গ্রীষ্মকাল" color={C.accent} size={28} /></In>
      <In t={t} cue={tSum + 0.2}><Sun x={1590} y={385} r={40} t={t} glow={0.5} /></In>
      <In t={t} cue={tDist} out={tReal + 0.3}><Chip x={960} y={230} text="দূরত্বই শীতের কারণ?" color={C.muted} size={28} /></In>
      {hypo > 0.01 && (
        <g opacity={hypo * 0.55}>
          {[0, 1, 2].map((i) => <SnowIcon key={i} x={1490 + i * 100} y={420 + (i % 2) * 40} r={24} rot={t * 20 + i * 40} />)}
        </g>
      )}
      <Cross x={1590} y={540} t={t} cue={tReal} s={1.5} />
      <In t={t} cue={tWhy - 0.5} out={70.8}>
        <text x={960} y={330 + Math.sin(t * 5) * 6} textAnchor="middle" fontSize={190} fontWeight={700} fontFamily={FONT} fill={C.accent} stroke={C.text} strokeWidth={5}>?</text>
      </In>
    </Svg>
  );
};

/** 70.8-82.2  The earth is tilted: axis ~ 23.5 degrees */
export const SceneTilt: React.FC<SceneProps> = ({ t }) => {
  const tStraight = W("সোজা", 71), tAxisW = W("কাল্পনিক"), tTop = W("লাটিমের"), tAxis = W("অক্ষ।", 77), tAng = W("সাড়ে");
  const tilt = 23.5 * pop(t, tStraight + 0.4, "soft");
  const axis = prog(t, tAxisW, tAxisW + 0.6);
  const GX = 820, GY = 480, R = 190;
  const k = 23.5;
  const tip = { x: GX + 1.42 * R * Math.sin((k * Math.PI) / 180), y: GY - 1.42 * R * Math.cos((k * Math.PI) / 180) };
  const arcP = prog(t, tAng, tAng + 0.7);
  const AR = 255;
  const ex = GX + AR * Math.sin((k * Math.PI) / 180), ey = GY - AR * Math.cos((k * Math.PI) / 180);
  return (
    <Svg>
      <In t={t} cue={70.9} dy={0}><line x1={GX} y1={GY - 1.5 * R} x2={GX} y2={GY + 1.5 * R} stroke={C.muted} strokeWidth={4} strokeDasharray="12 10" /></In>
      <Globe x={GX} y={GY} r={R} tilt={tilt} id="s1" t={t} axis={axis} spin={t > tTop + 0.7 ? 50 : 0} />
      <In t={t} cue={tStraight} out={74}><Chip x={450} y={300} text="সোজা নয়" color={C.accent} size={30} /></In>
      <In t={t} cue={tTop} dy={50}><Top x={1420} y={720} s={1.2} t={t} /></In>
      <In t={t} cue={tAxis}><Chip x={tip.x + 100} y={tip.y - 12} text="অক্ষ" color={C.accent} size={30} /></In>
      {arcP > 0 && (
        <g opacity={arcP}>
          <path d={`M ${GX} ${GY - AR} A ${AR} ${AR} 0 0 1 ${ex} ${ey}`} fill="none" stroke={C.accent} strokeWidth={8} strokeLinecap="round" />
        </g>
      )}
      <In t={t} cue={tAng}><Chip x={tip.x + 170} y={tip.y + 100} text="সাড়ে ২৩°" color={C.accent} size={32} /></In>
      {t >= tAng + 0.5 && t < tAng + 1.8 && <Ring x={ex} y={ey} t={t} cue={tAng + 0.5} r={26} />}
    </Svg>
  );
};

/** 82.2-98.7  One lap = one year, the axis keeps pointing the same way */
export const SceneOrbit: React.FC<SceneProps> = ({ t }) => {
  const tYear = W("এক", 84.5), tSame = W("একই", 89), tBesh = W("বেশি", 96), tKom = W("কম", 97.4);
  const OX = 960, OY = 470, RX = 640, RY = 210;
  const lap = prog(t, 82.4, 86.6, INOUT);
  const th = (180 + 360 * lap) * (Math.PI / 180);
  const ex = OX + RX * Math.cos(th), ey = OY + RY * Math.sin(th);
  const stations = [
    { a: 180, cue: 88.6 }, { a: 270, cue: 89.2 }, { a: 0, cue: 89.8 }, { a: 90, cue: 90.4 },
  ];
  const showGhost = t >= 88.4;
  return (
    <Svg>
      <ellipse cx={OX} cy={OY} rx={RX} ry={RY} fill="none" stroke={C.data} strokeWidth={5} strokeDasharray="4 14" strokeLinecap="round" opacity={0.7} />
      <Sun x={OX} y={OY} r={80} t={t} />
      {!showGhost && <Globe x={ex} y={ey} r={56} tilt={23.5} id="o1" axis={1} t={t} />}
      {showGhost && stations.map((s, i) => {
        const a = (s.a * Math.PI) / 180;
        const gx = OX + RX * Math.cos(a), gy = OY + RY * Math.sin(a);
        const p = pop(t, s.cue, "snap");
        if (p <= 0) return null;
        return <g key={i} transform={`translate(${gx} ${gy}) scale(${p}) translate(${-gx} ${-gy})`}><Globe x={gx} y={gy} r={50} tilt={23.5} id={`o${i + 2}`} axis={1} t={t} /></g>;
      })}
      <In t={t} cue={tYear}><Chip x={960} y={822} text="এক বছর" color={C.data} size={30} /></In>
      <In t={t} cue={tSame} dy={20}><Chip x={960} y={170} text="অক্ষ একই দিকে" color={C.accent} size={30} /></In>
      <In t={t} cue={tBesh}><Chip x={320} y={330} text="বেশি ঝুঁকে" color={C.good} size={28} /></In>
      <Arrow x1={360} y1={395} x2={470} y2={395} p={prog(t, tBesh + 0.2, tBesh + 0.8)} color={C.good} />
      <In t={t} cue={tKom}><Chip x={1600} y={330} text="কম ঝুঁকে" color={C.flow} size={28} /></In>
      <Arrow x1={1640} y1={395} x2={1750} y2={395} p={prog(t, tKom + 0.2, tKom + 0.8)} color={C.flow} />
    </Svg>
  );
};

/** 98.7-115.4  December (north leans away) vs June (north leans toward the sun) */
export const SceneJunDec: React.FC<SceneProps> = ({ t }) => {
  const tDec = W("ডিসেম্বরের"), tBd = W("বাংলাদেশ", 102), tAway = W("বিপরীত", 104), tJun = W("জুনের"), tToward = W("দিকে", 109.5), tHow = W("কীভাবে?"), tTemp = W("তাপমাত্রা", 113);
  const GY = 480, R = 130;
  const pinR = pop(t, tBd, "snap");
  return (
    <Svg>
      <Sun x={960} y={GY} r={90} t={t} />
      {/* December: right earth */}
      <In t={t} cue={tDec}><Globe x={1520} y={GY} r={R} tilt={23.5} id="j1" axis={1} shade="right" t={t} pins={[{ lat: 24, lon: -10, p: pinR }]} /></In>
      <In t={t} cue={tDec}><Chip x={1520} y={230} text="ডিসেম্বর" color={C.flow} size={30} /></In>
      <Flow x1={1100} y1={GY} x2={1380} y2={GY} t={t} n={5} opacity={prog(t, tDec + 0.5, tDec + 1)} />
      <In t={t} cue={W("উত্তর", 101)}><Chip x={1520} y={690} text="উত্তর গোলার্ধ" color={C.data} size={28} /></In>
      <In t={t} cue={tAway}><Chip x={1520} y={770} text="সূর্যের বিপরীতে" color={C.flow} size={28} /></In>
      {/* June: left earth */}
      <In t={t} cue={tJun}><Globe x={400} y={GY} r={R} tilt={23.5} id="j2" axis={1} shade="left" t={t} pins={[{ lat: 24, lon: -10, p: pop(t, tJun + 1, "snap") }]} /></In>
      <In t={t} cue={tJun}><Chip x={400} y={230} text="জুন" color={C.accent} size={30} /></In>
      <Flow x1={820} y1={GY} x2={540} y2={GY} t={t} n={5} opacity={prog(t, tJun + 0.5, tJun + 1)} />
      <In t={t} cue={W("উত্তর", 108)}><Chip x={400} y={690} text="উত্তর গোলার্ধ" color={C.data} size={28} /></In>
      <In t={t} cue={tToward}><Chip x={400} y={770} text="সূর্যের দিকে" color={C.accent} size={28} /></In>
      {/* temperature changes */}
      <In t={t} cue={tTemp}><Thermo x={170} y={690} h={240} level={0.85} /></In>
      <In t={t} cue={tTemp + 0.4}><Thermo x={1790} y={690} h={240} level={0.2} /></In>
      <In t={t} cue={tHow} out={115.5}>
        <text x={960} y={800 + Math.sin(t * 5) * 6} textAnchor="middle" fontSize={190} fontWeight={700} fontFamily={FONT} fill={C.accent} stroke={C.text} strokeWidth={5}>?</text>
      </In>
    </Svg>
  );
};
