import React from "react";
import { AbsoluteFill, interpolate } from "remotion";
import { L } from "../layout";
import { FONT } from "../fonts";
import { wordTime } from "../captions";
import { theme as C } from "../theme";
import { glen } from "../captions";

export type SceneProps = { t: number };
export const Svg: React.FC<{ children?: React.ReactNode }> = ({ children }) => (
  <AbsoluteFill>
    <svg width={L.w} height={L.h} viewBox="0 0 1920 1080" style={{ fontFamily: FONT }}>{children}</svg>
  </AbsoluteFill>
);
export const GROUND = 790;

/** time (s) of the first caption word containing `needle` at or after `after` */
export const W = (needle: string, after = 0) => wordTime(needle, after);

/** fixed-width pill with a big value, e.g. "১০০ জন" */
export const Pill: React.FC<{ x: number; y: number; text: string; color?: string; size?: number; w?: number }> = ({ x, y, text, color = C.accent, size = 44, w }) => {
  const ww = w ?? glen(text) * size * 0.62 + 56;
  const h = size * 1.7;
  return (
    <g>
      <rect x={x - ww / 2} y={y - h / 2 + 5} width={ww} height={h} rx={h / 2} fill="rgba(16,35,58,0.10)" />
      <rect x={x - ww / 2} y={y - h / 2} width={ww} height={h} rx={h / 2} fill={C.surface} stroke={color} strokeWidth={4} />
      <text x={x} y={y + size * 0.36} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={size} fill={C.text}>{text}</text>
    </g>
  );
};

/** piecewise-linear value over absolute seconds (clamped) */
export const track = (t: number, times: number[], vals: number[]) => interpolate(t, times, vals, { extrapolateLeft: "clamp", extrapolateRight: "clamp" });

/** Ruler-style measure line with end caps. p = draw progress 0..1. */
export const Measure: React.FC<{ x1: number; x2: number; y: number; p?: number; color?: string; w?: number; dash?: boolean; cap?: number }> = ({ x1, x2, y, p = 1, color = C.data, w = 7, dash = false, cap = 26 }) => {
  if (p <= 0.001) return null;
  const ex = x1 + (x2 - x1) * p;
  return (
    <g>
      <line x1={x1} y1={y} x2={ex} y2={y} stroke={color} strokeWidth={w} strokeLinecap="round" strokeDasharray={dash ? "18 12" : undefined} />
      <line x1={x1} y1={y - cap} x2={x1} y2={y + cap} stroke={color} strokeWidth={w} strokeLinecap="round" />
      {p > 0.97 && <line x1={x2} y1={y - cap} x2={x2} y2={y + cap} stroke={color} strokeWidth={w} strokeLinecap="round" />}
    </g>
  );
};

/** tiny tick used as a "plausible" mark (not green) */
export const Tick: React.FC<{ x: number; y: number; color?: string; s?: number }> = ({ x, y, color = C.warn, s = 1 }) => (
  <path transform={`translate(${x} ${y}) scale(${s})`} d="M -12 0 L -3 10 L 14 -10" stroke={color} strokeWidth={7} fill="none" strokeLinecap="round" strokeLinejoin="round" />
);
