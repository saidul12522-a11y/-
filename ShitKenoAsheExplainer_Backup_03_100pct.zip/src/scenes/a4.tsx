import React from "react";
import { theme as C } from "../theme";
import { Svg, SceneProps, W, GROUND, Tick } from "./common";
import { In, Chip, Ring, Ground, Cross, Check } from "../components/kit";
import { Sun, Globe, Thermo, Flow, City, PieClock, dayArcPath, sunOnArc } from "../art/space";
import { prog, pop, lerp, INOUT, SMOOTH } from "../motion";
import { Dressed } from "./a2";

const CXA = 960;
const SUMMER = { rw: 720, h: 520 };
const WINTER = { rw: 430, h: 230 };

/** day arc drawn with progress p (0..1) or as a faint dashed ghost */
const Arc: React.FC<{ rw: number; h: number; p?: number; color?: string; ghost?: boolean; w?: number }> = ({ rw, h, p = 1, color = C.accent, ghost = false, w = 8 }) => {
  if (p <= 0.001) return null;
  return ghost ? (
    <path d={dayArcPath(CXA, GROUND, rw, h)} fill="none" stroke={C.muted} strokeWidth={5} strokeDasharray="4 16" strokeLinecap="round" opacity={0.6} />
  ) : (
    <path d={dayArcPath(CXA, GROUND, rw, h)} fill="none" stroke={color} strokeWidth={w} strokeLinecap="round" pathLength={1} strokeDasharray={`${p} 2`} />
  );
};

const Ends: React.FC<{ rw: number; o: number }> = ({ rw, o }) => (
  <g opacity={o}>
    <circle cx={CXA - rw} cy={GROUND} r={12} fill={C.accent} stroke={C.text} strokeWidth={4} />
    <circle cx={CXA + rw} cy={GROUND} r={12} fill={C.accent} stroke={C.text} strokeWidth={4} />
  </g>
);

/** 172.9-186.7  Winter: the sun takes a short low path, rises late, sets early */
export const SceneWinterDay: React.FC<SceneProps> = ({ t }) => {
  const tShort = W("দিনের", 173.5), tPath = W("ছোট", 177.5), tLate = W("দেরিতে"), tEarly = W("তাড়াতাড়ি"), tTime = W("সময়ও", 184);
  const u = Math.min(1, Math.max(-1, (t - 177.6) / (182.9 - 177.6) * 2 - 1));
  const sp = sunOnArc(CXA, GROUND, WINTER.rw, WINTER.h, u);
  return (
    <Svg>
      <Arc rw={SUMMER.rw} h={SUMMER.h} ghost />
      <Arc rw={WINTER.rw} h={WINTER.h} p={prog(t, tPath - 1.2, tPath + 1.2, INOUT)} />
      {t >= 177.5 && t < 183.4 && <Sun x={sp.x} y={sp.y} r={58} t={t} />}
      <Ground y={GROUND} />
      <Ends rw={WINTER.rw} o={prog(t, tPath + 1, tPath + 1.4)} />
      <In t={t} cue={tShort}><Chip x={960} y={200} text="দিনের দৈর্ঘ্য কম" color={C.flow} size={30} /></In>
      <In t={t} cue={tPath}><Chip x={960} y={430} text="ছোট পথ" color={C.accent} size={30} /></In>
      <In t={t} cue={tLate}><Chip x={CXA - WINTER.rw} y={720} text="দেরিতে ওঠে" color={C.data} size={28} /></In>
      <In t={t} cue={tEarly}><Chip x={CXA + WINTER.rw} y={720} text="তাড়াতাড়ি ডোবে" color={C.data} size={28} /></In>
      <In t={t} cue={tTime}><PieClock x={1640} y={300} r={64} frac={0.28} /></In>
      <In t={t} cue={tTime}><Chip x={1640} y={410} text="সময় কম" color={C.flow} size={28} /></In>
    </Svg>
  );
};

/** 186.7-201.8  Summer: straight light, long day, more time to heat the ground */
export const SceneSummerDay: React.FC<SceneProps> = ({ t }) => {
  const tSummer = W("গ্রীষ্মকালে", 187), tStraight = W("সোজা", 192), tLong = W("বড়", 194), tTime = W("বেশি", 195.5), tTemp = W("তাপমাত্রা", 199.5);
  const u = Math.min(1, Math.max(-1, (t - 190.6) / (199.4 - 190.6) * 2 - 1));
  const sp = sunOnArc(CXA, GROUND, SUMMER.rw, SUMMER.h, u);
  const lvl = lerp(0.35, 0.92, prog(t, tTemp, tTemp + 1.4));
  return (
    <Svg>
      <Arc rw={WINTER.rw} h={WINTER.h} ghost />
      <Arc rw={SUMMER.rw} h={SUMMER.h} p={prog(t, tSummer + 0.4, tSummer + 2.6, INOUT)} />
      {t >= 190.4 && t < 199.8 && (
        <g>
          <Sun x={sp.x} y={sp.y} r={58} t={t} />
          {t >= tStraight && sp.y < GROUND - 90 && [-30, 0, 30].map((dx) => <Flow key={dx} x1={sp.x + dx} y1={sp.y + 70} x2={sp.x + dx} y2={GROUND - 4} t={t + dx / 100} n={3} speed={0.45} />)}
        </g>
      )}
      <Ground y={GROUND} />
      <Ends rw={SUMMER.rw} o={prog(t, tSummer + 2.4, tSummer + 2.8)} />
      <In t={t} cue={tSummer}><Chip x={960} y={200} text="গ্রীষ্মকাল" color={C.accent} size={30} /></In>
      <In t={t} cue={tStraight}><Chip x={960} y={832} text="সোজা আলো" color={C.warn} size={28} /></In>
      <In t={t} cue={tLong}><Chip x={600} y={500} text="দিন বড়" color={C.accent} size={30} /></In>
      <In t={t} cue={tTime}><PieClock x={1640} y={290} r={64} frac={0.8} /></In>
      <In t={t} cue={tTime}><Chip x={1640} y={400} text="বেশি সময়" color={C.warn} size={28} /></In>
      <In t={t} cue={tTemp}><Thermo x={1790} y={760} h={260} level={lvl} /></In>
    </Svg>
  );
};

/** 201.8-217.1  Distance matters a little, the tilt matters much more */
export const SceneBalance: React.FC<SceneProps> = ({ t }) => {
  const tNone = W("ভূমিকা", 203), tWrong = W("ভুল"), tSmall = W("কিছুটা"), tTilt = W("অক্ষের", 213), tMuch = W("অনেক", 215.5);
  const PX = 960, PY = 400, HALF = 340;
  const phi = t < 207.2 ? 0 : t < tTilt ? -5 * prog(t, 207.2, 208.4, SMOOTH) : lerp(-5, 14, prog(t, tTilt + 0.2, tTilt + 1.6, INOUT));
  const c = Math.cos((phi * Math.PI) / 180), s = Math.sin((phi * Math.PI) / 180);
  const L = { x: PX - HALF * c, y: PY - HALF * s }, R = { x: PX + HALF * c, y: PY + HALF * s };
  const plateL = L.y + 150, plateR = R.y + 150;
  const pan = (p: { x: number; y: number }, py: number) => (
    <g>
      <line x1={p.x} y1={p.y} x2={p.x - 110} y2={py} stroke={C.text} strokeWidth={4} />
      <line x1={p.x} y1={p.y} x2={p.x + 110} y2={py} stroke={C.text} strokeWidth={4} />
      <rect x={p.x - 140} y={py} width={280} height={22} rx={11} fill={C.surface} stroke={C.text} strokeWidth={5} />
    </g>
  );
  return (
    <Svg>
      <In t={t} cue={tNone - 0.3} out={207}><Chip x={960} y={230} text="দূরত্বের কোনো ভূমিকা নেই?" color={C.muted} size={28} /></In>
      <g opacity={1 - prog(t, 206.6, 207.0)}><Cross x={1480} y={230} t={t} cue={tWrong} s={1.3} /></g>
      {t >= tWrong + 0.8 && <g opacity={0}></g>}
      <g opacity={prog(t, 206.6, 207.2)}>
        <rect x={PX - 14} y={PY} width={28} height={GROUND - PY} fill={C.tint} stroke={C.text} strokeWidth={5} />
        <rect x={PX - 140} y={GROUND - 24} width={280} height={24} rx={8} fill={C.tint} stroke={C.text} strokeWidth={5} />
        <line x1={L.x} y1={L.y} x2={R.x} y2={R.y} stroke={C.text} strokeWidth={14} strokeLinecap="round" />
        <circle cx={PX} cy={PY} r={20} fill={C.accent} stroke={C.text} strokeWidth={5} />
        {pan(L, plateL)}
        {pan(R, plateR)}
        <In t={t} cue={207.3} dy={20}>
          <Sun x={L.x - 80} y={plateL - 50} r={26} t={t} glow={0} />
          <line x1={L.x - 50} y1={plateL - 50} x2={L.x + 60} y2={plateL - 50} stroke={C.data} strokeWidth={5} strokeDasharray="10 8" />
          <Globe x={L.x + 90} y={plateL - 40} r={30} id="b1" t={t} />
        </In>
        <In t={t} cue={tTilt + 0.1} dy={-60}><Globe x={R.x} y={plateR - 82} r={64} tilt={23.5} axis={1} id="b2" t={t} /></In>
        <Chip x={L.x} y={plateL + 80} text="দূরত্ব" color={C.data} size={28} />
        {t >= tSmall && <Chip x={L.x} y={plateL + 160} text="কিছুটা বদলায়" color={C.flow} size={26} />}
        {t >= tTilt && <Chip x={R.x} y={plateR + 80} text="অক্ষের হেলে থাকা" color={C.accent} size={28} />}
        {t >= tMuch && <Chip x={R.x} y={plateR + 160} text="প্রভাব অনেক বেশি" color={C.accent} size={28} />}
      </g>
    </Svg>
  );
};

/** 217.1-228.4  Bangladesh sits near the Tropic of Cancer; in June the north leans toward the sun */
export const SceneBdGlobe: React.FC<SceneProps> = ({ t }) => {
  const tBd = W("বাংলাদেশের", 218.5), tTropic = W("কর্কটক্রান্ত"), tJun = W("জুন", 224), tToward = W("দিকে", 226.5);
  return (
    <Svg>
      <In t={t} cue={217.3}><Globe x={620} y={490} r={230} tilt={23.5} axis={1} id="bd" t={t} lines={t >= tTropic ? [23.5] : []} pins={[{ lat: 24, lon: 0, p: pop(t, tBd, "snap") }]} /></In>
      <In t={t} cue={tBd}><Chip x={1010} y={310} text="বাংলাদেশ" color={C.data} size={30} /></In>
      {t >= tBd && <line x1={700} y1={390} x2={880} y2={330} stroke={C.data} strokeWidth={4} strokeDasharray="8 8" opacity={prog(t, tBd, tBd + 0.4)} />}
      <In t={t} cue={tTropic}><Chip x={1050} y={420} text="কর্কটক্রান্ত রেখা" color={C.accent} size={30} /></In>
      {t >= tTropic && <line x1={820} y1={440} x2={870} y2={420} stroke={C.accent} strokeWidth={4} opacity={prog(t, tTropic, tTropic + 0.4)} />}
      <In t={t} cue={tJun}><Sun x={1730} y={560} r={70} t={t} /></In>
      <In t={t} cue={tJun}><Globe x={1380} y={560} r={85} tilt={23.5} axis={1} shade="left" id="bd2" t={t} pins={[{ lat: 24, lon: 0, p: 1 }]} /></In>
      <In t={t} cue={tJun}><Chip x={1380} y={380} text="জুন" color={C.accent} size={30} /></In>
      <In t={t} cue={tToward}><Chip x={1380} y={745} text="সূর্যের দিকে" color={C.accent} size={28} /></In>
    </Svg>
  );
};

const PERSON_X = 1300;
const shadowLen = (sunY: number) => {
  const el = Math.max(8, 70 * ((GROUND - sunY) / SUMMER.h));
  return Math.min(520, 270 / Math.tan((el * Math.PI) / 180));
};
const Shadow: React.FC<{ len: number }> = ({ len }) => (
  <ellipse cx={PERSON_X + len / 2} cy={GROUND + 10} rx={Math.max(10, len / 2)} ry={13} fill="rgba(16,35,58,0.22)" />
);

/** 228.4-241.7  Dhaka in June: sun high, short shadow, long day */
export const SceneDhakaJune: React.FC<SceneProps> = ({ t }) => {
  const tDhaka = W("ঢাকায়"), tHigh = W("উঁচুতে"), tDay = W("প্রায়", 233.5), tStr = W("সোজা", 237), tBesh = W("বেশি", 240);
  const u = -0.85 + 0.97 * prog(t, 229.6, 232.6, INOUT);
  const sp = sunOnArc(CXA, GROUND, SUMMER.rw, SUMMER.h, u);
  const arcP = prog(t, tDay - 0.3, tDay + 1.4, INOUT);
  return (
    <Svg>
      <Arc rw={SUMMER.rw} h={SUMMER.h} ghost />
      <Arc rw={SUMMER.rw} h={SUMMER.h} p={arcP} />
      <Sun x={sp.x} y={sp.y} r={58} t={t} />
      {t >= tStr && [-30, 0, 30].map((dx) => <Flow key={dx} x1={sp.x + dx} y1={sp.y + 70} x2={sp.x + dx} y2={GROUND - 4} t={t + dx / 100} n={3} speed={0.45} />)}
      <Ground y={GROUND} />
      <In t={t} cue={tDhaka} dy={50}><City y={GROUND} x0={110} x1={640} seed={5} t={t} /></In>
      <Shadow len={shadowLen(sp.y)} />
      <In t={t} cue={tDhaka + 0.2}><Dressed x={PERSON_X} y={GROUND} s={0.9} kind="sun" t={t} /></In>
      <In t={t} cue={tDhaka}><Chip x={380} y={240} text="ঢাকা" color={C.data} size={32} /></In>
      {t >= tHigh && <line x1={sp.x} y1={sp.y + 64} x2={sp.x} y2={GROUND} stroke={C.accent} strokeWidth={4} strokeDasharray="10 8" opacity={prog(t, tHigh, tHigh + 0.4) * (1 - prog(t, tStr, tStr + 0.3))} />}
      <In t={t} cue={tHigh - 0.2} out={tStr}><Chip x={sp.x + 190} y={sp.y + 110} text="সূর্য অনেক উঁচুতে" color={C.accent} size={28} /></In>
      <Ends rw={SUMMER.rw} o={arcP > 0.9 ? 1 : 0} />
      <In t={t} cue={tDay}><Chip x={960} y={560} text="প্রায় ১৩ ঘন্টা ৩৬ মিনিট" color={C.accent} size={30} /></In>
      <In t={t} cue={tStr}><Chip x={960} y={832} text="সোজা আলো" color={C.warn} size={28} /></In>
      <In t={t} cue={tBesh}><Chip x={1600} y={300} text="দিন বড়" color={C.accent} size={28} icon={<Tick x={0} y={0} s={0.8} color={C.good} />} /></In>
    </Svg>
  );
};

/** 241.7-256.0  Dhaka in December: low sun path, long shadow, short day, cooler */
export const SceneDhakaDec: React.FC<SceneProps> = ({ t }) => {
  const tDec = W("ডিসেম্বর", 241), tAway = W("বিপরীত", 244), tLow = W("নিচু"), tShort = W("ছোট", 250), tSlant = W("তির্যকভাবে", 250), tTemp = W("তাপমাত্রা", 254);
  const u = -0.85 + 1.2 * prog(t, 246.6, 253.6, INOUT);
  const sp = sunOnArc(CXA, GROUND, WINTER.rw, WINTER.h, u);
  const arcP = prog(t, tLow - 0.9, tLow + 1.6, INOUT);
  const lvl = lerp(0.6, 0.15, prog(t, tTemp, tTemp + 1.3));
  const cold = t > 252;
  return (
    <Svg>
      <Arc rw={SUMMER.rw} h={SUMMER.h} ghost />
      <Arc rw={WINTER.rw} h={WINTER.h} p={arcP} />
      <In t={t} cue={tDec}><Chip x={960} y={200} text="ডিসেম্বর" color={C.flow} size={30} /></In>
      <In t={t} cue={tAway - 0.9} dy={0}>
        <Sun x={1700} y={270} r={50} t={t} glow={0.4} />
        <Globe x={1480} y={270} r={58} tilt={-23.5} axis={1} shade="left" id="dm" t={t} />
      </In>
      <In t={t} cue={tAway}><Chip x={1590} y={410} text="সূর্যের বিপরীতে" color={C.flow} size={26} /></In>
      {t >= 246.4 && <Sun x={sp.x} y={sp.y} r={58} t={t} />}
      {t >= tSlant && t >= 246.4 && [-30, 0, 30].map((dx) => <Flow key={dx} x1={sp.x + dx} y1={sp.y + 50} x2={sp.x + dx + (GROUND - sp.y) * 0.55} y2={GROUND - 4} t={t + dx / 100} n={3} speed={0.4} />)}
      <Ground y={GROUND} />
      <City y={GROUND} x0={110} x1={640} seed={5} t={t} />
      <Shadow len={shadowLen(sp.y)} />
      <Dressed x={PERSON_X} y={GROUND} s={0.9} kind={cold ? "cold" : "sun"} t={t} />
      <In t={t} cue={tLow}><Chip x={960} y={440} text="নিচু পথ" color={C.accent} size={30} /></In>
      <In t={t} cue={tShort}><Chip x={960} y={705} text="দিন ছোট" color={C.flow} size={30} /></In>
      <In t={t} cue={tSlant}><Chip x={960} y={832} text="তির্যক আলো" color={C.flow} size={28} /></In>
      <In t={t} cue={tTemp}><Thermo x={1790} y={760} h={260} level={lvl} /></In>
    </Svg>
  );
};
