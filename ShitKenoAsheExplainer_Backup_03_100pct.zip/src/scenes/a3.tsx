import React from "react";
import { theme as C } from "../theme";
import { Svg, SceneProps, W, GROUND, track } from "./common";
import { In, Chip, Ring, Ground } from "../components/kit";
import { Sun, Globe, Torch, Wall, Flow, Thermo, rad } from "../art/space";
import { Person } from "../art/art";
import { prog, pop, lerp, INOUT } from "../motion";

/** 115.5-136.3  Torch: straight beam = small bright spot, tilted beam = bigger dimmer spot */
export const SceneTorch: React.FC<SceneProps> = ({ t }) => {
  const tTorch = W("torch-এর", 116), tWall = W("দেয়ালে"), tStraight = W("সোজা", 120.5), tSmall = W("ছোট", 122.8), tStrong = W("তীব্রতা", 126), tTilt = W("torchটি"), tKat = W("কাত", 129), tBig = W("বড়", 131.5), tWeak = W("কমে", 134.5);
  const PX = 440, PY = 640, WX = 1200, A = 10;
  const th = 22 * prog(t, tKat - 0.3, tKat + 1.3, INOUT);
  const apex = { x: PX + 150 * Math.cos(rad(th)), y: PY - 150 * Math.sin(rad(th)) };
  const d = WX - apex.x;
  const yTop = apex.y - d * Math.tan(rad(th + A)), yBot = apex.y - d * Math.tan(rad(th - A));
  const o = lerp(0.5, 0.24, th / 22);
  const beamOn = prog(t, tStraight - 0.3, tStraight + 0.4);
  const bx = WX + 130;
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={tTorch - 0.4} dy={30}><Person x={300} y={GROUND} pose="give" t={t} cloth={C.cloth2} s={1} /></In>
      <In t={t} cue={tTorch}><Torch x={PX} y={PY} rot={-th} /></In>
      <In t={t} cue={tWall} dx={60} dy={0}><Wall x={WX} y={150} w={90} h={GROUND - 150} /></In>
      {beamOn > 0 && (
        <g opacity={beamOn}>
          <path d={`M ${apex.x} ${apex.y} L ${WX} ${yTop} L ${WX} ${yBot} Z`} fill={C.gold} opacity={o + 0.15} />
          <line x1={WX - 6} y1={Math.max(150, yTop)} x2={WX - 6} y2={yBot} stroke={C.gold} strokeWidth={14} strokeLinecap="round" opacity={0.5 + 0.5 * (1 - th / 22) * 0.9} />
          <Flow x1={apex.x} y1={apex.y} x2={WX} y2={(yTop + yBot) / 2} t={t} n={5} opacity={1 - th / 22 * 0.6} />
        </g>
      )}
      {beamOn > 0 && (
        <g opacity={beamOn}>
          <line x1={bx} y1={yTop} x2={bx} y2={yBot} stroke={C.accent} strokeWidth={8} strokeLinecap="round" />
          <line x1={bx - 18} y1={yTop} x2={bx + 18} y2={yTop} stroke={C.accent} strokeWidth={8} strokeLinecap="round" />
          <line x1={bx - 18} y1={yBot} x2={bx + 18} y2={yBot} stroke={C.accent} strokeWidth={8} strokeLinecap="round" />
        </g>
      )}
      {t < tKat + 0.2 && <In t={t} cue={tSmall} out={tKat}><Chip x={bx + 230} y={(yTop + yBot) / 2} text="ছোট জায়গা" color={C.accent} size={28} /></In>}
      <In t={t} cue={tStrong} out={tKat}><Chip x={bx + 230} y={(yTop + yBot) / 2 + 90} text="তীব্রতা বেশি" color={C.warn} size={28} /></In>
      <In t={t} cue={tBig}><Chip x={bx + 230} y={(yTop + yBot) / 2} text="বড় জায়গা" color={C.accent} size={28} /></In>
      <In t={t} cue={tWeak}><Chip x={bx + 230} y={(yTop + yBot) / 2 + 90} text="তীব্রতা কম" color={C.flow} size={28} /></In>
    </Svg>
  );
};

/** 136.3-152.9  Sunlight in winter hits the north at a slant and spreads over a bigger area */
export const SceneSlant: React.FC<SceneProps> = ({ t }) => {
  const tSame = W("এভাবেই"), tWinter = W("শীতকালে", 138), tAway = W("বিপরীত", 140), tSlant = W("তির্যকভাবে"), tEnergy = W("সৌরশক্তি"), tBig = W("বড়", 148), tSoil = W("মাটি", 150);
  const CX = 1330, CY = 490, R = 250, TILT = 23.5, SX = 430;
  const cs = Math.cos(rad(TILT)), sn = Math.sin(rad(TILT));
  const lat = 24;
  const nx = Math.cos(rad(lat)) * -cs + Math.sin(rad(lat)) * sn;
  const ny = Math.cos(rad(lat)) * -sn - Math.sin(rad(lat)) * cs;
  const hb = 90;
  const edgeX = (y: number) => CX - Math.sqrt(Math.max(0, R * R - (y - CY) * (y - CY)));
  const pyO = CY + R * ny;
  const L = hb / Math.abs(nx);
  void L;
  const yO = [pyO - hb / 2, pyO, pyO + hb / 2];
  const yS = [CY - hb / 2, CY, CY + hb / 2];
  const pS = prog(t, tSame - 0.3, tSame + 0.8), pO = prog(t, tSlant - 0.9, tSlant + 0.2);
  const rays = (ys: number[], p: number, color: string, opacity: number) => (
    <g opacity={opacity}>
      {ys.map((y, i) => <line key={i} x1={SX} y1={y} x2={SX + (edgeX(y) - SX) * p} y2={y} stroke={color} strokeWidth={6} strokeLinecap="round" />)}
      <Flow x1={SX} y1={ys[1]} x2={edgeX(ys[1])} y2={ys[1]} t={t} n={5} color={color} opacity={p} />
    </g>
  );
  const patch = (ys: number[], p: number, color: string, w: number) => (
    <line x1={edgeX(ys[0])} y1={ys[0]} x2={edgeX(ys[2])} y2={ys[2]} stroke={color} strokeWidth={w} strokeLinecap="round" opacity={p} />
  );
  const sizeP = prog(t, tEnergy, tEnergy + 1.2);
  return (
    <Svg>
      <Sun x={210} y={CY} r={110} t={t} />
      <In t={t} cue={tSame - 0.3} dy={0}><Globe x={CX} y={CY} r={R} tilt={TILT * pop(t, tAway, "soft")} id="sl" axis={prog(t, tAway + 0.3, tAway + 1)} t={t} /></In>
      {rays(yS, pS, C.warn, 1)}
      {patch(yS, pS, C.accent, 14)}
      <In t={t} cue={tSame}><Chip x={720} y={CY + 130} text="সোজা আলো" color={C.warn} size={28} /></In>
      {rays(yO, pO, C.warn, 0.55)}
      {patch(yO, pO, C.accent, 14 + 0 * sizeP)}
      <In t={t} cue={tSlant}><Chip x={720} y={pyO - 110} text="তির্যক আলো" color={C.flow} size={28} /></In>
      <In t={t} cue={tWinter}><Chip x={1560} y={250} text="শীতকাল" color={C.flow} size={28} /></In>
      {t >= tBig && t < tBig + 1.4 && <Ring x={(edgeX(yO[0]) + edgeX(yO[2])) / 2} y={pyO} t={t} cue={tBig} r={50} />}
      <In t={t} cue={tBig}><Chip x={1000} y={pyO - 60 - 140} text="বড় এলাকা" color={C.accent} size={28} /></In>
      <In t={t} cue={tSoil}><Thermo x={1700} y={760} h={260} level={0.2} /></In>
      <In t={t} cue={tSoil}><Chip x={1700} y={420} text="মাটি কম গরম" color={C.flow} size={26} /></In>
    </Svg>
  );
};

/** 152.9-172.7  Same energy over 1 m2 vs 2 m2 -> about half per square metre */
export const SceneSquare: React.FC<SceneProps> = ({ t }) => {
  const tStraight = W("সোজা", 154), tM1 = W("বর্গমিটার", 155.5), tSlant = W("কাত", 158), tTwo = W("দুই", 160), tHalf = W("অর্ধেক"), tReal = W("বাস্তবে", 167);
  const GY = 650, d = { x: 0.866, y: 0.5 };
  const xA = 1170, xB = 1490, up = 380;
  const pL = prog(t, tStraight - 0.3, tStraight + 0.7), pR = prog(t, tSlant - 0.3, tSlant + 0.7);
  const half = prog(t, tHalf - 1.0, tHalf + 0.3);
  const tile = (x: number, w: number, op: number) => <rect key={x} x={x} y={GY} width={w} height={40} fill={C.accent} opacity={op} stroke={C.text} strokeWidth={4} />;
  return (
    <Svg>
      <line x1={100} y1={GY} x2={1820} y2={GY} stroke={C.text} strokeWidth={5} />
      {/* left: straight light on 1 m2 */}
      <In t={t} cue={tStraight} dy={0}><Sun x={520} y={190} r={44} t={t} glow={0.5} /></In>
      <g opacity={pL}>
        <rect x={440} y={260} width={160} height={GY - 260} fill={C.gold} opacity={0.25} />
        {[0, 1, 2, 3].map((i) => <Flow key={i} x1={460 + i * 40} y1={270} x2={460 + i * 40} y2={GY - 6} t={t + i * 0.13} n={3} speed={0.4} />)}
      </g>
      <g opacity={pL}>{tile(440, 160, 1)}</g>
      <In t={t} cue={tM1}><Chip x={520} y={745} text="১ বর্গমিটার" color={C.accent} size={28} /></In>
      {/* right: slanted light on 2 m2 */}
      <In t={t} cue={tSlant} dy={0}><Sun x={720} y={380} r={44} t={t} glow={0.5} /></In>
      <g opacity={pR}>
        <path d={`M ${xA - d.x * up} ${GY - d.y * up} L ${xB - d.x * up} ${GY - d.y * up} L ${xB} ${GY} L ${xA} ${GY} Z`} fill={C.gold} opacity={0.25} />
        {[0, 1, 2, 3].map((i) => {
          const sx = xA - d.x * up + (320 * (i + 0.5)) / 4;
          return <Flow key={i} x1={sx} y1={GY - d.y * up} x2={sx + d.x * up} y2={GY - 6} t={t + i * 0.13} n={3} speed={0.4} />;
        })}
      </g>
      <g opacity={pR}>{tile(xA, 160, 1 - 0.5 * half)}{tile(xA + 160, 160, 1 - 0.5 * half)}</g>
      <In t={t} cue={tTwo}><Chip x={1330} y={745} text="২ বর্গমিটার" color={C.accent} size={28} /></In>
      <In t={t} cue={tHalf} dy={20}><Chip x={1330} y={820} text="প্রতি বর্গমিটারে প্রায় অর্ধেক" color={C.flow} size={26} /></In>
      <In t={t} cue={tReal} dy={20}><Chip x={1010} y={190} text="কোণের উপর নির্ভর করে" color={C.muted} size={26} /></In>
    </Svg>
  );
};
