import React from "react";
import { SceneHook, SceneNear, SceneTiltTease, SceneDistances, SceneThree } from "./scenes/a1";
import { SceneAustralia, SceneTilt, SceneOrbit, SceneJunDec } from "./scenes/a2";
import { SceneTorch, SceneSlant, SceneSquare } from "./scenes/a3";
import { SceneWinterDay, SceneSummerDay, SceneBalance, SceneBdGlobe, SceneDhakaJune, SceneDhakaDec } from "./scenes/a4";
import { SceneAustraliaWhy, SceneRecap, SceneTruth, SceneStayed, SceneOutro } from "./scenes/a5";

export type SceneDef = { id: string; title: string; start: number; end: number; C: React.FC<{ t: number }> };

/**
 * Storyboard (seconds, from the voiceover / corrected SRT):
 * 01 hook         "why does winter come?" myth: the sun moves away
 * 02 near         truth: in winter we are NEAREST to the sun -> why cold?
 * 03 tiltTease    the answer hides in the tilt; first check how much distance matters
 * 04 distances    January 14.70 crore km vs July 15.20 crore km, gap 50 lakh km
 * 05 three        the gap is only about 3 percent
 * 06 australia    Australia is in summer when we are in winter -> distance is not the main cause
 * 07 tilt         earth is not upright; axis is tilted about 23.5 degrees
 * 08 orbit        one lap = one year, axis keeps pointing the same way
 * 09 junDec       December: north leans away; June: north leans toward the sun
 * 10 torch        straight torch = small bright spot; tilted = bigger, weaker
 * 11 slant        winter sunlight is oblique over the north and spreads over a larger area
 * 12 square       same energy over 1 m2 vs 2 m2 -> about half per m2
 * 13 winterDay    shorter day, low short path, late sunrise / early sunset
 * 14 summerDay    straight light, long day, more heating time
 * 15 balance      distance matters a little; tilt matters much more
 * 16 bdGlobe      Bangladesh near the Tropic of Cancer; June leans toward the sun
 * 17 dhakaJune    Dhaka June: high sun, short shadow, 13h 36m day
 * 18 dhakaDec     Dhaka December: low sun, long shadow, short day, cooler
 * 19 australiaWhy December: south leans toward the sun -> summer in Australia
 * 20 recap        tilt, angle of light, length of day
 * 21 truth        not "sun went away": north leans away -> less heating, shorter day
 * 22 stayed       the sun did not leave; earth turns its face away a little
 * 23 outro        logo, like, comment, subscribe
 */
export const SCENES: SceneDef[] = [
  { id: "hook", title: "Hook", start: 0, end: 8.8, C: SceneHook },
  { id: "near", title: "Nearest to the sun", start: 8.8, end: 20.4, C: SceneNear },
  { id: "tiltTease", title: "Tilt teaser", start: 20.4, end: 32.9, C: SceneTiltTease },
  { id: "distances", title: "Jan vs Jul distance", start: 32.9, end: 48.2, C: SceneDistances },
  { id: "three", title: "Only 3 percent", start: 48.2, end: 55.4, C: SceneThree },
  { id: "australia", title: "Australia summer", start: 55.4, end: 70.8, C: SceneAustralia },
  { id: "tilt", title: "Axis tilt", start: 70.8, end: 82.2, C: SceneTilt },
  { id: "orbit", title: "Orbit", start: 82.2, end: 98.7, C: SceneOrbit },
  { id: "junDec", title: "June vs December", start: 98.7, end: 115.5, C: SceneJunDec },
  { id: "torch", title: "Torch", start: 115.5, end: 136.3, C: SceneTorch },
  { id: "slant", title: "Slanted sunlight", start: 136.3, end: 152.9, C: SceneSlant },
  { id: "square", title: "1 m2 vs 2 m2", start: 152.9, end: 172.8, C: SceneSquare },
  { id: "winterDay", title: "Winter day", start: 172.8, end: 186.8, C: SceneWinterDay },
  { id: "summerDay", title: "Summer day", start: 186.8, end: 201.8, C: SceneSummerDay },
  { id: "balance", title: "Distance vs tilt", start: 201.8, end: 217.1, C: SceneBalance },
  { id: "bdGlobe", title: "Bangladesh globe", start: 217.1, end: 228.4, C: SceneBdGlobe },
  { id: "dhakaJune", title: "Dhaka June", start: 228.4, end: 241.7, C: SceneDhakaJune },
  { id: "dhakaDec", title: "Dhaka December", start: 241.7, end: 256.0, C: SceneDhakaDec },
  { id: "australiaWhy", title: "Australia why", start: 256.0, end: 272.9, C: SceneAustraliaWhy },
  { id: "recap", title: "Recap", start: 272.9, end: 281.0, C: SceneRecap },
  { id: "truth", title: "Truth", start: 281.0, end: 294.6, C: SceneTruth },
  { id: "stayed", title: "Sun stayed", start: 294.6, end: 301.5, C: SceneStayed },
  { id: "outro", title: "Outro", start: 301.5, end: 312, C: SceneOutro },
];
