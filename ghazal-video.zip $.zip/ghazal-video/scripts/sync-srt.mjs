// Converts public/ghazal.srt -> src/data/ghazal.srt.ts (the single timing source).
import fs from "node:fs";
import path from "node:path";
import {fileURLToPath} from "node:url";
const root = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const raw = fs.readFileSync(path.join(root, "public", "ghazal.srt"), "utf8").replace(/^\uFEFF/, "").replace(/\r/g, "");
fs.writeFileSync(
  path.join(root, "src", "data", "ghazal.srt.ts"),
  "// Generated from public/ghazal.srt by `npm run srt`. The SRT is the ONLY timing source.\nexport const SRT_TEXT = `" +
    raw.replace(/\\/g, "\\\\").replace(/`/g, "\\`").replace(/\$\{/g, "\\${") + "`;\n"
);
console.log("src/data/ghazal.srt.ts updated");
