// Pure-Node sanity checks: plan ↔ SRT consistency, assets present, SFX peaks/clipping.
import fs from "node:fs";
import path from "node:path";
import {fileURLToPath} from "node:url";

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = (p) => fs.readFileSync(path.join(root, p), "utf8");
let errors = 0, warns = 0;
const bad = (m) => { errors++; console.error("✗", m); };
const warn = (m) => { warns++; console.warn("!", m); };
const ok = (m) => console.log("✓", m);

// SRT
const toSec = (h, m, s, ms) => +h * 3600 + +m * 60 + +s + +ms / 1000;
const cues = read("public/ghazal.srt").replace(/\r/g, "").trim().split(/\n\s*\n/).map((b) => {
  const l = b.split("\n"), m = l[1].match(/(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)/);
  return {i: +l[0], s: toSec(...m.slice(1, 5)), e: toSec(...m.slice(5, 9)), text: l.slice(2).join(" ").replace(/\s+/g, " ")};
});
ok(`${cues.length} cues, ${cues[0].s}s → ${cues.at(-1).e}s`);
cues.forEach((c, k) => {
  if (c.e <= c.s) bad(`cue ${c.i}: end <= start`);
  if (k && c.s < cues[k - 1].e) bad(`cue ${c.i} overlaps previous cue`);
});
const tsSrt = read("src/data/ghazal.srt.ts");
const norm = (t) => t.replace(/\r/g, "").trim();
if (!tsSrt.includes(norm(read("public/ghazal.srt")).split("\n")[2])) bad("src/data/ghazal.srt.ts is out of sync — run `npm run srt`");
else ok("src/data/ghazal.srt.ts matches public/ghazal.srt (spot check)");

// Plan
const plan = JSON.parse(read("src/data/plan.json"));
for (const [k, p] of Object.entries(plan.images)) fs.existsSync(path.join(root, "public", p)) ? null : bad(`image missing: ${p} (${k})`);
ok(`${Object.keys(plan.images).length} images referenced`);
for (const c of cues) {
  const v = plan.verses[String(c.i)];
  if (!v) { warn(`cue ${c.i} has no plan.json entry (auto fallback will be used)`); continue; }
  if (!plan.images[v.image]) bad(`cue ${c.i}: unknown image key ${v.image}`);
  for (const p of v.phrases) {
    if (!c.text.includes(p.t)) bad(`cue ${c.i}: phrase "${p.t}" is NOT in the SRT text`);
    if (p.t.split(" ").length > 4) warn(`cue ${c.i}: phrase "${p.t}" is long`);
  }
}
ok("all on-screen phrases are literal substrings of their SRT cue");
// the whole ghazal must never appear on screen
const shown = Object.values(plan.verses).reduce((n, v) => n + v.phrases.length, 0);
console.log(`  ${shown} phrases shown for ${cues.length} cues`);

// SFX
const sfxDir = path.join(root, "public", "sfx");
for (const f of fs.readdirSync(sfxDir).filter((x) => x.endsWith(".wav"))) {
  const b = fs.readFileSync(path.join(sfxDir, f));
  let peak = 0, clip = 0;
  for (let o = 44; o < b.length; o += 2) { const v = Math.abs(b.readInt16LE(o)); peak = Math.max(peak, v); if (v >= 32767) clip++; }
  const db = 20 * Math.log10(peak / 32768);
  console.log(`  ${f.padEnd(22)} peak ${db.toFixed(1)} dBFS  clipped samples: ${clip}`);
  if (clip) bad(`${f} clips`); if (db > -3) bad(`${f} peak too hot`);
}
if (!fs.existsSync(path.join(root, "public", "voiceover.mp3"))) warn("public/voiceover.mp3 missing (optional)");
if (!fs.existsSync(path.join(root, "public", "fonts")) || fs.readdirSync(path.join(root, "public", "fonts")).length < 4) warn("public/fonts is empty — run `npm install` (postinstall copies the Bengali fonts)");
console.log(`\n${errors} error(s), ${warns} warning(s)`);
process.exit(errors ? 1 : 0);
