// Synthesises a small, non-musical SFX kit (16-bit mono WAV, 48 kHz) into public/sfx/.
// Deterministic: same output on every run. No downloads, no instruments, no melodies.
import fs from "node:fs";
import path from "node:path";
import {fileURLToPath} from "node:url";

const SR = 48000;
const OUT = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "public", "sfx");
fs.mkdirSync(OUT, {recursive: true});

const rng = (seed) => () => {
  seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
const noise = (r) => r() * 2 - 1;
const dB = (x) => Math.pow(10, x / 20);

// Chamberlin state-variable band-pass with a moving centre frequency.
const sweptBand = (n, r, f0, f1, q, curve = (t) => t) => {
  const out = new Float32Array(n);
  let low = 0, band = 0;
  for (let i = 0; i < n; i++) {
    const t = i / n;
    const fc = f0 + (f1 - f0) * curve(t);
    const f = 2 * Math.sin((Math.PI * fc) / SR);
    const x = noise(r);
    low += f * band;
    const high = x - low - q * band;
    band += f * high;
    out[i] = band;
  }
  return out;
};
const env = (n, attack) => (i) => {
  const t = i / n;
  return t < attack ? Math.pow(t / attack, 2) : Math.pow((1 - t) / (1 - attack), 2);
};
const normalise = (a, peakDb) => {
  let p = 0; for (const v of a) p = Math.max(p, Math.abs(v));
  const g = dB(peakDb) / (p || 1);
  return a.map((v) => v * g);
};
const write = (name, data) => {
  const buf = Buffer.alloc(44 + data.length * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + data.length * 2, 4); buf.write("WAVE", 8);
  buf.write("fmt ", 12); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write("data", 36); buf.writeUInt32LE(data.length * 2, 40);
  for (let i = 0; i < data.length; i++) buf.writeInt16LE(Math.round(Math.max(-1, Math.min(1, data[i])) * 32767), 44 + i * 2);
  fs.writeFileSync(path.join(OUT, name), buf);
  console.log("wrote", name, (data.length / SR).toFixed(2) + "s");
};

// 1 · soft whoosh (0.9 s)
{
  const n = Math.round(0.9 * SR), b = sweptBand(n, rng(1), 280, 2600, 0.55, (t) => t * t), e = env(n, 0.38);
  write("whoosh_soft.wav", normalise(b.map((v, i) => v * e(i)), -8));
}
// 2 · transition sweep (1.4 s) — slower, lower, airier
{
  const n = Math.round(1.4 * SR), b = sweptBand(n, rng(2), 160, 1500, 0.9, (t) => Math.sin((t * Math.PI) / 2)), e = env(n, 0.5);
  write("sweep_transition.wav", normalise(b.map((v, i) => v * e(i)), -9));
}
// 3 · gentle pop (0.25 s) — pitch-dropping sine, no pitch centre
{
  const n = Math.round(0.25 * SR), a = new Float32Array(n); let ph = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR; ph += (2 * Math.PI * (170 + 330 * Math.exp(-t * 38))) / SR;
    a[i] = Math.sin(ph) * Math.exp(-t * 26) * Math.min(1, t / 0.002);
  }
  write("pop_gentle.wav", normalise(a, -9));
}
// 4 · subtle click (0.1 s)
{
  const n = Math.round(0.1 * SR), r = rng(4), a = new Float32Array(n); let prev = 0;
  for (let i = 0; i < n; i++) { const x = noise(r); a[i] = (x - prev) * Math.exp(-(i / SR) * 150); prev = x; }
  write("click_subtle.wav", normalise(a, -14));
}
// 5 · gentle chime (2.4 s) — inharmonic glass-like partials, soft attack
{
  const n = Math.round(2.4 * SR), a = new Float32Array(n);
  const partials = [[1318.5, 1, 1.6], [3634, 0.32, 0.9], [7125, 0.12, 0.45], [659.3, 0.35, 2.0]];
  for (let i = 0; i < n; i++) {
    const t = i / SR; let s = 0;
    for (const [f, amp, dec] of partials) s += Math.sin(2 * Math.PI * f * t) * amp * Math.exp(-t / dec * 3);
    a[i] = s * Math.min(1, t / 0.006);
  }
  write("chime_gentle.wav", normalise(a, -11));
}
// 6 · air texture (20 s, seamless loop) — dark filtered noise with slow swells
{
  const L = 20 * SR, X = SR, n = L + X, r = rng(6), raw = new Float32Array(n);
  let l1 = 0, l2 = 0;
  for (let i = 0; i < n; i++) {
    l1 += 0.045 * (noise(r) - l1); l2 += 0.06 * (l1 - l2);
    const t = i / SR;
    raw[i] = l2 * (0.7 + 0.3 * Math.sin(2 * Math.PI * t / 10 + 1) * Math.sin(2 * Math.PI * t / 6.7));
  }
  const a = new Float32Array(L);
  for (let i = 0; i < L; i++) a[i] = raw[i];
  for (let i = 0; i < X; i++) { const w = i / X; a[i] = raw[i] * w + raw[L + i] * (1 - w); } // equal-gain crossfade into the tail
  write("air_texture.wav", normalise(a, -18));
}
