// postinstall: copies Bengali-subset WOFF2 files from @fontsource into public/fonts (offline use).
import fs from "node:fs";
import path from "node:path";
import {fileURLToPath} from "node:url";

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const dest = path.join(root, "public", "fonts");
fs.mkdirSync(dest, {recursive: true});
let n = 0;
for (const pkg of ["hind-siliguri", "noto-sans-bengali"]) {
  const dir = path.join(root, "node_modules", "@fontsource", pkg, "files");
  if (!fs.existsSync(dir)) { console.warn(`[fonts] @fontsource/${pkg} not installed yet`); continue; }
  for (const f of fs.readdirSync(dir)) {
    if (/-bengali-(500|700)-normal\.woff2$/.test(f)) { fs.copyFileSync(path.join(dir, f), path.join(dest, f)); n++; }
  }
}
console.log(`[fonts] copied ${n} font file(s) to public/fonts`);
if (n < 4) console.warn("[fonts] expected 4 files — the CSS fallback stack will be used for missing ones.");
