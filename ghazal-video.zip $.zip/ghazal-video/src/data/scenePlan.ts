import plan from "./plan.json";
import type {KbName} from "../theme";

export type PhrasePlan = {t: string; hero?: boolean; key?: boolean};
export type Anchor = `${"left" | "center" | "right"}-${"top" | "middle" | "bottom"}`;

export type VersePlan = {
  image: string; // path inside public/
  kb: KbName;
  anchor: Anchor;
  rays: number;
  particles: number;
  phrases: PhrasePlan[];
};
export type SimplePlan = {image: string; kb: KbName};

const img = (key: string): string => {
  const p = (plan.images as Record<string, string>)[key];
  if (!p) throw new Error(`plan.json: unknown image key "${key}"`);
  return p;
};

const imageKeys = Object.keys(plan.images);

export const hookPlan = (): SimplePlan => ({image: img(plan.hook.image), kb: plan.hook.kb as KbName});

export const interludePlan = (afterCue: number): SimplePlan => {
  const p = (plan.interludes as Record<string, {image: string; kb: string}>)[String(afterCue)];
  return p
    ? {image: img(p.image), kb: p.kb as KbName}
    : {image: img("allahHall"), kb: "pushCenter"};
};

export const versePlan = (cueIndex: number, fallbackLines: string[]): VersePlan => {
  const p = (plan.verses as Record<string, any>)[String(cueIndex)];
  if (p) {
    return {
      image: img(p.image),
      kb: p.kb as KbName,
      anchor: p.anchor as Anchor,
      rays: p.rays,
      particles: p.particles,
      phrases: p.phrases as PhrasePlan[],
    };
  }
  // Fallback for a cue that has no entry in plan.json (e.g. a new SRT): cycle the images.
  return {
    image: img(imageKeys[(cueIndex - 1) % imageKeys.length]),
    kb: (["pushIn", "panLeft", "pullOut", "panRight"] as KbName[])[cueIndex % 4],
    anchor: "left-middle",
    rays: 0.4,
    particles: 24,
    phrases: fallbackLines.slice(0, 2).map((t) => ({t})),
  };
};
