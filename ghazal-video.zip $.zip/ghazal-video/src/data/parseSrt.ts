export type Cue = {
  index: number;
  startSec: number;
  endSec: number;
  text: string; // lines joined with a single space
  lines: string[];
};

const toSec = (h: string, m: string, s: string, ms: string) =>
  Number(h) * 3600 + Number(m) * 60 + Number(s) + Number(ms.padEnd(3, "0")) / 1000;

export const parseSrt = (raw: string): Cue[] =>
  raw
    .replace(/\r/g, "")
    .replace(/^\uFEFF/, "")
    .trim()
    .split(/\n\s*\n/)
    .map((block) => {
      const l = block.split("\n").map((x) => x.trim());
      const m = l[1]?.match(/(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)/);
      if (!m) throw new Error(`Bad SRT block: ${block}`);
      const lines = l.slice(2).filter(Boolean);
      return {
        index: parseInt(l[0], 10),
        startSec: toSec(m[1], m[2], m[3], m[4]),
        endSec: toSec(m[5], m[6], m[7], m[8]),
        text: lines.join(" "),
        lines,
      };
    });
