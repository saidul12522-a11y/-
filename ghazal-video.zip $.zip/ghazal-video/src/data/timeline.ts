import {theme} from "../theme";
import {parseSrt} from "./parseSrt";
import {SRT_TEXT} from "./ghazal.srt";
import {hookPlan, interludePlan, versePlan, SimplePlan, VersePlan} from "./scenePlan";

export type PhraseWindow = {text: string; hero: boolean; key: boolean; start: number; end: number}; // absolute frames

type Base = {seqFrom: number; from: number; to: number; overlapIn: number}; // seqFrom = from - overlapIn
export type HookScene = Base & {type: "hook"; plan: SimplePlan};
export type InterludeScene = Base & {type: "interlude"; plan: SimplePlan};
export type VerseSceneDef = Base & {type: "verse" | "closing"; cueIndex: number; plan: VersePlan; phrases: PhraseWindow[]};
export type SceneDef = HookScene | InterludeScene | VerseSceneDef;

export type SfxEvent = {frame: number; kind: "whoosh" | "sweep" | "pop" | "chime"};

const FPS = theme.video.fps;
const sec = (s: number) => Math.round(s * FPS);

export const cues = parseSrt(SRT_TEXT);
const lastEnd = cues[cues.length - 1].endSec;
export const totalFrames = Math.ceil((lastEnd + theme.motion.tailSec) * FPS);
export const overlapFrames = sec(theme.motion.crossfadeSec);

const phraseWindows = (cueIdx: number, sceneTo: number): PhraseWindow[] => {
  const cue = cues[cueIdx];
  const plan = versePlan(cue.index, cue.lines);
  const startF = sec(cue.startSec);
  const dur = sec(cue.endSec) - startF;
  const text = cue.text.replace(/\s+/g, " ");
  const n = plan.phrases.length;
  const raw = plan.phrases.map((p, i) => {
    const at = text.indexOf(p.t);
    const frac = at >= 0 ? at / text.length : i / n; // SRT-proportional position inside the cue
    return {p, frac};
  });
  raw.sort((a, b) => a.frac - b.frac);
  const out: PhraseWindow[] = [];
  let minStart = startF + sec(0.2);
  raw.forEach(({p, frac}, i) => {
    let s = Math.round(startF + dur * (0.03 + 0.8 * frac));
    s = Math.max(s, minStart);
    const e = i === raw.length - 1 ? sceneTo : 0; // fixed below
    out.push({text: p.t, hero: !!p.hero, key: !!p.key, start: s, end: e});
    minStart = s + sec(1.8);
  });
  out.forEach((w, i) => {
    if (i < out.length - 1) w.end = out[i + 1].start;
  });
  return out;
};

const build = () => {
  const scenes: SceneDef[] = [];
  const first = sec(cues[0].startSec);
  scenes.push({type: "hook", seqFrom: 0, from: 0, to: first, overlapIn: 0, plan: hookPlan()});

  cues.forEach((cue, i) => {
    const from = sec(cue.startSec);
    const isLast = i === cues.length - 1;
    const next = cues[i + 1];
    const gap = next ? next.startSec - cue.endSec : 0;
    const makeInterlude = !isLast && gap >= theme.motion.interludeMinGapSec;
    const to = isLast ? totalFrames : makeInterlude ? sec(cue.endSec) : sec(next.startSec);
    scenes.push({
      type: isLast ? "closing" : "verse",
      seqFrom: from - overlapFrames,
      from,
      to,
      overlapIn: overlapFrames,
      cueIndex: cue.index,
      plan: versePlan(cue.index, cue.lines),
      phrases: phraseWindows(i, to),
    });
    if (makeInterlude) {
      const iFrom = sec(cue.endSec);
      scenes.push({
        type: "interlude",
        seqFrom: iFrom - overlapFrames,
        from: iFrom,
        to: sec(next.startSec),
        overlapIn: overlapFrames,
        plan: interludePlan(cue.index),
      });
    }
  });
  return scenes;
};

export const scenes = build();

export const sfxEvents: SfxEvent[] = (() => {
  const ev: SfxEvent[] = [];
  scenes.forEach((s, i) => {
    if (i > 0) ev.push({frame: s.seqFrom + 2, kind: s.type === "interlude" || scenes[i - 1].type === "interlude" ? "sweep" : "whoosh"});
    if (s.type === "verse" || s.type === "closing") {
      s.phrases.forEach((w) => ev.push({frame: w.start, kind: w.key ? "chime" : "pop"}));
    }
  });
  return ev;
})();
