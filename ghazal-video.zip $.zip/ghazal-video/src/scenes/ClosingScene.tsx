import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {BgMesh, Grade, LightRays, Particles, TextScrim} from "../components/Backdrop";
import {KenBurns} from "../components/KenBurns";
import {FrameOrnament, StarMedallion} from "../components/Ornaments";
import {PhraseLayer} from "../components/Phrase";
import {SceneShell} from "../components/SceneShell";
import type {VerseSceneDef} from "../data/timeline";

/** Last cue + quiet tail. The camera keeps pushing in, a gold medallion draws itself, then the picture rests in light. */
export const ClosingScene: React.FC<{def: VerseSceneDef}> = ({def}) => {
  const frame = useCurrentFrame();
  const {fps, width} = useVideoConfig();
  const dur = def.to - def.seqFrom;
  const local = def.phrases.map((p) => ({text: p.text, hero: p.hero, start: p.start - def.seqFrom, end: p.end - def.seqFrom}));
  const first = local[0]?.start ?? 0;
  const lastEnd = local[local.length - 1]?.end ?? dur;
  // text leaves ~2.5s before the very end, the medallion stays
  const textEnd = Math.min(lastEnd, dur - Math.round(fps * 2.5));
  const adj = local.map((p, i) => (i === local.length - 1 ? {...p, end: textEnd} : p));
  const scrim = interpolate(frame, [first - 6, first + 14, textEnd - 10, textEnd], [0, 1, 1, 0], {
    easing: theme.ease.out,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const med = interpolate(frame, [textEnd - fps, textEnd + fps * 1.8], [0, 1], {easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  return (
    <SceneShell overlapIn={def.overlapIn}>
      <BgMesh />
      <KenBurns src={def.plan.image} preset={def.plan.kb} durationInFrames={dur}>
        {/* pinned to the picture, outside the calligraphy disc */}
        <AbsoluteFill style={{opacity: med * 0.8}}>
          <div style={{position: "absolute", left: "50.5%", top: "48.5%", transform: "translate(-50%, -50%)"}}>
            <StarMedallion size={Math.round(width * 0.5)} progress={med} hollow />
          </div>
        </AbsoluteFill>
      </KenBurns>
      <LightRays intensity={def.plan.rays} />
      <Particles count={def.plan.particles} seed={14} speed={0.7} />
      <FrameOrnament delay={Math.round(fps * 0.3)} />
      <TextScrim anchor={def.plan.anchor} opacity={scrim} />
      <PhraseLayer phrases={adj} anchor={def.plan.anchor} />
      <Grade />
    </SceneShell>
  );
};
