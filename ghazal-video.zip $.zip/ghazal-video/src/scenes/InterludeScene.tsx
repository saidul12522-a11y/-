import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {BgMesh, Grade, LightRays, Particles} from "../components/Backdrop";
import {KenBurns} from "../components/KenBurns";
import {FrameOrnament, StarMedallion} from "../components/Ornaments";
import {SceneShell} from "../components/SceneShell";
import type {InterludeScene as InterludeDef} from "../data/timeline";

/** Instrumental gap between verses — a quiet, text-free "Minimal Islamic Statement": calligraphy hall + a gold ring that draws around it. */
export const InterludeScene: React.FC<{def: InterludeDef}> = ({def}) => {
  const frame = useCurrentFrame();
  const {fps, width} = useVideoConfig();
  const dur = def.to - def.seqFrom;
  const ring = interpolate(frame, [fps * 0.8, fps * 5], [0, 1], {easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  const glow = 0.5 + 0.5 * Math.sin((frame / fps) * 1.1);
  const size = Math.round(width * 0.5); // wide enough that no line touches the calligraphy disc
  return (
    <SceneShell overlapIn={def.overlapIn}>
      <BgMesh />
      <KenBurns src={def.plan.image} preset={def.plan.kb} durationInFrames={dur}>
        {/* pinned to the calligraphy medallion of the picture (centre ≈ 50.5%, 48.5%) */}
        <AbsoluteFill style={{justifyContent: "center", alignItems: "center"}}>
          <div style={{position: "absolute", left: "50.5%", top: "48.5%", transform: "translate(-50%, -50%)", opacity: 0.85, filter: `drop-shadow(0 0 ${10 + glow * 16}px ${theme.colors.glowGold})`}}>
            <StarMedallion size={size} progress={ring} hollow />
          </div>
        </AbsoluteFill>
      </KenBurns>
      <LightRays intensity={0.9} />
      <Particles count={30} seed={77} speed={0.6} />
      <FrameOrnament delay={Math.round(fps * 0.4)} />
      <Grade />
    </SceneShell>
  );
};
