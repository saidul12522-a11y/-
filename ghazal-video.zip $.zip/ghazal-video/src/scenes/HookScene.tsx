import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {BgMesh, Grade, LightRays, Particles} from "../components/Backdrop";
import {KenBurns} from "../components/KenBurns";
import {ArchOutline, FrameOrnament} from "../components/Ornaments";
import {SceneShell} from "../components/SceneShell";
import type {HookScene as HookDef} from "../data/timeline";

/** Opening hook: black → night sky, cinematic bars open, a mosque-arch draws itself in light. No text, no invented words. */
export const HookScene: React.FC<{def: HookDef}> = ({def}) => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const dur = def.to - def.seqFrom;
  const fadeIn = interpolate(frame, [0, fps * 1.2], [1, 0], {easing: theme.ease.out, extrapolateRight: "clamp"});
  const bars = interpolate(frame, [0, fps * 2.2], [96, 0], {easing: theme.ease.inOut, extrapolateRight: "clamp"});
  const arch = interpolate(frame, [fps * 1.2, fps * 5.5], [0, 1], {easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  const archFade = interpolate(frame, [fps * 9, fps * 12], [1, 0.25], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  const rays = interpolate(frame, [0, fps * 6], [0.3, 1], {easing: theme.ease.out, extrapolateRight: "clamp"});
  const aw = Math.round(width * 0.78);
  const ah = Math.round(height * 0.84);
  return (
    <SceneShell overlapIn={def.overlapIn}>
      <BgMesh />
      <KenBurns src={def.plan.image} preset={def.plan.kb} durationInFrames={dur} />
      <LightRays intensity={rays} />
      <Particles count={44} seed={3} speed={0.8} />
      <AbsoluteFill style={{justifyContent: "center", alignItems: "center", opacity: archFade}}>
        <ArchOutline w={aw} h={ah} progress={arch} />
      </AbsoluteFill>
      <FrameOrnament delay={Math.round(fps * 2)} />
      <Grade />
      <AbsoluteFill style={{background: theme.colors.deep, opacity: fadeIn}} />
      <div style={{position: "absolute", top: 0, left: 0, right: 0, height: bars, background: theme.colors.deep}} />
      <div style={{position: "absolute", bottom: 0, left: 0, right: 0, height: bars, background: theme.colors.deep}} />
    </SceneShell>
  );
};
