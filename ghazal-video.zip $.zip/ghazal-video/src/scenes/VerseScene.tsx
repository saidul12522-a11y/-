import React from "react";
import {interpolate, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {BgMesh, Grade, LightRays, Particles, TextScrim} from "../components/Backdrop";
import {KenBurns} from "../components/KenBurns";
import {FrameOrnament} from "../components/Ornaments";
import {PhraseLayer} from "../components/Phrase";
import {SceneShell} from "../components/SceneShell";
import type {VerseSceneDef} from "../data/timeline";

/** One cue of the ghazal: picture + a few key phrases. Five layers: mesh → picture → light/type → grade → (global grain). */
export const VerseScene: React.FC<{def: VerseSceneDef}> = ({def}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const dur = def.to - def.seqFrom;
  const local = def.phrases.map((p) => ({text: p.text, hero: p.hero, start: p.start - def.seqFrom, end: p.end - def.seqFrom}));
  const first = local[0]?.start ?? 0;
  const lastEnd = local[local.length - 1]?.end ?? dur;
  const scrim = interpolate(frame, [first - 6, first + 14, lastEnd - 10, lastEnd], [0, 1, 1, 0], {
    easing: theme.ease.out,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  return (
    <SceneShell overlapIn={def.overlapIn}>
      <BgMesh />
      <KenBurns src={def.plan.image} preset={def.plan.kb} durationInFrames={dur} />
      <LightRays intensity={def.plan.rays} />
      <Particles count={def.plan.particles} seed={def.cueIndex} />
      <FrameOrnament delay={Math.round(fps * 0.3)} />
      <TextScrim anchor={def.plan.anchor} opacity={scrim} />
      <PhraseLayer phrases={local} anchor={def.plan.anchor} />
      <Grade />
    </SceneShell>
  );
};
