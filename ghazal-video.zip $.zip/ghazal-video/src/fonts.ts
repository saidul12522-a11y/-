import {useEffect, useState} from "react";
import {continueRender, delayRender, staticFile} from "remotion";

// Offline Bengali fonts. Files are copied from node_modules into public/fonts by `npm install`
// (scripts/copy-fonts.mjs). Missing files are skipped and the CSS fallback stack is used instead.
const FACES = [
  {family: "Hind Siliguri", weight: "500", file: "fonts/hind-siliguri-bengali-500-normal.woff2"},
  {family: "Hind Siliguri", weight: "700", file: "fonts/hind-siliguri-bengali-700-normal.woff2"},
  {family: "Noto Sans Bengali", weight: "500", file: "fonts/noto-sans-bengali-bengali-500-normal.woff2"},
  {family: "Noto Sans Bengali", weight: "700", file: "fonts/noto-sans-bengali-bengali-700-normal.woff2"},
];

export const useFonts = (): boolean => {
  const [handle] = useState(() => delayRender("Loading Bengali fonts"));
  const [ready, setReady] = useState(false);
  useEffect(() => {
    Promise.all(
      FACES.map(async (f) => {
        try {
          const face = new FontFace(f.family, `url(${staticFile(f.file)})`, {weight: f.weight});
          await face.load();
          document.fonts.add(face);
        } catch (e) {
          console.warn(`Font not loaded: ${f.file} (run npm install to copy fonts)`);
        }
      })
    ).finally(() => {
      setReady(true);
      continueRender(handle);
    });
  }, [handle]);
  return ready;
};

export const useFileExists = (url: string): boolean => {
  const [handle] = useState(() => delayRender(`Checking ${url}`));
  const [exists, setExists] = useState(false);
  useEffect(() => {
    fetch(url, {method: "HEAD"})
      .then((r) => setExists(r.ok))
      .catch(() => setExists(false))
      .finally(() => continueRender(handle));
  }, [url, handle]);
  return exists;
};
