import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from "remotion";
import {rgba, theme} from "../theme";

const rand = (n: number) => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};
const mod = (a: number, b: number) => ((a % b) + b) % b;

/** Layer 1 — never a flat color: slowly drifting emerald/gold mesh. */
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const x1 = 30 + Math.sin(t * 0.3) * 8;
  const y1 = 25 + Math.cos(t * 0.25) * 6;
  return (
    <AbsoluteFill
      style={{
        background: `radial-gradient(ellipse at ${x1}% ${y1}%, ${theme.colors.glowEmerald} 0%, transparent 55%),
          radial-gradient(ellipse at 78% 88%, ${rgba(theme.colors.accent, 0.14)} 0%, transparent 50%),
          ${theme.colors.bg}`,
      }}
    />
  );
};

/** Layer 4 — colour grade: emerald soft-light wash + top/bottom depth. */
export const Grade: React.FC = () => (
  <>
    <AbsoluteFill
      style={{
        background: `linear-gradient(180deg, ${rgba(theme.colors.deep, 0.5)} 0%, transparent 26%, transparent 58%, ${rgba(theme.colors.deep, 0.72)} 100%)`,
      }}
    />
    <AbsoluteFill style={{background: theme.colors.hero, mixBlendMode: "soft-light", opacity: 0.32}} />
    <AbsoluteFill style={{background: theme.colors.accent, mixBlendMode: "soft-light", opacity: 0.1}} />
  </>
);

/** Layer 5 — film grain + vignette, mounted once on top of the whole video. */
export const GrainVignette: React.FC = () => {
  const frame = useCurrentFrame();
  const seed = Math.floor(frame / 2) % 40;
  return (
    <>
      <AbsoluteFill
        style={{
          background: `radial-gradient(ellipse at center, transparent 52%, ${rgba(theme.colors.deep, 0.78)} 100%)`,
        }}
      />
      <AbsoluteFill style={{mixBlendMode: "overlay", opacity: 0.1}}>
        <svg width="100%" height="100%">
          <filter id="grain">
            <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" seed={seed} />
            <feColorMatrix type="saturate" values="0" />
          </filter>
          <rect width="100%" height="100%" filter="url(#grain)" />
        </svg>
      </AbsoluteFill>
    </>
  );
};

/** Floating light motes. Deterministic (no Math.random). */
export const Particles: React.FC<{count?: number; seed?: number; speed?: number}> = ({count = 24, seed = 1, speed = 1}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  return (
    <AbsoluteFill style={{pointerEvents: "none"}}>
      {Array.from({length: count}).map((_, i) => {
        const x0 = rand(i + seed * 13) * 100;
        const y0 = rand(i * 3 + seed * 7) * 100;
        const size = 3 + rand(i * 7 + seed) * 7;
        const v = (0.5 + rand(i * 11 + seed) * 1.2) * speed;
        const ph = rand(i * 5 + seed) * 6.28;
        const y = mod(y0 - t * v * 1.6, 106) - 3;
        const x = x0 + Math.sin(t * 0.6 + ph) * 1.4;
        const tw = 0.3 + 0.7 * (0.5 + 0.5 * Math.sin(t * 1.8 + ph));
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: `${x}%`,
              top: `${y}%`,
              width: size,
              height: size,
              borderRadius: "50%",
              background: theme.colors.text,
              opacity: tw * 0.75,
              boxShadow: `0 0 ${size * 3}px ${size}px ${theme.colors.glowGold}`,
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

/** Soft god-rays from the top. Subtle by design; intensity 0..1. */
export const LightRays: React.FC<{intensity?: number}> = ({intensity = 0.6}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const fadeIn = interpolate(frame, [0, fps * 1.2], [0, 1], {easing: theme.ease.out, extrapolateRight: "clamp"});
  return (
    <AbsoluteFill style={{mixBlendMode: "screen", opacity: fadeIn, overflow: "hidden"}}>
      {Array.from({length: 6}).map((_, i) => {
        const ang = -26 + i * 10 + Math.sin(t * 0.25 + i) * 2.5;
        const breathe = 0.55 + 0.45 * Math.sin(t * 0.7 + i * 1.3);
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              top: -160,
              left: `${38 + i * 4}%`,
              width: 150 + (i % 3) * 70,
              height: 1500,
              transformOrigin: "50% 0%",
              transform: `rotate(${ang}deg)`,
              background: `linear-gradient(180deg, ${rgba(theme.colors.accent, 0.5)} 0%, transparent 78%)`,
              filter: "blur(26px)",
              opacity: intensity * 0.34 * breathe,
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

/** Readability scrim that follows the text anchor (stronger on bright floors/marble). */
export const TextScrim: React.FC<{anchor: string; opacity: number}> = ({anchor, opacity}) => {
  const [ax, ay] = anchor.split("-");
  const strong = rgba(theme.colors.deep, 0.92);
  const mid = rgba(theme.colors.deep, 0.5);
  const dir = ax === "left" ? "90deg" : ax === "right" ? "270deg" : ay === "bottom" ? "0deg" : "180deg";
  const stop = ax === "center" ? "58%" : "64%";
  return <AbsoluteFill style={{opacity, background: `linear-gradient(${dir}, ${strong} 0%, ${mid} 34%, transparent ${stop})`}} />;
};
