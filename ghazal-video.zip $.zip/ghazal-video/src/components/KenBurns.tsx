import React from "react";
import {AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame} from "remotion";
import {KbName, theme} from "../theme";

/** Every still gets a slow camera move. `children` live inside the moving plane (ring/ornaments pinned to the picture). */
export const KenBurns: React.FC<{
  src: string;
  preset: KbName;
  durationInFrames: number;
  children?: React.ReactNode;
}> = ({src, preset, durationInFrames, children}) => {
  const frame = useCurrentFrame();
  const k = theme.kb[preset];
  const t = interpolate(frame, [0, Math.max(1, durationInFrames)], [0, 1], {
    easing: theme.ease.kb,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const s = k.s0 + (k.s1 - k.s0) * t;
  const x = k.x0 + (k.x1 - k.x0) * t;
  const y = k.y0 + (k.y1 - k.y0) * t;
  return (
    <AbsoluteFill style={{overflow: "hidden"}}>
      <AbsoluteFill
        style={{
          transform: `translate(${x}%, ${y}%) scale(${s})`,
          transformOrigin: `${k.ox}% ${k.oy}%`,
        }}
      >
        <Img src={staticFile(src)} style={{width: "100%", height: "100%", objectFit: "cover"}} />
        {children}
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
