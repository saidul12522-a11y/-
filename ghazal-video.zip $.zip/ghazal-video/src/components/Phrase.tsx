import React from "react";
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {rgba, theme} from "../theme";

type Align = "left" | "center" | "right";
const flexAlign = (a: Align) => (a === "left" ? "flex-start" : a === "right" ? "flex-end" : "center");
const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

export type PhraseProps = {text: string; start: number; end: number; hero?: boolean; align: Align; maxWidthPct: number};

/** One key phrase: word-by-word mask reveal (spaces only — conjuncts are never split). */
export const Phrase: React.FC<PhraseProps> = ({text, start, end, hero, align, maxWidthPct}) => {
  const frame = useCurrentFrame();
  const {fps, width} = useVideoConfig();
  if (frame < start - 1 || frame > end + 1) return null;

  const words = text.split(" ").filter(Boolean);
  const size = hero ? theme.type.hero : theme.type.title;
  const stagger = Math.max(3, Math.round(theme.motion.staggerSec * fps));
  const exitF = Math.round(theme.motion.exitSec * fps);
  const local = frame - start;
  const exit = interpolate(frame, [end - exitF, end], [0, 1], {easing: theme.ease.in, extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  const breathe = 1 + Math.sin((frame / fps) * 1.4) * 0.006;
  const lineP = spring({frame: local - words.length * stagger - 4, fps, config: theme.spring.smooth});
  const color = hero ? theme.colors.accent : theme.colors.text;
  const padV = Math.round(size * 0.24);
  const padH = Math.round(size * 0.08);

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: flexAlign(align),
        maxWidth: (width * maxWidthPct) / 100,
        opacity: 1 - exit,
        transform: `translateY(${-exit * 26}px) scale(${breathe})`,
        transformOrigin: align === "left" ? "0% 50%" : align === "right" ? "100% 50%" : "50% 50%",
        filter: `blur(${exit * 6}px)`,
      }}
    >
      <div style={{display: "flex", flexWrap: "wrap", justifyContent: flexAlign(align), columnGap: Math.round(size * 0.3), rowGap: 0}}>
        {words.map((w, i) => {
          const p = spring({frame: local - i * stagger, fps, config: theme.spring.smooth});
          return (
            <span
              key={i}
              style={{display: "inline-block", overflow: "hidden", padding: `${padV}px ${padH}px`, margin: `-${padV}px -${padH}px`}}
            >
              <span
                style={{
                  display: "inline-block",
                  fontFamily: theme.fonts.display,
                  fontWeight: theme.type.weightTitle,
                  fontSize: size,
                  lineHeight: theme.type.lineHeight,
                  letterSpacing: theme.type.letterSpacing,
                  color,
                  whiteSpace: "nowrap",
                  textShadow: hero ? theme.shadows.heroGlow : theme.shadows.text,
                  opacity: clamp01(p * 2.2),
                  transform: `translateY(${(1 - p) * 105}%) scale(${0.94 + 0.06 * p})`,
                  filter: `blur(${(1 - p) * 8}px)`,
                }}
              >
                {w}
              </span>
            </span>
          );
        })}
      </div>
      <div
        style={{
          marginTop: Math.round(size * 0.1),
          height: 3,
          width: `${Math.round(clamp01(lineP) * 46)}%`,
          minWidth: 0,
          borderRadius: 2,
          background:
            align === "center"
              ? `linear-gradient(90deg, transparent, ${theme.colors.accent}, transparent)`
              : `linear-gradient(${align === "left" ? 90 : 270}deg, ${theme.colors.accent}, transparent)`,
          boxShadow: `0 0 18px ${rgba(theme.colors.accent, 0.6)}`,
        }}
      />
    </div>
  );
};

export type LocalPhrase = {text: string; start: number; end: number; hero: boolean};

/** Places the active phrase at the scene's anchor. Phrases occupy the same slot one after another. */
export const PhraseLayer: React.FC<{phrases: LocalPhrase[]; anchor: string}> = ({phrases, anchor}) => {
  const {width, height} = useVideoConfig();
  const [ax, ay] = anchor.split("-") as [Align, "top" | "middle" | "bottom"];
  const mx = Math.round(width * 0.07);
  return (
    <AbsoluteFill
      style={{
        display: "flex",
        flexDirection: "row", // AbsoluteFill is a column flexbox by default
        justifyContent: flexAlign(ax),
        alignItems: ay === "top" ? "flex-start" : ay === "bottom" ? "flex-end" : "center",
        paddingLeft: mx,
        paddingRight: mx,
        paddingTop: Math.round(height * (ay === "top" ? 0.15 : 0.05)),
        paddingBottom: Math.round(height * (ay === "bottom" ? 0.08 : 0.05)),
      }}
    >
      {phrases.map((p, i) => (
        <Phrase key={i} text={p.text} start={p.start} end={p.end} hero={p.hero} align={ax} maxWidthPct={ax === "center" ? 82 : 50} />
      ))}
    </AbsoluteFill>
  );
};
