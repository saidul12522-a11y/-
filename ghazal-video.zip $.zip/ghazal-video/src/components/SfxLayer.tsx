import React from "react";
import {Audio, interpolate, Sequence, staticFile, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {sfxEvents, totalFrames} from "../data/timeline";

/** Short, restrained, non-musical effects. They sit far below the voice-over. */
export const SfxLayer: React.FC = () => {
  const {fps} = useVideoConfig();
  const S = theme.sfx;
  const vol = (k: "whoosh" | "sweep" | "pop" | "chime") => S.volume[k];
  const file = (k: "whoosh" | "sweep" | "pop" | "chime") => S[k];
  return (
    <>
      {/* ambient bed with fade in/out */}
      <Audio
        src={staticFile(`sfx/${S.air.file}`)}
        loop
        volume={(f) =>
          S.volume.air *
          interpolate(f, [0, fps * 3, totalFrames - fps * 4, totalFrames], [0, 1, 1, 0], {extrapolateLeft: "clamp", extrapolateRight: "clamp"})
        }
      />
      {sfxEvents.map((e, i) => (
        <Sequence key={i} from={Math.max(0, e.frame)} durationInFrames={Math.ceil(file(e.kind).sec * fps)} layout="none">
          <Audio src={staticFile(`sfx/${file(e.kind).file}`)} volume={vol(e.kind)} />
        </Sequence>
      ))}
    </>
  );
};
