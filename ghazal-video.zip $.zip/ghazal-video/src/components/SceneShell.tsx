import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {LightSweep} from "./Ornaments";

/** Crossfade-in (opacity + slight scale) with a gold light sweep. Every scene after the first uses it. */
export const SceneShell: React.FC<{overlapIn: number; children: React.ReactNode}> = ({overlapIn, children}) => {
  const frame = useCurrentFrame();
  const p = overlapIn > 0 ? interpolate(frame, [0, overlapIn], [0, 1], {easing: theme.ease.out, extrapolateRight: "clamp"}) : 1;
  return (
    <AbsoluteFill style={{opacity: p, transform: `scale(${1.025 - 0.025 * p})`}}>
      {children}
      {overlapIn > 0 ? <LightSweep frames={overlapIn} /> : null}
    </AbsoluteFill>
  );
};
