import React from "react";
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {rgba, theme} from "../theme";

const starPoints = (cx: number, cy: number, R: number, r: number, n = 8): string =>
  Array.from({length: n * 2})
    .map((_, i) => {
      const a = (Math.PI * i) / n - Math.PI / 2;
      const rad = i % 2 === 0 ? R : r;
      return `${cx + Math.cos(a) * rad},${cy + Math.sin(a) * rad}`;
    })
    .join(" ");

const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

/** Thin gold border with 8-point stars in the corners — draws itself on. */
export const FrameOrnament: React.FC<{delay?: number}> = ({delay = 6}) => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const inset = 44;
  const draw = interpolate(frame, [delay, delay + fps * 1.6], [0, 1], {easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  const corners: [number, number][] = [[inset, inset], [width - inset, inset], [inset, height - inset], [width - inset, height - inset]];
  return (
    <AbsoluteFill style={{pointerEvents: "none"}}>
      <svg width={width} height={height}>
        <rect
          x={inset} y={inset} width={width - inset * 2} height={height - inset * 2}
          fill="none" stroke={rgba(theme.colors.accent, 0.5)} strokeWidth={2}
          pathLength={1} strokeDasharray={1} strokeDashoffset={1 - draw}
        />
        <rect
          x={inset + 14} y={inset + 14} width={width - (inset + 14) * 2} height={height - (inset + 14) * 2}
          fill="none" stroke={rgba(theme.colors.accent, 0.22)} strokeWidth={1}
          pathLength={1} strokeDasharray={1} strokeDashoffset={1 - draw}
        />
        {corners.map(([cx, cy], i) => {
          const p = spring({frame: frame - delay - 10 - i * 5, fps, config: theme.spring.smooth});
          const rot = (frame / fps) * 4 * (i % 2 ? -1 : 1);
          return (
            <g key={i} transform={`translate(${cx} ${cy}) rotate(${rot}) scale(${p})`} opacity={clamp01(p)}>
              <polygon points={starPoints(0, 0, 22, 11)} fill={theme.colors.bg} stroke={theme.colors.accent} strokeWidth={2} />
              <circle r={4} fill={theme.colors.accent} />
            </g>
          );
        })}
      </svg>
    </AbsoluteFill>
  );
};

/** Rotating 8-fold geometric medallion (two squares + octagon + ring). */
/** `hollow` keeps the centre free (used around calligraphy — no line ever crosses the written Name). */
export const StarMedallion: React.FC<{size: number; progress: number; opacity?: number; hollow?: boolean}> = ({size, progress, opacity = 1, hollow = false}) => {
  const frame = useCurrentFrame();
  const R = size / 2;
  const sq = (rot: number) =>
    Array.from({length: 4}).map((_, i) => {
      const a = (Math.PI / 2) * i + (rot * Math.PI) / 180 - Math.PI / 4;
      return `${Math.cos(a) * R * 0.92},${Math.sin(a) * R * 0.92}`;
    }).join(" ");
  const oct = Array.from({length: 8}).map((_, i) => {
    const a = (Math.PI / 4) * i + Math.PI / 8;
    return `${Math.cos(a) * R * 0.5},${Math.sin(a) * R * 0.5}`;
  }).join(" ");
  const common = {fill: "none", stroke: theme.colors.accent, pathLength: 1, strokeDasharray: 1, strokeDashoffset: 1 - clamp01(progress), strokeLinejoin: "round" as const};
  return (
    <svg width={size} height={size} viewBox={`${-R} ${-R} ${size} ${size}`} style={{opacity, transform: `rotate(${frame * 0.06}deg)`}}>
      <circle r={R * 0.98} {...common} strokeWidth={3} />
      <circle r={R * 0.74} {...common} strokeWidth={1} />
      <polygon points={sq(0)} {...common} strokeWidth={3} />
      <polygon points={sq(45)} {...common} strokeWidth={3} />
      {hollow ? null : <polygon points={oct} {...common} strokeWidth={1.5} />}
    </svg>
  );
};

/** Pointed mosque-arch outline, drawn on. */
export const ArchOutline: React.FC<{w: number; h: number; progress: number}> = ({w, h, progress}) => {
  const d = `M 0 ${h} L 0 ${h * 0.4} C 0 ${h * 0.14}, ${w * 0.4} ${h * 0.07}, ${w / 2} 0 C ${w * 0.6} ${h * 0.07}, ${w} ${h * 0.14}, ${w} ${h * 0.4} L ${w} ${h}`;
  const p = clamp01(progress);
  return (
    <svg width={w} height={h} viewBox={`-6 -6 ${w + 12} ${h + 12}`} style={{overflow: "visible"}}>
      <path d={d} fill="none" stroke={rgba(theme.colors.accent, 0.25)} strokeWidth={14} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p} style={{filter: "blur(8px)"}} />
      <path d={d} fill="none" stroke={theme.colors.accent} strokeWidth={2.5} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p} />
    </svg>
  );
};

/** Elegant diagonal light sweep used on scene transitions. */
export const LightSweep: React.FC<{frames: number}> = ({frames}) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [0, frames * 1.8], [-0.3, 1.3], {easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  if (frame > frames * 1.8) return null;
  return (
    <AbsoluteFill style={{mixBlendMode: "screen", overflow: "hidden", pointerEvents: "none"}}>
      <div
        style={{
          position: "absolute", top: -200, bottom: -200, width: 420, left: `${p * 100}%`,
          transform: "skewX(-18deg)",
          background: `linear-gradient(90deg, transparent, ${rgba(theme.colors.accent, 0.34)}, transparent)`,
          filter: "blur(14px)",
        }}
      />
    </AbsoluteFill>
  );
};
