import React from "react";
import {Audio, getRemotionEnvironment, staticFile} from "remotion";
import {useFileExists} from "../fonts";

/**
 * Voice-over for synchronisation checks.
 * - Plays in Remotion Studio whenever public/voiceover.mp3 exists.
 * - OFF by default in renders; enable with  --props='{"renderVoiceover":true}'
 */
export const PreviewAudio: React.FC<{renderVoiceover: boolean}> = ({renderVoiceover}) => {
  const url = staticFile("voiceover.mp3");
  const exists = useFileExists(url);
  const {isRendering} = getRemotionEnvironment();
  if (!exists) return null;
  if (isRendering && !renderVoiceover) return null;
  return <Audio src={url} volume={1} />;
};
