// theme.ts — the ONLY place for colors, fonts, easings, springs, shadows and presets.
// Color scheme: 01 · Islamic Emerald Gold
import {Easing} from "remotion";

export const rgba = (hex: string, a: number): string => {
  const n = parseInt(hex.replace("#", ""), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
};

const colors = {
  bg: "#071F19",
  hero: "#0D6B4B",
  accent: "#D6B36A",
  text: "#FFF8E8",
  deep: "#03130F", // darkened bg, used for scrims / vignette only
} as const;

export const theme = {
  video: {width: 1920, height: 1080, fps: 30},
  colors: {
    ...colors,
    textDim: rgba(colors.text, 0.74),
    glowGold: rgba(colors.accent, 0.42),
    glowEmerald: rgba(colors.hero, 0.55),
    scrim: rgba(colors.deep, 0.8),
  },
  fonts: {
    // Offline copies are copied into public/fonts by scripts/copy-fonts.mjs
    display: '"Hind Siliguri", "Noto Sans Bengali", "Kohinoor Bangla", "Vrinda", sans-serif',
  },
  type: {
    hero: 150,
    title: 108,
    weightTitle: 700,
    weightBody: 500,
    lineHeight: 1.5, // Bengali matras/ref need generous line height
    letterSpacing: 0,
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
    kb: Easing.bezier(0.45, 0.05, 0.55, 0.95), // soft camera curve (never linear)
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    soft: {damping: 26, stiffness: 60, mass: 1.2},
  },
  motion: {
    crossfadeSec: 0.5,
    exitSec: 0.33,
    staggerSec: 0.14,
    tailSec: 5, // quiet closing after the last SRT cue
    endFadeSec: 2.5,
    interludeMinGapSec: 2,
  },
  shadows: {
    text: "0 4px 30px rgba(3, 19, 15, 0.85), 0 0 70px rgba(3, 19, 15, 0.6)",
    heroGlow: "0 0 40px rgba(214, 179, 106, 0.55), 0 4px 30px rgba(3, 19, 15, 0.85)",
  },
  // Camera presets. x/y in % of frame, s = scale. Kept within the safe margin of the scale.
  kb: {
    pushIn: {s0: 1.0, s1: 1.1, x0: 0, x1: -1.5, y0: 0, y1: -1, ox: 50, oy: 50},
    pushInSlow: {s0: 1.0, s1: 1.07, x0: 1, x1: 0, y0: 0, y1: -0.5, ox: 50, oy: 50},
    pullOut: {s0: 1.12, s1: 1.02, x0: 0, x1: 0, y0: -1, y1: 0, ox: 50, oy: 50},
    panLeft: {s0: 1.1, s1: 1.1, x0: 3, x1: -3, y0: 0, y1: 0, ox: 50, oy: 50},
    panRight: {s0: 1.1, s1: 1.1, x0: -3, x1: 3, y0: 0, y1: 0, ox: 50, oy: 50},
    driftUp: {s0: 1.06, s1: 1.1, x0: 0, x1: 0, y0: 2, y1: -2, ox: 50, oy: 50},
    pushCenter: {s0: 1.0, s1: 1.12, x0: 0, x1: 0, y0: 0, y1: 0, ox: 50, oy: 48},
    pushCenterOn: {s0: 1.12, s1: 1.2, x0: 0, x1: 0, y0: 0, y1: 0, ox: 50, oy: 48},
  },
  sfx: {
    // file name -> length in seconds (see scripts/generate-sfx.mjs)
    whoosh: {file: "whoosh_soft.wav", sec: 0.9},
    sweep: {file: "sweep_transition.wav", sec: 1.4},
    pop: {file: "pop_gentle.wav", sec: 0.25},
    click: {file: "click_subtle.wav", sec: 0.1},
    chime: {file: "chime_gentle.wav", sec: 2.4},
    air: {file: "air_texture.wav", sec: 20},
    volume: {whoosh: 0.16, sweep: 0.2, pop: 0.1, chime: 0.14, air: 0.05},
  },
} as const;

export type KbName = keyof typeof theme.kb;
