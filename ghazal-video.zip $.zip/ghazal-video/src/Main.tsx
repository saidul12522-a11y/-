import React from "react";
import {AbsoluteFill, interpolate, Sequence, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "./theme";
import {useFonts} from "./fonts";
import {scenes, totalFrames} from "./data/timeline";
import {GrainVignette} from "./components/Backdrop";
import {SfxLayer} from "./components/SfxLayer";
import {PreviewAudio} from "./components/PreviewAudio";
import {HookScene} from "./scenes/HookScene";
import {VerseScene} from "./scenes/VerseScene";
import {InterludeScene} from "./scenes/InterludeScene";
import {ClosingScene} from "./scenes/ClosingScene";

export type MainProps = {renderVoiceover: boolean};

const EndFade: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const o = interpolate(frame, [totalFrames - Math.round(theme.motion.endFadeSec * fps), totalFrames], [0, 1], {
    easing: theme.ease.in,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  return <AbsoluteFill style={{background: theme.colors.deep, opacity: o}} />;
};

export const Main: React.FC<MainProps> = ({renderVoiceover}) => {
  useFonts();
  return (
    <AbsoluteFill style={{backgroundColor: theme.colors.bg}}>
      {scenes.map((s, i) => (
        <Sequence key={i} from={s.seqFrom} durationInFrames={Math.max(1, s.to - s.seqFrom)}>
          {s.type === "hook" ? <HookScene def={s} /> : null}
          {s.type === "verse" ? <VerseScene def={s} /> : null}
          {s.type === "interlude" ? <InterludeScene def={s} /> : null}
          {s.type === "closing" ? <ClosingScene def={s} /> : null}
        </Sequence>
      ))}
      <GrainVignette />
      <EndFade />
      <SfxLayer />
      <PreviewAudio renderVoiceover={renderVoiceover} />
    </AbsoluteFill>
  );
};
