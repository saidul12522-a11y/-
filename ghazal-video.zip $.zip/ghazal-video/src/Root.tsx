import React from "react";
import {Composition} from "remotion";
import {Main, MainProps} from "./Main";
import {theme} from "./theme";
import {totalFrames} from "./data/timeline";

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Main"
    component={Main}
    durationInFrames={totalFrames}
    fps={theme.video.fps}
    width={theme.video.width}
    height={theme.video.height}
    defaultProps={{renderVoiceover: false} satisfies MainProps}
  />
);
