# গজল মোশন গ্রাফিক্স — Remotion প্রজেক্ট

Composition: `Main` · 1920×1080 · 30 fps · রং: Islamic Emerald Gold (`src/theme.ts`)

## কমান্ড
```
npm install                                   # প্যাকেজ + বাংলা ফন্ট (public/fonts-এ কপি হয়)
npx remotion studio                           # Preview (public/voiceover.mp3 থাকলে অডিও বাজে)
npx remotion render src/index.ts Main out/video.mp4
```
ভয়েসওভারসহ রেন্ডার: `npx remotion render src/index.ts Main out/video.mp4 --props='{"renderVoiceover":true}'`
(ডিফল্টে রেন্ডারে ভয়েসওভার বন্ধ, শুধু SFX থাকে।)

## ফাইল
- `public/ghazal.srt` → `npm run srt` → `src/data/ghazal.srt.ts` (একমাত্র টাইমিং সোর্স)
- `src/data/plan.json` — কোন কিউতে কোন ছবি, ক্যামেরা মুভ, টেক্সটের জায়গা ও দেখানো শব্দগুচ্ছ
- `src/theme.ts` — রং, ফন্ট, ইজিং, স্প্রিং, শ্যাডো, ক্যামেরা প্রিসেট
- `src/scenes/` — Hook, Verse, Interlude, Closing
- `public/sfx/` — `npm run sfx` দিয়ে আবার তৈরি করা যায়
- `npm run check` — SRT/plan/ছবি/SFX পিক ও টাইপ যাচাই

## জানা সীমাবদ্ধতা
- ভিডিওর দৈর্ঘ্য = SRT-এর শেষ কিউ + ৫ সেকেন্ড (`theme.motion.tailSec`)। আপলোড করা অডিও এর চেয়ে লম্বা।
- শব্দগুচ্ছের সময় কিউয়ের ভেতরে অক্ষর-অনুপাতে ধরা; Studio-তে ভয়েসওভার চালিয়ে মিলিয়ে নিন।

## GitHub Actions দিয়ে রেন্ডার
Repository → Actions → "Render video" → Run workflow → শেষ হলে run খুলে Artifacts থেকে `ghazal-video` নামান।
