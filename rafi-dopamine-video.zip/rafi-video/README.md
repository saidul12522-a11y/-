# Rafi Dopamine Video (Remotion)
npm install
npx remotion studio
npx remotion render Main out/video.mp4
