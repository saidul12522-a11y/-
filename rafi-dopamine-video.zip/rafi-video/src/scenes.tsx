import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {C, W, H} from './theme';
import {Bubble, Card, Cam, FF, Stamp, Vig, bn, lerp, prog, usePop} from './ui';
import {Character} from './Character';
import {Alarm, AClock, Bell, Bolt, Book, Bowl, Brain, Bubble2, Bulb, Heart, Slot, Story, Thumb, Trash, Txt} from './Icons';
import {Bed, Bg, Clock, Phone} from './Props';

type SP = {d: number};
type K = React.ComponentProps<typeof Bg>['kind'];
type WP = {kind: K; d: number; z?: [number, number]; px?: [number, number]; py?: [number, number]; shake?: number; vig?: number; art?: React.ReactNode; ui?: React.ReactNode; color?: string};
const Wrap: React.FC<WP> = ({kind, d, z, px, py, shake, vig = 0.22, art, ui, color}) => (
  <AbsoluteFill>
    <Cam d={d} z={z} px={px} py={py} shake={shake}>
      <Bg kind={kind} color={color} />
      <svg style={{position: 'absolute', left: 0, top: 0}} width={W} height={H}>{art}</svg>
      <AbsoluteFill>{ui}</AbsoluteFill>
    </Cam>
    <Vig a={vig} />
  </AbsoluteFill>
);
const Glow: React.FC<{x: number; y: number; r: number; c: string; o?: number}> = ({x, y, r, c, o = 0.35}) => (
  <div style={{position: 'absolute', left: x - r, top: y - r, width: r * 2, height: r * 2, borderRadius: r, background: `radial-gradient(circle, ${c} 0%, rgba(0,0,0,0) 70%)`, opacity: o}} />
);
const Label: React.FC<{x: number; y: number; t: string; size?: number; color?: string; w?: number}> = ({x, y, t, size = 34, color = C.ink, w = 320}) => (
  <div style={{position: 'absolute', left: x - w / 2, top: y, width: w, textAlign: 'center', fontFamily: FF, fontWeight: 700, fontSize: size, color}}>{t}</div>
);
const Table: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x},${y})`}><rect x={-60} y={-6} width={120} height={8} rx={4} fill="#B98B5E" stroke={C.ink} strokeWidth={3} /></g>
);
const Plate: React.FC<{x: number; y: number; rice?: number}> = ({x, y, rice = 0.5}) => (
  <g transform={`translate(${x},${y})`}>
    <ellipse rx={62} ry={12} cy={4} fill="#fff" stroke={C.ink} strokeWidth={4} />
    <path d={`M${-40 * rice - 8} 0 Q0 ${-50 * rice - 6} ${40 * rice + 8} 0Z`} fill="#fff" stroke={C.ink} strokeWidth={3} />
  </g>
);

/* 1 */ const S1: React.FC<SP> = ({d}) => (
  <Wrap kind="night" d={d} z={[1, 1.25]} px={[0, -50]} py={[0, -20]} vig={0.5}
    art={<><rect x={70} y={520} width={170} height={80} fill="#1B2240" stroke={C.ink} strokeWidth={4} /><Clock x={150} y={500} text="02:00" /><Bed x={640} y={600} glow /></>} />
);
/* 2 */ const S2: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const rise = prog(f, 20, 60);
  return (
    <Wrap kind="navy" d={d} z={[1, 1.08]} vig={0.5}
      art={<><Character x={640} y={960} s={2.6} mood={f < 70 ? 'sleepy' : 'neutral'} night down={f > 70} /><Phone x={640} y={lerp(900, 640, rise)} s={1.6} glow face={false} scroll={f * 3} /></>}
      ui={<><Glow x={640} y={420} r={380} c={C.glow} o={0.4 * rise} /><Bubble x={860} y={60} w={340} text="আর একটা ভিডিও…" thought delay={40} /></>} />
  );
};
/* 3 */ const S3: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const m = Math.floor(prog(f, 0, d - 10) * 180);
  const hh = 2 + Math.floor(m / 60), mm = String(m % 60).padStart(2, '0');
  return (
    <Wrap kind="navy" d={d} z={[1, 1.1]} vig={0.5}
      art={<><Phone x={640} y={420} s={1.6} scroll={f * 5} hands glow /><Clock x={1100} y={190} text={`0${hh}:${mm}`} s={1.2} /></>} />
  );
};
/* 4 */ const S4: React.FC<SP> = ({d}) => (
  <Wrap kind="office" d={d} z={[1, 1.06]}
    art={<Character x={520} y={575} sit seed={3} mood="neutral" armR={-60} />}
    ui={<Card x={880} y={190} w={330} text="২৮ বছর · ঢাকা" delay={30} />} />
);
/* 5 */ const S5: React.FC<SP> = ({d}) => (
  <Wrap kind="room" d={d} z={[1, 1.12]} px={[0, -40]}
    art={<Bed x={640} y={600} night={false} eyes="closed" arm />}
    ui={<Glow x={1100} y={200} r={300} c="#FFE9A8" o={0.5} />} />
);
/* 6 */ const S6: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const st = 1 - prog(f, 20, d - 20);
  return (
    <Wrap kind="office" d={d} z={[1, 1.1]} px={[0, 40]}
      art={<>
        <Character x={520} y={575} sit seed={5} down mood="sad" armR={-80} holdR={<g />} />
        <Phone x={640} y={430} s={0.34} rot={-15} glow />
        <Plate x={800} y={470} rice={0.9} />
        {[0, 1, 2].map((i) => (
          <path key={i} d={`M${780 + i * 20} 440 q-10 -16 0 -32 q10 -16 0 -32`} stroke="#9aa3b2" strokeWidth={4} fill="none" strokeLinecap="round" opacity={st * 0.8} transform={`translate(0,${-Math.sin((f + i * 8) / 6) * 4})`} />
        ))}
      </>} />
  );
};
/* 7 */ const S7: React.FC<SP> = ({d}) => (
  <Wrap kind="dine" d={d} z={[1, 1.08]} px={[0, -30]}
    art={<>
      <Plate x={560} y={470} rice={0.9} /><Plate x={800} y={470} rice={0.9} />
      <Character x={360} y={580} s={1} sit female talk flip={false} armR={-50} seed={9} mood="neutral" />
      <Character x={930} y={580} sit flip seed={2} down mood="neutral" armL={-70} holdL={<g />} armR={-30} />
      <Phone x={860} y={448} s={0.3} rot={-8} glow />
    </>}
    ui={<Bubble x={150} y={80} w={430} text="পাশের বাড়ির খালার অসুখের কথা…" delay={15} size={32} />} />
);
/* 8 */ const S8: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const t = [0.08, 0.38, 0.68].map((p) => Math.round(d * p));
  const talking = t.some((s) => f >= s && f < s + 22);
  return (
    <Wrap kind="dine" d={d} z={[1, 1.08]}
      art={<>
        <Plate x={560} y={470} rice={0.9} /><Plate x={800} y={470} rice={0.9} />
        <Character x={360} y={580} sit female talk={talking} armR={-50} seed={9} />
        <Character x={930} y={580} sit flip seed={2} down />
        <Phone x={860} y={448} s={0.3} rot={-8} glow />
      </>}
      ui={<>
        {t.map((s, i) => <Bubble key={i} x={330 + i * 60} y={90 + i * 6} w={90} text="?" delay={s} size={44} />)}
        {t.map((s, i) => <Bubble key={'h' + i} x={820 + i * 20} y={230 - i * 4} w={150} text="হুম" delay={s + 24} tail="r" size={34} />)}
      </>} />
  );
};
/* 9 */ const S9: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const w = prog(f, 20, d * 0.5);
  const pl = prog(f, 5, 30);
  return (
    <Wrap kind="dine" d={d} z={[1, 1.5]} px={[0, -260]} py={[0, -60]}
      art={<>
        <Plate x={800} y={470} rice={0.45} /><Plate x={lerp(560, 480, pl)} y={470} rice={0.9} />
        <Character x={lerp(360, -200, w)} y={580} female walk={w > 0 && w < 1} flip armR={-10} seed={9} mood="sad" />
        <Character x={930} y={580} sit flip seed={2} down mood="sad" />
      </>} />
  );
};
/* 10 */ const S10: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  return (
    <Wrap kind="plain" d={d} z={[1, 1.05]} vig={0.12}
      art={<>
        <Brain x={640} y={340} s={1.5} />
        {[0, 1, 2, 3, 4, 5].map((i) => <circle key={i} cx={640 + Math.cos(f / 20 + i) * 190} cy={330 + Math.sin(f / 20 + i) * 120} r={9} fill={C.amber} stroke={C.ink} strokeWidth={3} />)}
      </>}
      ui={<>
        <Card x={90} y={260} w={330} text="ইচ্ছার দুর্বলতা" bg="#FFE0E0" delay={10} />
        <Card x={860} y={260} w={330} text="মস্তিষ্কের রসায়ন" bg="#D8F5EF" delay={50} />
        <Stamp x={130} y={380} text="✗" color={C.red} delay={d * 0.33} size={90} />
        <Stamp x={950} y={380} text="✓" color={C.teal} delay={d * 0.6} size={90} />
      </>} />
  );
};
/* 11 */ const S11: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const p = (f % 24) / 24;
  const q = prog(f, d * 0.6, d * 0.75);
  return (
    <Wrap kind="plain" d={d} z={[1, 1.05]} vig={0.12}
      art={<>
        <Phone x={260} y={380} s={1.1} scroll={f * 4} hands />
        <Brain x={800} y={330} s={1} />
        <circle cx={lerp(360, 760, p)} cy={lerp(330, 320, p) - Math.sin(Math.PI * p) * 90} r={16} fill={C.amber} stroke={C.ink} strokeWidth={4} />
        <g transform="translate(1100,360)" opacity={q}><rect x={-70} y={-70} width={140} height={140} rx={16} fill="#fff" stroke={C.ink} strokeWidth={5} /><Txt x={0} y={26} t="?" size={90} /></g>
      </>}
      ui={<Label x={800} y={450} t="Dopamine" color={C.amber} size={44} />} />
  );
};
/* 12 */ const S12: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const stops = [0.35, 0.5, 0.65].map((p) => d * p);
  return (
    <Wrap kind="plain" d={d} z={[1, 1.06]} vig={0.12}
      art={<>
        <rect x={440} y={100} width={400} height={480} rx={36} fill={C.red} stroke={C.ink} strokeWidth={6} />
        <rect x={480} y={220} width={320} height={150} rx={14} fill="#fff" stroke={C.ink} strokeWidth={5} />
        {stops.map((s, i) => <Slot key={i} x={540 + i * 100} y={295} sym={f < s ? Math.floor(f / 2 + i) % 4 : 0} s={1.2} />)}
        {[0, 1, 2, 3, 4, 5].map((i) => <circle key={i} cx={480 + i * 64} cy={160} r={11} fill={Math.floor(f / 6) % 2 === i % 2 ? '#FFE066' : '#8a2a2e'} stroke={C.ink} strokeWidth={3} />)}
        <line x1={850} y1={300} x2={910} y2={lerp(190, 330, f % 40 < 20 ? 1 : 0)} stroke={C.ink} strokeWidth={10} strokeLinecap="round" />
        <circle cx={910} cy={lerp(190, 330, f % 40 < 20 ? 1 : 0)} r={20} fill={C.amber} stroke={C.ink} strokeWidth={5} />
      </>} />
  );
};
/* 13 */ const S13: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const g = prog(f, 10, d * 0.85);
  const st: React.CSSProperties = {filter: `grayscale(${g})`, opacity: 1 - g * 0.55};
  return (
    <Wrap kind="plain" d={d} z={[1, 1.05]} vig={0.12}
      art={<g style={st}><Book x={320} y={340} s={1.7} /><Story x={640} y={340} s={1.7} /><Bowl x={960} y={350} s={1.7} /></g>} />
  );
};
/* 14 */ const S14: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const a = prog(f, 5, d * 0.5), o = 1 - prog(f, d * 0.5, d * 0.6), ic = prog(f, d * 0.62, d * 0.95);
  const bars = (x: number, c: string) => <rect x={x} y={560 - lerp(320, 90, a)} width={150} height={lerp(320, 90, a)} rx={10} fill={c} stroke="#fff" strokeWidth={3} />;
  return (
    <Wrap kind="navy" d={d} z={[1, 1.05]} vig={0.4}
      art={<>
        <g opacity={o}>{bars(420, C.glow)}{bars(710, C.amber)}</g>
        <g opacity={prog(f, d * 0.55, d * 0.65)}>
          <g transform={`translate(${lerp(480, 880, ic)},${lerp(300, 330, ic)}) scale(${1 - ic * 0.4})`}><rect x={-50} y={-50} width={100} height={100} rx={22} fill="#3B5BDB" /><Txt x={0} y={26} t="f" size={80} fill="#fff" /></g>
          <g transform={`translate(${lerp(680, 880, ic)},${lerp(300, 330, ic)}) scale(${1 - ic * 0.4})`}><rect x={-50} y={-50} width={100} height={100} rx={26} fill="#D6249F" /><circle r={24} fill="none" stroke="#fff" strokeWidth={7} /></g>
          <Trash x={900} y={440} s={1.6} />
        </g>
      </>}
      ui={<>
        <Label x={495} y={585} t="মনোযোগ" color="#fff" /><Label x={785} y={585} t="ঘুম" color="#fff" />
      </>} />
  );
};
/* 15 */ const S15: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const p = prog(f, 20, d - 10);
  return (
    <Wrap kind="night" d={d} z={[1, 1.06]} vig={0.5}
      art={<>
        <Character x={380} y={590} sit night down mood="sad" armR={-70} seed={4} />
        <Phone x={500} y={440} s={0.35} rot={-20} glow />
        <circle cx={1090} cy={150} r={70} fill="none" stroke="#2A3868" strokeWidth={14} />
        <circle cx={1090} cy={150} r={70} fill="none" stroke={C.amber} strokeWidth={14} strokeDasharray={`${p * 440} 440`} strokeLinecap="round" transform="rotate(-90 1090 150)" />
        <rect x={700} y={250} width={460} height={290} rx={16} fill="#fff" stroke={C.ink} strokeWidth={5} />
        <rect x={700} y={250} width={460} height={52} rx={16} fill="#E5E9F2" />
        <rect x={716} y={304} width={420} height={110} rx={8} fill="#D9DEEA" /><rect x={716} y={430} width={300} height={16} rx={8} fill="#B7BED1" />
      </>}
      ui={<>
        <Label x={1090} y={122} t="১ ঘণ্টা" size={26} color="#fff" w={140} />
        <Label x={820} y={256} t="facebook" size={24} w={200} /><Label x={1020} y={256} t="instagram" size={24} w={200} />
      </>} />
  );
};
/* 16 */ const S16: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  return (
    <Wrap kind="room" d={d} z={[1, 1.06]} shake={25}
      art={<>
        <Character x={380} y={640} s={1.4} mood="shock" seed={1} armR={-40} />
        <rect x={720} y={110} width={420} height={440} rx={26} fill="#15171f" stroke={C.ink} strokeWidth={6} />
        {[0, 1, 2, 3, 4, 5, 6].map((i) => <rect key={i} x={760 + i * 52} y={500 - prog(f, 10 + i * 4, 40 + i * 4) * (80 + i * 38)} width={38} height={prog(f, 10 + i * 4, 40 + i * 4) * (80 + i * 38)} rx={6} fill={i > 4 ? C.red : C.glow} />)}
      </>}
      ui={<Label x={930} y={130} t="Screen time" color="#fff" size={36} />} />
  );
};
/* 17 */ const S17: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const p = prog(f, 5, d * 0.6);
  return (
    <Wrap kind="plain" d={d} z={[1, 1.05]} vig={0.12}
      art={<Character x={1070} y={680} s={0.9} mood="think" armR={-20} seed={6} />}
      ui={<>
        <Card x={170} y={190} w={700} text={`${bn(Math.floor(6 * p))} ঘণ্টা ${bn(Math.floor(40 * p))} মিনিট`} bg="#FFF3B0" size={72} rot={-2} delay={0} />
        <Bubble x={900} y={190} w={110} text="" thought delay={d * 0.55} tail="r"><svg width={50} height={60} viewBox="-30 -50 60 90"><Bulb x={0} y={0} /></svg></Bubble>
      </>} />
  );
};
/* 18 */ const S18: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const p = prog(f, 10, d * 0.8), fall = prog(f, d * 0.8, d - 5);
  const rx = lerp(300, 520, p);
  return (
    <Wrap kind="plain" d={d} z={[1, 1.05]} vig={0.12}
      art={<>
        <line x1={0} y1={600} x2={W} y2={600} stroke="#C9BFAA" strokeWidth={6} />
        <line x1={rx + 70} y1={420} x2={880} y2={420} stroke="#8B5E3C" strokeWidth={8} />
        <g transform={`rotate(${-fall * 70} ${rx} 600)`}><Character x={rx} y={600} armR={-85} armL={-85} mood="angry" seed={2} /></g>
        <Phone x={1000} y={400} s={1.5} face />
      </>} />
  );
};
/* 19 */ const S19: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const w = prog(f, 20, d * 0.75);
  return (
    <Wrap kind="night" d={d} z={[1, 1.06]} vig={0.5}
      art={<>
        <rect x={0} y={480} width={W} height={14} fill="#2A3868" />
        {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map((i) => <line key={i} x1={i * 110 + 20} y1={494} x2={i * 110 + 20} y2={600} stroke="#2A3868" strokeWidth={6} />)}
        <rect x={880} y={420} width={220} height={12} rx={4} fill="#6B4A33" stroke={C.ink} strokeWidth={3} />
        <Phone x={990} y={398} s={0.2} rot={90} />
        <line x1={1010} y1={420} x2={1080} y2={300} stroke="#aab" strokeWidth={4} /><Bolt x={1080} y={280} s={0.8 + 0.2 * Math.sin(f / 5)} />
        <Character x={lerp(840, 380, w)} y={600} flip walk={w > 0 && w < 1} night seed={3} />
      </>} />
  );
};
/* 20 */ const S20: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const p = usePop(18);
  return (
    <Wrap kind="night" d={d} z={[1, 1.08]} vig={0.5}
      art={<>
        <Bed x={700} y={600} eyes="closed" />
        <rect x={150} y={500} width={150} height={100} fill="#1B2240" stroke={C.ink} strokeWidth={4} />
        <g transform={`translate(225,450) scale(${p * 1.3})`}><Alarm x={0} y={0} ring={Math.sin(f / 2) * 6 * (f > 40 ? 1 : 0)} /></g>
      </>} />
  );
};
/* 21 */ const S21: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const g = prog(f, d * 0.55, d * 0.85);
  const tg = (t: number, y: number) => {
    const off = prog(f, t, t + 8);
    return (
      <g key={y} transform={`translate(900,${y})`}>
        <rect x={-60} y={-28} width={120} height={56} rx={28} fill={off ? '#555C73' : C.teal} stroke="#fff" strokeWidth={3} />
        <circle cx={lerp(30, -30, off)} cy={0} r={22} fill="#fff" />
      </g>
    );
  };
  return (
    <Wrap kind="night" d={d} z={[1, 1.06]} vig={0.5}
      art={<><Phone x={400} y={380} s={1.4} gray={g} scroll={f * 2} glow />{tg(20, 250)}{tg(45, 380)}{tg(70, 510)}</>} />
  );
};
/* 22 */ const S22: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const p = prog(f, 10, d - 10);
  const secs = Math.round((1 - p) * 600);
  const reach = -75 * Math.abs(Math.sin(f / 18));
  return (
    <Wrap kind="night" d={d} z={[1, 1.06]} vig={0.5}
      art={<>
        <circle cx={400} cy={380} r={150} fill="none" stroke="#2A3868" strokeWidth={22} />
        <circle cx={400} cy={380} r={150} fill="none" stroke={C.amber} strokeWidth={22} strokeDasharray={`${(1 - p) * 942} 942`} strokeLinecap="round" transform="rotate(-90 400 380)" />
        <Txt x={400} y={400} t={bn(`${String(Math.floor(secs / 60)).padStart(2, '0')}:${String(secs % 60).padStart(2, '0')}`)} size={64} fill="#fff" />
        <rect x={740} y={500} width={150} height={14} rx={5} fill="#6B4A33" stroke={C.ink} strokeWidth={3} />
        <Phone x={810} y={486} s={0.25} rot={90} />
        <Character x={1060} y={640} flip armR={reach} night mood="sad" seed={5} />
      </>} />
  );
};
/* 23 */ const S23: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const p = prog(f, 0, d);
  return (
    <Wrap kind="roof" d={d} z={[1, 1.06]}
      art={<><circle cx={900} cy={lerp(500, 220, p)} r={70} fill="#FFB347" /><circle cx={900} cy={lerp(500, 220, p)} r={110} fill="#FFB347" opacity={0.3} />
        <rect y={520} width={W} height={50} fill="#BDB5A8" stroke={C.ink} strokeWidth={3} />
        <Character x={560} y={640} sit mood="happy" seed={7} armR={-60} /></>} />
  );
};
/* 24 */ const S24: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const cup = (
    <g stroke={C.ink} strokeWidth={4}>
      <path d="M-20 -30 L-16 10 H16 L20 -30Z" fill="#fff" /><path d="M20 -20 Q38 -16 18 0" fill="none" />
      {[0, 1].map((i) => <path key={i} d={`M${-6 + i * 12} -40 q-8 -12 0 -24`} stroke="#9aa3b2" fill="none" opacity={0.8} transform={`translate(0,${Math.sin((f + i * 9) / 6) * 3})`} />)}
    </g>
  );
  return (
    <Wrap kind="roof" d={d} z={[1.1, 1.0]}
      art={<><rect y={520} width={W} height={50} fill="#BDB5A8" stroke={C.ink} strokeWidth={3} />
        <Character x={560} y={650} s={1.3} mood="sad" armL={-70} holdL={cup} armR={Math.abs(Math.sin(f / 14)) * 28} seed={8} /></>} />
  );
};
/* 25 */ const S25: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  if (f < d * 0.55) {
    return (
      <Wrap kind="plain" d={d} z={[1, 1.04]} vig={0.12}
        art={<>
          <rect x={290} y={110} width={700} height={470} rx={24} fill="#fff" stroke={C.ink} strokeWidth={6} />
          <rect x={290} y={110} width={700} height={70} rx={24} fill={C.red} stroke={C.ink} strokeWidth={6} />
          {[0, 1, 2].map((r) => [0, 1, 2, 3, 4, 5, 6].map((c) => {
            const on = f > 12 + r * 22 && c <= 6;
            return <rect key={r + '-' + c} x={320 + c * 92} y={210 + r * 112} width={74} height={80} rx={10} fill={on ? (r === 2 ? C.teal : C.amber) : '#EEE'} stroke={C.ink} strokeWidth={3} />;
          }))}
        </>}
        ui={<>{[0, 1, 2].map((r) => <Label key={r} x={190} y={230 + r * 112} t={`সপ্তাহ ${bn(r + 1)}`} size={30} w={170} />)}</>} />
    );
  }
  const sl = prog(f, d * 0.55, d * 0.7);
  return (
    <Wrap kind="dine" d={d} z={[1, 1.06]}
      art={<>
        <Character x={560} y={580} s={1} sit female seed={9} mood="happy" flip />
        <Character x={lerp(1100, 800, sl)} y={580} sit flip seed={2} mood="neutral" />
      </>} />
  );
};
/* 26 */ const S26: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const rice = prog(f, d * 0.55, d * 0.7);
  const happy = f > d * 0.5;
  return (
    <Wrap kind="dine" d={d} z={[1, 1.08]}
      art={<>
        <Plate x={640} y={470} rice={0.35 + rice * 0.65} />
        <Character x={420} y={580} sit female talk={!happy} mood={happy ? 'happy' : 'neutral'} armR={happy ? -70 : -30} seed={9}
          holdR={happy ? <g transform="translate(0,0)"><rect x={-4} y={0} width={8} height={36} fill="#aaa" stroke={C.ink} strokeWidth={2} /></g> : undefined} />
        <Character x={860} y={580} sit flip mood={happy ? 'happy' : 'neutral'} seed={2} />
        {happy && <g opacity={prog(f, d * 0.7, d * 0.8)}><Heart x={640} y={300} s={1.6} /></g>}
      </>} />
  );
};
/* 27 */ const S27: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const sway = Math.sin(f / 12) * 8;
  return (
    <Wrap kind="plain" d={d} z={[1, 1.04]} vig={0.12}
      art={<>
        <line x1={640} y1={0} x2={640} y2={H} stroke={C.ink} strokeWidth={5} />
        <Character x={320} y={640} mood="happy" armR={-60} seed={1} />
        <Phone x={410} y={470} s={0.3} rot={-10} />
        <Phone x={960} y={110} s={0.7} face />
        {[[0, -300, 0], [-34, -195, 0], [34, -195, 0]].map((p, i) => <line key={i} x1={960 + (i - 1) * 40} y1={210} x2={960 + p[0] + sway * (i === 0 ? 0.3 : 1)} y2={640 + p[1]} stroke={C.ink} strokeWidth={3} />)}
        <Character x={960} y={640} mood="sad" armL={-40 + sway * 2} armR={40 - sway * 2} seed={3} />
      </>} />
  );
};
/* 28 */ const S28: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const p = prog(f, d * 0.3, d * 0.9);
  return (
    <Wrap kind="plain" d={d} z={[1, 1.05]} vig={0.12}
      art={<>
        <AClock x={lerp(520, 1000, p)} y={480} s={1.5} a={f * 6} />
        <g strokeLinecap="round"><line x1={lerp(1300, 1060, Math.min(1, p * 3))} y1={480} x2={lerp(1300, 1060, Math.min(1, p * 3)) + 200} y2={480} stroke={C.ink} strokeWidth={36} /><line x1={lerp(1300, 1060, Math.min(1, p * 3))} y1={480} x2={lerp(1300, 1060, Math.min(1, p * 3)) + 200} y2={480} stroke={C.skin} strokeWidth={28} /></g>
      </>}
      ui={<Card x={250} y={110} w={780} text="“সে তোমার সময় চুরি করে”" bg="#FFF3B0" size={52} rot={-1} />} />
  );
};
/* 29 */ const S29: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const back = prog(f, 10, d * 0.5);
  return (
    <Wrap kind="dine" d={d} z={[1.08, 1]}
      art={<>
        <Character x={500} y={580} sit female mood="happy" flip seed={9} />
        <Character x={780} y={580} sit flip mood="happy" seed={2} />
        <rect x={1060} y={300} width={130} height={10} rx={4} fill="#6B4A33" stroke={C.ink} strokeWidth={3} />
        <Phone x={1125} y={290} s={0.2} rot={90} />
        <AClock x={lerp(1125, 640, back)} y={lerp(290, 230, back)} s={lerp(0.4, 0.9, back)} a={f * 3} />
        <g opacity={prog(f, d * 0.5, d * 0.65)}><Heart x={640} y={130} s={1.2} /></g>
      </>} />
  );
};
/* 30 */ const S30: React.FC<SP> = ({d}) => {
  const f = useCurrentFrame();
  const out = 1 - prog(f, d - 10, d);
  const btn = (x: number, bg: string, t: string, ic: React.ReactNode, delay: number) => <Card key={t} x={x} y={270} w={330} bg={bg} color="#fff" pin={false} rot={0} delay={delay} size={46}>{null}<div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14}}><svg width={70} height={60} viewBox="-40 -35 80 70">{ic}</svg>{t}</div></Card>;
  return (
    <AbsoluteFill style={{opacity: out}}>
      <Wrap kind="plain" d={d} z={[1, 1.04]} vig={0.1}
        ui={<>{btn(60, C.teal, 'Like', <Thumb x={0} y={0} />, 5)}{btn(475, C.amber, 'Comment', <Bubble2 x={0} y={0} />, 35)}{btn(890, C.red, 'Subscribe', <Bell x={0} y={0} />, 65)}</>} />
    </AbsoluteFill>
  );
};

export const SceneList: React.FC<SP>[] = [S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11, S12, S13, S14, S15, S16, S17, S18, S19, S20, S21, S22, S23, S24, S25, S26, S27, S28, S29, S30];
