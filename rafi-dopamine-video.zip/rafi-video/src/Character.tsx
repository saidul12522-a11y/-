import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from './theme';

export type Mood = 'neutral' | 'sad' | 'shock' | 'happy' | 'think' | 'sleepy' | 'angry';
type P = {
  x: number; y: number; s?: number; mood?: Mood; talk?: boolean; flip?: boolean;
  armL?: number; armR?: number; shirt?: string; skin?: string; hair?: string;
  night?: boolean; walk?: boolean; sit?: boolean; seed?: number; female?: boolean; down?: boolean;
  holdL?: React.ReactNode; holdR?: React.ReactNode;
};

export const Limb: React.FC<{x1: number; y1: number; x2: number; y2: number; w: number; c: string}> = ({x1, y1, x2, y2, w, c}) => (
  <g strokeLinecap="round">
    <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={C.ink} strokeWidth={w + 6} />
    <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={c} strokeWidth={w} />
  </g>
);

// Origin = feet centre. Arm angle: 0 hangs down, negative swings forward (towards facing side).
export const Character: React.FC<P> = ({
  x, y, s = 1, mood = 'neutral', talk, flip, armL = 0, armR = 0, shirt = C.shirt, skin = C.skin, hair = C.ink,
  night, walk, sit, seed = 0, female, down, holdL, holdR,
}) => {
  const f = useCurrentFrame();
  const bob = Math.sin((f + seed) / 14) * 2.5;
  const blink = (f + seed * 7) % 96 < 4;
  const sw = walk ? Math.sin(f / 5) * 24 : 0;
  const lip = [0, 1, 2, 1, 0, 2, 1, 0][Math.floor(f / 3) % 8];
  const body = female ? C.mom : shirt;
  const ey = -252 + (down ? 5 : 0);
  const torsoY = sit ? 45 : 0;
  const lc = female ? '#55705F' : '#2B2F3A';

  const mouth = talk ? (
    <ellipse cx={0} cy={-226} rx={7 + lip * 1.5} ry={2 + lip * 4} fill="#6b2f2f" stroke={C.ink} strokeWidth={2.5} />
  ) : mood === 'happy' ? (
    <path d="M-12 -232 Q0 -214 12 -232" fill="none" stroke={C.ink} strokeWidth={3.5} strokeLinecap="round" />
  ) : mood === 'sad' || mood === 'angry' ? (
    <path d="M-10 -222 Q0 -232 10 -222" fill="none" stroke={C.ink} strokeWidth={3.5} strokeLinecap="round" />
  ) : mood === 'shock' ? (
    <ellipse cx={0} cy={-224} rx={8} ry={11} fill="#6b2f2f" stroke={C.ink} strokeWidth={3} />
  ) : (
    <line x1={-9} y1={-227} x2={9} y2={-227} stroke={C.ink} strokeWidth={3.5} strokeLinecap="round" />
  );

  const brow = (sx: number) => {
    const o = sx; // -1 left, +1 right
    if (mood === 'sad') return <line x1={o * 24} y1={-270 + 6} x2={o * 8} y2={-270 - 4} stroke={C.ink} strokeWidth={3.5} strokeLinecap="round" />;
    if (mood === 'angry') return <line x1={o * 24} y1={-270 - 4} x2={o * 8} y2={-270 + 6} stroke={C.ink} strokeWidth={4} strokeLinecap="round" />;
    if (mood === 'shock') return <line x1={o * 24} y1={-282} x2={o * 8} y2={-282} stroke={C.ink} strokeWidth={3.5} strokeLinecap="round" />;
    if (mood === 'think' && o > 0) return <line x1={o * 24} y1={-280} x2={o * 8} y2={-276} stroke={C.ink} strokeWidth={3.5} strokeLinecap="round" />;
    return <line x1={o * 24} y1={-272} x2={o * 8} y2={-272} stroke={C.ink} strokeWidth={3.5} strokeLinecap="round" />;
  };

  const eye = (cx: number) =>
    mood === 'sleepy' || blink ? (
      <line x1={cx - 6} y1={ey} x2={cx + 6} y2={ey} stroke={C.ink} strokeWidth={3.5} strokeLinecap="round" />
    ) : mood === 'shock' ? (
      <circle cx={cx} cy={ey} r={7} fill="#fff" stroke={C.ink} strokeWidth={3}><title>eye</title></circle>
    ) : (
      <circle cx={cx} cy={ey} r={4.5} fill={C.ink} />
    );

  const arm = (sx: number, ang: number, hold?: React.ReactNode) => (
    <g transform={`translate(${sx},${-195 + torsoY}) rotate(${ang})`}>
      <Limb x1={0} y1={0} x2={0} y2={86} w={20} c={skin} />
      {hold && <g transform="translate(0,90)">{hold}</g>}
    </g>
  );

  return (
    <g transform={`translate(${x},${y + bob}) scale(${flip ? -s : s},${s})`} style={{filter: night ? 'brightness(0.72) saturate(0.9)' : undefined}}>
      {/* legs */}
      {sit ? (
        <>
          <Limb x1={14} y1={-62} x2={86} y2={-60} w={22} c={lc} />
          <Limb x1={86} y1={-60} x2={90} y2={-6} w={22} c={lc} />
          <Limb x1={-12} y1={-62} x2={58} y2={-56} w={22} c={lc} />
          <Limb x1={58} y1={-56} x2={62} y2={-6} w={22} c={lc} />
        </>
      ) : (
        <>
          <g transform={`translate(-16,-105) rotate(${sw})`}><Limb x1={0} y1={0} x2={0} y2={100} w={22} c={lc} /></g>
          <g transform={`translate(16,-105) rotate(${-sw})`}><Limb x1={0} y1={0} x2={0} y2={100} w={22} c={lc} /></g>
        </>
      )}
      <g transform={`translate(0,${torsoY})`}>
        {arm(-38, armL + sw * 0.6, holdL)}
        <rect x={-36} y={-208} width={72} height={108} rx={30} fill={body} stroke={C.ink} strokeWidth={3.5} />
        {female && <path d="M-36 -190 L30 -110" stroke="#B6573F" strokeWidth={14} strokeLinecap="round" />}
        {/* head */}
        <ellipse cx={-41} cy={-248} rx={6} ry={9} fill={skin} stroke={C.ink} strokeWidth={3} />
        <ellipse cx={41} cy={-248} rx={6} ry={9} fill={skin} stroke={C.ink} strokeWidth={3} />
        <ellipse cx={0} cy={-250} rx={41} ry={44} fill={skin} stroke={C.ink} strokeWidth={3.5} />
        <path d="M-41 -256 Q-40 -298 0 -296 Q41 -298 41 -256 Q16 -276 -41 -256Z" fill={hair} stroke={C.ink} strokeWidth={3} />
        {female && <circle cx={0} cy={-302} r={15} fill={hair} stroke={C.ink} strokeWidth={3} />}
        {brow(-1)}{brow(1)}
        {eye(-15)}{eye(15)}
        {mouth}
        {mood === 'sad' && <ellipse cx={26} cy={-236} rx={3} ry={5} fill={C.glow} />}
        {arm(38, armR - sw * 0.6, holdR)}
      </g>
    </g>
  );
};
