export const FPS = 30;
export const W = 1280;
export const H = 720;
export const TOTAL = 4639; // ceil(154.6217s * 30)
export const C = {
  day: '#FBF7F0', night: '#0D1326', ink: '#222222', skin: '#F3D2B3',
  shirt: '#1E3A5F', teal: '#14B8A6', amber: '#FF9F1C', glow: '#5BC8FF',
  red: '#E5484D', mom: '#7C9A8B', gray: '#9AA3B2', warm: '#F1D7AE',
};
// Scene start times (seconds) from SRT/Audio. cap=false -> bubble/card carries the text (no duplicate caption)
export const SCENES: {s: number; dark: boolean; cap: boolean}[] = [
  {s: 0, dark: true, cap: true}, {s: 5.06, dark: true, cap: false}, {s: 9.46, dark: true, cap: true},
  {s: 13.64, dark: false, cap: false}, {s: 18.64, dark: false, cap: true}, {s: 23.28, dark: false, cap: true},
  {s: 32.07, dark: false, cap: false}, {s: 40.88, dark: false, cap: false}, {s: 45.58, dark: false, cap: true},
  {s: 53.35, dark: false, cap: false}, {s: 60.9, dark: false, cap: true}, {s: 66.05, dark: false, cap: true},
  {s: 70.42, dark: false, cap: true}, {s: 74.9, dark: true, cap: true}, {s: 79.28, dark: true, cap: true},
  {s: 83.42, dark: false, cap: true}, {s: 87.96, dark: false, cap: false}, {s: 92.82, dark: false, cap: true},
  {s: 97.56, dark: true, cap: true}, {s: 101.74, dark: true, cap: true}, {s: 106.5, dark: true, cap: true},
  {s: 110.93, dark: true, cap: true}, {s: 115.6, dark: false, cap: true}, {s: 120.6, dark: false, cap: true},
  {s: 124.9, dark: false, cap: true}, {s: 129.34, dark: false, cap: true}, {s: 134.16, dark: false, cap: true},
  {s: 138.04, dark: false, cap: false}, {s: 142.32, dark: false, cap: true}, {s: 147.28, dark: false, cap: false},
];
