import React from 'react';
import {C} from './theme';
import {FF} from './ui';

type G = {x: number; y: number; s?: number};
const T = (p: {x: number; y: number; s?: number}) => `translate(${p.x},${p.y}) scale(${p.s ?? 1})`;

export const Brain: React.FC<G> = (p) => (
  <g transform={T(p)} stroke={C.ink} strokeWidth={5} fill="#F4A6B7">
    <circle cx={-45} cy={-10} r={50} /><circle cx={45} cy={-10} r={50} /><circle cx={0} cy={-45} r={46} /><circle cx={-25} cy={30} r={42} /><circle cx={30} cy={30} r={42} />
    <path d="M0 -80 Q-10 -20 0 40" fill="none" /><path d="M-60 0 Q-30 -10 -15 10 M60 0 Q30 -10 15 10" fill="none" />
  </g>
);
export const Bulb: React.FC<G> = (p) => (
  <g transform={T(p)} stroke={C.ink} strokeWidth={4}>
    <circle cx={0} cy={0} r={22} fill="#FFE066" /><rect x={-11} y={20} width={22} height={14} rx={3} fill="#bbb" />
    {[-1, 0, 1].map((i) => <line key={i} x1={i * 26} y1={-34} x2={i * 34} y2={-44} strokeLinecap="round" />)}
  </g>
);
export const Heart: React.FC<G> = (p) => (
  <path transform={T(p)} d="M0 20 C-40 -10 -26 -44 0 -22 C26 -44 40 -10 0 20Z" fill={C.red} stroke={C.ink} strokeWidth={4} />
);
export const Book: React.FC<G> = (p) => (
  <g transform={T(p)} stroke={C.ink} strokeWidth={5}>
    <rect x={-60} y={-45} width={120} height={90} rx={6} fill="#4C8DD6" /><rect x={-50} y={-35} width={100} height={70} fill="#fff" />
    <line x1={0} y1={-45} x2={0} y2={45} /><line x1={-40} y1={-15} x2={-10} y2={-15} /><line x1={10} y1={-15} x2={40} y2={-15} /><line x1={-40} y1={5} x2={-10} y2={5} /><line x1={10} y1={5} x2={40} y2={5} />
  </g>
);
export const Story: React.FC<G> = (p) => (
  <g transform={T(p)} stroke={C.ink} strokeWidth={5}>
    <rect x={-45} y={-60} width={90} height={120} rx={8} fill="#FFE8A3" />
    {[-30, -10, 10, 30].map((y) => <line key={y} x1={-28} y1={y} x2={28} y2={y} strokeLinecap="round" />)}
  </g>
);
export const Bowl: React.FC<G> = (p) => (
  <g transform={T(p)} stroke={C.ink} strokeWidth={5}>
    <path d="M-60 0 Q-60 55 0 55 Q60 55 60 0Z" fill="#E36B4F" /><path d="M-48 0 Q-30 -40 0 -36 Q30 -40 48 0Z" fill="#fff" />
  </g>
);
export const Trash: React.FC<G> = (p) => (
  <g transform={T(p)} stroke={C.ink} strokeWidth={5}>
    <path d="M-45 -40 L-35 60 L35 60 L45 -40Z" fill="#8A93A8" /><rect x={-55} y={-58} width={110} height={16} rx={6} fill="#6C7590" />
    <line x1={-14} y1={-25} x2={-12} y2={45} /><line x1={14} y1={-25} x2={12} y2={45} />
  </g>
);
export const AClock: React.FC<G & {a?: number}> = ({a = 0, ...p}) => (
  <g transform={T(p)}>
    <circle r={60} fill="#fff" stroke={C.ink} strokeWidth={6} />
    <line x1={0} y1={0} x2={0} y2={-38} stroke={C.ink} strokeWidth={6} strokeLinecap="round" transform={`rotate(${a})`} />
    <line x1={0} y1={0} x2={26} y2={12} stroke={C.ink} strokeWidth={6} strokeLinecap="round" transform={`rotate(${a / 12})`} />
  </g>
);
export const Alarm: React.FC<G & {ring?: number}> = ({ring = 0, ...p}) => (
  <g transform={T(p)} stroke={C.ink} strokeWidth={5}>
    <g transform={`rotate(${ring})`}>
      <circle cx={-38} cy={-52} r={16} fill="#E5484D" /><circle cx={38} cy={-52} r={16} fill="#E5484D" />
      <circle r={50} fill="#fff" />
      <line x1={0} y1={0} x2={0} y2={-30} strokeLinecap="round" /><line x1={0} y1={0} x2={20} y2={10} strokeLinecap="round" />
    </g>
    <line x1={-30} y1={50} x2={-40} y2={66} /><line x1={30} y1={50} x2={40} y2={66} />
  </g>
);
export const Bolt: React.FC<G> = (p) => (
  <path transform={T(p)} d="M6 -40 L-24 6 L-4 6 L-12 40 L24 -8 L2 -8Z" fill={C.amber} stroke={C.ink} strokeWidth={4} strokeLinejoin="round" />
);
export const Bell: React.FC<G> = (p) => (
  <g transform={T(p)} fill="#fff" stroke="#fff" strokeWidth={3}>
    <path d="M-20 10 Q-20 -24 0 -26 Q20 -24 20 10 L26 18 L-26 18Z" /><circle cy={26} r={6} />
  </g>
);
export const Thumb: React.FC<G> = (p) => (
  <g transform={T(p)} fill="#fff"><rect x={-26} y={-6} width={14} height={32} rx={3} /><path d="M-8 -4 L6 -30 Q16 -32 14 -16 L12 -4 L28 -4 Q34 -2 30 8 L26 24 Q24 28 18 28 L-8 26Z" /></g>
);
export const Bubble2: React.FC<G> = (p) => (
  <g transform={T(p)} fill="#fff"><path d="M-28 -22 H28 Q34 -22 34 -16 V10 Q34 16 28 16 H0 L-14 30 V16 H-28 Q-34 16 -34 10 V-16 Q-34 -22 -28 -22Z" /></g>
);
export const Slot: React.FC<{sym: number} & G> = ({sym, ...p}) => (
  <g transform={T(p)} stroke={C.ink} strokeWidth={4}>
    {sym === 0 && (<><circle r={34} fill={C.teal} /><path d="M-10 -16 L18 0 L-10 16Z" fill="#fff" /></>)}
    {sym === 1 && <rect x={-28} y={-28} width={56} height={56} rx={8} fill={C.amber} />}
    {sym === 2 && <circle r={28} fill={C.red} />}
    {sym === 3 && <path d="M0 -32 L10 -8 L36 -6 L16 10 L22 34 L0 20 L-22 34 L-16 10 L-36 -6 L-10 -8Z" fill="#FFE066" />}
  </g>
);
export const Txt: React.FC<{x: number; y: number; t: string; size?: number; fill?: string}> = ({x, y, t, size = 30, fill = C.ink}) => (
  <text x={x} y={y} textAnchor="middle" fontFamily={FF} fontWeight={700} fontSize={size} fill={fill}>{t}</text>
);
