import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, H, W} from './theme';
import {FF} from './ui';

const abs: React.CSSProperties = {position: 'absolute', left: 0, top: 0};

export const Bg: React.FC<{kind: 'night' | 'room' | 'office' | 'dine' | 'roof' | 'plain' | 'navy'; color?: string}> = ({kind, color}) => {
  let inner: React.ReactNode;
  if (kind === 'night')
    inner = (
      <>
        <rect width={W} height={H} fill={C.night} />
        <rect y={600} width={W} height={120} fill="#090E1C" />
        <g transform="translate(1030,90)">
          <rect width={170} height={200} rx={6} fill="#142048" stroke="#2A3868" strokeWidth={6} />
          <line x1={85} y1={0} x2={85} y2={200} stroke="#2A3868" strokeWidth={6} />
          <line x1={0} y1={100} x2={170} y2={100} stroke="#2A3868" strokeWidth={6} />
          <circle cx={45} cy={50} r={16} fill="#E8EEFF" opacity={0.8} />
        </g>
      </>
    );
  else if (kind === 'room')
    inner = (
      <>
        <rect width={W} height={H} fill="#F7EFE2" />
        <rect y={600} width={W} height={120} fill="#E4D2B4" />
        <g transform="translate(1000,80)">
          <rect width={200} height={230} rx={6} fill="#CDEBF5" stroke="#fff" strokeWidth={10} />
          <line x1={100} y1={0} x2={100} y2={230} stroke="#fff" strokeWidth={8} />
          <circle cx={150} cy={60} r={26} fill="#FFD36B" />
        </g>
      </>
    );
  else if (kind === 'office')
    inner = (
      <>
        <rect width={W} height={H} fill="#EEF2F7" />
        <rect y={600} width={W} height={120} fill="#D5DAE3" />
        <g transform="translate(90,90)">
          <rect width={320} height={250} rx={8} fill="#BFE3F2" stroke="#fff" strokeWidth={10} />
          <circle cx={90} cy={190} r={110} fill="#7DBE7A" />
          <circle cx={230} cy={210} r={100} fill="#5FA867" />
          <circle cx={250} cy={60} r={28} fill="#FFD36B" />
        </g>
        <g transform="translate(900,150)">
          <circle r={48} fill="#fff" stroke={C.ink} strokeWidth={5} />
          <line x1={0} y1={0} x2={0} y2={-30} stroke={C.ink} strokeWidth={5} strokeLinecap="round" />
          <line x1={0} y1={0} x2={22} y2={10} stroke={C.ink} strokeWidth={5} strokeLinecap="round" />
        </g>
        <rect x={600} y={470} width={500} height={18} rx={4} fill="#B98B5E" stroke={C.ink} strokeWidth={3} />
        <rect x={620} y={488} width={16} height={112} fill="#8B6440" />
        <rect x={1064} y={488} width={16} height={112} fill="#8B6440" />
        <rect x={900} y={400} width={130} height={70} rx={6} fill="#3A4256" stroke={C.ink} strokeWidth={3} />
      </>
    );
  else if (kind === 'dine')
    inner = (
      <>
        <rect width={W} height={H} fill="#F1D7AE" />
        <rect y={600} width={W} height={120} fill="#B98A5C" />
        <radialGradient id="lampg"><stop offset="0" stopColor="#FFE9A8" stopOpacity={0.9} /><stop offset="1" stopColor="#FFE9A8" stopOpacity={0} /></radialGradient>
        <circle cx={640} cy={260} r={420} fill="url(#lampg)" />
        <line x1={640} y1={0} x2={640} y2={110} stroke={C.ink} strokeWidth={4} />
        <path d="M580 150 Q640 80 700 150Z" fill="#E8A33D" stroke={C.ink} strokeWidth={4} />
        <rect x={120} y={120} width={150} height={110} rx={6} fill="#CDEBF5" stroke="#8B5E3C" strokeWidth={8} />
        <rect x={280} y={470} width={720} height={20} rx={4} fill="#8B5E3C" stroke={C.ink} strokeWidth={3} />
        <rect x={310} y={490} width={18} height={110} fill="#6E4A30" />
        <rect x={952} y={490} width={18} height={110} fill="#6E4A30" />
      </>
    );
  else if (kind === 'roof')
    inner = (
      <>
        <linearGradient id="skyg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#FFD9A8" /><stop offset="1" stopColor="#BFE3F2" /></linearGradient>
        <rect width={W} height={H} fill="url(#skyg)" />
        {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
          <rect key={i} x={i * 170 - 20} y={330 + ((i * 53) % 90)} width={120 + ((i * 37) % 50)} height={300} fill={i % 2 ? '#9FB8C8' : '#B4C8D4'} />
        ))}
        <rect y={560} width={W} height={160} fill="#CFC8BC" />
        <rect y={520} width={W} height={50} fill="#BDB5A8" stroke={C.ink} strokeWidth={3} />
      </>
    );
  else inner = <rect width={W} height={H} fill={kind === 'navy' ? C.night : color || C.day} />;
  return <svg style={abs} width={W} height={H}>{inner}</svg>;
};

export const Clock: React.FC<{x: number; y: number; s?: number; text: string; color?: string}> = ({x, y, s = 1, text, color = '#FF5A4F'}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x={-80} y={-20} width={160} height={120} rx={8} fill="#1B2240" stroke={C.ink} strokeWidth={4} />
    <rect x={-60} y={-80} width={120} height={64} rx={10} fill="#0B0F1E" stroke={C.ink} strokeWidth={4} />
    <text x={0} y={-33} textAnchor="middle" fontFamily={FF} fontWeight={700} fontSize={38} fill={color}>{text}</text>
  </g>
);

export const Phone: React.FC<{x: number; y: number; s?: number; rot?: number; gray?: number; scroll?: number; hands?: boolean; face?: boolean; glow?: boolean}> = ({x, y, s = 1, rot = 0, gray = 0, scroll = 0, hands, face, glow}) => {
  const id = 'cp' + React.useId().replace(/:/g, '');
  const f = useCurrentFrame();
  const w = 180, h = 340;
  return (
    <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`}>
      {glow && <circle r={300} fill={C.glow} opacity={0.12 + 0.04 * Math.sin(f / 8)} />}
      <g style={{filter: `grayscale(${gray})`}}>
        <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={26} fill="#15171f" stroke={C.ink} strokeWidth={5} />
        <clipPath id={id}><rect x={-w / 2 + 10} y={-h / 2 + 12} width={w - 20} height={h - 24} rx={18} /></clipPath>
        <g clipPath={`url(#${id})`}>
          <rect x={-w / 2} y={-h / 2} width={w} height={h} fill="#1d2030" />
          {[0, 1, 2, 3, 4].map((i) => {
            const yy = -h / 2 + 24 + i * 100 - (scroll % 100);
            const hot = Math.floor((scroll + i * 100) / 100) % 3 === 0;
            return (
              <g key={i}>
                <rect x={-72} y={yy} width={144} height={84} rx={10} fill="#2a2f48" stroke={hot ? C.amber : 'none'} strokeWidth={3} />
                <circle cx={-52} cy={yy + 18} r={8} fill="#E9967A" />
                <rect x={-36} y={yy + 12} width={70} height={8} rx={4} fill="#4a5075" />
                <rect x={-60} y={yy + 36} width={120} height={36} rx={6} fill={hot ? '#5a3d1a' : '#353b5c'} />
              </g>
            );
          })}
          {face && (
            <g>
              <circle cx={-30} cy={-30} r={11} fill={C.glow} /><circle cx={30} cy={-30} r={11} fill={C.glow} />
              <path d="M-40 30 Q0 70 40 30" stroke={C.glow} strokeWidth={8} fill="none" strokeLinecap="round" />
            </g>
          )}
        </g>
      </g>
      {hands && (
        <>
          <g transform={`translate(${-w / 2 - 4},${h / 2 - 10}) rotate(-8)`}><rect x={-26} y={-100} width={52} height={230} rx={26} fill={C.skin} stroke={C.ink} strokeWidth={4} /></g>
          <g transform={`translate(${w / 2 + 6},${h / 2 - 40 + Math.sin(f / 6) * 18}) rotate(14)`}><rect x={-26} y={-60} width={52} height={230} rx={26} fill={C.skin} stroke={C.ink} strokeWidth={4} /></g>
        </>
      )}
    </g>
  );
};

export const Bed: React.FC<{x: number; y: number; s?: number; eyes?: 'open' | 'closed'; glow?: boolean; arm?: boolean; night?: boolean}> = ({x, y, s = 1, eyes = 'open', glow, arm, night = true}) => {
  const f = useCurrentFrame();
  const sw = arm ? Math.sin(f / 7) * 18 : 0;
  return (
    <g transform={`translate(${x},${y}) scale(${s})`}>
      <radialGradient id="bedgl"><stop offset="0" stopColor={C.glow} stopOpacity={0.7} /><stop offset="1" stopColor={C.glow} stopOpacity={0} /></radialGradient>
      <rect x={-290} y={-70} width={580} height={70} rx={8} fill="#6B4A33" stroke={C.ink} strokeWidth={4} />
      <rect x={-280} y={-112} width={560} height={46} rx={14} fill={night ? '#2A3558' : '#fff'} stroke={C.ink} strokeWidth={4} />
      <rect x={-302} y={-220} width={26} height={220} rx={8} fill="#6B4A33" stroke={C.ink} strokeWidth={4} />
      <ellipse cx={-200} cy={-126} rx={72} ry={24} fill={night ? '#3A4670' : '#F3F3F3'} stroke={C.ink} strokeWidth={4} />
      <circle cx={-200} cy={-168} r={40} fill={C.skin} stroke={C.ink} strokeWidth={4} style={{filter: night ? 'brightness(0.8)' : undefined}} />
      <path d="M-240 -174 Q-236 -214 -200 -210 Q-164 -212 -160 -174 Q-190 -190 -240 -174Z" fill={C.ink} />
      {eyes === 'open' ? (
        <><circle cx={-214} cy={-166} r={4.5} fill={C.ink} /><circle cx={-186} cy={-166} r={4.5} fill={C.ink} /></>
      ) : (
        <><line x1={-220} y1={-166} x2={-208} y2={-166} stroke={C.ink} strokeWidth={3.5} /><line x1={-192} y1={-166} x2={-180} y2={-166} stroke={C.ink} strokeWidth={3.5} /></>
      )}
      <line x1={-208} y1={-150} x2={-192} y2={-150} stroke={C.ink} strokeWidth={3.5} strokeLinecap="round" />
      <rect x={-140} y={-150} width={410} height={90} rx={34} fill={night ? '#2F4B7C' : '#7FB5C9'} stroke={C.ink} strokeWidth={4} />
      {glow && <circle cx={-200} cy={-168} r={170} fill="url(#bedgl)" opacity={0.55 + 0.2 * Math.sin(f / 9)} />}
      {arm && (
        <>
          <rect x={-120} y={-122} width={26} height={16} rx={4} fill="#111" stroke={C.ink} strokeWidth={2} />
          <g transform={`translate(-60,-135) rotate(${sw})`}><Limb2 /></g>
        </>
      )}
    </g>
  );
};
const Limb2 = () => (
  <g strokeLinecap="round">
    <line x1={0} y1={0} x2={-62} y2={4} stroke={C.ink} strokeWidth={26} />
    <line x1={0} y1={0} x2={-62} y2={4} stroke={C.skin} strokeWidth={20} />
  </g>
);
