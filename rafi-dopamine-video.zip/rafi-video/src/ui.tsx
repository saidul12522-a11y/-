import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont} from '@remotion/google-fonts/HindSiliguri';
import {C} from './theme';

export const {fontFamily: FF} = loadFont('normal', {weights: ['400', '600', '700'], subsets: ['bengali', 'latin']});

export const bn = (s: string | number) => String(s).replace(/\d/g, (d) => '০১২৩৪৫৬৭৮৯'[+d]);
export const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
export const prog = (f: number, a: number, b: number) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

export const usePop = (delay = 0, damping = 11) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: Math.max(0, f - delay), fps, config: {damping, stiffness: 140}, durationInFrames: 25});
};

export const Cam: React.FC<{
  d: number; z?: [number, number]; px?: [number, number]; py?: [number, number]; shake?: number; children?: React.ReactNode;
}> = ({d, z = [1, 1.06], px = [0, 0], py = [0, 0], shake = 0, children}) => {
  const f = useCurrentFrame();
  const p = Math.min(1, f / Math.max(1, d));
  const e = p * p * (3 - 2 * p);
  const l = (a: number[]) => a[0] + (a[1] - a[0]) * e;
  const k = f < shake ? 1 - f / shake : 0;
  const sx = Math.sin(f * 2.3) * 10 * k;
  const sy = Math.cos(f * 3.1) * 8 * k;
  return (
    <AbsoluteFill style={{transform: `translate(${l(px) + sx}px,${l(py) + sy}px) scale(${l(z)})`}}>{children}</AbsoluteFill>
  );
};

export const Vig: React.FC<{a?: number}> = ({a = 0.22}) => (
  <AbsoluteFill style={{pointerEvents: 'none', background: `radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,0,0,${a}) 100%)`}} />
);

export const Bubble: React.FC<{
  x: number; y: number; w?: number; text: string; delay?: number; thought?: boolean; tail?: 'l' | 'r'; size?: number; children?: React.ReactNode;
}> = ({x, y, w = 380, text, delay = 0, thought, tail = 'l', size = 34, children}) => {
  const p = usePop(delay);
  const side = tail === 'l' ? {left: 40} : {right: 40};
  return (
    <div style={{position: 'absolute', left: x, top: y, width: w, transform: `scale(${p})`, transformOrigin: tail === 'l' ? '15% 100%' : '85% 100%', opacity: p > 0.01 ? 1 : 0}}>
      <div style={{background: '#fff', border: `4px solid ${C.ink}`, borderRadius: thought ? 60 : 28, padding: '14px 22px', fontFamily: FF, fontWeight: 700, fontSize: size, color: C.ink, textAlign: 'center', lineHeight: 1.25}}>
        {text}{children}
      </div>
      {thought ? (
        <>
          <div style={{position: 'absolute', bottom: -30, ...side, width: 22, height: 22, borderRadius: 11, background: '#fff', border: `4px solid ${C.ink}`}} />
          <div style={{position: 'absolute', bottom: -52, ...side, width: 12, height: 12, borderRadius: 6, background: '#fff', border: `3px solid ${C.ink}`}} />
        </>
      ) : (
        <div style={{position: 'absolute', bottom: -14, ...side, width: 24, height: 24, background: '#fff', borderRight: `4px solid ${C.ink}`, borderBottom: `4px solid ${C.ink}`, transform: 'rotate(45deg)'}} />
      )}
    </div>
  );
};

export const Card: React.FC<{
  x: number; y: number; w?: number; text?: string; bg?: string; color?: string; rot?: number; delay?: number; size?: number; pin?: boolean; children?: React.ReactNode;
}> = ({x, y, w = 300, text, bg = '#FFF3B0', color = C.ink, rot = -3, delay = 0, size = 38, pin = true, children}) => {
  const p = usePop(delay, 10);
  return (
    <div style={{position: 'absolute', left: x, top: y, width: w, transform: `rotate(${rot}deg) scale(${p})`, opacity: p > 0.01 ? 1 : 0, background: bg, border: `4px solid ${C.ink}`, borderRadius: 16, padding: '20px 18px', textAlign: 'center', fontFamily: FF, fontWeight: 700, fontSize: size, color, boxShadow: '6px 8px 0 rgba(0,0,0,0.15)', lineHeight: 1.25}}>
      {pin && <div style={{position: 'absolute', left: '50%', top: -14, width: 22, height: 22, marginLeft: -11, borderRadius: 11, background: C.red, border: `3px solid ${C.ink}`}} />}
      {text}{children}
    </div>
  );
};

export const Stamp: React.FC<{x: number; y: number; text: string; color: string; delay?: number; size?: number; rot?: number}> = ({x, y, text, color, delay = 0, size = 54, rot = -8}) => {
  const f = useCurrentFrame();
  const sc = interpolate(f - delay, [0, 6], [3, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <div style={{position: 'absolute', left: x, top: y, opacity: f >= delay ? 1 : 0, transform: `rotate(${rot}deg) scale(${sc})`, border: `7px solid ${color}`, color, borderRadius: 14, padding: '2px 22px', fontFamily: FF, fontWeight: 700, fontSize: size}}>{text}</div>
  );
};
