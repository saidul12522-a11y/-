import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {C, FPS, SCENES, TOTAL} from './theme';
import {CUES} from './cues';
import {SceneList} from './scenes';
import {FF} from './ui';

const starts = SCENES.map((s) => Math.round(s.s * FPS));
const KEYS = ['dopamine', 'scroll', 'Facebook', 'Instagram', 'screen time', 'alarm', 'notification', 'Lunch break', 'browser', 'Like', 'Comment', 'Subscribe', 'রাত দুটো', 'তিন ঘণ্টা', 'সময়', 'মস্তিষ্কের', 'জুয়ার মেশিনের', 'ছয় ঘণ্টা', 'চল্লিশ মিনিট'];
const re = new RegExp('(' + KEYS.join('|') + ')', 'g');

const Fade: React.FC<{children: React.ReactNode}> = ({children}) => {
  const f = useCurrentFrame();
  return <AbsoluteFill style={{opacity: interpolate(f, [0, 6], [0.25, 1], {extrapolateRight: 'clamp'})}}>{children}</AbsoluteFill>;
};

const Captions: React.FC = () => {
  const f = useCurrentFrame();
  let idx = 0;
  starts.forEach((s, i) => { if (f >= s) idx = i; });
  const sc = SCENES[idx];
  const cue = CUES.find((c) => f >= c.a * FPS && f <= c.b * FPS + 3);
  if (!cue || !sc.cap) return null;
  const k = f - cue.a * FPS;
  const o = interpolate(k, [0, 6], [0, 1], {extrapolateRight: 'clamp'});
  const y = interpolate(k, [0, 6], [18, 0], {extrapolateRight: 'clamp'});
  const base = sc.dark ? '#fff' : C.ink;
  const parts = cue.t.split(re);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 34, textAlign: 'center', opacity: o, transform: `translateY(${y}px)`, fontFamily: FF, fontWeight: 600, fontSize: 40, color: base, whiteSpace: 'nowrap', textShadow: sc.dark ? '0 2px 8px rgba(0,0,0,0.8)' : '0 2px 8px rgba(255,255,255,0.9)'}}>
      {parts.map((p, i) => (KEYS.includes(p) ? <span key={i} style={{color: C.amber, fontWeight: 700}}>{p}</span> : <span key={i}>{p}</span>))}
    </div>
  );
};

export const Video: React.FC = () => (
  <AbsoluteFill style={{background: '#111'}}>
    <Audio src={staticFile('voiceover.wav')} />
    {SceneList.map((S, i) => {
      const from = starts[i];
      const to = i < SceneList.length - 1 ? starts[i + 1] : TOTAL;
      return (
        <Sequence key={i} from={from} durationInFrames={to - from}>
          <Fade><S d={to - from} /></Fade>
        </Sequence>
      );
    })}
    <Captions />
  </AbsoluteFill>
);
