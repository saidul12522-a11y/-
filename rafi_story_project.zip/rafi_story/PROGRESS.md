# PROGRESS
- [x] Input check, sentence timing (provisional), scene plan v2 (11 shots)
- [x] Remotion + Three.js project written (syntax checked with esbuild only)
- [x] GitHub Actions workflow (test/full modes, per-shot render, resume cache, Release upload)
- [ ] First GitHub test run (NOT run yet)
- [ ] Visual review of stills and 5s clip
- [ ] Full render
No render has been completed. Nothing here has been executed in a browser.
