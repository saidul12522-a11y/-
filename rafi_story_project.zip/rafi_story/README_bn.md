# রাফির গল্প: Remotion + Three.js প্রজেক্ট (মোবাইল থেকে GitHub-এ রেন্ডার)

## ফাইল
- `src/` কোড (Story.jsx = shot ও ক্যামেরা, Worlds.jsx = 3D পরিবেশ, Character.jsx = ক্যারেক্টার)
- `public/voiceover.mp3` আপনার অডিও, `story.srt` আপনার সাবটাইটেল (অপরিবর্তিত)
- `scripts/render.sh`, `.github/workflows/render.yml` রেন্ডার স্ক্রিপ্ট

## ফোন থেকে ধাপ (কম্পিউটার লাগবে না)
1. github.com-এ লগইন করে নতুন repository খোলো (Public হলে GitHub Actions বিনামূল্যে ও সীমাহীন)।
2. Repository-তে **Add file → Upload files** চাপো, `rafi_story_project.zip` সিলেক্ট করে Commit করো (zip খুলতে হবে না)।
3. **Add file → Create new file** চাপো। নামের ঘরে লেখো `.github/workflows/render.yml`। `render.yml` ফাইলের পুরো লেখা পেস্ট করে Commit করো।
4. **Actions** ট্যাব → **Render video** → **Run workflow**। প্রথমবার `mode = test` রাখো।
5. শেষ হলে run পেজের নিচে Artifacts থেকে `render-output-test` নামাও। ভেতরে ১১টি still, contact sheet ও ৫ সেকেন্ডের clip থাকবে। আমাকে দেখাও।
6. ঠিক থাকলে আবার Run workflow, `mode = full`। শেষে **Releases** পেজে `final_video.mp4` সরাসরি ডাউনলোড করা যাবে।
7. শুধু কিছু shot ঠিক করতে চাইলে `shots` ঘরে `3,7` লিখে চালাও; বাকি shot ক্যাশ থেকে আসবে।

## সতর্কতা
- এই কোড আমার সেশনে চালিয়ে দেখা যায়নি (ইন্টারনেট নেই)। প্রথম test run-ই আসল পরীক্ষা। ব্যর্থ হলে লগের শেষ কয়েক লাইন পাঠাও।
- Depth of Field বাদ আছে। Shadow slow হলে `shadows = false` দাও।
- Private repo-তে মাসিক সীমা আছে (GitHub Free: ২,০০০ মিনিট)।
