import React from 'react';
import * as THREE from 'three';
import {Box, Cyl, Ball, Wall, Label, useTex, C, INK, FONT} from './kit.jsx';

const BOOK_COLORS = ['#c0583a', '#4f8a8b', '#d6a23a', '#7b5ea7', '#4d6b54', '#a65a46'];

function Shelf({p, n = 8}) {
  return (
    <group position={p}>
      <Box p={[0, 0, 0]} s={[0.4, 0.07, 2.0]} c={C.wood} />
      {Array.from({length: n}).map((_, i) => (
        <Box key={i} p={[0, 0.2 + (i % 3) * 0.02, -0.85 + i * 0.23]} s={[0.26, 0.34 + (i % 3) * 0.04, 0.17]} c={BOOK_COLORS[i % 6]} o={0.03} />
      ))}
    </group>
  );
}

function Notebooks({p, n}) {
  return (
    <group position={p}>
      {Array.from({length: n}).map((_, i) => (
        <Box key={i} p={[((i * 37) % 7) * 0.012 - 0.03, 0.06 + i * 0.105, ((i * 53) % 5) * 0.01]} s={[0.62, 0.09, 0.45]} c={BOOK_COLORS[i % 6]} o={0.03} />
      ))}
    </group>
  );
}

// Home: room (open on the right) plus the alley in front of the window wall.
export function Home({stack = 1, sway = 0, spin = 0, night = 1, lampOn = 1}) {
  const clock = useTex(256, 256, (g, w, h) => {
    g.fillStyle = '#f3e9d6';
    g.fillRect(0, 0, w, h);
    g.strokeStyle = '#351f22';
    g.lineWidth = 8;
    g.beginPath();
    g.arc(w / 2, h / 2, w / 2 - 10, 0, Math.PI * 2);
    g.stroke();
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2;
      g.lineWidth = i % 3 === 0 ? 8 : 4;
      g.beginPath();
      g.moveTo(w / 2 + Math.sin(a) * 92, h / 2 - Math.cos(a) * 92);
      g.lineTo(w / 2 + Math.sin(a) * 108, h / 2 - Math.cos(a) * 108);
      g.stroke();
    }
    g.lineWidth = 10; // minute hand at 12
    g.beginPath();
    g.moveTo(w / 2, h / 2);
    g.lineTo(w / 2, h / 2 - 90);
    g.stroke();
    g.lineWidth = 14; // hour hand at 2
    g.beginPath();
    g.moveTo(w / 2, h / 2);
    g.lineTo(w / 2 + Math.sin(Math.PI / 3) * 58, h / 2 - Math.cos(Math.PI / 3) * 58);
    g.stroke();
  });
  const win = night ? '#ffd98a' : '#fff4d8';
  return (
    <group>
      {/* ---- room ---- */}
      <Box p={[0, -0.06, 0]} s={[10.4, 0.12, 8.4]} c={C.floor} />
      <Box p={[0, 0.011, 0.6]} s={[3.4, 0.02, 2.4]} c="#7a3b36" o={0.04} />
      <Wall p={[0, 0, -4]} w={10.4} h={3.6} hole={{x0: 1.7, x1: 3.3, y0: 1.5, y1: 2.8}} />
      <Wall p={[0, 0, 4]} w={10.4} h={3.6} hole={{x0: -2.2, x1: -0.4, y0: 1.1, y1: 2.6}} />
      <Wall p={[-5.2, 0, 0]} ry={Math.PI / 2} w={8.4} h={3.6} c="#cfa985" />
      <Box p={[0, 3.72, 4]} s={[10.8, 0.24, 0.5]} c={C.wood} />
      {/* curtains swaying (secondary animation) */}
      <group position={[3.3, 2.9, -3.86]} rotation={[0, sway * 0.5, 0]}>
        <Box p={[0.05, -0.65, 0]} s={[0.34, 1.5, 0.05]} c={C.teal} o={0.03} />
      </group>
      <group position={[-0.4, 2.7, 3.86]} rotation={[0, sway * 0.5, 0]}>
        <Box p={[0.05, -0.65, 0]} s={[0.34, 1.5, 0.05]} c={C.teal} o={0.03} />
      </group>
      {/* door */}
      <Box p={[-4.2, 1.1, -3.9]} s={[1.1, 2.2, 0.08]} c="#5a3a2a" />
      <Ball p={[-3.8, 1.05, -3.84]} rad={0.05} c={C.mustard} o={0.03} />
      {/* clock with painted label (2:00) */}
      <Cyl p={[0.9, 2.7, -3.9]} rt={0.34} rb={0.34} h={0.08} c={C.cream} r={[Math.PI / 2, 0, 0]} o={0.06} />
      <Label p={[0.9, 2.7, -3.855]} size={[0.6, 0.6]} tex={clock} />
      <Shelf p={[-5.0, 2.0, -0.8]} />
      {/* chouki (low bed) */}
      <Box p={[-3.4, 0.3, -2.5]} s={[3.0, 0.12, 1.5]} c={C.wood} />
      {[[-4.7, -3.1], [-2.1, -3.1], [-4.7, -1.9], [-2.1, -1.9]].map((q, i) => (
        <Box key={i} p={[q[0], 0.12, q[1]]} s={[0.12, 0.24, 0.12]} c={C.wood} o={0.03} />
      ))}
      <Box p={[-3.4, 0.4, -2.5]} s={[2.8, 0.1, 1.3]} c="#d8cfb8" />
      <Box p={[-3.0, 0.5, -2.5]} s={[1.6, 0.1, 1.34]} c={C.teal} o={0.04} />
      {/* desk, stool, lamp */}
      <Box p={[2.5, 0.9, -3.1]} s={[2.2, 0.1, 0.9]} c={C.wood} />
      <Box p={[1.5, 0.43, -3.1]} s={[0.1, 0.86, 0.8]} c={C.wood} o={0.03} />
      <Box p={[3.5, 0.43, -3.1]} s={[0.1, 0.86, 0.8]} c={C.wood} o={0.03} />
      <Box p={[2.5, 0.25, -1.7]} s={[0.8, 0.5, 0.6]} c="#8a6a4a" />
      <Cyl p={[3.2, 1.0, -3.1]} rt={0.12} rb={0.14} h={0.1} c={C.dark} />
      <Cyl p={[3.2, 1.3, -3.1]} rt={0.02} rb={0.02} h={0.6} c={C.dark} o={0.03} />
      <Cyl p={[3.2, 1.65, -3.1]} rt={0.06} rb={0.22} h={0.3} c={C.mustard} />
      <mesh position={[3.2, 1.5, -3.1]}>
        <sphereGeometry args={[0.07, 12, 10]} />
        <meshBasicMaterial color={lampOn ? '#fff2b8' : '#6b5a3a'} />
      </mesh>
      {lampOn > 0 && <pointLight position={[3.0, 1.7, -2.4]} color="#ffc77a" intensity={26 * lampOn} distance={9} decay={2} />}
      <Box p={[2.1, 0.97, -3.1]} s={[0.7, 0.05, 0.5]} c="#efe6d2" o={0.03} />
      <Notebooks p={[4.3, 0, -2.4]} n={stack} />
      {/* sewing table, machine, cloth */}
      <Box p={[-0.6, 0.8, -3.2]} s={[1.5, 0.1, 0.8]} c={C.wood} />
      <Box p={[-1.25, 0.38, -3.2]} s={[0.1, 0.76, 0.7]} c={C.wood} o={0.03} />
      <Box p={[0.05, 0.38, -3.2]} s={[0.1, 0.76, 0.7]} c={C.wood} o={0.03} />
      <Box p={[-0.6, 1.0, -3.25]} s={[0.7, 0.3, 0.32]} c="#2f5d5f" />
      <Box p={[-0.85, 1.28, -3.25]} s={[0.16, 0.34, 0.28]} c="#2f5d5f" />
      <group position={[-0.2, 1.12, -3.08]} rotation={[spin, 0, 0]}>
        <Cyl p={[0, 0, 0]} rt={0.13} rb={0.13} h={0.05} c={C.mustard} r={[0, 0, Math.PI / 2]} o={0.04} />
        <Box p={[0.04, 0.09, 0]} s={[0.03, 0.05, 0.03]} c={INK} ink={false} />
      </group>
      <Box p={[-0.6, 0.2, -2.3]} s={[0.7, 0.4, 0.5]} c="#8a6a4a" />
      <Box p={[-0.6, 0.88, -2.95]} s={[0.55, 0.05, 0.4]} c={C.mustard} o={0.03} />
      <Box p={[-1.6, 0.09, -3.4]} s={[0.7, 0.18, 0.5]} c={C.terra} o={0.04} />
      <Box p={[-1.5, 0.26, -3.4]} s={[0.55, 0.16, 0.45]} c={C.cloth} o={0.04} />
      {/* ---- alley ---- */}
      <Box p={[0, -0.06, 16]} s={[12, 0.12, 24]} c="#7b6b5a" />
      <Box p={[0, 0.0, 16]} s={[3.2, 0.02, 24]} c="#8f7e68" o={0.02} />
      <Box p={[-7.5, 3.0, 10]} s={[3, 6, 14]} c={C.brick} />
      <Box p={[7.5, 3.5, 10]} s={[3, 7, 14]} c="#8b6a52" />
      {[[-5.95, 3.4, 7.5], [-5.95, 3.4, 11], [-5.95, 4.6, 9]].map((q, i) => (
        <Box key={'wl' + i} p={q} s={[0.06, 0.85, 0.6]} c={win} o={0.05} ink />
      ))}
      {[[5.95, 3.6, 8], [5.95, 5.0, 12], [5.95, 3.6, 12]].map((q, i) => (
        <Box key={'wr' + i} p={q} s={[0.06, 0.85, 0.6]} c={i === 1 ? win : '#3a4560'} o={0.05} />
      ))}
      <Cyl p={[3.6, 1.6, 8.5]} rt={0.07} rb={0.1} h={3.2} c={C.dark} />
      <Box p={[3.6, 3.3, 8.5]} s={[0.45, 0.4, 0.45]} c="#ffd98a" />
      {night > 0 && <pointLight position={[3.6, 3.1, 8.5]} color="#ffcf8a" intensity={18 * night} distance={14} decay={2} />}
      <Cyl p={[-3.0, 0.4, 6.5]} rt={0.35} rb={0.4} h={0.8} c="#6a5a4a" />
      <Box p={[-3.8, 0.25, 12]} s={[0.9, 0.5, 0.9]} c="#8a6a4a" />
      {night > 0.5 && (
        <mesh position={[-8, 12, -26]}>
          <sphereGeometry args={[1.8, 20, 16]} />
          <meshBasicMaterial color="#f4ecd0" />
        </mesh>
      )}
    </group>
  );
}

// School yard with notice board (X offset is applied by the parent group).
export function School({calT = -1}) {
  const board = useTex(512, 256, (g, w, h) => {
    g.fillStyle = '#e9dcc0';
    g.fillRect(0, 0, w, h);
    g.fillStyle = '#351f22';
    g.font = `bold 64px ${FONT}`;
    g.textAlign = 'center';
    g.fillText('ফলাফল', w / 2, 84);
    g.fillStyle = '#6b4330';
    for (let i = 0; i < 6; i++) {
      g.fillRect(40, 120 + i * 20, 300, 6);
      g.fillRect(380, 120 + i * 20, 90, 6);
    }
  });
  return (
    <group>
      <Box p={[0, -0.06, 2]} s={[26, 0.12, 18]} c="#9a8a68" />
      <Box p={[0, 2.5, -3.3]} s={[16, 5, 0.4]} c="#c9a46a" />
      <Box p={[0, 5.1, -3.3]} s={[16.4, 0.3, 0.7]} c={C.wood} />
      <Box p={[0, 2.2, -3.0]} s={[5.4, 2.8, 0.14]} c={C.wood} />
      <Label p={[0, 2.2, -2.92]} size={[5.0, 2.5]} tex={board} />
      {/* calendar: pages fall away one by one after calT >= 0 */}
      <Box p={[-4.4, 2.4, -3.0]} s={[1.3, 1.6, 0.1]} c={C.cream} />
      {Array.from({length: 6}).map((_, i) => {
        const k = Math.max(0, calT - i * 0.22);
        const fall = Math.min(k / 0.9, 1);
        return (
          <group key={i} position={[-4.4 + fall * 0.6 * (i % 2 ? 1 : -1), 2.4 - fall * fall * 2.2, -2.92 + i * 0.012 + fall * 0.5]} rotation={[0, 0, fall * (i % 2 ? 1 : -1) * 0.8]}>
            <Box p={[0, 0, 0]} s={[1.2, 1.5, 0.02]} c={BOOK_COLORS[i % 6] === C.terra ? '#f3e9d6' : '#f7efde'} o={0.025} cast={false} />
          </group>
        );
      })}
      {[-6, -2.5, 2.5, 6].map((x, i) => (
        <Box key={i} p={[x, 3.4, -3.05]} s={[1.0, 1.1, 0.06]} c={i % 2 ? '#a9d2dc' : '#9cc5cf'} o={0.05} />
      ))}
      <Box p={[6.2, 1.1, -3.05]} s={[1.2, 2.2, 0.1]} c="#5a3a2a" />
      <Cyl p={[7.2, 1.0, -0.5]} rt={0.18} rb={0.24} h={2.0} c="#6b4330" />
      <Ball p={[7.2, 3.0, -0.5]} rad={1.5} c={C.green} />
      <Box p={[-6.8, 0.3, 0.5]} s={[2.0, 0.12, 0.5]} c={C.wood} />
      <Box p={[-7.6, 0.15, 0.5]} s={[0.1, 0.3, 0.45]} c={C.wood} o={0.03} />
      <Box p={[-6.0, 0.15, 0.5]} s={[0.1, 0.3, 0.45]} c={C.wood} o={0.03} />
      {Array.from({length: 9}).map((_, i) => (
        <Box key={i} p={[-8 + i * 2, 0.35, 4.5]} s={[0.1, 0.7, 0.1]} c="#7b5a3c" o={0.03} />
      ))}
      <Box p={[0, 0.7, 4.5]} s={[16, 0.08, 0.06]} c="#7b5a3c" o={0.03} />
    </group>
  );
}

// Classroom: blackboard at the front (z=-8), five bench rows, windows on the left, door at the back.
export function Classroom({paper = 1}) {
  const chalk = useTex(512, 128, (g, w, h) => {
    g.fillStyle = '#2f4f43';
    g.fillRect(0, 0, w, h);
    g.strokeStyle = '#e8e8dc';
    g.lineWidth = 4;
    g.lineCap = 'round';
    for (let i = 0; i < 4; i++) {
      g.beginPath();
      g.moveTo(40, 26 + i * 26);
      g.lineTo(150 + ((i * 97) % 220), 26 + i * 26 + ((i * 7) % 4));
      g.stroke();
    }
  });
  const rows = [-4, -2, 0, 2, 4];
  return (
    <group>
      <Box p={[0, -0.06, 0]} s={[16, 0.12, 17]} c="#9a6f4a" />
      <Wall p={[0, 0, -8]} w={16} h={4.2} c="#cdbb92" />
      <Wall p={[0, 0, 8]} w={16} h={4.2} c="#cdbb92" />
      <Wall p={[-8, 0, 0]} ry={Math.PI / 2} w={16} h={4.2} c="#d9c8a0" />
      <Box p={[0, 2.1, -7.83]} s={[7.4, 2.3, 0.1]} c={C.wood} />
      <Label p={[0, 2.1, -7.76]} size={[7.0, 1.9]} tex={chalk} />
      {[-4.5, 0, 4.5].map((z, i) => (
        <Box key={i} p={[-7.88, 2.6, z]} s={[0.1, 1.5, 2.2]} c="#aed3df" o={0.06} />
      ))}
      <Box p={[5.5, 1.1, 7.88]} s={[1.3, 2.2, 0.1]} c="#5a3a2a" />
      {rows.map((z) =>
        [-2.6, 2.6].map((x) => (
          <group key={z + ':' + x}>
            <Box p={[x, 0.82, z]} s={[2.4, 0.1, 0.9]} c="#b98757" />
            <Box p={[x - 1.1, 0.4, z]} s={[0.08, 0.8, 0.8]} c={C.wood} o={0.03} />
            <Box p={[x + 1.1, 0.4, z]} s={[0.08, 0.8, 0.8]} c={C.wood} o={0.03} />
            <Box p={[x, 0.46, z + 0.95]} s={[2.4, 0.1, 0.5]} c="#9a6f4a" />
            <Box p={[x - 1.1, 0.22, z + 0.95]} s={[0.08, 0.44, 0.45]} c={C.wood} o={0.03} />
            <Box p={[x + 1.1, 0.22, z + 0.95]} s={[0.08, 0.44, 0.45]} c={C.wood} o={0.03} />
          </group>
        ))
      )}
      {/* failed paper on the last bench */}
      {paper > 0 && (
        <group position={[-2.2, 0.88, 4]}>
          <Box p={[0, 0, 0]} s={[0.5, 0.02, 0.36]} c="#f7efde" o={0.02} cast={false} />
          <Box p={[0.05, 0.015, 0]} s={[0.3, 0.01, 0.04]} c="#c0231a" ink={false} cast={false} />
        </group>
      )}
    </group>
  );
}
