import React from 'react';
import * as THREE from 'three';
import {INK, clamp} from './kit.jsx';

const G = 0.022; // outline growth
const ell = (rx, ry, g = 0) => {
  const s = new THREE.Shape();
  s.absellipse(0, 0, rx + g, ry + g, 0, Math.PI * 2, false, 0);
  return s;
};
const limb = (w0, w1, L, g = 0) => {
  const s = new THREE.Shape();
  s.moveTo(-(w0 + g), 0);
  s.lineTo(-(w1 + g), -L);
  s.absarc(0, -L, w1 + g, Math.PI, Math.PI * 2, false);
  s.lineTo(w0 + g, 0);
  s.absarc(0, 0, w0 + g, 0, Math.PI, false);
  return s;
};
const half = (r, g = 0) => {
  const s = new THREE.Shape();
  s.absarc(0, 0, r + g, 0, Math.PI, false);
  return s;
};
const rect = (w, h, g = 0) => {
  const s = new THREE.Shape();
  const x = w / 2 + g;
  const y = h / 2 + g;
  s.moveTo(-x, -y);
  s.lineTo(x, -y);
  s.lineTo(x, y);
  s.lineTo(-x, y);
  return s;
};
const poly = (pts, g = 0) => {
  const s = new THREE.Shape();
  pts.forEach(([x, y], i) => {
    const k = 1 + g / 0.1;
    if (i === 0) s.moveTo(x * k, y * k);
    else s.lineTo(x * k, y * k);
  });
  return s;
};
const pair = (f) => [f(0), f(G)];

const SH = {
  head: pair((g) => ell(0.36, 0.37, g)),
  hairBack: pair((g) => ell(0.385, 0.385, g)),
  ear: pair((g) => ell(0.05, 0.07, g)),
  torsoLo: pair((g) => ell(0.31, 0.36, g)),
  torsoUp: pair((g) => ell(0.25, 0.27, g)),
  arm: pair((g) => limb(0.065, 0.048, 0.5, g)),
  leg: pair((g) => limb(0.08, 0.06, 0.38, g)),
  hand: pair((g) => ell(0.06, 0.06, g)),
  shoe: pair((g) => ell(0.1, 0.05, g)),
  fringe: pair((g) => half(0.37, g)),
  bun: pair((g) => ell(0.13, 0.13, g)),
  capTop: pair((g) => half(0.38, g)),
  brim: pair((g) => ell(0.3, 0.05, g)),
  pocket: pair((g) => rect(0.11, 0.1, g * 0.4)),
  collarL: pair((g) => poly([[-0.01, 0], [-0.17, 0.0], [-0.06, -0.14]], g * 0.3)),
  collarR: pair((g) => poly([[0.01, 0], [0.17, 0.0], [0.06, -0.14]], g * 0.3)),
  tie: pair((g) => poly([[-0.04, 0.0], [0.04, 0.0], [0.065, -0.2], [0, -0.26], [-0.065, -0.2]], g * 0.3)),
  book: pair((g) => rect(0.56, 0.4, g * 0.5)),
  eyeW: ell(0.07, 0.062),
  pupil: ell(0.034, 0.034),
  lid: half(0.074),
  brow: ell(0.07, 0.014),
  shadow: ell(0.42, 0.2),
};

const Flat = ({sh, color, p = [0, 0, 0], r = 0, z = 0, ink = true, s = [1, 1, 1]}) => (
  <group position={[p[0], p[1], z]} rotation={[0, 0, r]} scale={s}>
    {ink && (
      <mesh position={[0, 0, -0.006]}>
        <shapeGeometry args={[sh[1]]} />
        <meshBasicMaterial color={INK} />
      </mesh>
    )}
    <mesh>
      <shapeGeometry args={[sh[0]]} />
      <meshBasicMaterial color={color} />
    </mesh>
  </group>
);

const Plain = ({shape, color, p = [0, 0, 0], r = 0, z = 0, s = [1, 1, 1]}) => (
  <group position={[p[0], p[1], z]} rotation={[0, 0, r]} scale={s}>
    <mesh>
      <shapeGeometry args={[shape]} />
      <meshBasicMaterial color={color} />
    </mesh>
  </group>
);

export const PAL = {
  rafi: {skin: '#f3dcc4', hair: '#2b1f22', up: '#8da6ad', lo: '#76909a', pants: '#4a4a5a', tie: '#c0583a', collar: '#ffffff', shoe: INK},
  mom: {skin: '#e6c3a0', hair: '#9a9a9a', up: '#a4515a', lo: '#8a3f49', pants: '#5a4a60', tie: null, collar: null, shoe: INK},
  fr1: {skin: '#f0d3b8', hair: '#3a2a1e', up: '#d6a23a', lo: '#b98a2a', pants: '#3f4f5f', tie: '#4f8a8b', collar: '#ffffff', shoe: INK},
  fr2: {skin: '#e8c4a2', hair: '#1f1a1a', up: '#4f8a8b', lo: '#3f7273', pants: '#4a3f3a', tie: '#d6a23a', collar: '#ffffff', shoe: INK},
  fr3: {skin: '#f3dcc4', hair: '#5a3a28', up: '#c0583a', lo: '#a24630', pants: '#2f3a4a', tie: '#efe6d2', collar: '#ffffff', shoe: INK},
  teacher: {skin: '#e8c9a8', hair: '#777777', up: '#7b5ea7', lo: '#664b8f', pants: '#3a3340', tie: '#d6a23a', collar: '#ffffff', shoe: INK},
};

/*
 Props:
  p        world position of the feet [x,y,z]
  cam      camera world position (character turns toward it, yaw clamped to 0.7 rad)
  pal      palette from PAL
  t        time in seconds (drives idle motion)
  pose     {walk, arms:[left,right] (0 hang, + outward/up, - inward), emotion -1..1, look:[x,y], seated, lying,
            book, packet, certificate, tear, bounce, tired}
  hat      'cap' | undefined      glasses  bool     bun  bool
*/
export function Character({p, cam, pal, t = 0, pose = {}, hat, glasses = false, bun = false, ph = 0}) {
  const {
    walk = 0, arms = [0.06, 0.06], emotion = 0.25, look = [0, 0], seated = false, lying = false,
    book = false, packet = false, certificate = false, tear = 0, bounce = 0, tired = 0, walkPhase = 0, flip = 1,
  } = pose;
  const yaw = lying ? 0 : clamp(Math.atan2(cam[0] - p[0], cam[2] - p[2]), -0.7, 0.7);
  const idle = Math.sin(t * 2.1 + ph);
  const breathe = 1 + 0.018 * Math.sin(t * 1.8 + ph);
  const wp = walkPhase;
  const bob = seated ? 0.008 * idle : 0.012 * idle + Math.abs(Math.sin(wp)) * 0.05 * walk + Math.abs(Math.sin(t * 9 + ph)) * 0.05 * bounce;
  const swayL = 0.05 * Math.sin(t * 1.6 + ph) + Math.sin(wp) * 0.55 * walk;
  const swayR = 0.05 * Math.sin(t * 1.6 + ph + 1.3) - Math.sin(wp) * 0.55 * walk;
  const aL = -(arms[0] + swayL);
  const aR = arms[1] + swayR;
  const blinkCycle = (t * 0.33 + ph * 0.17) % 1;
  const blink = blinkCycle > 0.965 ? 0.1 : 1;
  const eyeSy = blink * (1 - 0.45 * tired);
  const head = clamp(idle * 0.025 + (look[0] || 0) * 0.1, -0.2, 0.2);
  const mouthSy = -Math.sign(emotion || 0.01) * Math.max(Math.abs(emotion), 0.18);
  const lift = seated ? 0 : 0;

  const body = (
    <group position={[0, bob + lift, 0]}>
      {/* legs */}
      {!seated && (
        <>
          <group position={[-0.12, 0.4, 0.01]} rotation={[0, 0, -Math.sin(wp) * 0.5 * walk]}>
            <Flat sh={SH.leg} color={pal.pants} />
            <Flat sh={SH.shoe} color={pal.shoe} p={[0, -0.4, 0]} z={0.002} ink={false} />
          </group>
          <group position={[0.12, 0.4, 0.01]} rotation={[0, 0, Math.sin(wp) * 0.5 * walk]}>
            <Flat sh={SH.leg} color={pal.pants} />
            <Flat sh={SH.shoe} color={pal.shoe} p={[0, -0.4, 0]} z={0.002} ink={false} />
          </group>
        </>
      )}
      {/* torso: pear shape, two tone */}
      <group scale={[1, breathe, 1]} position={[0, 0.66 * (1 - breathe) * 0, 0]}>
        <Flat sh={SH.torsoLo} color={pal.lo} p={[0, 0.66, 0]} z={0.02} />
        <Flat sh={SH.torsoUp} color={pal.up} p={[0, 0.95, 0]} z={0.03} />
        <Flat sh={SH.pocket} color={pal.up} p={[0.13, 0.62, 0]} z={0.05} />
        {pal.collar && <Flat sh={SH.collarL} color={pal.collar} p={[0, 1.15, 0]} z={0.06} ink />}
        {pal.collar && <Flat sh={SH.collarR} color={pal.collar} p={[0, 1.15, 0]} z={0.06} ink />}
        {pal.tie && <Flat sh={SH.tie} color={pal.tie} p={[0, 1.1, 0]} z={0.07} />}
      </group>
      {/* book in lap */}
      {book && (
        <group position={[0, 0.6, 0.1]}>
          <Flat sh={SH.book} color="#c0583a" />
          <Plain shape={rect(0.5, 0.34)} color="#efe6d2" p={[0, 0, 0.004]} />
          <Plain shape={rect(0.01, 0.34)} color={INK} p={[0, 0, 0.008]} />
        </group>
      )}
      {certificate && (
        <group position={[0, 0.68, 0.12]}>
          <Flat sh={SH.book} color="#d6a23a" s={[0.9, 0.9, 1]} />
          <Plain shape={rect(0.46, 0.3)} color="#fff8e6" p={[0, 0, 0.004]} />
          <Plain shape={rect(0.3, 0.025)} color={INK} p={[0, 0.07, 0.008]} />
          <Plain shape={rect(0.34, 0.015)} color="#6b4330" p={[0, 0.0, 0.008]} />
          <Plain shape={rect(0.34, 0.015)} color="#6b4330" p={[0, -0.04, 0.008]} />
          <Plain shape={ell(0.045, 0.045)} color="#c0583a" p={[0.15, -0.1, 0.01]} />
        </group>
      )}
      {/* arms */}
      <group position={[-0.25, 1.02, 0.09]} rotation={[0, 0, aL]}>
        <Flat sh={SH.arm} color={pal.up} />
        <Flat sh={SH.hand} color="#3b2a2e" p={[0, -0.5, 0]} z={0.004} ink={false} />
        {packet && flip === 1 && (
          <group position={[0.02, -0.5, 0.05]}>
            <Flat sh={pair((g) => rect(0.26, 0.2, g * 0.4))} color="#d6a23a" />
            <Plain shape={rect(0.26, 0.03)} color="#c0583a" p={[0, 0, 0.004]} />
          </group>
        )}
      </group>
      <group position={[0.25, 1.02, 0.09]} rotation={[0, 0, aR]}>
        <Flat sh={SH.arm} color={pal.up} />
        <Flat sh={SH.hand} color="#3b2a2e" p={[0, -0.5, 0]} z={0.004} ink={false} />
      </group>
      {/* head */}
      <group position={[0, 1.3, 0.08]} rotation={[0, 0, head]}>
        <Flat sh={SH.hairBack} color={pal.hair} p={[0, 0.02, 0]} z={-0.04} />
        <Flat sh={SH.ear} color={pal.skin} p={[-0.36, -0.02, 0]} z={-0.02} />
        <Flat sh={SH.ear} color={pal.skin} p={[0.36, -0.02, 0]} z={-0.02} />
        <Flat sh={SH.head} color={pal.skin} z={0} />
        {bun && <Flat sh={SH.bun} color={pal.hair} p={[0, 0.43, 0]} z={-0.05} />}
        {/* eyes */}
        {[-1, 1].map((sx) => (
          <group key={sx} position={[sx * 0.14, 0.0, 0.02]} scale={[1, eyeSy, 1]}>
            <Plain shape={SH.eyeW} color="#ffffff" />
            <Plain shape={SH.pupil} color={INK} p={[(look[0] || 0) * 0.03, (look[1] || 0) * 0.025, 0.003]} />
            <Plain shape={SH.lid} color={pal.skin} p={[0, 0.0, 0.006]} s={[1.2, 0.55 + 0.4 * tired, 1]} />
            <Plain shape={SH.lid} color={INK} p={[0, 0.0, 0.0075]} s={[1.25, 0.16, 1]} />
          </group>
        ))}
        {/* brows */}
        <Plain shape={SH.brow} color={INK} p={[-0.14, 0.13, 0.02]} r={emotion < -0.2 ? 0.25 : -0.08 * emotion} />
        <Plain shape={SH.brow} color={INK} p={[0.14, 0.13, 0.02]} r={emotion < -0.2 ? -0.25 : 0.08 * emotion} />
        {glasses && (
          <group position={[0, 0, 0.04]}>
            <mesh position={[-0.14, 0, 0]}>
              <torusGeometry args={[0.095, 0.012, 6, 22]} />
              <meshBasicMaterial color={INK} />
            </mesh>
            <mesh position={[0.14, 0, 0]}>
              <torusGeometry args={[0.095, 0.012, 6, 22]} />
              <meshBasicMaterial color={INK} />
            </mesh>
            <mesh position={[0, 0.03, 0]}>
              <boxGeometry args={[0.07, 0.012, 0.01]} />
              <meshBasicMaterial color={INK} />
            </mesh>
          </group>
        )}
        {/* mouth: small smile / frown */}
        <mesh position={[0, -0.15, 0.03]} scale={[1, mouthSy, 1]}>
          <torusGeometry args={[0.07, 0.011, 6, 16, Math.PI]} />
          <meshBasicMaterial color={INK} side={THREE.DoubleSide} />
        </mesh>
        {/* tear */}
        {tear > 0 && (
          <Plain shape={ell(0.022, 0.034)} color="#8cc7ee" p={[0.15, -0.06 - tear * 0.2, 0.05]} s={[1, 1, 1]} />
        )}
        {/* hair fringe / cap */}
        {!hat && <Flat sh={SH.fringe} color={pal.hair} p={[0, 0.16, 0]} z={0.04} r={0.0} s={[1, 0.62, 1]} />}
        {hat === 'cap' && (
          <>
            <Flat sh={SH.capTop} color="#4f8a8b" p={[0, 0.14, 0]} z={0.05} s={[1, 0.8, 1]} />
            <Flat sh={SH.brim} color="#3f7273" p={[0.1, 0.12, 0]} z={0.055} />
          </>
        )}
      </group>
    </group>
  );

  const shadowY = -p[1] + 0.02;
  return (
    <group position={p}>
      {!lying && (
        <mesh position={[0, shadowY, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[0.4, 24]} />
          <meshBasicMaterial color="#000000" transparent opacity={0.28} depthWrite={false} />
        </mesh>
      )}
      <group rotation={[0, yaw, lying ? Math.PI / 2 : 0]} scale={[1, 1, 1]}>
        {body}
      </group>
    </group>
  );
}

export const ellShape = ell;
