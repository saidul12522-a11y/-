import React from 'react';
import {Composition} from 'remotion';
import {Story} from './Story.jsx';
import {FPS, TOTAL_FRAMES} from './data.js';

export const Root = () => (
  <Composition
    id="Story"
    component={Story}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={1080}
    height={1920}
    defaultProps={{shadows: true, subtitles: true}}
  />
);
