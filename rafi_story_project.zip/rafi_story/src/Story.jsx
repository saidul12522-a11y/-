import React, {useLayoutEffect} from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import {Character, PAL} from './Character.jsx';
import {Home, School, Classroom} from './Worlds.jsx';
import {Key, warpU, pathAt, clamp, mixColor, C, FONT, INK} from './kit.jsx';
import {BOUNDS, CUES, SENT, FPS} from './data.js';

const B = BOUNDS;
const XS = {home: 0, school: 60, class: 120};
const sS = (i) => SENT[i][0];

// Camera keys are in world coordinates. T = times (0..1) at which each key is reached.
const SHOTS = [
  // 1: night, alley -> through the window -> Rafi at his book
  {a: B[0], b: B[1], loc: 'home', T: [0, 0.55, 1],
    pos: [[-1.3, 1.9, 13], [-1.3, 1.85, 5.2], [0.6, 1.4, 0.5]],
    look: [[-1.3, 1.8, 0], [-1.3, 1.8, -1], [2.5, 0.95, -1.7]]},
  // 2: Rafi's shirt and eyes, mother asleep, sewing machine
  {a: B[1], b: B[2], loc: 'home', T: [0, 0.35, 0.65, 1],
    pos: [[1.2, 1.5, 0.5], [-0.3, 1.5, 0.7], [-1.2, 1.45, 0.6], [-1.2, 1.45, 0.6]],
    look: [[2.5, 0.95, -1.7], [-3.3, 0.8, -2.5], [-0.6, 0.95, -3.15], [-0.6, 0.95, -3.15]]},
  // 3: classroom, last bench
  {a: B[2], b: B[3], loc: 'class', T: [0, 0.5, 1],
    pos: [[120, 3.3, -3.5], [119.6, 2.0, -0.8], [119.4, 1.6, 1.8]],
    look: [[120, 1.2, 3.5], [118.4, 1.0, 4.6], [117.8, 0.95, 4.9]]},
  // 4: Rafi outside the window, camera goes in to the mother threading a needle
  {a: B[3], b: B[4], loc: 'home', T: [0, 0.5, 1],
    pos: [[-4.4, 1.6, 8.4], [-1.4, 1.6, 5.0], [-1.0, 1.5, 0.0]],
    look: [[-2.9, 1.1, 5.8], [-1.2, 1.4, 0], [-0.6, 1.15, -2.4]]},
  // 5: Rafi's decision
  {a: B[4], b: B[5], loc: 'home', T: [0, 1],
    pos: [[0.9, 1.35, 0.3], [1.7, 1.3, -0.5]],
    look: [[2.5, 1.1, -1.7], [2.5, 1.15, -1.7]]},
  // 6: months of study, night/day cycles, notebooks pile up
  {a: B[5], b: B[6], loc: 'home', T: [0, 0.5, 1],
    pos: [[1.5, 1.2, 0.2], [2.2, 1.7, 0.6], [3.2, 2.0, 0.4]],
    look: [[2.6, 1.0, -1.7], [2.8, 1.1, -2.2], [3.8, 1.0, -2.0]]},
  // 7: calendar pages fall, result board
  {a: B[6], b: B[7], loc: 'school', T: [0, 0.5, 1],
    pos: [[63.6, 1.7, 4.8], [61, 1.8, 4.4], [58.2, 1.8, 3.8]],
    look: [[61.5, 1.9, -3], [60.5, 2.1, -3], [58.8, 2.1, -3]]},
  // 8: certificate
  {a: B[7], b: B[8], loc: 'school', T: [0, 1],
    pos: [[58.5, 1.4, 4.2], [59.7, 1.3, 2.2]],
    look: [[60, 1.1, 0], [60, 1.0, 0]]},
  // 9: sweets, home, hug
  {a: B[8], b: B[9], loc: 'home', T: [0, 0.55, 1],
    pos: [[2.8, 1.5, 3.0], [1.0, 1.35, 1.2], [0.0, 1.35, 0.4]],
    look: [[3.0, 0.9, -1.5], [-0.6, 1.0, -1.7], [-1.2, 1.1, -1.8]]},
  // 10: mother's tears and Rafi's smile
  {a: B[9], b: B[10], loc: 'home', T: [0, 1],
    pos: [[-0.1, 1.45, 0.3], [-0.5, 1.4, -0.5]],
    look: [[-1.2, 1.15, -1.8], [-1.2, 1.2, -1.8]]},
  // 11: classroom, empty last bench -> pull-out to Rafi in the first row
  {a: B[10], b: B[11], loc: 'class', T: [0, 0.4, 1],
    pos: [[120, 1.6, 1.8], [120, 1.9, -2.0], [119.4, 1.9, -6.2]],
    look: [[117.8, 0.85, 4.8], [117.6, 1.0, 1.5], [117.6, 1.1, -3.0]]},
];

const shotIndex = (t) => {
  for (let i = SHOTS.length - 1; i >= 0; i--) if (t >= SHOTS[i].a) return i;
  return 0;
};

function Rig({pos, look, bg}) {
  const {camera, invalidate} = useThree();
  camera.position.set(pos[0], pos[1], pos[2]);
  camera.lookAt(look[0], look[1], look[2]);
  camera.fov = 80;
  camera.updateProjectionMatrix();
  camera.updateMatrixWorld();
  useLayoutEffect(() => {
    invalidate();
  });
  return (
    <>
      <color attach="background" args={[bg]} />
      <fog attach="fog" args={[bg, 35, 110]} />
    </>
  );
}

function lighting(loc, day) {
  if (loc === 'home') {
    return {
      bg: mixColor('#14203a', '#bfe0ea', day),
      amb: mixColor('#6b7fa8', '#fff1d6', day),
      ambI: 0.55 + 0.45 * day,
      key: mixColor('#8fa6d6', '#ffe2b0', day),
      keyI: 0.9 + 1.5 * day,
    };
  }
  return {bg: '#bfe0ea', amb: '#fff1d6', ambI: 1.0, key: '#ffe2b0', keyI: 2.4};
}

// ---------------------------------------------------------------- characters per shot
const Rafi = (o) => <Character pal={PAL.rafi} ph={0.3} {...o} />;
const Mom = (o) => <Character pal={PAL.mom} ph={1.1} glasses bun {...o} />;

function Chars({i, t, cam}) {
  const base = {cam, t};
  const lyingMom = <Mom key="ml" {...base} p={[-2.5, 0.78, -2.4]} pose={{lying: true, arms: [0.05, 0.05], emotion: 0.1, tired: 2}} />;
  const rafiRead = (pose) => <Rafi key="rr" {...base} p={[2.5, 0.2, -1.7]} pose={{seated: true, book: true, arms: [0.05, 0.05], look: [0, -0.6], ...pose}} />;

  if (i === 0) return <>{rafiRead({emotion: 0.15})}{lyingMom}</>;
  if (i === 1) return <>{rafiRead({emotion: -0.1, tired: 0.8})}{lyingMom}</>;

  if (i === 2) {
    const laugh = t >= sS(9);
    const wave = t >= sS(10);
    return (
      <>
        <Rafi {...base} p={[117.6, 0.16, 4.95]} pose={{seated: true, arms: [0.05, 0.05], look: [0, -0.5], emotion: -0.5}} />
        <Character {...base} pal={PAL.fr1} ph={2} p={[117.4, 0.16, 0.95]} pose={{seated: true, arms: [0.05, laugh ? 1.4 : 0.05], emotion: laugh ? 1 : 0.2, bounce: laugh ? 0.5 : 0}} />
        <Character {...base} pal={PAL.fr2} ph={3} hat="cap" p={[122.6, 0.16, 0.95]} pose={{seated: true, arms: [laugh ? 1.2 : 0.05, 0.05], emotion: laugh ? 1 : 0.2, bounce: laugh ? 0.4 : 0}} />
        <Character {...base} pal={PAL.fr3} ph={4} p={[122.6, 0.16, 2.95]} pose={{seated: true, arms: [0.05, 0.05], emotion: laugh ? 1 : 0.2, bounce: laugh ? 0.6 : 0}} />
        <Character {...base} pal={PAL.teacher} ph={5} glasses p={[124.4, 0, 1.2]} pose={{arms: [0.05, wave ? 1.2 + 0.3 * Math.sin(t * 6) : 0.05], emotion: wave ? -0.7 : -0.1, look: [wave ? -1 : 0, 0]}} />
      </>
    );
  }

  if (i === 3) {
    const thread = t >= sS(12);
    const sew = thread ? -2.3 + 0.06 * Math.sin(t * 22) : -0.5 + 0.12 * Math.sin(t * 7);
    return (
      <>
        <Rafi {...base} p={[-3.0, 0, 6.0]} pose={{arms: [0.05, 0.05], look: [1, 0.2], emotion: -0.3}} />
        <Mom {...base} p={[-0.6, 0.12, -2.3]} pose={{seated: true, arms: [-0.4, sew], emotion: -0.15, tired: 0.6, look: [0, thread ? 0.2 : -0.4]}} />
      </>
    );
  }

  if (i === 4) {
    const chest = t < sS(14);
    return (
      <Rafi {...base} p={[2.5, 0.2, -1.7]} pose={{
        seated: true, book: !chest,
        arms: chest ? [0.05, -0.8 + 0.03 * Math.sin(t * 25)] : [0.05, 0.05],
        emotion: chest ? -0.4 : 0.5, look: chest ? [0, 0] : [0, 0.1],
      }} />
    );
  }

  if (i === 5) {
    let arms = [0.05, 0.05], emotion = 0.1, look = [0, -0.6], tired = 0;
    if (t < sS(16)) { arms = [-2.9, 0.1]; emotion = -0.4; look = [0.4, 0.3]; tired = 0.3; }
    else if (t < sS(17)) { arms = [0.05, -0.3 + 0.1 * Math.sin(t * 8)]; }
    else if (t < sS(18)) { arms = [0.05, -0.45]; emotion = -0.6; look = [Math.sin(t * 4), -0.3]; tired = 0.5; }
    else { emotion = 0.6; look = [0, 0]; }
    return <Rafi {...base} p={[2.5, 0.2, -1.7]} pose={{seated: true, book: true, arms, emotion, look, tired}} />;
  }

  if (i === 6) {
    const win = clamp((t - sS(20)) / 1.2, 0, 1);
    return (
      <>
        <Rafi {...base} p={[62.2, 0, -0.5]} pose={{arms: [0.05, 0.05], emotion: -0.2 + 1.1 * win, look: [-0.6, 0.4], bounce: win > 0.8 ? 0.3 : 0}} />
        <Character {...base} pal={PAL.fr1} ph={2} p={[58.4, 0, -1.0]} pose={{arms: [0.05, 0.05], look: [0, 0.4], emotion: 0.2}} />
        <Character {...base} pal={PAL.fr2} ph={3} hat="cap" p={[59.6, 0, -1.6]} pose={{arms: [0.05, win * 2.5], look: [0, 0.4], emotion: 0.3 + win * 0.6, bounce: win * 0.4}} />
        <Character {...base} pal={PAL.fr3} ph={4} p={[60.9, 0, -1.2]} pose={{arms: [0.05, 0.05], look: [0, 0.4], emotion: 0.2}} />
      </>
    );
  }

  if (i === 7) {
    return (
      <Rafi {...base} p={[60, 0, 0]} pose={{arms: [-0.6, -0.6], emotion: 0.9, bounce: 0.15, certificate: true}} />
    );
  }

  if (i === 8) {
    const dt = t - B[8];
    const wlk = clamp(dt / 2.6, 0, 1);
    const hug = dt > 2.6;
    const x = 5.4 + (-0.95 - 5.4) * wlk;
    const z = -1.2 + (-1.55 + 1.2) * wlk;
    return (
      <>
        <Mom {...base} p={[-1.5, 0, -2.0]} pose={{arms: hug ? [-1.1, -1.1] : [0.05, 0.05], emotion: 0.6}} />
        <Rafi {...base} p={[x, 0, z]} pose={{walk: hug ? 0 : 1, walkPhase: t * 9, arms: hug ? [-1.1, -1.1] : [0.05, 0.05], packet: !hug, emotion: 0.8}} />
      </>
    );
  }

  if (i === 9) {
    const tear = ((t * 0.6) % 1) * (t > sS(23) + 0.4 ? 1 : 0);
    return (
      <>
        <Mom {...base} p={[-1.5, 0, -2.0]} pose={{arms: [-1.1, -1.1], emotion: 0.5, tear: Math.max(tear, 0.05)}} />
        <Rafi {...base} p={[-0.95, 0, -1.55]} pose={{arms: [-1.1, -1.1], emotion: 1}} />
      </>
    );
  }

  // i === 10
  const sit = t > B[10] + 1.5;
  return (
    <>
      <Character {...base} pal={PAL.fr1} ph={2} p={[117.4, 0.16, 0.95]} pose={{seated: true, arms: [0.05, 0.05], emotion: 0.3}} />
      <Character {...base} pal={PAL.fr2} ph={3} hat="cap" p={[122.6, 0.16, -1.05]} pose={{seated: true, arms: [0.05, 0.05], emotion: 0.3}} />
      <Character {...base} pal={PAL.fr3} ph={4} p={[122.6, 0.16, 2.95]} pose={{seated: true, arms: [0.05, 0.05], emotion: 0.3}} />
      <Rafi {...base} p={[117.6, 0.16, -3.05]} pose={{seated: true, book: true, arms: [0.05, 0.05], emotion: 0.8, look: [0, 0]}} />
    </>
  );
}

// ---------------------------------------------------------------- overlays
function Subtitle({t}) {
  const cue = CUES.find((c) => t >= c.s && t < c.e);
  if (!cue) return null;
  return (
    <div style={{position: 'absolute', left: 60, right: 60, bottom: 150, textAlign: 'center', fontFamily: FONT, fontWeight: 700, fontSize: 58, lineHeight: 1.35, color: '#fdf6e6', whiteSpace: 'pre-line', WebkitTextStroke: '9px ' + INK, paintOrder: 'stroke fill', textShadow: '0 4px 0 ' + INK}}>
      {cue.t}
    </div>
  );
}

function Dip({t}) {
  let o = 0;
  for (let i = 1; i < SHOTS.length; i++) {
    if (SHOTS[i].loc !== SHOTS[i - 1].loc) o = Math.max(o, clamp(1 - Math.abs(t - SHOTS[i].a) / 0.2, 0, 1));
  }
  if (o <= 0) return null;
  return <AbsoluteFill style={{background: C.cream, opacity: o}} />;
}

export const Story = ({shadows = true, subtitles = true}) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const idx = shotIndex(t);
  const sh = SHOTS[idx];
  const st = clamp((t - sh.a) / (sh.b - sh.a), 0, 1);
  const u = warpU(sh.T, st);
  const pos = pathAt(sh.pos, u);
  const look = pathAt(sh.look, u);

  let day = 0;
  if (idx === 5) {
    const p = (t - B[5]) / (B[6] - B[5]);
    day = Math.pow(Math.sin(2 * Math.PI * p), 2);
  } else if (idx >= 8 && sh.loc === 'home') day = 1;
  const L = lighting(sh.loc, day);
  const X = XS[sh.loc];
  const stack = idx < 5 ? 1 : idx === 5 ? 1 + Math.floor(((t - B[5]) / (B[6] - B[5])) * 7) : 8;
  const sewing = idx === 3 && t < sS(12);

  return (
    <AbsoluteFill style={{background: C.cream}}>
      <ThreeCanvas width={1080} height={1920} shadows={shadows} camera={{fov: 80, near: 0.1, far: 400, position: [0, 1.6, 6]}}>
        <Rig pos={pos} look={look} bg={L.bg} />
        <ambientLight color={L.amb} intensity={L.ambI} />
        <hemisphereLight args={[L.amb, '#6b5a4a', 0.35]} />
        <Key X={X} color={L.key} intensity={L.keyI} shadows={shadows} />
        <group visible={sh.loc === 'home'}>
          <Home stack={stack} sway={Math.sin(frame / 35) * 0.12} spin={sewing ? t * 8 : 0} night={1 - day} lampOn={1 - day} />
        </group>
        <group position={[60, 0, 0]} visible={sh.loc === 'school'}>
          <School calT={t - sS(19)} />
        </group>
        <group position={[120, 0, 0]} visible={sh.loc === 'class'}>
          <Classroom paper={idx === 2 ? 1 : 0} />
        </group>
        <Chars i={idx} t={t} cam={pos} />
      </ThreeCanvas>
      {subtitles && <Subtitle t={t} />}
      <Dip t={t} />
      <Audio src={staticFile('voiceover.mp3')} />
    </AbsoluteFill>
  );
};
