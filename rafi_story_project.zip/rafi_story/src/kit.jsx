import React, {useMemo, useRef, useLayoutEffect} from 'react';
import * as THREE from 'three';

export const INK = '#351f22';
export const C = {
  cream: '#f3e9d6', wall: '#d9b48f', wood: '#6b4330', floor: '#8a5a3c',
  teal: '#4f8a8b', mustard: '#d6a23a', terra: '#c0583a', brick: '#a65a46',
  green: '#4d6b54', paper: '#efe6d2', cloth: '#7b5ea7', dark: '#2f3a4a',
};
export const FONT = '"Noto Sans Bengali","Noto Serif Bengali","Noto Sans",sans-serif';

let gm = null;
export function gradient() {
  if (!gm) {
    gm = new THREE.DataTexture(new Uint8Array([90, 170, 255]), 3, 1, THREE.RedFormat);
    gm.minFilter = THREE.NearestFilter;
    gm.magFilter = THREE.NearestFilter;
    gm.needsUpdate = true;
  }
  return gm;
}

export const Toon = ({color}) => <meshToonMaterial color={color} gradientMap={gradient()} />;
const Ink = () => <meshBasicMaterial color={INK} side={THREE.BackSide} />;

// Box with 3-band toon shading and an inverted-hull ink outline.
export function Box({p = [0, 0, 0], s = [1, 1, 1], c = C.wall, r = [0, 0, 0], o = 0.05, ink = true, cast = true}) {
  return (
    <group position={p} rotation={r}>
      <mesh castShadow={cast} receiveShadow>
        <boxGeometry args={s} />
        <Toon color={c} />
      </mesh>
      {ink && (
        <mesh>
          <boxGeometry args={[s[0] + o, s[1] + o, s[2] + o]} />
          <Ink />
        </mesh>
      )}
    </group>
  );
}

export function Cyl({p = [0, 0, 0], rt = 0.5, rb = 0.5, h = 1, c = C.wall, r = [0, 0, 0], o = 0.05, seg = 24}) {
  return (
    <group position={p} rotation={r}>
      <mesh castShadow receiveShadow>
        <cylinderGeometry args={[rt, rb, h, seg]} />
        <Toon color={c} />
      </mesh>
      <mesh>
        <cylinderGeometry args={[rt + o / 2, rb + o / 2, h + o, seg]} />
        <Ink />
      </mesh>
    </group>
  );
}

export function Ball({p = [0, 0, 0], rad = 0.5, c = C.green, o = 0.07}) {
  return (
    <group position={p}>
      <mesh castShadow receiveShadow>
        <sphereGeometry args={[rad, 24, 18]} />
        <Toon color={c} />
      </mesh>
      <mesh>
        <sphereGeometry args={[rad + o, 24, 18]} />
        <Ink />
      </mesh>
    </group>
  );
}

// Wall in local space: x centred (-w/2..w/2), y 0..h. Optional rectangular hole (window) with a wooden frame.
export function Wall({p = [0, 0, 0], ry = 0, w = 10, h = 3.6, t = 0.14, hole = null, c = C.wall}) {
  const parts = [];
  const add = (x0, x1, y0, y1) => {
    if (x1 - x0 > 0.001 && y1 - y0 > 0.001) parts.push({x: (x0 + x1) / 2, y: (y0 + y1) / 2, sx: x1 - x0, sy: y1 - y0});
  };
  if (hole) {
    add(-w / 2, hole.x0, 0, h);
    add(hole.x1, w / 2, 0, h);
    add(hole.x0, hole.x1, 0, hole.y0);
    add(hole.x0, hole.x1, hole.y1, h);
  } else {
    add(-w / 2, w / 2, 0, h);
  }
  const f = 0.1;
  return (
    <group position={p} rotation={[0, ry, 0]}>
      {parts.map((q, i) => (
        <Box key={i} p={[q.x, q.y, 0]} s={[q.sx, q.sy, t]} c={c} o={0.04} />
      ))}
      {hole && (
        <>
          <Box p={[(hole.x0 + hole.x1) / 2, hole.y0, 0]} s={[hole.x1 - hole.x0 + f, f, t + 0.1]} c={C.wood} o={0.03} />
          <Box p={[(hole.x0 + hole.x1) / 2, hole.y1, 0]} s={[hole.x1 - hole.x0 + f, f, t + 0.1]} c={C.wood} o={0.03} />
          <Box p={[hole.x0, (hole.y0 + hole.y1) / 2, 0]} s={[f, hole.y1 - hole.y0, t + 0.1]} c={C.wood} o={0.03} />
          <Box p={[hole.x1, (hole.y0 + hole.y1) / 2, 0]} s={[f, hole.y1 - hole.y0, t + 0.1]} c={C.wood} o={0.03} />
        </>
      )}
    </group>
  );
}

export function useTex(w, h, draw) {
  return useMemo(() => {
    const cv = document.createElement('canvas');
    cv.width = w;
    cv.height = h;
    draw(cv.getContext('2d'), w, h);
    const t = new THREE.CanvasTexture(cv);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, []);
}

// In-world label: textured plane placed on a wall, sign or object.
export function Label({p, size, tex, r = [0, 0, 0]}) {
  return (
    <mesh position={p} rotation={r}>
      <planeGeometry args={size} />
      <meshBasicMaterial map={tex} toneMapped={false} />
    </mesh>
  );
}

// Directional key light whose target is moved next to the active location.
export function Key({X = 0, color = '#ffe2b0', intensity = 2.2, shadows = true, pos = [-8, 14, 9]}) {
  const ref = useRef();
  useLayoutEffect(() => {
    if (ref.current) {
      ref.current.target.position.set(X, 0, 0);
      ref.current.target.updateMatrixWorld();
    }
  });
  return (
    <directionalLight
      ref={ref}
      position={[X + pos[0], pos[1], pos[2]]}
      color={color}
      intensity={intensity}
      castShadow={shadows}
      shadow-mapSize={[1024, 1024]}
      shadow-camera-left={-13}
      shadow-camera-right={13}
      shadow-camera-top={13}
      shadow-camera-bottom={-13}
      shadow-camera-near={1}
      shadow-camera-far={60}
      shadow-bias={-0.0005}
    />
  );
}

// Smooth monotone time-warp (zero speed at first and last key).
export function warpU(T, t) {
  const n = T.length;
  if (t <= T[0]) return 0;
  if (t >= T[n - 1]) return 1;
  const sec = [];
  for (let i = 0; i < n - 1; i++) sec.push(1 / (n - 1) / (T[i + 1] - T[i]));
  const m = [0];
  for (let i = 1; i < n - 1; i++) m.push((2 * sec[i - 1] * sec[i]) / (sec[i - 1] + sec[i]));
  m.push(0);
  let i = 0;
  while (t > T[i + 1]) i++;
  const h = T[i + 1] - T[i];
  const x = (t - T[i]) / h;
  const x2 = x * x;
  const x3 = x2 * x;
  return (
    (2 * x3 - 3 * x2 + 1) * (i / (n - 1)) +
    (x3 - 2 * x2 + x) * h * m[i] +
    (-2 * x3 + 3 * x2) * ((i + 1) / (n - 1)) +
    (x3 - x2) * h * m[i + 1]
  );
}

export function pathAt(keys, u) {
  const n = keys.length;
  if (n === 1) return keys[0];
  const x = Math.min(Math.max(u, 0), 1) * (n - 1);
  const i = Math.min(Math.floor(x), n - 2);
  const f = x - i;
  return keys[i].map((v, k) => v + (keys[i + 1][k] - v) * f);
}

export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const mixColor = (a, b, t) => '#' + new THREE.Color(a).lerp(new THREE.Color(b), clamp(t, 0, 1)).getHexString();
