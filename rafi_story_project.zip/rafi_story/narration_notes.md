# Narration Notes (Mode A)
- Source of truth: story.srt (27 cues) + voiceover.mp3 (77.79s, mono, 44.1kHz). No word changed, added or removed.
- SRT ends 77.680s; audio 77.793s (~0.11s difference, normal).
- Pauses: 17.30-18.08, 67.60-68.20, 71.50-72.194; 0.695s silence at start.
- Cues break mid-sentence, so shots are cut on sentence boundaries.
- sentence_times.json is provisional (interpolated by character position inside each cue). Waveform check still pending.
