#!/usr/bin/env bash
# Usage: scripts/render.sh test|full [shots]
#   shots: "all" (render only missing shots, resume), "force" (re-render everything), or "1,3,5" (re-render those shots)
set -euo pipefail
MODE="${1:-test}"
SHOTS="${2:-all}"
GL="${GL:-swangle}"
CONC="${CONC:-$(nproc)}"
SHADOWS="${SHADOWS:-true}"
PROPS="{\"shadows\":${SHADOWS},\"subtitles\":true}"
ENTRY=src/index.jsx
COMMON=(--gl="$GL" --concurrency="$CONC" --timeout=240000 --props="$PROPS")
mkdir -p out/shots out/stills

if [ "$MODE" = "test" ]; then
  echo "== TEST: one still per shot + first 5 seconds (150 frames)"
  while read -r n a b mid; do
    printf -v nn "%02d" "$n"
    npx remotion still "$ENTRY" Story "out/stills/shot${nn}.png" --frame="$mid" "${COMMON[@]}"
  done < <(node scripts/shots.mjs)
  ffmpeg -y -loglevel error -framerate 1 -i out/stills/shot%02d.png -vf "scale=270:-1,tile=6x2" -frames:v 1 out/contact_sheet.png || true
  time npx remotion render "$ENTRY" Story out/test_5s.mp4 --frames=0-149 --codec=h264 --muted "${COMMON[@]}"
  ffprobe -v error -show_entries stream=codec_name,width,height,r_frame_rate,nb_frames -of default=nw=1 out/test_5s.mp4
  exit 0
fi

echo "== FULL render, shots=$SHOTS"
want() { # $1 = shot number
  case "$SHOTS" in
    force) return 0 ;;
    all) [ ! -s "out/shots/shot$(printf %02d "$1").mp4" ] ;;
    *) echo ",$SHOTS," | grep -q ",$1," ;;
  esac
}
while read -r n a b mid; do
  printf -v nn "%02d" "$n"
  if want "$n"; then
    echo "-- rendering shot $n (frames $a-$b)"
    npx remotion render "$ENTRY" Story "out/shots/shot${nn}.mp4" --frames="$a-$b" --codec=h264 --crf=18 --pixel-format=yuv420p --muted "${COMMON[@]}"
  else
    echo "-- keeping existing shot $n"
  fi
done < <(node scripts/shots.mjs)

: > out/concat.txt
for f in out/shots/shot*.mp4; do echo "file '$(pwd)/$f'" >> out/concat.txt; done
ffmpeg -y -loglevel error -f concat -safe 0 -i out/concat.txt -c copy out/video_silent.mp4
ffmpeg -y -loglevel error -i out/video_silent.mp4 -i public/voiceover.mp3 -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -movflags +faststart out/final_video.mp4

echo "== QC (ffprobe)"
ffprobe -v error -show_entries stream=codec_type,codec_name,width,height,r_frame_rate,duration -of default=nw=1 out/final_video.mp4 | tee out/qc.txt
ffmpeg -y -loglevel error -i out/final_video.mp4 -vf "fps=1/6.5,scale=270:-1,tile=6x2" -frames:v 1 out/final_contact_sheet.png || true
grep -q "codec_type=audio" out/qc.txt || { echo "ERROR: no audio stream"; exit 1; }
grep -q "width=1080" out/qc.txt && grep -q "height=1920" out/qc.txt || { echo "ERROR: wrong resolution"; exit 1; }
echo "OK: out/final_video.mp4"
