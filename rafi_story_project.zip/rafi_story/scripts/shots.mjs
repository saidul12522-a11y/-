// Prints "shot start_frame end_frame mid_frame" for each shot, derived from src/data.js (BOUNDS).
import {readFileSync} from 'node:fs';
const src = readFileSync(new URL('../src/data.js', import.meta.url), 'utf8');
const B = JSON.parse(src.match(/BOUNDS = (\[.*?\]);/)[1]);
const FPS = Number(src.match(/FPS = (\d+)/)[1]);
const TOTAL = Number(src.match(/TOTAL_FRAMES = (\d+)/)[1]);
for (let i = 0; i < B.length - 1; i++) {
  const a = Math.round(B[i] * FPS);
  const b = i === B.length - 2 ? TOTAL - 1 : Math.round(B[i + 1] * FPS) - 1;
  console.log(`${i + 1} ${a} ${b} ${Math.round((a + b) / 2)}`);
}
