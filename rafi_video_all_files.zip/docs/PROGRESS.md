# PROGRESS.md

## সম্পন্ন
- [x] ইনপুট ফাইল পরীক্ষা (SRT ২৭ cue, audio ৭৭.৭৯s, ref ৬৫s 720×1280)
- [x] Audio বিরতি শনাক্ত → বাক্য-শেষ সময় → SRT-র সঙ্গে মিল যাচাই (≤০.৫s)
- [x] শব্দ-ধরে-শব্দ caption সময় (আনুমানিক) — sentence_times.json
- [x] rulebook.md (ref-এর ১০ নমুনা frame ও cut শনাক্তকরণ ভিত্তিক)
- [x] scene_plan.md (১৩ shot) — অনুমোদনের অপেক্ষায়
- [x] GitHub Actions Compatibility Test কিট তৈরি (project.zip + test.yml)

## বাকি / অজানা
- [ ] **GitHub runner-এ Remotion + Three.js + বাংলা ফন্ট সত্যিই চলে কি না — এখনো টেস্ট হয়নি**
- [ ] CPU rendering-এর আসল গতি (সেকেন্ড/frame) — অজানা, টেস্টে মাপা হবে
- [ ] Scene plan অনুমোদন
- [ ] চরিত্র ও 3D কিট, Visual Test (Still + ৫s Motion Test) → অনুমোদন
- [ ] Full render (scene-by-scene), merge, audio sync, QC
- [ ] final_video.mp4 (এখনো তৈরি হয়নি; কোনো Download link নেই)
