# GitHub-এ টেস্ট চালানোর ধাপ (শুধু ফোন থেকে)

আপনার ফোনের Chrome-এ github.com খুলুন। মেনুতে (⋮) "Desktop site" চালু করলে সব বোতাম দেখা যায়।

## ১. Account ও Repository
1. github.com → Sign up (বিনামূল্যে)। ইমেইল যাচাই করুন।
2. ডানে উপরে **+** → **New repository** → নাম: `rafi-video` → Public বা Private (নিচে দেখুন) → **Create repository**।

**Public বনাম Private:** আমার জানা মতে Public repo-তে GitHub Actions-এর standard runner বিনামূল্যে ও সীমাহীন। Private-এ মাসে ২,০০০ মিনিটের সীমা। টেস্ট দুটোতেই চলবে। অসন্তুষ্ট হলে পরে বদলানো যায়, কিন্তু Public করলে ভিডিওর ফাইল ও audio যে কেউ দেখতে পাবে। এই সীমা আমি এখনো আমার দিক থেকে নিশ্চিত করিনি, তাই Full render-এর আগে আবার যাচাই করব।

## ২. ফাইল তোলা
1. Repository পাতায় **Add file → Upload files**।
2. `project.zip` এবং `test.yml`, দুটোই বেছে নিন (আমার দেওয়া ফাইল) → **Commit changes**।
3. এবার `test.yml` ফাইলটি খুলুন → পেন্সিল (✎ Edit) আইকন → ফাইলের নামের ঘরে নাম বদলে লিখুন:
   `.github/workflows/test.yml`
   (ঘরের শুরুতে `.github/workflows/` লিখলেই GitHub নিজে folder বানায়) → **Commit changes**।
   - এটা কাজ না করলে: **Add file → Create new file** → নাম `.github/workflows/test.yml` → `test.yml`-এর লেখা কপি করে বসান → Commit। এরপর root-এর `test.yml` মুছে দিন।

## ৩. টেস্ট চলবে
1. উপরের **Actions** ট্যাব → `compat-test` চলছে দেখাবে (হলুদ বৃত্ত)। সাধারণত কয়েক মিনিট লাগে।
2. সবুজ ✓ হলে সফল, লাল ✗ হলে ব্যর্থ। **দুই ক্ষেত্রেই** রানটি ট্যাপ করুন।
3. নিচে **Artifacts → compat-report** ট্যাপ করে ডাউনলোড করুন (zip)। ফাইল-অ্যাপে খুলে `report.txt` দেখুন।
4. `report.txt`-এর লেখা (বা screenshot) আর `still.png` ছবিটি আমাকে পাঠান। ব্যর্থ হলে `still.log` ও `render.log`-এর শেষ অংশও পাঠান।

## ৪. টেস্টে কী যাচাই হবে
- Remotion + Three.js GPU ছাড়া চলে কি না
- বাংলা ফন্ট ঠিকঠাক দেখায় কি না (still.png-তে "রাত দুইটা। নিঝুম গলি")
- CPU-তে প্রতি frame-এর সময় (এই সংখ্যা থেকে Full render কত সময়/মিনিট লাগবে তা ঠিক হবে)
