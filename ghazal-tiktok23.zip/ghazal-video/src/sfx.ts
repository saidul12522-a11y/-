// SFX plan — every event time comes from the SRT-derived word timings.
// Voiceover always dominates: SFX volumes stay low (-14 dB or quieter relative to the vocal).
import {SCENES, cue, tw, twFrom} from './timeline';
import {FPS} from './timeline';

export type SfxEvent = {t: number; file: string; vol: number};
export const SFX_DUR: Record<string, number> = {
  'whoosh-soft': 0.95, sweep: 1.5, pop: 0.2, click: 0.08, shimmer: 1.7, drop: 0.28, thud: 0.7, ambient: 13,
};

const ev: SfxEvent[] = [];
const add = (t: number, file: string, vol: number) => ev.push({t, file, vol});

// scene transitions (soft sweep, lands slightly before the cut)
SCENES.forEach((s, i) => {
  if (i === 0) return add(0.05, 'whoosh-soft', 0.32);
  add(s.from / FPS - 0.1, s.id === 'interlude' ? 'sweep' : 'whoosh-soft', 0.28);
});

// 1 hook
add(tw('রব্বুল', 0), 'pop', 0.3); add(tw('আলামীন', 0), 'pop', 0.3); add(2.0, 'shimmer', 0.2);
add(tw('রব্বুল', 1), 'pop', 0.32); add(tw('আলামীন', 1), 'pop', 0.32); add(tw('রব্বুল', 1) - 0.05, 'shimmer', 0.22);
// 2 scroll
add(tw('স্ক্রলের'), 'pop', 0.28); add(tw('পাপের') + 0.52, 'thud', 0.42); add(tw('পাপের'), 'pop', 0.26);
// 3 dua
add(tw('মাফ', 0), 'pop', 0.3);
[26, 40, 56].forEach((fr) => add(tw('কেঁদে') + fr / FPS, 'drop', 0.3));
// 4 likes
add(tw('ফলোয়ার'), 'pop', 0.26); add(tw('লাইকের'), 'pop', 0.26); add(tw('পেলে') - 0.1, 'shimmer', 0.24); add(tw('পেলে'), 'pop', 0.3);
// 5 fajr
add(tw('আল্লাহর'), 'pop', 0.28); add(tw('আল্লাহর') + 0.2, 'shimmer', 0.22);
add(tw('ফজরের'), 'pop', 0.28); add(tw('আযান'), 'shimmer', 0.24); add(tw('ঘুম'), 'pop', 0.28);
add(tw('অ্যালার্ম'), 'click', 0.35); add(tw('বন্ধ'), 'click', 0.4); add(tw('ওজু'), 'pop', 0.3);
for (let k = 0; k < 8; k++) add(tw('ওজু') + 38 / FPS + k * 0.3, 'drop', 0.2 + (k % 3) * 0.04);
// 6 gaze
add(tw('ভিডিওর'), 'pop', 0.26); add(tw('চোখের'), 'pop', 0.26); add(tw('দৃষ্টি'), 'click', 0.4);
add(tw('লজ্জা'), 'pop', 0.28); add(tw('মুখ'), 'shimmer', 0.26);
// 7 interlude
add(cue(16).start, 'ambient', 0.3); add(cue(16).start + 1.2, 'shimmer', 0.2); add(cue(16).start + 6.5, 'shimmer', 0.18);
// 8 ikhlas
add(tw('ভাইরাল'), 'pop', 0.26); add(tw('নিয়ত'), 'pop', 0.26); add(tw('ইখলাস') - 0.05, 'shimmer', 0.28); add(tw('ইখলাস'), 'pop', 0.3);
for (let k = 0; k < 6; k++) add(tw('ছড়াও') + (k * 9 + 12) / FPS, 'click', 0.3);
add(tw('ভালো'), 'pop', 0.28);
// 9 dawah
add(tw('দাওয়াতের'), 'pop', 0.28); add(tw('হাত', 1), 'pop', 0.3);
// 10 battery
add(tw('ফোনের', 1), 'pop', 0.26); add(tw('দৌড়ে'), 'click', 0.4); add(tw('দৌড়ে') + 0.1, 'shimmer', 0.2);
add(tw('ঈমানের'), 'pop', 0.28); add(tw('ভরো'), 'shimmer', 0.28); add(tw('জিকির'), 'pop', 0.3);
// 11 sujood
add(tw('গুনাহগার'), 'pop', 0.28); add(tw('ক্ষমা'), 'pop', 0.28); add(tw('স্ক্রিন'), 'click', 0.4);
add(tw('সিজদায়'), 'pop', 0.3); add(tw('সিজদায়') + 0.1, 'shimmer', 0.2);
// 12 time
add(tw('তওবা', 0), 'pop', 0.3); add(tw('মন'), 'shimmer', 0.22); add(tw('সময়'), 'pop', 0.28);
// 13 arsh
add(tw('মালিকের'), 'pop', 0.26); add(tw('আরশ'), 'shimmer', 0.3); add(tw('ঠাঁই'), 'pop', 0.3);
// 14 mafi
add(tw('মাফ', 1), 'pop', 0.32); add(tw('মাফ', 1) + 0.3, 'drop', 0.3); add(tw('মাফ', 2), 'pop', 0.34); add(tw('ওগো'), 'shimmer', 0.26);
// 15 close
add(tw('তওবা', 1), 'pop', 0.28); add(tw('কবুল'), 'shimmer', 0.3); add(tw('মোর'), 'pop', 0.3);

export const SFX_EVENTS = ev.sort((a, b) => a.t - b.t);
