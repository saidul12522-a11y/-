import React from 'react';
import {Composition} from 'remotion';
import {Main} from './Main';
import {TOTAL_FRAMES} from './timeline';
import {VIDEO} from './theme';
import {loadFonts} from './fonts';

loadFonts();

export const Root: React.FC = () => (
  <Composition id="Main" component={Main} durationInFrames={TOTAL_FRAMES} fps={VIDEO.fps} width={VIDEO.width} height={VIDEO.height} />
);
