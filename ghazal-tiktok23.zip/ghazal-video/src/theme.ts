// theme.ts — single source of truth: colors, fonts, easing, springs, layout.
// Palette: 02 Midnight Islamic Blue (user-chosen, light layout).
import {Easing} from 'remotion';

const rgb = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
export const mix = (a: string, b: string, t: number) => {
  const A = rgb(a);
  const B = rgb(b);
  return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * t).toString(16).padStart(2, '0')).join('');
};
export const alpha = (hex: string, a: number) => {
  const [r, g, b] = rgb(hex);
  return `rgba(${r},${g},${b},${a})`;
};

const base = {bg: '#F5F2E9', hero: '#173D68', accent: '#D9B76E', text: '#08172D'};

export const theme = {
  name: 'Midnight Islamic Blue — Light',
  colors: {
    ...base,
    // tints derived ONLY from the four user colors
    bgDeep: mix(base.bg, base.accent, 0.24),
    accentPale: mix(base.accent, base.bg, 0.55),
    accentDeep: mix(base.accent, base.text, 0.38),
    heroLight: mix(base.hero, base.bg, 0.3),
    heroMist: mix(base.hero, base.bg, 0.66),
    nightSoft: mix(base.text, base.hero, 0.42),
    nightMid: mix(base.text, base.hero, 0.74),
  },
  fonts: {
    display: '"Hind Siliguri", "Noto Sans Bengali", sans-serif',
    body: '"Hind Siliguri", "Noto Sans Bengali", sans-serif',
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    soft: Easing.bezier(0.45, 0, 0.2, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  // Gentle, non-bouncy springs (Islamic cinematic — no cartoon bounce)
  spring: {
    smooth: {damping: 22, stiffness: 80, mass: 1.1},
    word: {damping: 20, stiffness: 120, mass: 0.8},
    slow: {damping: 30, stiffness: 50, mass: 1.4},
  },
  shadow: {
    textOnNight: '0 2px 28px rgba(8,23,45,0.6)',
    glowGold: '0 0 40px rgba(217,183,110,0.55)',
  },
  type: {
    kinetic: {weight: 700, size: 112},
    caption: {weight: 600, size: 58},
  },
  anim: {
    transitionFrames: 14, // scene cross-dissolve overlap
    exitFrames: 10,
    kineticStagger: 5,
  },
} as const;

export const VIDEO = {width: 1920, height: 1080, fps: 30} as const;

// Arch-shaped "stage" window (mihrab) — every scene lives inside it.
export const STAGE = {x: 260, y: 44, w: 1400, h: 800} as const;
export const CAPTION = {cx: 960, y: 938} as const;
