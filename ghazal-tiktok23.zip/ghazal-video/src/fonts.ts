// Offline fonts: files live in public/fonts (no network needed).
import {continueRender, delayRender, staticFile} from 'remotion';

const BN =
  'U+0951-0952,U+0964-0965,U+0980-09FE,U+1CD0,U+1CD2,U+1CD5-1CD6,U+1CD8,U+1CE1,U+1CEA,U+1CED,U+1CF2,U+1CF5-1CF7,U+200C-200D,U+20B9,U+25CC,U+A8F1';
const LATIN =
  'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD';

const faces = [
  ...[500, 600, 700].map((w) => ({family: 'Hind Siliguri', file: `hind-siliguri-bengali-${w}-normal.woff2`, weight: String(w), range: BN})),
  ...[500, 700].map((w) => ({family: 'Hind Siliguri', file: `hind-siliguri-latin-${w}-normal.woff2`, weight: String(w), range: LATIN})),
  ...[500, 700, 800].map((w) => ({family: 'Noto Sans Bengali', file: `noto-sans-bengali-bengali-${w}-normal.woff2`, weight: String(w), range: BN})),
];

export const loadFonts = () => {
  if (typeof document === 'undefined') return;
  const handle = delayRender('Loading offline Bengali fonts');
  Promise.all(
    faces.map(async (f) => {
      const face = new FontFace(f.family, `url(${staticFile('fonts/' + f.file)}) format('woff2')`, {
        weight: f.weight,
        unicodeRange: f.range,
      });
      await face.load();
      (document.fonts as unknown as {add: (f: FontFace) => void}).add(face);
    }),
  )
    .then(() => continueRender(handle))
    .catch((e) => {
      console.error('Font load failed', e);
      continueRender(handle);
    });
};
