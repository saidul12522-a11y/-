// timeline.ts — everything is derived from the SRT cues (single timing source).
import {CUES} from './data/cues.generated';
import {VIDEO} from './theme';

export const FPS = VIDEO.fps;
export const sec2f = (s: number) => Math.round(s * FPS);
export const cue = (n: number) => CUES[n - 1];

// English words in the SRT are shown in Bengali script on screen.
const TRANSLIT: [RegExp, string][] = [
  [/Scroll/g, 'স্ক্রল'],
  [/Follower/g, 'ফলোয়ার'],
  [/Like/g, 'লাইক'],
  [/Viral/g, 'ভাইরাল'],
  [/Alarm/g, 'অ্যালার্ম'],
  [/Charge/g, 'চার্জ'],
  [/Battery/g, 'ব্যাটারি'],
  [/Screen/g, 'স্ক্রিন'],
];
const clean = (t: string) => {
  let s = t.replace(/\[[^\]]*\]/g, ' ');
  for (const [r, b] of TRANSLIT) s = s.replace(r, b);
  return s.replace(/\s+/g, ' ').trim();
};

export type Token = {text: string; start: number; end: number; cue: number};

// Word timing: proportional to word length inside each SRT cue window.
export const TOKENS: Token[] = CUES.flatMap((c) => {
  const words = clean(c.text).split(' ').filter(Boolean);
  if (!words.length) return [];
  const w = words.map((x) => [...x].length + 1);
  const sum = w.reduce((a, b) => a + b, 0);
  let t = c.start;
  return words.map((x, k) => {
    const d = ((c.end - c.start) * w[k]) / sum;
    const tok = {text: x, start: t, end: t + d, cue: c.i};
    t += d;
    return tok;
  });
});

const norm = (s: string) => s.replace(/[।,?!\-\s]/g, '');
/** start time (seconds) of the nth occurrence of a word in the lyrics */
export const tw = (word: string, nth = 0) => {
  const hits = TOKENS.filter((t) => norm(t.text) === norm(word));
  if (!hits[nth]) throw new Error(`timeline: word "${word}" (#${nth}) not found in SRT`);
  return hits[nth].start;
};
export const twEnd = (word: string, nth = 0) => {
  const hits = TOKENS.filter((t) => norm(t.text) === norm(word));
  if (!hits[nth]) throw new Error(`timeline: word "${word}" (#${nth}) not found in SRT`);
  return hits[nth].end;
};

/** first occurrence of a word at/after a given time (seconds) */
export const twFrom = (word: string, afterSec: number) => {
  const hit = TOKENS.find((t) => norm(t.text) === norm(word) && t.start >= afterSec - 0.001);
  if (!hit) throw new Error(`timeline: word "${word}" after ${afterSec}s not found`);
  return hit.start;
};

// ---- Caption pages (phrase groups) ----
export type Page = {tokens: Token[]; start: number; end: number; show: number; hide: number};
const MAX_WORDS = 6;
export const PAGES: Page[] = (() => {
  const phrases: Token[][] = [];
  let cur: Token[] = [];
  TOKENS.forEach((t) => {
    const prev = cur[cur.length - 1];
    if (prev && t.start - prev.end > 1.0 && cur.length > 2) {
      phrases.push(cur);
      cur = [];
    }
    cur.push(t);
    if (/[।,?!]$/.test(t.text)) {
      phrases.push(cur);
      cur = [];
    }
  });
  if (cur.length) phrases.push(cur);
  const pages: Page[] = [];
  phrases.forEach((p) => {
    const parts = Math.ceil(p.length / MAX_WORDS);
    const size = Math.ceil(p.length / parts);
    for (let i = 0; i < p.length; i += size) {
      const tk = p.slice(i, i + size);
      pages.push({tokens: tk, start: tk[0].start, end: tk[tk.length - 1].end, show: 0, hide: 0});
    }
  });
  pages.forEach((pg, i) => {
    const next = pages[i + 1];
    pg.show = Math.max(0, pg.start - 0.18);
    pg.hide = Math.min(pg.end + 0.35, next ? next.start - 0.18 : Infinity);
    if (pg.hide < pg.end) pg.hide = pg.end;
  });
  return pages;
})();

// ---- Scene plan (boundaries come from SRT words/cues) ----
export type SceneId =
  | 'hook' | 'scroll' | 'dua' | 'likes' | 'fajr' | 'gaze' | 'interlude' | 'ikhlas'
  | 'dawah' | 'battery' | 'sujood' | 'time' | 'arsh' | 'mafi' | 'close';

const starts: [SceneId, number][] = [
  ['hook', 0],
  ['scroll', tw('স্ক্রলের')],
  ['dua', tw('রবের')],
  ['likes', tw('ফলোয়ার')],
  ['fajr', tw('আল্লাহর')],
  ['gaze', tw('ভুল')],
  ['interlude', cue(16).start],
  ['ikhlas', cue(17).start],
  ['dawah', tw('দাওয়াতের')],
  ['battery', tw('ফোনের', 1)],
  ['sujood', tw('গুনাহগার')],
  ['time', cue(28).start],
  ['arsh', tw('মালিকের')],
  ['mafi', tw('মাফ', 1)],
  ['close', tw('তওবা', 1)],
];
export const END_SEC = cue(CUES.length).end + 4.3;
export const TOTAL_FRAMES = sec2f(END_SEC);

export type SceneDef = {id: SceneId; from: number; to: number; dur: number};
export const SCENES: SceneDef[] = starts.map(([id, s], i) => {
  const from = sec2f(s);
  const to = i + 1 < starts.length ? sec2f(starts[i + 1][1]) : TOTAL_FRAMES;
  return {id, from, to, dur: to - from};
});
export const sceneOf = (id: SceneId) => SCENES.find((s) => s.id === id)!;
