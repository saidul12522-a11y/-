import React from 'react';
import {alpha, mix, theme} from '../theme';
import {Camera, SvgStage, ramp, rng, useScene, useUid} from '../lib';
import {Glow, Motes, Rays, Rosette, Sky, Stars} from '../components/Art';
import {Lantern} from '../components/Silhouettes';
import {Kinetic} from '../components/Kinetic';
import {tw} from '../timeline';

const c = theme.colors;

/** Viral chase muddies the intention; ikhlas clears it to pure light; good words spread as lanterns of light. */
export const S08Ikhlas: React.FC = () => {
  const {f, local} = useScene();
  const id = useUid('orb');
  const tViral = local(tw('ভাইরাল'));
  const tMurk = local(tw('ঘোলা')) - 40;
  const tClear = local(tw('ইখলাস'));
  const tSpread = local(tw('ছড়াও'));
  const murk = ramp(f, tMurk, tMurk + 40) * (1 - ramp(f, tClear, tClear + 50));
  const pure = ramp(f, tClear, tClear + 50);
  const sparks = ramp(f, tViral, tViral + 20) * (1 - ramp(f, tViral + 60, tViral + 100));
  const r = rng(77);
  const blobs = Array.from({length: 7}, () => ({a: r() * 6.28, d: 20 + r() * 90, s: 60 + r() * 70, sp: 0.01 + r() * 0.02}));
  const lanterns = [[190, 330, 1.0], [380, 280, 0.9], [1020, 280, 0.9], [1210, 330, 1.0], [80, 450, 0.8], [1320, 450, 0.8]];
  return (
    <>
      <Camera zoom={[1, 1.07]}>
        <SvgStage>
          <Sky stops={[[0, c.text], [0.7, c.nightSoft], [1, c.hero]]} />
          <Stars n={70} seed={61} yMax={400} opacity={0.7} />
          <Glow cx={700} cy={470} r={520} opacity={0.14 + pure * 0.5} />
          <Rays cx={700} cy={470} count={13} length={560} spread={360} angle={180} opacity={pure * 0.26} width={70} />
          <defs>
            <radialGradient id={id} cx="0.4" cy="0.35" r="0.8">
              <stop offset="0" stopColor={mix(c.bg, c.accent, pure * 0.35)} stopOpacity={0.9} />
              <stop offset="1" stopColor={mix(c.heroLight, c.accent, pure)} stopOpacity={0.55 + pure * 0.35} />
            </radialGradient>
            <clipPath id={id + 'c'}><circle cx={700} cy={470} r={168} /></clipPath>
          </defs>
          <circle cx={700} cy={470} r={168} fill={`url(#${id})`} stroke={c.accent} strokeWidth={4} />
          <g clipPath={`url(#${id}c)`} opacity={murk}>
            {blobs.map((b, i) => (
              <ellipse key={i} cx={700 + Math.cos(b.a + f * b.sp) * b.d} cy={470 + Math.sin(b.a * 1.3 + f * b.sp) * b.d} rx={b.s} ry={b.s * 0.7} fill={mix(c.nightMid, c.accentDeep, 0.55)} opacity={0.85} />
            ))}
          </g>
          <Rosette cx={700} cy={470} r={116} draw={pure} rot={f * 0.35} layers={2} sw={3} color={c.text} />
          {/* "viral" sparks racing outward */}
          <g opacity={sparks}>
            {Array.from({length: 16}, (_, i) => {
              const a = (i / 16) * Math.PI * 2, d = 200 + ramp(f, tViral, tViral + 90, 0, 420);
              return <circle key={i} cx={700 + Math.cos(a) * d} cy={470 + Math.sin(a) * d * 0.7} r={5 + (i % 3) * 2} fill={c.accent} />;
            })}
          </g>
          {lanterns.map(([x, y, s], i) => (
            <Lantern key={i} x={x} y={y} s={s} lit={ramp(f, tSpread + i * 9, tSpread + i * 9 + 24)} />
          ))}
          <Motes n={36} seed={50} speed={0.4} opacity={0.7} />
        </SvgStage>
      </Camera>
      <Kinetic items={[
        {text: 'ভাইরাল হওয়ার শখ', wordAt: [tw('ভাইরাল'), tw('হওয়ার'), tw('শখে')], at: tw('ভাইরাল'), until: tw('নিয়ত') - 0.1, x: 700, y: 150, size: 100},
        {text: 'নিয়ত ঘোলা', wordAt: [tw('নিয়ত'), tw('ঘোলা')], at: tw('নিয়ত'), until: tw('ইখলাস') - 0.1, x: 700, y: 150, size: 108},
        {text: 'ইখলাস', at: tw('ইখলাস'), until: tw('ছড়াও') - 0.1, x: 700, y: 150, size: 128, gold: true, underline: true},
        {text: 'ভালো কথার আলো', wordAt: [tw('ভালো'), tw('কথার'), tw('আলো')], at: tw('ভালো'), x: 700, y: 150, size: 112, gold: true},
      ]} />
    </>
  );
};
