import React from 'react';
import type {SceneId} from '../timeline';
import type {Tone} from '../lib';
import {SvgStage} from '../lib';
import {Sky} from '../components/Art';
import {theme} from '../theme';
import {S01Hook} from './S01Hook';
import {S02Scroll} from './S02Scroll';
import {S03Dua} from './S03Dua';
import {S04Likes} from './S04Likes';
import {S05Fajr} from './S05Fajr';
import {S06Gaze} from './S06Gaze';
import {S07Interlude} from './S07Interlude';
import {S08Ikhlas} from './S08Ikhlas';
import {S09Dawah} from './S09Dawah';
import {S10Battery} from './S10Battery';
import {S11Sujood} from './S11Sujood';
import {S12Time} from './S12Time';
import {S13Arsh} from './S13Arsh';
import {S14Mafi} from './S14Mafi';
import {S15Close} from './S15Close';

const Placeholder: React.FC = () => (
  <SvgStage><Sky stops={[[0, theme.colors.text], [1, theme.colors.hero]]} /></SvgStage>
);

export const SCENE_REGISTRY: Record<SceneId, {Component: React.FC; tone: Tone}> = {
  hook: {Component: S01Hook, tone: 'night'},
  scroll: {Component: S02Scroll, tone: 'night'},
  dua: {Component: S03Dua, tone: 'night'},
  likes: {Component: S04Likes, tone: 'night'},
  fajr: {Component: S05Fajr, tone: 'night'},
  gaze: {Component: S06Gaze, tone: 'night'},
  interlude: {Component: S07Interlude, tone: 'night'},
  ikhlas: {Component: S08Ikhlas, tone: 'night'},
  dawah: {Component: S09Dawah, tone: 'night'},
  battery: {Component: S10Battery, tone: 'night'},
  sujood: {Component: S11Sujood, tone: 'night'},
  time: {Component: S12Time, tone: 'night'},
  arsh: {Component: S13Arsh, tone: 'night'},
  mafi: {Component: S14Mafi, tone: 'night'},
  close: {Component: S15Close, tone: 'dawn'},
};
