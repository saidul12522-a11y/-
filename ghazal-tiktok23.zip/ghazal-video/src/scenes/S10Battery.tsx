import React from 'react';
import {alpha, theme} from '../theme';
import {Camera, SvgStage, ramp, useScene} from '../lib';
import {Glow, Motes, Rosette, Sky, Stars} from '../components/Art';
import {Battery} from '../components/Silhouettes';
import {Kinetic} from '../components/Kinetic';
import {tw} from '../timeline';

const c = theme.colors;

/** Phone battery runs low and gets charged — then the battery of iman is filled with dhikr. */
export const S10Battery: React.FC = () => {
  const {f, local} = useScene();
  const tLow = local(tw('কমলে'));
  const tRun = local(tw('দৌড়ে'));
  const tIman = local(tw('ঈমানের'));
  const tFill = local(tw('ভরো'));
  const tZikr = local(tw('জিকির'));
  const phone = f < tIman;
  const fill = f < tRun ? ramp(f, 0, tLow + 30, 0.8, 0.1, theme.ease.soft)
    : f < tIman ? ramp(f, tRun, tRun + 40, 0.1, 1)
    : f < tFill ? ramp(f, tIman, tIman + 24, 1, 0.12, theme.ease.in)
    : ramp(f, tFill, tZikr + 110, 0.12, 1, theme.ease.soft);
  const blink = f >= tLow && f < tRun ? 0.55 + 0.45 * Math.sin(f / 3) : 1;
  const grow = ramp(f, tIman, tIman + 30, 1, 1.35, theme.ease.inOut);
  const imanMode = f >= tIman;
  const beads = Array.from({length: 24}, (_, i) => (i / 24) * Math.PI * 2);
  const zk = ramp(f, tZikr, tZikr + 30);
  const act = Math.floor(ramp(f, tZikr, tZikr + 150, 0, 24, theme.ease.soft));
  return (
    <>
      <Camera zoom={[1, 1.06]}>
        <SvgStage>
          <Sky stops={[[0, c.text], [1, c.nightSoft]]} />
          <Stars n={50} seed={90} yMax={360} opacity={0.6} />
          <Glow cx={700} cy={470} r={560} opacity={imanMode ? 0.15 + fill * 0.45 : 0.16} color={imanMode ? c.accent : c.heroMist} />
          {imanMode && <Rosette cx={700} cy={470} r={290} draw={ramp(f, tIman, tIman + 60)} rot={f * 0.15} layers={3} sw={2} color={alpha(c.accent, 0.7)} />}
          <g opacity={blink}>
            <Battery x={700} y={470} s={grow} fill={fill} color={c.bg} fillColor={imanMode ? c.accent : c.heroLight} mark={imanMode} pulse={Math.sin(f / 10) * 0.5 + 0.5} />
          </g>
          {phone && f >= tRun && f < tRun + 60 && (
            <g transform="translate(700,470) scale(1.4)" opacity={ramp(f, tRun, tRun + 8) * (1 - ramp(f, tRun + 40, tRun + 58))}>
              <path d="M 14 -60 L -34 8 L -4 8 L -18 60 L 36 -18 L 6 -18 Z" fill={c.accent} stroke={c.text} strokeWidth={3} strokeLinejoin="round" />
            </g>
          )}
          {/* dhikr ring (beads) */}
          <g opacity={zk}>
            {beads.map((a, i) => {
              const lit = i < act;
              const x = 700 + Math.cos(a - Math.PI / 2 + f * 0.004) * 330, y = 470 + Math.sin(a - Math.PI / 2 + f * 0.004) * 190;
              return <circle key={i} cx={x} cy={y} r={lit ? 11 : 8} fill={lit ? c.accent : alpha(c.bg, 0.4)} />;
            })}
          </g>
          <Motes n={30} seed={41} speed={0.4} opacity={0.6} />
        </SvgStage>
      </Camera>
      <Kinetic items={[
        {text: 'ফোনের চার্জ', wordAt: [tw('ফোনের', 1), tw('চার্জ', 0)], at: tw('ফোনের', 1), until: tw('দৌড়ে') - 0.1, x: 700, y: 150, size: 108},
        {text: 'দৌড়ে চার্জ দাও', wordAt: [tw('দৌড়ে'), tw('চার্জ', 1), tw('দাও')], at: tw('দৌড়ে'), until: tw('ঈমানের') - 0.1, x: 700, y: 150, size: 108},
        {text: 'ঈমানের ব্যাটারি', wordAt: [tw('ঈমানের'), tw('ব্যাটারি')], at: tw('ঈমানের'), until: tw('জিকির') - 0.1, x: 700, y: 150, size: 112, gold: true},
        {text: 'জিকির', at: tw('জিকির'), x: 700, y: 150, size: 128, gold: true, underline: true},
      ]} />
    </>
  );
};
