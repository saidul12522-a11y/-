import React, {useMemo} from 'react';
import {theme} from '../theme';
import {Camera, SW, SvgStage, ramp, rng, useScene} from '../lib';
import {Glow, Heart, Motes, Sky} from '../components/Art';
import {Kinetic} from '../components/Kinetic';
import {tw} from '../timeline';

const c = theme.colors;

/** Chasing likes & followers — everything dissolves to dust at "পেলে কি বলো?" */
export const S04Likes: React.FC = () => {
  const {f, local} = useScene();
  const burst = local(tw('পেলে'));
  const hearts = useMemo(() => {
    const r = rng(33);
    return Array.from({length: 26}, () => ({x: 120 + r() * (SW - 240), y0: 780 + r() * 360, s: 0.8 + r() * 1.7, sp: 1.4 + r() * 2.2, rot: (r() - 0.5) * 40, ph: r() * 6}));
  }, []);
  const avatars = [0, 1, 2, 3, 4].map((i) => ({x: 330 + i * 185, delay: 10 + i * 8}));
  const fade = ramp(f, burst - 8, burst + 8, 1, 0, theme.ease.in);
  return (
    <>
      <Camera zoom={[1, 1.06]}>
        <SvgStage>
          <Sky stops={[[0, c.text], [1, c.nightSoft]]} />
          <Glow cx={700} cy={760} r={560} opacity={0.2 * fade} />
          {hearts.map((h, i) => {
            const y = h.y0 - f * h.sp * 2.1 - (f > burst ? (f - burst) * 3 : 0);
            return <Heart key={i} x={h.x + Math.sin(f / 30 + h.ph) * 24} y={y} s={h.s} rot={h.rot} color={c.accentDeep} opacity={0.75 * fade * ramp(f, i * 2, i * 2 + 10)} />;
          })}
          {avatars.map((a, i) => {
            const p = ramp(f, a.delay, a.delay + 22);
            return (
              <g key={i} transform={`translate(${a.x},${600 - (1 - p) * 40}) scale(${p})`} opacity={fade}>
                <circle r={46} fill={c.hero} stroke={c.accent} strokeWidth={3} />
                <circle cy={-10} r={14} fill={c.bg} />
                <path d="M -26 28 Q 0 -4 26 28 Z" fill={c.bg} />
              </g>
            );
          })}
          <Motes n={f > burst ? 70 : 20} seed={5} speed={f > burst ? 0.9 : 0.3} opacity={f > burst ? 0.9 : 0.4} />
        </SvgStage>
      </Camera>
      <Kinetic items={[
        {text: 'ফলোয়ার', at: tw('ফলোয়ার'), until: tw('পেলে') - 0.1, x: 440, y: 210, size: 96},
        {text: 'লাইক', at: tw('লাইকের'), until: tw('পেলে') - 0.1, x: 960, y: 210, size: 96, gold: true},
        {text: 'পেলে কি বলো?', at: tw('পেলে'), x: 700, y: 360, size: 124, gold: true, underline: true},
      ]} />
    </>
  );
};
