import React from 'react';
import {mix, theme} from '../theme';
import {Camera, SvgStage, ramp, useScene} from '../lib';
import {Glow, Motes, Rays, Sky, Stars} from '../components/Art';
import {DuaHands, Drop} from '../components/Silhouettes';
import {Kinetic} from '../components/Kinetic';
import {tw, twFrom} from '../timeline';

const c = theme.colors;

/** "মাফ করো, মাফ করো, ওগো দয়াময়" — hope: hands raised, tears turning into rising lights. */
export const S14Mafi: React.FC = () => {
  const {f, local} = useScene();
  const t1 = local(tw('মাফ', 1));
  const t2 = local(tw('মাফ', 2));
  const rise = ramp(f, 0, 50, 180, 0);
  const pulse = (t: number) => Math.max(0, 1 - Math.abs(f - t) / 18);
  const glow = 0.3 + pulse(t1) * 0.3 + pulse(t2) * 0.3 + ramp(f, local(tw('ওগো')), local(tw('ওগো')) + 60, 0, 0.25);
  return (
    <>
      <Camera zoom={[1, 1.07]} origin="50% 80%">
        <SvgStage>
          <Sky stops={[[0, c.text], [0.55, c.hero], [1, mix(c.hero, c.accent, 0.75)]]} />
          <Stars n={60} seed={39} yMax={330} opacity={0.6} />
          <Glow cx={700} cy={500} r={620} opacity={glow} />
          <Rays cx={700} cy={-40} count={9} length={860} spread={64} opacity={0.18 + glow * 0.3} width={110} />
          <g transform={`translate(0,${rise})`}><DuaHands x={700} y={500} s={1.3} /></g>
          {/* tears become rising lights */}
          {Array.from({length: 14}, (_, i) => {
            const t0 = i * 18;
            const cyc = ((f - t0) % 120 + 120) % 120;
            const p = cyc / 120;
            return <circle key={i} cx={700 + Math.sin(i * 2.1 + f / 40) * (80 + i * 14)} cy={460 - p * 460} r={3 + (i % 4)} fill={c.accent} opacity={Math.sin(p * Math.PI) * 0.95} />;
          })}
          <Drop x={700} y={ramp(f, t1 + 10, t1 + 44, 290, 450, theme.ease.in)} s={1.4} color={c.accent} opacity={ramp(f, t1 + 10, t1 + 14) * (1 - ramp(f, t1 + 44, t1 + 50))} />
          <Motes n={60} seed={71} speed={0.9} opacity={0.85} size={3} />
        </SvgStage>
      </Camera>
      <Kinetic items={[
        {text: 'মাফ করো', wordAt: [tw('মাফ', 1), twFrom('করো', tw('মাফ', 1))], at: tw('মাফ', 1), until: tw('মাফ', 2) - 0.12, x: 700, y: 160, size: 140, gold: true},
        {text: 'মাফ করো', wordAt: [tw('মাফ', 2), twFrom('করো', tw('মাফ', 2))], at: tw('মাফ', 2), until: tw('ওগো') - 0.12, x: 700, y: 160, size: 150, gold: true, underline: true},
        {text: 'ওগো দয়াময়', wordAt: [tw('ওগো'), tw('দয়াময়', 0)], at: tw('ওগো'), x: 700, y: 160, size: 126},
      ]} />
    </>
  );
};
