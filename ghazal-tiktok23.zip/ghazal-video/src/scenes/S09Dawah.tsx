import React from 'react';
import {mix, theme} from '../theme';
import {Camera, SvgStage, ramp, useScene} from '../lib';
import {Glow, Hills, Moon, Motes, Sky, Stars} from '../components/Art';
import {Figure} from '../components/Silhouettes';
import {Kinetic} from '../components/Kinetic';
import {tw} from '../timeline';

const c = theme.colors;

/** Walking the path of da'wah hand in hand. */
export const S09Dawah: React.FC = () => {
  const {f} = useScene();
  const xs = [250, 410, 570, 730, 890, 1050, 1210];
  const walk = f * 0.7;
  const ground = (x: number) => 640 - Math.sin((x + 400) / 220) * 26;
  return (
    <>
      <Camera zoom={[1, 1.06]} origin="50% 80%">
        <SvgStage>
          <Sky stops={[[0, c.text], [0.55, c.hero], [1, mix(c.hero, c.accent, 0.7)]]} />
          <Stars n={60} seed={72} yMax={330} opacity={0.65} />
          <Moon cx={1130} cy={210} r={36} />
          <Glow cx={700} cy={640} r={560} opacity={0.5} />
          <Hills y={600} amp={50} fill={c.nightMid} seed={7} />
          <Hills y={700} amp={34} fill={c.text} seed={12} freq={1.2} />
          {xs.slice(0, -1).map((x, i) => {
            const x1 = x + walk * 0 + 0, x2 = xs[i + 1];
            const p = ramp(f, 14 + i * 7, 34 + i * 7);
            return <line key={i} x1={x1 + 18} y1={ground(x1) - 54 * 2} x2={x2 - 18} y2={ground(x2) - 54 * 2} stroke={c.text} strokeWidth={6} strokeLinecap="round" opacity={p} />;
          })}
          {xs.map((x, i) => {
            const p = ramp(f, 8 + i * 7, 30 + i * 7);
            return (
              <g key={i} opacity={p} transform={`translate(0,${(1 - p) * 20})`}>
                <Figure x={x} y={ground(x)} s={2} color={c.text} walk={f / 4 + i} />
              </g>
            );
          })}
          <Motes n={30} seed={3} speed={0.5} opacity={0.7} />
        </SvgStage>
      </Camera>
      <Kinetic items={[
        {text: 'দাওয়াতের পথে', at: tw('দাওয়াতের'), until: tw('হাত', 1) - 0.1, x: 700, y: 150, size: 112, gold: true},
        {text: 'হাত ধরে', wordAt: [tw('হাত', 1), tw('ধরে', 1)], at: tw('হাত', 1), x: 700, y: 150, size: 124, gold: true, underline: true},
      ]} />
    </>
  );
};
