import React from 'react';
import {alpha, theme} from '../theme';
import {Camera, SvgStage, ramp, useScene} from '../lib';
import {Glow, Motes, Rosette, Sky} from '../components/Art';
import {Eye} from '../components/Silhouettes';
import {Kinetic} from '../components/Kinetic';
import {tw} from '../timeline';

const c = theme.colors;

/** The trap of the screen -> lowering the gaze -> modesty -> turning away into light. */
export const S06Gaze: React.FC = () => {
  const {f, local} = useScene();
  const tTrap = local(tw('ফাঁদে'));
  const tDrist = local(tw('দৃষ্টি'));
  const tShame = local(tw('লজ্জা'));
  const tTurn = local(tw('মুখ'));
  const web = ramp(f, tTrap - 8, tTrap + 20) * (1 - ramp(f, tDrist, tDrist + 14));
  const lid = ramp(f, tDrist + 6, tDrist + 36, 0, 0.88, theme.ease.inOut);
  const look = ramp(f, tDrist, tDrist + 30, 0, 26);
  const reflect = (0.6 + 0.4 * Math.sin(f / 9)) * (1 - ramp(f, tDrist, tDrist + 16));
  const lattice = ramp(f, tShame, tShame + 40);
  const turn = ramp(f, tTurn, tTurn + 50, 0, 1, theme.ease.inOut);
  const lines = Array.from({length: 24}, (_, i) => (i / 24) * Math.PI * 2);
  return (
    <>
      <Camera zoom={[1, 1.06]}>
        <SvgStage>
          <Sky stops={[[0, c.text], [1, c.nightSoft]]} />
          <Glow cx={700} cy={470} r={520} opacity={0.22 + lattice * 0.25} />
          {/* the trap: fine web converging on the eye */}
          <g opacity={web * 0.75} stroke={c.heroMist} strokeWidth={1.6} fill="none">
            {lines.map((a, i) => <line key={i} x1={700 + Math.cos(a) * 700} y1={470 + Math.sin(a) * 700} x2={700 + Math.cos(a) * 110} y2={470 + Math.sin(a) * 110} />)}
            {[160, 250, 350, 460].map((r) => <circle key={r} cx={700} cy={470} r={r * (1 + (1 - web) * 0.3)} opacity={0.6} />)}
          </g>
          {/* modesty lattice of light */}
          <g opacity={lattice}>
            {[[-1, 0], [1, 0], [0, -1], [0, 1], [-1, -1], [1, -1], [-1, 1], [1, 1]].map(([dx, dy], i) => (
              <Rosette key={i} cx={700 + dx * 380} cy={470 + dy * 230} r={70} draw={lattice} rot={f * 0.3 * (i % 2 ? 1 : -1)} layers={2} sw={2} color={alpha(c.accent, 0.8)} />
            ))}
          </g>
          <g transform={`translate(0,${-turn * 40}) scale(1)`} opacity={1 - turn * 0.9}>
            <Eye x={700} y={470} s={1.5 - turn * 0.5} lid={lid} look={look} reflect={reflect} />
          </g>
          <g opacity={turn}>
            <Rosette cx={700} cy={430} r={120} draw={turn} rot={f * 0.4} layers={3} sw={3} />
            <Glow cx={700} cy={430} r={380} opacity={0.5 * turn} />
          </g>
          <Motes n={26} seed={15} speed={0.35} opacity={0.6} />
        </SvgStage>
      </Camera>
      <Kinetic items={[
        {text: 'ভিডিওর ফাঁদ', at: tw('ভিডিওর'), until: tw('চোখের') - 0.15, x: 700, y: 160, size: 104},
        {text: 'চোখের গুনাহ', at: tw('চোখের'), until: tw('দৃষ্টি') - 0.15, x: 700, y: 160, size: 108, gold: true},
        {text: 'দৃষ্টি নামাও', at: tw('দৃষ্টি'), until: tw('লজ্জা') - 0.15, x: 700, y: 160, size: 112, gold: true, underline: true},
        {text: 'লজ্জা রাখো', at: tw('লজ্জা'), until: tw('মুখ') - 0.15, x: 700, y: 160, size: 112},
        {text: 'মুখ ফিরিয়ে', at: tw('মুখ'), x: 700, y: 160, size: 112, gold: true},
      ]} />
    </>
  );
};
