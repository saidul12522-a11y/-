import React from 'react';
import {alpha, mix, theme} from '../theme';
import {Camera, SvgStage, archPath, ramp, useScene} from '../lib';
import {Glow, Motes, Rays, Sky, Stars} from '../components/Art';
import {Phone, Sujood} from '../components/Silhouettes';
import {Kinetic} from '../components/Kinetic';
import {tw} from '../timeline';

const c = theme.colors;

/** A servant seeks forgiveness; the screen goes dark; forehead to the ground in sujood. */
export const S11Sujood: React.FC = () => {
  const {f, local} = useScene();
  const tServant = local(tw('গুনাহগার'));
  const tScreen = local(tw('স্ক্রিন'));
  const tSujood = local(tw('সিজদায়'));
  const appear = ramp(f, tServant + 6, tServant + 70);
  const on = 1 - ramp(f, tScreen, tScreen + 20);
  const phoneDrop = ramp(f, tScreen + 10, tScreen + 70, 0, 120, theme.ease.in);
  const light = ramp(f, tServant, tServant + 80, 0.2, 0.55) + ramp(f, tSujood, tSujood + 60, 0, 0.25);
  return (
    <>
      <Camera zoom={[1, 1.07]} origin="45% 80%">
        <SvgStage>
          <Sky stops={[[0, c.text], [0.7, c.nightSoft], [1, c.nightMid]]} />
          <Stars n={40} seed={12} yMax={300} opacity={0.5} />
          <Glow cx={620} cy={620} r={560} opacity={light} />
          <Rays cx={620} cy={-40} count={6} length={820} spread={26} opacity={light * 0.55} width={90} />
          {/* prayer rug with mihrab niche */}
          <path d="M 250 660 L 1010 660 L 1130 770 L 130 770 Z" fill={c.hero} stroke={c.accent} strokeWidth={4} />
          <path d="M 300 668 L 960 668 L 1050 762 L 210 762 Z" fill="none" stroke={alpha(c.accent, 0.7)} strokeWidth={2} />
          <g transform="translate(630,664) scale(0.34,0.17) translate(-700,-800)"><path d={archPath(1400, 800)} fill={alpha(c.accent, 0.18)} stroke={c.accent} strokeWidth={9} /></g>
          <Sujood x={330} y={736} s={1.3} appear={appear} rim={c.accent} />
          <g transform={`translate(1090,${300 + phoneDrop}) rotate(${14 + phoneDrop * 0.1})`} opacity={1 - ramp(f, tScreen + 40, tScreen + 80)}>
            <Phone x={0} y={0} s={0.5} on={on} scroll={f * 5 * on} />
          </g>
          <Motes n={30} seed={66} speed={0.35} opacity={0.65} />
        </SvgStage>
      </Camera>
      <Kinetic items={[
        {text: 'গুনাহগার বান্দা', wordAt: [tw('গুনাহগার'), tw('বান্দা')], at: tw('গুনাহগার'), until: tw('ক্ষমা') - 0.1, x: 700, y: 150, size: 108},
        {text: 'ক্ষমা চাই', wordAt: [tw('ক্ষমা'), tw('চাই')], at: tw('ক্ষমা'), until: tw('স্ক্রিন') - 0.1, x: 700, y: 150, size: 120, gold: true, underline: true},
        {text: 'স্ক্রিন বন্ধ', wordAt: [tw('স্ক্রিন'), tw('বন্ধ', 1)], at: tw('স্ক্রিন'), until: tw('সিজদায়') - 0.1, x: 700, y: 150, size: 112},
        {text: 'সিজদায় মাথা', wordAt: [tw('সিজদায়'), tw('মাথা')], at: tw('সিজদায়'), until: tw('তওবা', 0) - 0.1, x: 700, y: 150, size: 120, gold: true, underline: true},
      ]} />
    </>
  );
};
