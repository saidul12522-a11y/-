import React from 'react';
import {alpha, mix, theme} from '../theme';
import {Camera, SH, SW, SvgStage, archPath, ramp, useScene} from '../lib';
import {Glow, Motes, Rays, Rosette, Sky, Stars} from '../components/Art';

const c = theme.colors;

/** Instrumental interlude: a slow glide forward through nested mihrab arches into a blooming star of light. No text. */
export const S07Interlude: React.FC = () => {
  const {f, len} = useScene();
  const draw = ramp(f, 8, 150, 0, 1, theme.ease.inOut);
  const N = 7;
  const cycle = 150; // frames per arch life
  return (
    <>
      <Camera zoom={[1.0, 1.06]} origin="50% 55%">
        <SvgStage>
          <Sky stops={[[0, c.text], [0.55, c.hero], [1, mix(c.hero, c.accent, 0.65)]]} />
          <Stars n={60} seed={31} yMax={360} opacity={0.55} />
          <Glow cx={700} cy={430} r={700} opacity={0.5} />
          <Rays cx={700} cy={-20} count={11} length={820} spread={90} opacity={0.22} width={100} />
          {/* nested arches rushing toward the camera */}
          {Array.from({length: N}, (_, i) => {
            const ph = (((f / cycle + i / N) % 1) + 1) % 1;
            const sc = 0.12 + Math.pow(ph, 1.7) * 2.1;
            const op = Math.sin(Math.min(1, ph * 1.15) * Math.PI) * 0.95;
            return (
              <g key={i} transform={`translate(700,470) scale(${sc}) translate(-700,-440)`} opacity={op}>
                <path d={archPath(SW, SH)} fill={alpha(c.hero, 0.12)} stroke={c.accent} strokeWidth={3} vectorEffect="non-scaling-stroke" />
                <path d={archPath(SW, SH, 14)} fill="none" stroke={alpha(c.bg, 0.7)} strokeWidth={1.5} vectorEffect="non-scaling-stroke" />
              </g>
            );
          })}
          <Rosette cx={700} cy={400} r={150} draw={draw} rot={f * 0.2} layers={4} sw={2.6} />
          <Rosette cx={700} cy={400} r={90} draw={draw} rot={-f * 0.3} layers={2} sw={2.2} color={c.bg} />
          <circle cx={700} cy={400} r={14 + Math.sin(f / 18) * 2} fill={c.accent} opacity={draw} />
          <Motes n={54} seed={27} speed={0.5} opacity={0.85} size={3} />
          <rect width={SW} height={SH} fill={alpha(c.text, ramp(f, 0, 25, 0.5, 0) + ramp(f, len - 20, len, 0, 0.3))} />
        </SvgStage>
      </Camera>
    </>
  );
};
