import React from 'react';
import {mix, theme} from '../theme';
import {Camera, SvgStage, ramp, useScene} from '../lib';
import {Bird, Glow, Hills, Mosque, Motes, Rings, Rosette, Sky, Stars} from '../components/Art';
import {Alarm, Drop} from '../components/Silhouettes';
import {Kinetic} from '../components/Kinetic';
import {tw} from '../timeline';

const c = theme.colors;

/** Allah's love -> Fajr adhan -> waking up -> alarm off -> wudu. Night turns to dawn. */
export const S05Fajr: React.FC = () => {
  const {f, local} = useScene();
  const tFajr = local(tw('ফজরের'));
  const tAdhan = local(tw('আযান'));
  const tWake = local(tw('ঘুম'));
  const tAlarm = local(tw('অ্যালার্ম'));
  const tOff = local(tw('বন্ধ'));
  const tWudu = local(tw('ওজু'));
  const dawn = ramp(f, tFajr, tFajr + 110, 0, 1, theme.ease.inOut);
  const sunUp = ramp(f, tWake, tWake + 100, 0, 1, theme.ease.out);
  const mosque = ramp(f, tFajr, tFajr + 70, 0, 1);
  const roseOp = 1 - ramp(f, tFajr - 6, tFajr + 40);
  const alarmP = ramp(f, tAlarm, tAlarm + 16) * (1 - ramp(f, tOff + 16, tOff + 34));
  const off = ramp(f, tOff, tOff + 12);
  const drops = [0, 1, 2, 3, 4, 5];
  return (
    <>
      <Camera zoom={[1, 1.07]} origin="50% 75%">
        <SvgStage>
          <Sky stops={[[0, mix(c.text, c.hero, dawn * 0.5)], [0.62, mix(c.nightSoft, c.heroLight, dawn * 0.45)], [1, mix(c.hero, c.accent, dawn * 0.85)]]} />
          <Stars n={100} seed={44} yMax={420} opacity={1 - dawn * 0.85} />
          <Glow cx={1130} cy={ramp(f, tWake, tWake + 100, 800, 560)} r={380 + sunUp * 140} opacity={0.15 + sunUp * 0.6} />
          <circle cx={1130} cy={ramp(f, tWake, tWake + 100, 800, 560)} r={62} fill={c.accent} opacity={sunUp} />
          <g opacity={roseOp}>
            <Glow cx={700} cy={470} r={330} opacity={ramp(f, 0, 60, 0, 0.5)} />
            <Rosette cx={700} cy={470} r={125} draw={ramp(f, 4, 90)} rot={f * 0.25} layers={3} sw={3} />
          </g>
          <g transform={`translate(0,${(1 - mosque) * 100})`} opacity={mosque}>
            <Hills y={650} amp={40} fill={c.nightMid} seed={3} />
            <Mosque cx={700} base={700} s={0.95} fill={c.text} winOpacity={0.6 + dawn * 0.4} />
          </g>
          <Hills y={745} amp={26} fill={c.text} seed={8} freq={1.5} />
          <Rings cx={415} cy={318} start={tAdhan} n={4} gap={16} maxR={300} life={90} sw={2.5} />
          {sunUp > 0.2 && [0, 1, 2].map((i) => (
            <Bird key={i} x={ramp(f, tWake + i * 14, tWake + 200, 160 + i * 70, 1250 - i * 40, theme.ease.soft)} y={300 + i * 52 - ramp(f, tWake, tWake + 200, 0, 60)} s={0.8 - i * 0.12} phase={i * 1.6} />
          ))}
          <g opacity={alarmP}><Alarm x={1130} y={380} s={0.9} off={off} /></g>
          {f > tWudu && drops.map((i) => {
            const cyc = ((f - tWudu - i * 9) % 54 + 54) % 54;
            const p = cyc / 38;
            return p < 1 ? <Drop key={i} x={1130 + (i % 2 ? 12 : -12)} y={560 + p * p * 190} s={1.2} color={c.bg} opacity={ramp(f, tWudu, tWudu + 10)} /> : null;
          })}
          {f > tWudu && <Rings cx={1130} cy={754} start={tWudu + 30} n={5} gap={9} maxR={120} squash={0.22} color={c.bg} sw={2.5} life={44} />}
          <Motes n={30} seed={19} speed={0.4} opacity={0.6} />
        </SvgStage>
      </Camera>
      <Kinetic items={[
        {text: 'আল্লাহর ভালোবাসা', at: tw('আল্লাহর'), until: tw('ফজরের') - 0.25, x: 700, y: 190, size: 108, gold: true, underline: true},
        {text: 'ফজরের আযান', at: tw('ফজরের'), until: tw('ঘুম') - 0.2, x: 700, y: 190, size: 112},
        {text: 'ঘুম ভেঙে ওঠো', at: tw('ঘুম'), until: tw('অ্যালার্ম') - 0.2, x: 700, y: 190, size: 112, gold: true},
        {text: 'অ্যালার্ম বন্ধ', at: tw('অ্যালার্ম'), until: tw('ওজু') - 0.1, x: 700, y: 190, size: 112},
        {text: 'ওজু করো', at: tw('ওজু'), x: 700, y: 190, size: 120, gold: true, underline: true},
      ]} />
    </>
  );
};
