import React from 'react';
import {theme} from '../theme';
import {Camera, SvgStage, ramp, useScene} from '../lib';
import {Glow, Motes, Rays, Sky, Stars} from '../components/Art';
import {DuaHands, Drop} from '../components/Silhouettes';
import {Kinetic} from '../components/Kinetic';
import {tw} from '../timeline';

const c = theme.colors;

/** Dua: raised hands in silhouette, gold light descends, tears fall into the palms. */
export const S03Dua: React.FC = () => {
  const {f, local} = useScene();
  const rise = ramp(f, 0, 60, 230, 0, theme.ease.out);
  const t0 = local(tw('কেঁদে'));
  const drops = [0, 14, 30].map((d) => {
    const p = ramp(f, t0 + d, t0 + d + 26, 0, 1, theme.ease.in);
    return {p, y: -40 + p * 450, land: ramp(f, t0 + d + 26, t0 + d + 50, 1, 0)};
  });
  const bloom = drops.reduce((a, d) => a + (d.p >= 1 ? d.land * 0.35 : 0), 0.18);
  return (
    <>
      <Camera zoom={[1, 1.08]} origin="50% 75%">
        <SvgStage>
          <Sky stops={[[0, c.text], [0.6, c.nightSoft], [1, c.hero]]} />
          <Stars n={50} seed={8} yMax={300} opacity={0.6} />
          <Glow cx={700} cy={70} r={700} opacity={ramp(f, 10, 110, 0, 0.5)} />
          <Rays cx={700} cy={-60} count={7} length={820} spread={50} opacity={ramp(f, 10, 120, 0, 0.34)} width={120} />
          <Glow cx={700} cy={420 + rise} r={300} opacity={bloom} />
          <g transform={`translate(0,${rise})`}>
            <DuaHands x={700} y={480} s={1.2} />
          </g>
          {drops.map((d, i) => d.p > 0 && d.p < 1 && <Drop key={i} x={700 + (i - 1) * 16} y={d.y} s={1.4} color={c.accent} />)}
          <Motes n={36} seed={13} speed={0.5} opacity={0.8} />
        </SvgStage>
      </Camera>
      <Kinetic items={[
        {text: 'মাফ চেয়ে নাও', wordAt: [tw('মাফ', 0), tw('চেয়ে'), tw('নাও')], at: tw('মাফ', 0), x: 700, y: 175, size: 112, gold: true, underline: true},
      ]} />
    </>
  );
};
