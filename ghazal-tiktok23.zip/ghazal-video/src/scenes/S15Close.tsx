import React from 'react';
import {mix, theme} from '../theme';
import {Camera, SvgStage, ramp, useScene} from '../lib';
import {Glow, Hills, Mosque, Motes, Moon, Rosette, Sky, Stars} from '../components/Art';
import {Kinetic} from '../components/Kinetic';
import {tw, twFrom} from '../timeline';

const c = theme.colors;

/** Closing: "তওবা কবুল করো মোর দয়াময়" — a calm dawn of light, the star of geometry in full bloom. */
export const S15Close: React.FC = () => {
  const {f} = useScene();
  const dawn = ramp(f, 0, 130, 0, 1, theme.ease.inOut);
  const bloom = ramp(f, 10, 150);
  const top = mix(c.text, c.hero, 0.3 + dawn * 0.5);
  const mid = mix(c.hero, c.heroLight, dawn);
  const low = mix(c.nightSoft, c.accentPale, dawn);
  const hor = mix(c.hero, c.accent, 0.35 + dawn * 0.65);
  return (
    <>
      <Camera zoom={[1, 1.05]} origin="50% 80%">
        <SvgStage>
          <Sky stops={[[0, top], [0.45, mid], [0.8, low], [1, hor]]} />
          <Stars n={50} seed={33} yMax={300} opacity={1 - dawn * 0.8} />
          <Glow cx={700} cy={640} r={760} opacity={0.35 + dawn * 0.5} />
          <Rosette cx={700} cy={335} r={96} draw={bloom} rot={f * 0.18} layers={4} sw={3} color={c.bg} />
          <Rosette cx={700} cy={335} r={58} draw={bloom} rot={-f * 0.25} layers={2} sw={2.4} color={c.accent} />
          <Glow cx={700} cy={335} r={240} opacity={0.4 * bloom} color={c.accent} />
          <Moon cx={1150} cy={200} r={34} />
          <Hills y={665} amp={34} fill={mix(c.hero, c.heroLight, 0.4)} seed={4} />
          <Mosque cx={700} base={725} s={0.85} fill={c.text} windows={c.accent} winOpacity={0.95} />
          <Hills y={765} amp={20} fill={c.text} seed={9} freq={1.4} />
          <Motes n={44} seed={81} speed={0.45} opacity={0.9} size={3} />
        </SvgStage>
      </Camera>
      <Kinetic items={[
        {text: 'তওবা কবুল করো', wordAt: [tw('তওবা', 1), tw('কবুল'), twFrom('করো', tw('কবুল'))], at: tw('তওবা', 1), until: tw('মোর') - 0.1, x: 700, y: 150, size: 116, gold: true},
        {text: 'মোর দয়াময়', wordAt: [tw('মোর'), tw('দয়াময়', 1)], at: tw('মোর'), x: 700, y: 150, size: 130, gold: true, underline: true},
      ]} />
    </>
  );
};
