import React from 'react';
import {alpha, mix, theme} from '../theme';
import {Camera, SH, SW, SvgStage, archPath, ramp, useScene} from '../lib';
import {Glow, Motes, Rays, Rosette, Sky, Stars} from '../components/Art';
import {Figure} from '../components/Silhouettes';
import {Kinetic} from '../components/Kinetic';
import {tw} from '../timeline';

const c = theme.colors;

/** Shelter beneath the Throne — shown only as vast light and sacred geometry (no depiction). */
export const S13Arsh: React.FC = () => {
  const {f, local} = useScene();
  const tArsh = local(tw('আরশ'));
  const tPlace = local(tw('ঠাঁই'));
  const open = ramp(f, tArsh - 20, tArsh + 80, 0, 1, theme.ease.inOut);
  const shelter = ramp(f, tPlace, tPlace + 50);
  return (
    <>
      <Camera zoom={[1, 1.08]} origin="50% 85%">
        <SvgStage>
          <Sky stops={[[0, c.text], [0.5, c.nightSoft], [1, mix(c.hero, c.accent, 0.5)]]} />
          <Stars n={90} seed={17} yMax={420} opacity={0.7} />
          <Glow cx={700} cy={80} r={760} opacity={0.15 + open * 0.55} />
          <Rays cx={700} cy={20} count={13} length={760} spread={86} opacity={0.12 + open * 0.28} width={100} />
          {/* concentric mihrab arches opening above */}
          {[1, 0.8, 0.62, 0.46, 0.32].map((k, i) => {
            const p = ramp(f, i * 10, i * 10 + 60) * (0.9 - i * 0.1);
            return (
              <g key={i} transform={`translate(700,800) scale(${k * (0.9 + 0.1 * open)}) translate(-700,-800)`} opacity={p}>
                <path d={archPath(SW, SH)} fill={i % 2 ? alpha(c.accent, 0.06) : 'none'} stroke={i === 0 ? alpha(c.accent, 0.9) : c.accent} strokeWidth={2.4} vectorEffect="non-scaling-stroke" />
              </g>
            );
          })}
          <Rosette cx={700} cy={250} r={96} draw={open} rot={f * 0.25} layers={3} sw={2.6} />
          <Glow cx={700} cy={250} r={200} opacity={0.5 * open} />
          {/* the servant, sheltered */}
          <g opacity={ramp(f, tArsh, tArsh + 40)}>
            <Glow cx={700} cy={700} r={260} opacity={0.35 + shelter * 0.4} />
            <Figure x={700} y={730} s={1.7} color={c.text} />
          </g>
          <Motes n={44} seed={23} speed={0.55} opacity={0.85} />
        </SvgStage>
      </Camera>
      <Kinetic items={[
        {text: 'মালিকের আরশ তলে', wordAt: [tw('মালিকের'), tw('আরশ'), tw('তলে')], at: tw('মালিকের'), until: tw('ঠাঁই') - 0.1, x: 700, y: 150, size: 100},
        {text: 'পাবে ঠাঁই', wordAt: [tw('পাবে'), tw('ঠাঁই')], at: tw('পাবে'), x: 700, y: 150, size: 132, gold: true, underline: true},
      ]} />
    </>
  );
};
