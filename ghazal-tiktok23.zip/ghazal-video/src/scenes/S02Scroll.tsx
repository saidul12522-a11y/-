import React from 'react';
import {theme} from '../theme';
import {Camera, SvgStage, ramp, useScene} from '../lib';
import {Glow, Moon, Motes, Sky, Stars} from '../components/Art';
import {Phone} from '../components/Silhouettes';
import {Kinetic} from '../components/Kinetic';
import {tw} from '../timeline';

const c = theme.colors;

/** Late-night scrolling: phone glow, moon racing across the sky, then the weight of sin lands. */
export const S02Scroll: React.FC = () => {
  const {f, local, len} = useScene();
  const fall = local(tw('পাপের'));
  const land = fall + 16;
  const stoneY = f < fall ? -240 : ramp(f, fall, land, -240, 160, theme.ease.in);
  const impact = Math.max(0, 1 - Math.abs(f - land) / 10);
  const settled = ramp(f, land, land + 28, 0, 1);
  const on = 1 - settled * 0.7;
  const moonX = ramp(f, 0, len, 1250, 150, theme.ease.soft);
  return (
    <>
      <Camera zoom={[1.02, 1.08]} origin="40% 60%">
        <SvgStage>
          <Sky stops={[[0, c.text], [0.7, c.nightSoft], [1, c.nightMid]]} />
          <Stars n={60} seed={21} yMax={380} opacity={0.8} />
          <Moon cx={moonX} cy={110 + Math.abs(moonX - 700) * 0.12} r={34} />
          <Glow cx={470} cy={450} r={620} color={c.heroMist} opacity={0.34 * on} />
          <g transform={`translate(0,${impact * 10 + settled * 18})`}>
            <Phone x={470} y={450} s={1.12} on={on} scroll={f * 6 * (1 - settled * 0.8)} tilt={-3} />
          </g>
          <g transform={`translate(470,${stoneY + 60}) scale(${1 + impact * 0.06},${1 - impact * 0.08})`}>
            <path d="M -110 60 C -140 -10 -80 -96 0 -92 C 90 -96 140 -10 112 60 C 100 92 -96 92 -110 60 Z" fill={c.text} stroke={c.heroLight} strokeWidth={4} />
            <path d="M -30 -70 L -10 -20 L -44 20 M 40 -64 L 22 -10 L 56 30" fill="none" stroke={c.accent} strokeWidth={3} opacity={0.8} />
          </g>
          <Motes n={26} seed={4} speed={0.3} color={c.heroMist} opacity={0.5} />
        </SvgStage>
      </Camera>
      <Kinetic items={[
        {text: 'স্ক্রলের নেশা', at: tw('স্ক্রলের'), until: tw('পাপের') - 0.15, x: 1010, y: 330, size: 100},
        {text: 'পাপের ভার', at: tw('পাপের'), x: 1010, y: 330, size: 116, gold: true, underline: true},
      ]} />
    </>
  );
};
