import React from 'react';
import {alpha, theme} from '../theme';
import {Camera, SvgStage, ramp, useScene} from '../lib';
import {Glow, Hills, Mosque, Motes, Moon, Rays, Sky, Stars} from '../components/Art';
import {Kinetic} from '../components/Kinetic';
import {tw} from '../timeline';

const c = theme.colors;

/** Cinematic hook: starry night, rising mosque silhouette, descending light on "রব্বুল আলামীন". */
export const S01Hook: React.FC = () => {
  const {f, local} = useScene();
  const rise = ramp(f, 4, 90, 110, 0, theme.ease.out);
  const moonY = ramp(f, 0, 420, 330, 250, theme.ease.inOut);
  const second = local(tw('রব্বুল', 1));
  const pulse = Math.max(0, 1 - Math.abs(f - second) / 24) * 0.22;
  const rayOp = ramp(f, local(1.6), local(4.6), 0, 0.36) + pulse;
  return (
    <>
      <Camera zoom={[1, 1.09]} origin="50% 70%">
        <SvgStage>
          <Sky stops={[[0, c.text], [0.62, c.nightSoft], [1, c.hero]]} />
          <Stars n={120} seed={5} yMax={470} />
          <Moon cx={1190} cy={moonY} r={44} />
          <Glow cx={700} cy={640} r={520} color={c.accent} opacity={ramp(f, 20, 120, 0, 0.42)} />
          <Rays cx={700} cy={-60} count={9} length={900} spread={78} opacity={rayOp} width={110} />
          <g transform={`translate(0,${rise * 0.5})`}><Hills y={640} amp={46} fill={c.nightMid} seed={2} /></g>
          <g transform={`translate(0,${rise * 0.8})`}><Mosque cx={700} base={690} s={1.12} fill={c.text} winOpacity={ramp(f, 60, 120)} /></g>
          <g transform={`translate(0,${rise})`}><Hills y={730} amp={30} fill={c.text} seed={5} freq={1.4} /></g>
          <Motes n={46} seed={9} speed={0.45} opacity={0.75} />
        </SvgStage>
      </Camera>
      <Kinetic items={[
        {text: 'রব্বুল আলামীন', wordAt: [tw('রব্বুল', 0), tw('আলামীন', 0)], at: tw('রব্বুল', 0), until: tw('রব্বুল', 1) - 0.5, x: 700, y: 215, size: 126, gold: true, underline: true},
        {text: 'রব্বুল আলামীন', wordAt: [tw('রব্বুল', 1), tw('আলামীন', 1)], at: tw('রব্বুল', 1), until: tw('স্ক্রলের') - 0.25, x: 700, y: 215, size: 138, gold: true, underline: true},
      ]} />
      <div style={{position: 'absolute', inset: 0, background: `linear-gradient(180deg, ${alpha(c.text, 0.0)} 60%, ${alpha(c.text, 0.25)})`}} />
    </>
  );
};
