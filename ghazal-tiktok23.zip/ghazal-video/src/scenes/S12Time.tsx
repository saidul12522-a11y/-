import React from 'react';
import {theme} from '../theme';
import {Camera, SvgStage, ramp, useScene} from '../lib';
import {Glow, Heart, Motes, Rosette, Sky, Stars} from '../components/Art';
import {Hourglass} from '../components/Silhouettes';
import {Kinetic} from '../components/Kinetic';
import {tw, twFrom} from '../timeline';

const c = theme.colors;

/** "Make tawbah, O my heart — time is running out": the hourglass empties while a heart of light opens. */
export const S12Time: React.FC = () => {
  const {f, local, len} = useScene();
  const tHeart = local(tw('মন'));
  const tTime = local(tw('সময়'));
  const sand = ramp(f, 10, len - 10, 0.02, 0.9, theme.ease.soft);
  const heart = ramp(f, tHeart, tHeart + 50);
  const urgency = ramp(f, tTime, len);
  return (
    <>
      <Camera zoom={[1, 1.06]}>
        <SvgStage>
          <Sky stops={[[0, c.text], [1, c.nightSoft]]} />
          <Stars n={80} seed={52} yMax={420} opacity={0.65} />
          <Glow cx={700} cy={470} r={560} opacity={0.12 + urgency * 0.35} />
          <Rosette cx={700} cy={505} r={290} draw={ramp(f, 20, 140)} rot={f * 0.12} layers={3} sw={1.8} color={c.heroMist} />
          <Hourglass x={700} y={505} s={1.3} t={sand} />
          <g opacity={heart}>
            <Glow cx={700} cy={505} r={150} opacity={0.6 * heart} />
            <Heart x={700} y={505 + Math.sin(f / 14) * 3} s={1.9 * (0.7 + 0.3 * heart)} color={c.accent} opacity={0.95} />
          </g>
          <Motes n={36} seed={28} speed={0.35} opacity={0.7} />
        </SvgStage>
      </Camera>
      <Kinetic items={[
        {text: 'তওবা করো', wordAt: [tw('তওবা', 0), twFrom('করো', tw('তওবা', 0))], at: tw('তওবা', 0), until: tw('সময়') - 0.1, x: 700, y: 150, size: 126, gold: true, underline: true},
        {text: 'সময় তো আর বেশি নেই', wordAt: [tw('সময়'), tw('তো'), twFrom('আর', tw('সময়')), tw('বেশি'), tw('নেই')], at: tw('সময়'), x: 700, y: 150, size: 104},
      ]} />
    </>
  );
};
