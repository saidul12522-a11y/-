import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import {theme} from './theme';
import {SCENES} from './timeline';
import {SCENE_REGISTRY} from './scenes';
import {Backdrop} from './components/Backdrop';
import {Captions} from './components/Captions';
import {Grade, Grain, Vignette} from './components/Overlays';
import {SceneShell, StageBorder} from './components/Stage';
import {PreviewAudio} from './components/PreviewAudio';
import {SfxTrack} from './components/SfxTrack';

export const Main: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: theme.colors.bg}}>
    {/* layer 1: patterned cream backdrop */}
    <Backdrop />
    {/* layer 2-3: scene art + kinetic type inside the arch stage */}
    {SCENES.map((s, i) => {
      const {Component, tone} = SCENE_REGISTRY[s.id];
      const last = i === SCENES.length - 1;
      return (
        <Sequence key={s.id} from={s.from} durationInFrames={s.dur + (last ? 0 : theme.anim.transitionFrames + 14)} name={s.id}>
          <SceneShell from={s.from} to={s.to} tone={tone} first={i === 0}>
            <Component />
          </SceneShell>
        </Sequence>
      );
    })}
    <StageBorder />
    <Captions />
    {/* layer 4-5: grade, grain, vignette */}
    <Grade />
    <Grain />
    <Vignette />
    <PreviewAudio />
    <SfxTrack />
  </AbsoluteFill>
);
