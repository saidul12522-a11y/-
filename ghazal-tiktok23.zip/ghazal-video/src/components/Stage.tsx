import React from 'react';
import {AbsoluteFill} from 'remotion';
import {STAGE, alpha, theme} from '../theme';
import {SceneCtx, Tone, archPath, ramp, useScene} from '../lib';

/** Persistent mihrab-arch border drawn above every scene. */
export const StageBorder: React.FC = () => {
  const c = theme.colors;
  const {w, h, x, y} = STAGE;
  const pad = 30;
  return (
    <svg width={w + pad * 2} height={h + pad * 2} style={{position: 'absolute', left: x - pad, top: y - pad, overflow: 'visible'}}>
      <g transform={`translate(${pad},${pad})`}>
        <path d={archPath(w, h, -16)} fill="none" stroke={alpha(c.accent, 0.95)} strokeWidth={2.5} />
        <path d={archPath(w, h, -7)} fill="none" stroke={alpha(c.hero, 0.9)} strokeWidth={2} />
        <path d={archPath(w, h, 0)} fill="none" stroke={c.text} strokeWidth={7} />
        <path d={archPath(w, h, 12)} fill="none" stroke={alpha(c.accent, 0.8)} strokeWidth={1.6} />
      </g>
    </svg>
  );
};

/** Wraps a scene: arch clip, cross-dissolve in, soft light sweep. */
export const SceneShell: React.FC<{from: number; to: number; tone: Tone; first: boolean; children: React.ReactNode}> = ({from, to, tone, first, children}) => (
  <SceneCtx.Provider value={{from, to, tone}}>
    <ShellInner first={first}>{children}</ShellInner>
  </SceneCtx.Provider>
);

const ShellInner: React.FC<{first: boolean; children: React.ReactNode}> = ({first, children}) => {
  const {f} = useScene();
  const OV = theme.anim.transitionFrames;
  const fade = first ? 1 : ramp(f, 0, OV, 0, 1, theme.ease.soft);
  const sweepX = ramp(f, 0, OV + 10, -500, STAGE.w + 300, theme.ease.inOut);
  const sweepOp = first ? 0 : ramp(f, 0, OV + 10, 1, 0, theme.ease.soft);
  return (
    <AbsoluteFill>
      <div
        style={{
          position: 'absolute', left: STAGE.x, top: STAGE.y, width: STAGE.w, height: STAGE.h,
          clipPath: `path('${archPath(STAGE.w, STAGE.h)}')`, overflow: 'hidden', opacity: fade,
        }}
      >
        {children}
        {/* elegant light sweep */}
        <div
          style={{
            position: 'absolute', top: -100, bottom: -100, width: 380, left: 0, opacity: sweepOp * 0.55,
            transform: `translateX(${sweepX}px) skewX(-18deg)`,
            background: `linear-gradient(90deg, transparent, ${alpha(theme.colors.accent, 0.8)}, ${alpha(theme.colors.bg, 0.9)}, transparent)`,
          }}
        />
      </div>
    </AbsoluteFill>
  );
};
