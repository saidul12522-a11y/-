import React from 'react';
import {useCurrentFrame, useVideoConfig} from 'remotion';
import {PAGES} from '../timeline';
import {CAPTION, alpha, theme} from '../theme';
import {ramp} from '../lib';

/** Word-synced Bengali captions. Page layout is stable; the active word gets a gold pill. */
export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const page = PAGES.find((p) => t >= p.show && t < p.hide + 0.25);
  if (!page) return null;
  const c = theme.colors;
  const enter = ramp(t, page.show, page.show + 0.3);
  const exit = ramp(t, page.hide, page.hide + 0.25, 1, 0, theme.ease.in);
  const op = Math.min(enter, exit);
  const size = theme.type.caption.size;

  return (
    <div
      style={{
        position: 'absolute', left: 0, right: 0, top: CAPTION.y - 90, height: 180,
        display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: op,
        transform: `translateY(${(1 - enter) * 18 + (1 - exit) * -10}px)`,
      }}
    >
      <div
        style={{
          display: 'flex', flexWrap: 'wrap', justifyContent: 'center', alignItems: 'center',
          columnGap: 8, rowGap: 0, maxWidth: 1560,
          fontFamily: theme.fonts.body, fontWeight: theme.type.caption.weight, fontSize: size,
          lineHeight: 1.5, letterSpacing: 0, color: c.text,
        }}
      >
        {page.tokens.map((tk, i) => {
          const act = ramp(t, tk.start - 0.04, tk.start + 0.12);
          const off = ramp(t, tk.end, tk.end + 0.25, 1, 0, theme.ease.in);
          const pill = Math.min(act, off);
          const future = t < tk.start - 0.04;
          return (
            <span key={i} style={{position: 'relative', display: 'inline-block', padding: '0 14px', opacity: future ? 0.36 : 1}}>
              <span
                style={{
                  position: 'absolute', left: 0, right: 0, top: 8, bottom: 6, borderRadius: 16, zIndex: 0,
                  background: c.accent, opacity: pill * 0.95,
                  transform: `scale(${0.9 + 0.1 * pill})`,
                  boxShadow: `0 6px 22px ${alpha(c.accent, 0.5 * pill)}`,
                }}
              />
              <span style={{position: 'relative', zIndex: 1}}>{tk.text}</span>
            </span>
          );
        })}
      </div>
    </div>
  );
};
