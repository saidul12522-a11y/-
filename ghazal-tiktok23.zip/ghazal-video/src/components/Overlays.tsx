import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {alpha, theme} from '../theme';

export const Grade: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: 'none'}}>
    <AbsoluteFill style={{backgroundColor: theme.colors.hero, mixBlendMode: 'soft-light', opacity: 0.12}} />
    <AbsoluteFill
      style={{background: `linear-gradient(180deg, ${alpha(theme.colors.text, 0.06)}, transparent 22%, transparent 78%, ${alpha(theme.colors.accent, 0.1)})`}}
    />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: 'none', backgroundImage: noise, backgroundSize: '220px',
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.05, mixBlendMode: 'multiply',
      }}
    />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{pointerEvents: 'none', background: `radial-gradient(ellipse at center, transparent 58%, ${alpha(theme.colors.hero, 0.16)} 100%)`}}
  />
);
