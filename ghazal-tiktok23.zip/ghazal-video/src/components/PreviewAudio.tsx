import React from 'react';
import {Audio, getRemotionEnvironment, getStaticFiles, staticFile} from 'remotion';

/**
 * Voiceover for sync-checking in Remotion Studio / Player.
 * Plays only if public/voiceover.mp3 exists. During `remotion render` it is OFF by default
 * (set VOICEOVER_IN_RENDER = true to bake it into the MP4).
 */
export const VOICEOVER_IN_RENDER = false;

export const PreviewAudio: React.FC = () => {
  const env = getRemotionEnvironment();
  const preview = env.isStudio || env.isPlayer;
  if (!preview && !VOICEOVER_IN_RENDER) return null;
  if (preview && !getStaticFiles().some((f) => f.name === 'voiceover.mp3')) return null;
  return <Audio src={staticFile('voiceover.mp3')} volume={1} />;
};
