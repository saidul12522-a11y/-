import React, {useMemo} from 'react';
import {alpha, theme} from '../theme';
import {SH, SW, ramp, rng, star8Path, useScene, useUid} from '../lib';

const c = theme.colors;

export const Sky: React.FC<{stops: [number, string][]; id?: string}> = ({stops}) => {
  const id = useUid('sky');
  return (
    <>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          {stops.map(([o, col], i) => <stop key={i} offset={o} stopColor={col} />)}
        </linearGradient>
      </defs>
      <rect width={SW} height={SH} fill={`url(#${id})`} />
    </>
  );
};

export const Glow: React.FC<{cx: number; cy: number; r: number; color?: string; opacity?: number}> = ({cx, cy, r, color = c.accent, opacity = 0.6}) => {
  const id = useUid('gl');
  return (
    <>
      <defs>
        <radialGradient id={id}>
          <stop offset="0" stopColor={color} stopOpacity={opacity} />
          <stop offset="0.45" stopColor={color} stopOpacity={opacity * 0.35} />
          <stop offset="1" stopColor={color} stopOpacity={0} />
        </radialGradient>
      </defs>
      <circle cx={cx} cy={cy} r={r} fill={`url(#${id})`} />
    </>
  );
};

export const Stars: React.FC<{n?: number; seed?: number; yMax?: number; color?: string; appear?: number; opacity?: number}> = ({n = 90, seed = 3, yMax = 520, color = c.bg, appear = 40, opacity = 1}) => {
  const {f} = useScene();
  const items = useMemo(() => {
    const r = rng(seed);
    return Array.from({length: n}, () => ({x: r() * SW, y: r() * yMax, s: 0.7 + r() * 2.0, ph: r() * 6.28, sp: 18 + r() * 40, d: r() * appear}));
  }, [n, seed, yMax, appear]);
  return (
    <g fill={color}>
      {items.map((s, i) => {
        const tw = 0.45 + 0.55 * (0.5 + 0.5 * Math.sin(f / s.sp + s.ph));
        const o = ramp(f, s.d, s.d + 22) * tw * opacity * (1 - (s.y / yMax) * 0.45);
        return <circle key={i} cx={s.x} cy={s.y} r={s.s} opacity={o} />;
      })}
    </g>
  );
};

export const Moon: React.FC<{cx: number; cy: number; r: number; color?: string; cut?: number}> = ({cx, cy, r, color = c.accent, cut = 0.42}) => {
  const id = useUid('mn');
  return (
    <g>
      <Glow cx={cx} cy={cy} r={r * 3.2} opacity={0.35} />
      <defs>
        <mask id={id}>
          <rect x={cx - r * 2} y={cy - r * 2} width={r * 4} height={r * 4} fill="white" />
          <circle cx={cx + r * cut * 1.5} cy={cy - r * 0.12} r={r * 0.92} fill="black" />
        </mask>
      </defs>
      <circle cx={cx} cy={cy} r={r} fill={color} mask={`url(#${id})`} />
    </g>
  );
};

/** Layered hills silhouette. */
export const Hills: React.FC<{y: number; amp?: number; fill: string; seed?: number; freq?: number; shift?: number}> = ({y, amp = 40, fill, seed = 1, freq = 1, shift = 0}) => {
  const d = useMemo(() => {
    const pts: string[] = [];
    for (let x = -20; x <= SW + 20; x += 20) {
      const yy = y - Math.sin((x + seed * 133) / (160 / freq)) * amp * 0.6 - Math.sin((x + seed * 71) / (63 / freq)) * amp * 0.4;
      pts.push(`${x},${yy.toFixed(1)}`);
    }
    return `M -20,${SH + 20} L ${pts.join(' L ')} L ${SW + 20},${SH + 20} Z`;
  }, [y, amp, seed, freq]);
  return <path d={d} fill={fill} transform={`translate(${shift},0)`} />;
};

/** Mosque silhouette with glowing arched windows. */
export const Mosque: React.FC<{cx: number; base: number; s?: number; fill?: string; windows?: string; winOpacity?: number; minarets?: boolean}> = ({cx, base, s = 1, fill = c.text, windows = c.accent, winOpacity = 1, minarets = true}) => {
  const {f} = useScene();
  const U = (n: number) => n * s;
  const dome = (x: number, w: number, h: number, y: number) =>
    `M ${x - w / 2} ${y} C ${x - w / 2} ${y - h * 0.75} ${x - w * 0.18} ${y - h * 0.95} ${x} ${y - h} C ${x + w * 0.18} ${y - h * 0.95} ${x + w / 2} ${y - h * 0.75} ${x + w / 2} ${y} Z`;
  const minaret = (x: number) => (
    <g>
      <rect x={x - U(15)} y={base - U(330)} width={U(30)} height={U(330)} fill={fill} />
      <path d={`M ${x - U(26)} ${base - U(252)} L ${x + U(26)} ${base - U(252)} L ${x + U(17)} ${base - U(236)} L ${x - U(17)} ${base - U(236)} Z`} fill={fill} />
      <path d={`M ${x - U(18)} ${base - U(330)} L ${x} ${base - U(405)} L ${x + U(18)} ${base - U(330)} Z`} fill={fill} />
      <circle cx={x} cy={base - U(410)} r={U(5)} fill={fill} />
      <rect x={x - U(4)} y={base - U(300)} width={U(8)} height={U(24)} rx={U(4)} fill={windows} opacity={0.9 * winOpacity} />
    </g>
  );
  const win = (x: number, y: number, w: number, h: number, k: number) => (
    <path key={k} d={`M ${x - w / 2} ${y + h} L ${x - w / 2} ${y + w / 2} Q ${x - w / 2} ${y} ${x} ${y - w * 0.15} Q ${x + w / 2} ${y} ${x + w / 2} ${y + w / 2} L ${x + w / 2} ${y + h} Z`}
      fill={windows} opacity={winOpacity * (0.75 + 0.25 * Math.sin(f / 17 + k * 2))} />
  );
  return (
    <g>
      {minarets && minaret(cx - U(300))}
      {minarets && minaret(cx + U(300))}
      <rect x={cx - U(250)} y={base - U(150)} width={U(500)} height={U(150)} fill={fill} />
      <path d={dome(cx - U(165), U(120), U(80), base - U(150))} fill={fill} />
      <path d={dome(cx + U(165), U(120), U(80), base - U(150))} fill={fill} />
      <rect x={cx - U(100)} y={base - U(210)} width={U(200)} height={U(70)} fill={fill} />
      <path d={dome(cx, U(230), U(150), base - U(205))} fill={fill} />
      <rect x={cx - U(2.5)} y={base - U(385)} width={U(5)} height={U(40)} fill={fill} />
      <circle cx={cx} cy={base - U(390)} r={U(7)} fill={fill} />
      {[-205, -125, -45, 45, 125, 205].map((dx, i) => win(cx + U(dx), base - U(112), U(26), U(62), i))}
      {[-45, 45].map((dx, i) => win(cx + U(dx), base - U(195), U(22), U(46), i + 8))}
    </g>
  );
};

/** Soft volumetric light shafts fanning from a point. */
export const Rays: React.FC<{cx: number; cy: number; count?: number; length?: number; spread?: number; color?: string; opacity?: number; sway?: number; width?: number; angle?: number}> = ({cx, cy, count = 9, length = 900, spread = 80, color = c.accent, opacity = 0.35, sway = 1, width = 90, angle = 0}) => {
  const {f} = useScene();
  const id = useUid('ry');
  return (
    <g>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={color} stopOpacity={opacity} />
          <stop offset="1" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {Array.from({length: count}, (_, i) => {
        const a = angle + (i / (count - 1) - 0.5) * spread + Math.sin(f / 70 + i) * 2 * sway;
        const w = width * (0.55 + 0.45 * Math.sin(i * 1.7 + 1));
        return (
          <path key={i} d={`M ${-w * 0.12} 0 L ${w * 0.12} 0 L ${w} ${length} L ${-w} ${length} Z`} fill={`url(#${id})`}
            opacity={0.5 + 0.5 * Math.sin(f / 45 + i * 1.3) * 0.5 + 0.25} transform={`translate(${cx},${cy}) rotate(${a})`} />
        );
      })}
    </g>
  );
};

/** Floating dust motes. */
export const Motes: React.FC<{n?: number; seed?: number; speed?: number; color?: string; opacity?: number; size?: number; y0?: number; y1?: number}> = ({n = 40, seed = 7, speed = 0.5, color = c.accent, opacity = 0.8, size = 2.4, y0 = 0, y1 = SH}) => {
  const {f} = useScene();
  const items = useMemo(() => {
    const r = rng(seed);
    return Array.from({length: n}, () => ({x: r() * SW, y: r(), s: 0.5 + r() * size, sp: 0.4 + r() * 0.9, ph: r() * 6.28, am: 8 + r() * 26}));
  }, [n, seed, size]);
  const span = y1 - y0;
  return (
    <g fill={color}>
      {items.map((m, i) => {
        const yy = (((m.y * span - f * speed * m.sp) % span) + span) % span + y0;
        const o = opacity * (0.35 + 0.65 * (0.5 + 0.5 * Math.sin(f / 20 + m.ph))) * Math.min(1, (yy - y0) / 40) * Math.min(1, (y1 - yy) / 60);
        return <circle key={i} cx={m.x + Math.sin(f / 50 + m.ph) * m.am} cy={yy} r={m.s} opacity={o} />;
      })}
    </g>
  );
};

/** Islamic rosette: 8-petal lotus + 8-pointed star polygons (no overlapping squares, no crosses). */
export const Rosette: React.FC<{cx: number; cy: number; r: number; draw?: number; rot?: number; color?: string; layers?: number; sw?: number; fill?: string}> = ({cx, cy, r, draw = 1, rot = 0, color = c.accent, layers = 3, sw = 2, fill}) => {
  const dash = {pathLength: 1, strokeDasharray: 1, strokeDashoffset: 1 - draw} as const;
  const petal = `M 0 0 Q ${r * 0.34} ${-r * 0.5} 0 ${-r * 0.95} Q ${-r * 0.34} ${-r * 0.5} 0 0 Z`;
  return (
    <g transform={`translate(${cx},${cy}) rotate(${rot})`} fill="none" stroke={color} strokeWidth={sw} strokeLinejoin="round" strokeLinecap="round">
      <circle r={r * 1.1} {...dash} opacity={0.6} />
      {Array.from({length: 8}, (_, k) => <path key={k} d={petal} transform={`rotate(${k * 45})`} {...dash} opacity={0.75} />)}
      {Array.from({length: layers}, (_, k) => (
        <path key={k} d={star8Path(r * (1 - k * 0.22))} transform={`rotate(${k * 22.5})`} {...dash} fill={k === 0 ? fill : 'none'} opacity={1 - k * 0.12} />
      ))}
      <circle r={r * 0.18} {...dash} />
    </g>
  );
};

/** Water-ripple / sound rings. */
export const Rings: React.FC<{cx: number; cy: number; start: number; n?: number; gap?: number; maxR?: number; color?: string; sw?: number; life?: number; squash?: number}> = ({cx, cy, start, n = 3, gap = 14, maxR = 260, color = c.accent, sw = 2.5, life = 70, squash = 1}) => {
  const {f} = useScene();
  return (
    <g fill="none" stroke={color}>
      {Array.from({length: n}, (_, i) => {
        const p = ramp(f - i * gap, start, start + life, 0, 1, theme.ease.out);
        if (p <= 0 || p >= 1) return null;
        return <ellipse key={i} cx={cx} cy={cy} rx={maxR * p} ry={maxR * p * squash} strokeWidth={sw} opacity={(1 - p) * 0.9} />;
      })}
    </g>
  );
};

export const Bird: React.FC<{x: number; y: number; s?: number; phase?: number; color?: string}> = ({x, y, s = 1, phase = 0, color = c.text}) => {
  const {f} = useScene();
  const flap = Math.sin(f / 4 + phase);
  const up = -26 * flap * s;
  return (
    <path d={`M ${x - 30 * s} ${y + up * 0.6} Q ${x - 14 * s} ${y + up - 8 * s} ${x} ${y} Q ${x + 14 * s} ${y + up - 8 * s} ${x + 30 * s} ${y + up * 0.6} Q ${x + 14 * s} ${y + up * 0.2 + 2 * s} ${x} ${y + 5 * s} Q ${x - 14 * s} ${y + up * 0.2 + 2 * s} ${x - 30 * s} ${y + up * 0.6} Z`} fill={color} />
  );
};

export const Heart: React.FC<{x: number; y: number; s?: number; color?: string; opacity?: number; rot?: number}> = ({x, y, s = 1, color = c.accent, opacity = 1, rot = 0}) => (
  <path d="M0 14 C-22 -2 -24 -22 -10 -26 C-3 -28 0 -22 0 -18 C0 -22 3 -28 10 -26 C24 -22 22 -2 0 14 Z" transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`} fill={color} opacity={opacity} />
);
