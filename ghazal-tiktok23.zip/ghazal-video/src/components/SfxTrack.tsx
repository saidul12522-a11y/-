import React from 'react';
import {Audio, Sequence, staticFile} from 'remotion';
import {SFX_DUR, SFX_EVENTS} from '../sfx';
import {FPS} from '../timeline';

/** Short, non-musical SFX placed 2 frames before each visual lands. Files live in public/sfx. */
export const SfxTrack: React.FC = () => (
  <>
    {SFX_EVENTS.map((e, i) => (
      <Sequence key={i} from={Math.max(0, Math.round(e.t * FPS) - 2)} durationInFrames={Math.ceil(SFX_DUR[e.file] * FPS) + 2} layout="none">
        <Audio src={staticFile(`sfx/${e.file}.wav`)} volume={e.vol} />
      </Sequence>
    ))}
  </>
);
