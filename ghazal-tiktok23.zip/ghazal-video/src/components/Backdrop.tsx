import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {alpha, theme, VIDEO} from '../theme';
import {star8Path} from '../lib';

// 8-pointed star (two squares) used for the lattice and corner ornaments
const Star8: React.FC<{r: number; stroke: string; sw?: number}> = ({r, stroke, sw = 1.5}) => (
  <g fill="none" stroke={stroke} strokeWidth={sw} strokeLinejoin="round">
    <path d={star8Path(r, r * 0.62)} />
    <circle r={r * 0.36} />
  </g>
);

export const Backdrop: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 90) * 40;
  const d2 = Math.cos(frame / 110) * 30;
  const {width: W, height: H} = VIDEO;
  const c = theme.colors;
  return (
    <AbsoluteFill style={{background: `radial-gradient(ellipse at 50% 40%, ${c.bg}, ${c.bgDeep})`}}>
      <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
        <defs>
          <pattern id="lat" width="120" height="120" patternUnits="userSpaceOnUse" patternTransform={`translate(${frame * 0.15},0)`}>
            <g transform="translate(60,60)"><Star8 r={34} stroke={alpha(c.hero, 0.1)} /></g>
            <g transform="translate(0,0)"><Star8 r={14} stroke={alpha(c.accent, 0.35)} sw={1.2} /></g>
            <g transform="translate(120,0)"><Star8 r={14} stroke={alpha(c.accent, 0.35)} sw={1.2} /></g>
            <g transform="translate(0,120)"><Star8 r={14} stroke={alpha(c.accent, 0.35)} sw={1.2} /></g>
            <g transform="translate(120,120)"><Star8 r={14} stroke={alpha(c.accent, 0.35)} sw={1.2} /></g>
          </pattern>
          <radialGradient id="bgGoldGlow"><stop offset="0" stopColor={c.accent} stopOpacity="0.38" /><stop offset="1" stopColor={c.accent} stopOpacity="0" /></radialGradient>
          <radialGradient id="bgBlueGlow"><stop offset="0" stopColor={c.hero} stopOpacity="0.20" /><stop offset="1" stopColor={c.hero} stopOpacity="0" /></radialGradient>
        </defs>
        <rect width={W} height={H} fill="url(#lat)" />
        <circle cx={160 + d1} cy={140} r={520} fill="url(#bgGoldGlow)" />
        <circle cx={W - 120 - d2} cy={H - 100} r={560} fill="url(#bgBlueGlow)" />
        {/* thin double frame */}
        <rect x={20} y={20} width={W - 40} height={H - 40} rx={6} fill="none" stroke={alpha(c.accent, 0.9)} strokeWidth={2} />
        <rect x={30} y={30} width={W - 60} height={H - 60} rx={4} fill="none" stroke={alpha(c.hero, 0.55)} strokeWidth={1} />
        {[[40, 40], [W - 40, 40], [40, H - 40], [W - 40, H - 40]].map(([x, y], i) => (
          <g key={i} transform={`translate(${x},${y})`}>
            <rect x={-13} y={-13} width={26} height={26} fill={c.bg} />
            <Star8 r={11} stroke={c.accentDeep} sw={1.6} />
          </g>
        ))}
        {/* divider between stage and caption */}
        <g transform={`translate(${W / 2},882)`}>
          <line x1={-300} x2={-26} y1={0} y2={0} stroke={alpha(c.accentDeep, 0.65)} strokeWidth={1.5} />
          <line x1={26} x2={300} y1={0} y2={0} stroke={alpha(c.accentDeep, 0.65)} strokeWidth={1.5} />
          <Star8 r={11} stroke={c.accentDeep} sw={1.6} />
        </g>
      </svg>
    </AbsoluteFill>
  );
};
