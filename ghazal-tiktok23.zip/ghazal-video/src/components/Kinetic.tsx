import React from 'react';
import {spring} from 'remotion';
import {alpha, theme} from '../theme';
import {ramp, useScene} from '../lib';

export type KItem = {
  text: string; at: number; until?: number; x: number; y: number;
  size?: number; gold?: boolean; underline?: boolean; stagger?: number; wordAt?: number[];
};

/** Kinetic Bengali typography: word-by-word mask reveal. Words never split into letters. */
export const Kinetic: React.FC<{items: KItem[]}> = ({items}) => {
  const {f, fps, local, tone, len} = useScene();
  const c = theme.colors;
  const dark = tone !== 'light';
  return (
    <>
      {items.map((it, k) => {
        const s = local(it.at);
        // with `until`, the exit finishes by that time (no overlap with the next item)
        const e = it.until !== undefined ? local(it.until) - theme.anim.exitFrames : len - 2;
        if (f < s - 1 || f > e + theme.anim.exitFrames + 2) return null;
        const size = it.size ?? theme.type.kinetic.size;
        const words = it.text.split(' ');
        const ex = ramp(f, e, e + theme.anim.exitFrames, 0, 1, theme.ease.in);
        const col = it.gold ? (dark ? c.accent : c.accentDeep) : dark ? c.bg : c.text;
        const breathe = 1 + Math.sin((f + k * 9) / 28) * 0.008;
        return (
          <div
            key={k}
            style={{
              position: 'absolute', left: it.x, top: it.y,
              transform: `translate(-50%,-50%) scale(${breathe}) translateY(${-24 * ex}px)`,
              opacity: 1 - ex, display: 'flex', columnGap: size * 0.26, justifyContent: 'center',
              fontFamily: theme.fonts.display, fontWeight: theme.type.kinetic.weight,
              fontSize: size, lineHeight: 1.3, letterSpacing: 0, color: col, whiteSpace: 'nowrap',
              textShadow: dark ? theme.shadow.textOnNight : 'none',
            }}
          >
            {words.map((w, i) => {
              const ws = it.wordAt ? local(it.wordAt[i] ?? it.at) : s + i * (it.stagger ?? theme.anim.kineticStagger);
              const p = spring({frame: f - ws, fps, config: theme.spring.word});
              return (
                <span key={i} style={{display: 'inline-block', overflow: 'hidden', padding: '0.18em 0.06em 0.3em', margin: '-0.18em -0.06em -0.3em'}}>
                  <span style={{display: 'inline-block', opacity: Math.min(1, p * 1.6), transform: `translateY(${(1 - p) * 105}%) scale(${0.94 + 0.06 * p})`}}>
                    {w}
                  </span>
                </span>
              );
            })}
            {it.underline && (
              <span
                style={{
                  position: 'absolute', left: '4%', right: '4%', bottom: -2, height: Math.max(4, size * 0.04), borderRadius: 4,
                  background: dark ? c.accent : c.accentDeep, transformOrigin: 'left',
                  transform: `scaleX(${spring({frame: f - s - 10, fps, config: theme.spring.smooth})})`,
                  boxShadow: `0 0 18px ${alpha(c.accent, 0.6)}`,
                }}
              />
            )}
          </div>
        );
      })}
    </>
  );
};
