// Procedural, non-musical SFX (no downloads, deterministic). Writes 16-bit mono WAVs to public/sfx.
import fs from 'node:fs';
import path from 'node:path';

const SR = 44100;
const out = path.resolve('public/sfx');
fs.mkdirSync(out, {recursive: true});
let seed = 1234567;
const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647) * 2 - 1;

const buf = (sec) => new Float32Array(Math.floor(sec * SR));
const norm = (b, peak) => {
  let m = 0;
  for (const v of b) m = Math.max(m, Math.abs(v));
  const g = m ? peak / m : 1;
  return b.map((v) => v * g);
};
const fade = (b, inS, outS) => {
  const a = Math.floor(inS * SR), z = Math.floor(outS * SR);
  for (let i = 0; i < a && i < b.length; i++) b[i] *= i / a;
  for (let i = 0; i < z && i < b.length; i++) b[b.length - 1 - i] *= i / z;
  return b;
};
// state-variable band-pass with time-varying cutoff
const bandNoise = (sec, fc, q, env) => {
  const b = buf(sec);
  let low = 0, band = 0;
  for (let i = 0; i < b.length; i++) {
    const t = i / b.length;
    const f = 2 * Math.sin((Math.PI * Math.min(fc(t), 9000)) / SR);
    const x = rnd();
    const high = x - low - q * band;
    band += f * high;
    low += f * band;
    b[i] = band * env(t);
  }
  return b;
};
const lowpass = (b, fc) => {
  const a = Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  return b.map((x) => (y = (1 - a) * x + a * y));
};
const wav = (name, b) => {
  const pcm = Buffer.alloc(44 + b.length * 2);
  pcm.write('RIFF', 0); pcm.writeUInt32LE(36 + b.length * 2, 4); pcm.write('WAVEfmt ', 8);
  pcm.writeUInt32LE(16, 16); pcm.writeUInt16LE(1, 20); pcm.writeUInt16LE(1, 22);
  pcm.writeUInt32LE(SR, 24); pcm.writeUInt32LE(SR * 2, 28); pcm.writeUInt16LE(2, 32); pcm.writeUInt16LE(16, 34);
  pcm.write('data', 36); pcm.writeUInt32LE(b.length * 2, 40);
  b.forEach((v, i) => pcm.writeInt16LE(Math.round(Math.max(-1, Math.min(1, v)) * 32767), 44 + i * 2));
  fs.writeFileSync(path.join(out, name + '.wav'), pcm);
  console.log('sfx', name, (b.length / SR).toFixed(2) + 's');
};
const sine = (sec, f0, f1, env) => {
  const b = buf(sec);
  let ph = 0;
  for (let i = 0; i < b.length; i++) {
    const t = i / b.length;
    ph += (2 * Math.PI * (f0 * Math.pow(f1 / f0, t))) / SR;
    b[i] = Math.sin(ph) * env(i / SR);
  }
  return b;
};

// 1. soft whoosh
wav('whoosh-soft', fade(norm(bandNoise(0.95, (t) => 260 + 2300 * Math.sin(Math.PI * t * 0.9) ** 1.4, 0.8, (t) => Math.sin(Math.PI * Math.pow(t, 0.7)) ** 2), 0.5), 0.01, 0.05));
// 2. transition sweep (longer, rising then settling)
wav('sweep', fade(norm(bandNoise(1.5, (t) => 180 + 3600 * t * t, 0.9, (t) => Math.pow(Math.sin(Math.PI * Math.min(1, t * 0.95)), 2.2)), 0.45), 0.01, 0.08));
// 3. gentle pop
{
  const p = sine(0.2, 520, 190, (t) => Math.exp(-t / 0.045));
  const c = lowpass(bandNoise(0.2, () => 1800, 1.2, (t) => Math.exp(-t * 90)), 3000);
  wav('pop', fade(norm(p.map((v, i) => v + c[i] * 0.5), 0.55), 0.001, 0.02));
}
// 4. subtle click
wav('click', fade(norm(bandNoise(0.08, () => 2800, 1.1, (t) => Math.exp(-t * 55)), 0.5), 0.0005, 0.01));
// 5. shimmer (inharmonic, non-melodic air)
{
  const b = buf(1.7);
  [2310, 3170, 4090, 5360, 6720].forEach((f, k) => {
    for (let i = 0; i < b.length; i++) {
      const t = i / SR;
      b[i] += Math.sin(2 * Math.PI * f * t + k) * Math.min(1, t / 0.06) * Math.exp(-t / (0.55 - k * 0.05)) / (k + 1.4);
    }
  });
  const air = bandNoise(1.7, () => 6200, 0.7, (t) => Math.exp(-t * 4) * 0.25);
  wav('shimmer', fade(norm(b.map((v, i) => v + air[i]), 0.4), 0.02, 0.15));
}
// 6. water drop
wav('drop', fade(norm(sine(0.28, 650, 1500, (t) => Math.exp(-t / 0.05)), 0.5), 0.001, 0.03));
// 7. heavy soft thud
{
  const s = sine(0.7, 95, 38, (t) => Math.exp(-t / 0.14));
  const n = lowpass(bandNoise(0.7, () => 500, 1, (t) => Math.exp(-t * 20)), 400);
  wav('thud', fade(norm(s.map((v, i) => v + n[i] * 0.6), 0.6), 0.001, 0.06));
}
// 8. light ambient air texture (used once, in the interlude)
{
  const b = bandNoise(13, () => 650, 1.6, (t) => 0.55 + 0.45 * Math.sin(t * 6.28 * 2.2));
  wav('ambient', fade(norm(lowpass(b, 900), 0.28), 1.6, 1.8));
}
