export const Easing = {bezier: () => (x) => x};
export const continueRender = () => {}; export const delayRender = () => 0; export const staticFile = (s) => s;
