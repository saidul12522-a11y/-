// Bundle once, render many still frames for visual QC.
// Usage: node scripts/qc-stills.mjs out/qc 100 450 900   (frames, or seconds with "s" suffix e.g. 12.5s)
import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition} from '@remotion/renderer';
import fs from 'node:fs';
import path from 'node:path';

const [outDir, ...args] = process.argv.slice(2);
fs.mkdirSync(outDir, {recursive: true});
const browserExecutable = process.env.BROWSER_EXECUTABLE || undefined;
const serveUrl = await bundle({entryPoint: path.resolve('src/index.ts'), onProgress: () => {}});
const comp = await selectComposition({serveUrl, id: 'Main', browserExecutable});
for (const a of args) {
  const frame = a.endsWith('s') ? Math.round(parseFloat(a) * comp.fps) : parseInt(a, 10);
  const output = path.join(outDir, `f${String(frame).padStart(5, '0')}.png`);
  await renderStill({composition: comp, serveUrl, output, frame, browserExecutable, imageFormat: 'png', overwrite: true});
  console.log('rendered', output);
}
