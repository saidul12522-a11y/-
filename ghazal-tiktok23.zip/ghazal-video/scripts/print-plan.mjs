import {build} from 'esbuild';
import fs from 'node:fs';
await build({entryPoints: ['src/timeline.ts'], bundle: true, format: 'esm', platform: 'node', outfile: 'out/.timeline.mjs', alias: {remotion: new URL('./remotion-stub.mjs', import.meta.url).pathname}, logLevel: 'error'});
const m = await import('../out/.timeline.mjs');
console.log('total frames', m.TOTAL_FRAMES, (m.TOTAL_FRAMES / 30).toFixed(2) + 's');
for (const s of m.SCENES) console.log(s.id.padEnd(10), (s.from / 30).toFixed(2).padStart(7), '->', (s.to / 30).toFixed(2).padStart(7), `(${(s.dur / 30).toFixed(1)}s)`);
console.log('pages', m.PAGES.length);
for (const p of m.PAGES) console.log(p.start.toFixed(2), p.end.toFixed(2), p.tokens.map((t) => t.text).join(' '));
