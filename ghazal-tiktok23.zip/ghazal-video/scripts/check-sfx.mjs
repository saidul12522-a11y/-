// SFX QC: peak, RMS, clipping per file.
import fs from 'node:fs';
import path from 'node:path';
const dir = path.resolve('public/sfx');
let bad = 0;
for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.wav'))) {
  const b = fs.readFileSync(path.join(dir, f));
  const n = (b.length - 44) / 2;
  let peak = 0, sum = 0, clip = 0;
  for (let i = 0; i < n; i++) {
    const v = b.readInt16LE(44 + i * 2) / 32768;
    peak = Math.max(peak, Math.abs(v));
    sum += v * v;
    if (Math.abs(v) >= 0.999) clip++;
  }
  const rms = Math.sqrt(sum / n);
  const ok = clip === 0 && peak < 0.8;
  if (!ok) bad++;
  console.log(`${f.padEnd(18)} dur ${(n / 44100).toFixed(2)}s  peak ${(20 * Math.log10(peak)).toFixed(1)} dBFS  rms ${(20 * Math.log10(rms)).toFixed(1)} dBFS  clipped ${clip}  ${ok ? 'OK' : 'FAIL'}`);
}
process.exit(bad ? 1 : 0);
