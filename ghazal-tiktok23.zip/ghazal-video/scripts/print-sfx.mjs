import {build} from 'esbuild';
await build({entryPoints: ['src/sfx.ts'], bundle: true, format: 'esm', platform: 'node', outfile: 'out/.sfx.mjs', alias: {remotion: new URL('./remotion-stub.mjs', import.meta.url).pathname}, logLevel: 'error'});
const m = await import('../out/.sfx.mjs');
console.log('events:', m.SFX_EVENTS.length);
const per = {}; m.SFX_EVENTS.forEach((e) => (per[e.file] = (per[e.file] || 0) + 1)); console.log(per);
// density check: max overlapping events within 1s window
let maxD = 0; m.SFX_EVENTS.forEach((e, i) => { const n = m.SFX_EVENTS.filter((x) => x.t >= e.t && x.t < e.t + 1).length; maxD = Math.max(maxD, n); }); console.log('max events/sec', maxD);
console.log('first/last', m.SFX_EVENTS[0].t.toFixed(2), m.SFX_EVENTS[m.SFX_EVENTS.length - 1].t.toFixed(2));
