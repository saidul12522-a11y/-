# তিকতক গজল — Islamic Motion Graphics (Remotion)

রং: Midnight Islamic Blue (হালকা লেআউট) — Background `#F5F2E9`, Hero `#173D68`, Accent `#D9B76E`, Text `#08172D`
Composition: `Main` · 1920×1080 · 30fps · ৫০৯৮ ফ্রেম (~১৬৯.৯৩ সেকেন্ড) · Entry: `src/index.ts`

## কমান্ড
```
npm install
npx remotion studio
npx remotion render src/index.ts Main out/video.mp4
```

## গঠন
- `public/tiktokgojol_ben.srt` — একমাত্র Timing Source। বদলালে: `node scripts/build-cues.mjs`
- `src/theme.ts` — সব রং, ফন্ট, Easing, Spring, Layout
- `src/timeline.ts` — SRT থেকে শব্দ-টাইমিং, ক্যাপশন পেজ, সিনের সীমানা
- `src/scenes/S01…S15` — প্রতিটি সিন আলাদা ফাইলে
- `src/components/` — Captions, Kinetic, Stage, Art, Silhouettes, Overlays, PreviewAudio, SfxTrack
- `src/sfx.ts` + `public/sfx/*.wav` — সংযত, বাদ্যযন্ত্রহীন SFX (`node scripts/make-sfx.mjs` দিয়ে পুনরায় তৈরি)
- `public/fonts/` — Hind Siliguri + Noto Sans Bengali (অফলাইন)
- `public/voiceover.mp3` — Studio-তে সিঙ্ক যাচাইয়ের জন্য চলে

## অডিও
- Studio/Player-এ voiceover চলে। Render-এ ডিফল্টে বন্ধ (`src/components/PreviewAudio.tsx` → `VOICEOVER_IN_RENDER = false`)।
- SFX Render-এ যুক্ত থাকে।

## QC স্ক্রিপ্ট
```
npm run typecheck
node scripts/check-sfx.mjs                 # SFX peak/clipping
node scripts/qc-stills.mjs out/qc 12s 60s  # নির্বাচিত ফ্রেমের Still
node scripts/print-plan.mjs                # সিন ও ক্যাপশন টাইমিং (esbuild লাগে)
```

## নকশা-নীতি
- শুধু ইসলামি দৃশ্য ও প্রতীক: মসজিদ, মিনার, গম্বুজ, ফানুস (খিলান-জানালা), মিহরাব-আর্চ, ৮-পাপড়ির পদ্ম ও ৮-কোণা ইসলামি তারা (একক পলিগন), অর্ধচন্দ্র।
- অন্য কোনো ধর্মের প্রতীক বা লোগো (ক্রুশের মতো "+" আকার, ওভারল্যাপ করা বর্গ/ত্রিভুজের তারা ইত্যাদি) ব্যবহার করা হয়নি। নতুন দৃশ্য যোগ করলেও এই নিয়ম মানবেন।
