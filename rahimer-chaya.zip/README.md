# রাহিমের ছায়া — Remotion Project

- Composition ID: `RahimerChaya` (1280x720, 30fps, 8640 frames = ৪:৪৮)
- সময়: `src/timing.ts` (SRT থেকে), দৃশ্য: `src/scenes/part1.tsx` (S01–S17), `src/scenes/part2.tsx` (S18–S34)
- কিট: `src/kit/` (core, Character, Props, Backdrops)
- ক্যাপশন নেই, অডিও নেই (নীরব ভিডিও)

```
npm install
npx remotion studio
npx remotion render RahimerChaya out/rahimer-chaya.mp4
```
