import React from 'react';
import {FY, H, INK, W, clamp, rnd, st, useT} from './core';

export const Bed: React.FC<{x: number; y?: number; blanket?: boolean}> = ({x, y = FY, blanket = true}) => (
  <g>
    <rect x={x - 14} y={y - 160} width={20} height={150} rx={6} fill="#7B4B2A" {...st} />
    <rect x={x} y={y - 34} width={430} height={24} fill="#8A5A36" {...st} />
    <rect x={x} y={y - 66} width={430} height={34} rx={10} fill="#8FA3D6" {...st} />
    <ellipse cx={x + 62} cy={y - 76} rx={48} ry={17} fill="#F6F2EA" {...st} />
    {blanket && <rect x={x + 150} y={y - 92} width={286} height={42} rx={16} fill="#5E78B8" {...st} />}
  </g>
);

export const BedSleeper: React.FC<{x: number; awake?: boolean}> = ({x, awake = false}) => {
  const {f} = useT();
  const br = Math.sin(f / 22) * 2.5;
  return (
    <g>
      <Bed x={x} blanket={false} />
      <circle cx={x + 66} cy={FY - 100} r={30} fill="#D6A074" {...st} />
      <path d={`M${x + 36},${FY - 104} A30,30 0 0 1 ${x + 96},${FY - 104} Q${x + 80},${FY - 122} ${x + 60},${FY - 116} Q${x + 44},${FY - 120} ${x + 36},${FY - 104} Z`} fill="#1E1A1A" {...st} />
      {awake ? (
        <>
          <circle cx={x + 56} cy={FY - 98} r={3.5} fill={INK} />
          <circle cx={x + 76} cy={FY - 98} r={3.5} fill={INK} />
        </>
      ) : (
        <>
          <path d={`M${x + 50},${FY - 98} q6,5 12,0`} stroke={INK} strokeWidth={2.5} fill="none" />
          <path d={`M${x + 70},${FY - 98} q6,5 12,0`} stroke={INK} strokeWidth={2.5} fill="none" />
        </>
      )}
      <path d={`M${x + 100},${FY - 66} Q${x + 112},${FY - 126 + br} ${x + 175},${FY - 124 + br} L${x + 420},${FY - 112 + br} L${x + 420},${FY - 66} Z`} fill="#5E78B8" {...st} />
    </g>
  );
};

export const Desk: React.FC<{x: number; y?: number; w?: number}> = ({x, y = FY, w = 300}) => (
  <g>
    <rect x={x + 8} y={y - 86} width={w - 16} height={86} fill="#7A4E2D" {...st} />
    <rect x={x + w * 0.55} y={y - 76} width={w * 0.38} height={30} rx={4} fill="#8F6038" {...st} />
    <rect x={x} y={y - 100} width={w} height={16} rx={4} fill="#A8723F" {...st} />
  </g>
);

export const Chair: React.FC<{x: number; y?: number}> = ({x, y = FY}) => (
  <g>
    <rect x={x - 32} y={y - 160} width={64} height={100} rx={8} fill="#6E4A2E" {...st} />
    <rect x={x - 42} y={y - 62} width={84} height={14} rx={4} fill="#8A5E3B" {...st} />
    <rect x={x - 36} y={y - 48} width={8} height={48} fill="#5E3A22" />
    <rect x={x + 28} y={y - 48} width={8} height={48} fill="#5E3A22" />
  </g>
);

export const Stool: React.FC<{x: number; y?: number; h?: number}> = ({x, y = FY, h = 70}) => (
  <g>
    <rect x={x - 28} y={y - h} width={56} height={10} rx={4} fill="#8A5E3B" {...st} />
    <rect x={x - 22} y={y - h + 10} width={6} height={h - 10} fill="#5E3A22" />
    <rect x={x + 16} y={y - h + 10} width={6} height={h - 10} fill="#5E3A22" />
  </g>
);

export const Clock: React.FC<{x: number; y: number; t: string}> = ({x, y, t}) => (
  <g>
    <rect x={x - 42} y={y - 24} width={84} height={44} rx={8} fill="#1A1A22" {...st} />
    <text x={x} y={y + 8} textAnchor="middle" fontFamily="monospace" fontWeight="bold" fontSize={28} fill="#FF4B3E">{t}</text>
  </g>
);

export const Phone: React.FC<{x: number; y: number; w?: number; h?: number; mode?: string; rot?: number; sp?: number; id?: string}> = ({
  x, y, w = 62, h = 110, mode = 'feed', rot = 0, sp = 2.2, id = 'p',
}) => {
  const {f} = useT();
  const cw = w - 12;
  const ch = Math.round(h * 0.46);
  const gap = 8;
  const raw = f * sp;
  const off = raw % (ch + gap);
  const base = Math.floor(raw / (ch + gap));
  const cols = ['#E86A4A', '#4A8FE8', '#E8C34A', '#5BC48A', '#B06AE8'];
  return (
    <g transform={`translate(${x},${y}) rotate(${rot})`}>
      <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={9} fill="#14141B" {...st} />
      <defs>
        <clipPath id={'cp' + id}>
          <rect x={-w / 2 + 5} y={-h / 2 + 8} width={w - 10} height={h - 16} rx={4} />
        </clipPath>
      </defs>
      <g clipPath={`url(#cp${id})`}>
        <rect x={-w / 2 + 5} y={-h / 2 + 8} width={w - 10} height={h - 16} fill={mode === 'off' ? '#0A0A0E' : '#1D1F2A'} />
        {mode === 'feed' &&
          [0, 1, 2, 3].map((i) => {
            const yy = -h / 2 + 8 - off + i * (ch + gap);
            const ci = (((i + base) % 5) + 5) % 5;
            return (
              <g key={i}>
                <rect x={-cw / 2} y={yy} width={cw} height={ch} rx={5} fill={cols[ci]} />
                <polygon points={`${-ch * 0.1},${yy + ch / 2 - ch * 0.13} ${ch * 0.14},${yy + ch / 2} ${-ch * 0.1},${yy + ch / 2 + ch * 0.13}`} fill="#fff" opacity={0.85} />
              </g>
            );
          })}
        {mode === 'lowbat' && (
          <g opacity={Math.floor(f / 8) % 2 ? 1 : 0.3}>
            <rect x={-14} y={-8} width={28} height={16} rx={3} fill="none" stroke="#FF3B3B" strokeWidth={3} />
            <rect x={-11} y={-5} width={5} height={10} fill="#FF3B3B" />
          </g>
        )}
      </g>
    </g>
  );
};

export const Steam: React.FC<{x: number; y: number; o?: number}> = ({x, y, o = 1}) => {
  const {f} = useT();
  return (
    <g>
      {[0, 1, 2].map((i) => {
        const ph = (f * 1.4 + i * 18) % 54;
        return (
          <path key={i} d={`M${x - 8 + i * 8},${y - ph} q-6,-8 0,-16 q6,-8 0,-16`} stroke="#EDEFF7" strokeWidth={4} fill="none" strokeLinecap="round" opacity={o * (1 - ph / 54) * 0.85} />
        );
      })}
    </g>
  );
};

export const Cup: React.FC<{x: number; y: number; hot?: number; fill?: number; s?: number}> = ({x, y, hot = 0, fill = 1, s = 1}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <ellipse cx={0} cy={2} rx={30} ry={7} fill="#E8E1D4" {...st} />
    <path d="M-20,-36 L20,-36 L16,0 L-16,0 Z" fill="#F4F0E6" {...st} />
    <path d="M20,-28 Q38,-26 33,-12 Q30,-6 17,-8" fill="none" stroke={INK} strokeWidth={3} />
    <ellipse cx={0} cy={-36} rx={20} ry={5} fill="#B8793E" {...st} opacity={fill} />
    {hot > 0 && <Steam x={0} y={-44} o={hot} />}
  </g>
);

export const Plate: React.FC<{x: number; y: number; hot?: number}> = ({x, y, hot = 0}) => (
  <g>
    <ellipse cx={x} cy={y} rx={48} ry={10} fill="#F1EEE6" {...st} />
    <ellipse cx={x - 6} cy={y - 6} rx={28} ry={13} fill="#FFFFFF" {...st} />
    <ellipse cx={x + 18} cy={y - 5} rx={14} ry={8} fill="#D98A2B" />
    {hot > 0 && <Steam x={x} y={y - 16} o={hot} />}
  </g>
);

export const Book: React.FC<{x: number; y: number; open?: boolean}> = ({x, y, open = true}) =>
  open ? (
    <g>
      <polygon points={`${x - 70},${y - 8} ${x + 70},${y - 8} ${x + 70},${y + 36} ${x - 70},${y + 36}`} fill="#3E6A9A" {...st} />
      <polygon points={`${x - 64},${y - 6} ${x},${y} ${x},${y + 34} ${x - 64},${y + 28}`} fill="#FFFDF6" stroke={INK} strokeWidth={2} />
      <polygon points={`${x},${y} ${x + 64},${y - 6} ${x + 64},${y + 28} ${x},${y + 34}`} fill="#FFFDF6" stroke={INK} strokeWidth={2} />
      {[8, 15, 22].map((d) => (
        <g key={d} stroke="#9AA6BC" strokeWidth={1.5}>
          <line x1={x - 54} y1={y + d - 3} x2={x - 10} y2={y + d} />
          <line x1={x + 10} y1={y + d} x2={x + 54} y2={y + d - 3} />
        </g>
      ))}
    </g>
  ) : (
    <g>
      <rect x={x - 32} y={y - 18} width={64} height={18} fill="#3E6A9A" {...st} />
      <rect x={x - 28} y={y - 14} width={56} height={10} fill="#FFFDF6" />
    </g>
  );

export const Candle: React.FC<{x: number; y: number}> = ({x, y}) => {
  const {f} = useT();
  const fl = 1 + Math.sin(f / 3) * 0.12 + Math.sin(f / 1.7) * 0.08;
  return (
    <g>
      <rect x={x - 9} y={y - 48} width={18} height={48} rx={3} fill="#F2E9D0" {...st} />
      <ellipse cx={x + Math.sin(f / 4) * 1.5} cy={y - 62} rx={7 * fl * 0.9} ry={13 * fl} fill="#FFC23D" />
      <ellipse cx={x} cy={y - 60} rx={3.5} ry={7} fill="#FFF1B0" />
    </g>
  );
};

export const Box: React.FC<{x: number; y: number; open?: number}> = ({x, y, open = 0}) => (
  <g>
    <rect x={x - 60} y={y - 50} width={120} height={50} fill="#E7C26B" {...st} />
    <g transform={`translate(${x - 60},${y - 50}) rotate(${-open * 100})`}>
      <rect x={0} y={-14} width={120} height={14} fill="#D6AE4F" {...st} />
    </g>
  </g>
);

export const Door: React.FC<{x: number; y?: number; w?: number; h?: number; light?: number}> = ({x, y = FY, w = 150, h = 300, light = 0}) => (
  <g>
    <rect x={x - 10} y={y - h - 10} width={w + 20} height={h + 10} fill="#5A3B25" {...st} />
    <rect x={x} y={y - h} width={w} height={h} fill="#9A6A3F" {...st} />
    <rect x={x + 16} y={y - h + 20} width={w - 32} height={h * 0.38} rx={4} fill="#8A5C34" stroke={INK} strokeWidth={2} />
    <rect x={x + 16} y={y - h * 0.5} width={w - 32} height={h * 0.42} rx={4} fill="#8A5C34" stroke={INK} strokeWidth={2} />
    <circle cx={x + w - 18} cy={y - h / 2} r={6} fill="#E3C25A" stroke={INK} strokeWidth={2} />
    {light > 0 && <rect x={x + 8} y={y - 8} width={w - 16} height={8} fill="#BFD8FF" opacity={light} />}
  </g>
);

export const Minaret: React.FC<{x: number; y?: number; s?: number}> = ({x, y = FY, s = 1}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x={-26} y={-300} width={52} height={300} fill="#D9CDB4" {...st} />
    <rect x={-38} y={-330} width={76} height={30} fill="#D9CDB4" {...st} />
    <path d="M-30,-330 Q0,-420 30,-330 Z" fill="#7BB7A0" {...st} />
    <line x1={0} y1={-385} x2={0} y2={-418} stroke={INK} strokeWidth={3} />
    <circle cx={0} cy={-424} r={6} fill="#E3C25A" stroke={INK} strokeWidth={2} />
    <rect x={-8} y={-250} width={16} height={34} rx={8} fill="#6B5A44" />
  </g>
);

export const Arcs: React.FC<{x: number; y: number; c?: string}> = ({x, y, c = '#FFFFFF'}) => {
  const {f} = useT();
  return (
    <g fill="none" stroke={c} strokeWidth={3}>
      {[0, 1, 2].map((i) => {
        const r = (f * 1.3 + i * 28) % 84;
        return <circle key={i} cx={x} cy={y} r={r} opacity={0.7 * (1 - r / 84)} />;
      })}
    </g>
  );
};

export const Bike: React.FC<{x: number; y?: number; s?: number; ring?: boolean}> = ({x, y = FY, s = 1, ring = false}) => {
  const {f} = useT();
  const wheel = (cx: number) => (
    <g key={cx}>
      <circle cx={cx} cy={-45} r={45} fill="none" stroke={INK} strokeWidth={5} />
      {[0, 1, 2, 3].map((i) => (
        <line key={i} x1={cx} y1={-45} x2={cx + Math.cos(f / 6 + (i * Math.PI) / 2) * 43} y2={-45 + Math.sin(f / 6 + (i * Math.PI) / 2) * 43} stroke="#555" strokeWidth={1.5} />
      ))}
    </g>
  );
  const rr = (f * 1.5) % 34;
  return (
    <g transform={`translate(${x},${y}) scale(${s})`}>
      {wheel(-60)}
      {wheel(60)}
      <path d="M-60,-45 L-10,-100 L50,-100 L60,-45 M-10,-100 L10,-45 L-60,-45 M50,-100 L42,-130 M30,-132 L60,-132" stroke="#B5392E" strokeWidth={6} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={30} cy={-140} r={8} fill="#E3C25A" stroke={INK} strokeWidth={2} />
      {ring && <circle cx={30} cy={-140} r={8 + rr} fill="none" stroke="#fff" strokeWidth={2.5} opacity={1 - rr / 34} />}
    </g>
  );
};

export const Palm: React.FC<{x: number; y?: number; s?: number; sway?: number}> = ({x, y = FY, s = 1, sway = 0}) => {
  const {f} = useT();
  const sw = Math.sin(f / 20) * (3 + sway);
  return (
    <g transform={`translate(${x},${y}) scale(${s})`}>
      <path d={`M0,0 Q${12 + sw},-130 ${sw * 2},-260`} stroke="#6B4A2E" strokeWidth={14} fill="none" strokeLinecap="round" />
      <g transform={`translate(${sw * 2},-260)`}>
        {[-70, -35, 0, 35, 70].map((a, i) => (
          <path key={i} d={`M0,0 Q${Math.sin((a * Math.PI) / 180) * 60},${-30 - Math.abs(a) * 0.2} ${Math.sin((a * Math.PI) / 180) * 110},${40 - Math.abs(a) * 0.2}`} stroke="#3F8A4F" strokeWidth={9} fill="none" strokeLinecap="round" />
        ))}
      </g>
    </g>
  );
};

export const Rain: React.FC<{n?: number; o?: number; x0?: number; x1?: number; y0?: number; y1?: number; sp?: number}> = ({
  n = 90, o = 0.5, x0 = 0, x1 = W, y0 = 0, y1 = H, sp = 26,
}) => {
  const {f} = useT();
  return (
    <g opacity={o}>
      {Array.from({length: n}, (_, i) => {
        const x = x0 + rnd(i) * (x1 - x0);
        const y = y0 + ((rnd(i + 50) * (y1 - y0) + f * sp) % (y1 - y0));
        return <line key={i} x1={x} y1={y} x2={x - 6} y2={y + 22} stroke="#BFD4F5" strokeWidth={2} strokeLinecap="round" />;
      })}
    </g>
  );
};

export const Smoke: React.FC<{x: number; y: number; p: number; n?: number; spread?: number; vx?: number; c?: string}> = ({
  x, y, p, n = 20, spread = 90, vx = 40, c = '#15101A',
}) => (
  <g>
    {Array.from({length: n}, (_, i) => {
      const d = rnd(i * 3 + 1);
      const t = clamp(p * 1.4 - d * 0.5);
      const px = x + (rnd(i) - 0.5) * spread + t * vx * 3;
      const py = y - t * 230 * (0.5 + d);
      const r = 14 + t * 46 * (0.6 + d);
      return <circle key={i} cx={px} cy={py} r={r} fill={c} opacity={Math.max(0, 1 - t) * 0.55} filter="url(#b8)" />;
    })}
  </g>
);

export const Motes: React.FC<{n?: number; x0: number; x1: number; y0: number; y1: number}> = ({n = 26, x0, x1, y0, y1}) => {
  const {f} = useT();
  return (
    <g fill="#FFF6D0" style={{mixBlendMode: 'screen'}}>
      {Array.from({length: n}, (_, i) => {
        const x = x0 + rnd(i) * (x1 - x0) + Math.sin(f / 30 + i) * 14;
        const y = y0 + ((rnd(i + 9) * (y1 - y0) - f * (0.3 + rnd(i + 4) * 0.5)) % (y1 - y0) + (y1 - y0)) % (y1 - y0);
        return <circle key={i} cx={x} cy={y} r={1.5 + rnd(i + 2) * 2.2} opacity={0.4 + 0.5 * Math.abs(Math.sin(f / 20 + i))} />;
      })}
    </g>
  );
};

export const Paper: React.FC<{x: number; y: number; w?: number; h?: number; rot?: number; marks?: number}> = ({
  x, y, w = 420, h = 540, rot = 0, marks = 1,
}) => {
  const sc = w / 420;
  const vis = (i: number) => clamp(marks * 8 - i);
  return (
    <g transform={`translate(${x},${y}) rotate(${rot}) scale(${sc})`}>
      <rect x={-200} y={-258} width={420} height={540} fill="#000" opacity={0.22} />
      <rect x={-210} y={-270} width={420} height={540} fill="#FFFDF4" {...st} />
      {Array.from({length: 9}, (_, i) => (
        <g key={i}>
          <line x1={-170} y1={-180 + i * 44} x2={170} y2={-180 + i * 44} stroke="#B8C7E0" strokeWidth={2} />
          <path d={`M-160,${-192 + i * 44} q20,-8 40,0 t40,0 t40,0 t30,0`} stroke="#4A5A7A" strokeWidth={2.5} fill="none" />
        </g>
      ))}
      <circle cx={120} cy={-205} r={46} fill="none" stroke="#E02B2B" strokeWidth={7} opacity={vis(0)} />
      {[1, 3, 5, 7].map((r, j) => (
        <g key={r} stroke="#E02B2B" strokeWidth={7} strokeLinecap="round" opacity={vis(j + 1)}>
          <line x1={150} y1={-190 + r * 44 - 18} x2={186} y2={-190 + r * 44 + 18} />
          <line x1={186} y1={-190 + r * 44 - 18} x2={150} y2={-190 + r * 44 + 18} />
        </g>
      ))}
      <path d="M-180,-60 Q-60,-40 20,-70 T180,-40" stroke="#E02B2B" strokeWidth={6} fill="none" strokeLinecap="round" opacity={vis(6)} />
      <path d="M-170,170 L170,120" stroke="#E02B2B" strokeWidth={9} strokeLinecap="round" opacity={vis(7)} />
    </g>
  );
};

/** রাহিমের ওপর চেপে বসা ছায়া-দানব */
export const Shade: React.FC<{
  x: number; y?: number; s?: number; alpha?: number; glow?: number; eyes?: number; arm?: [number, number] | null;
}> = ({x, y = FY, s = 1, alpha = 1, glow = 1, eyes = 1, arm = null}) => {
  const {f} = useT();
  const blob = (cx: number, cy: number, rx: number, ry: number, seed: number) => {
    let d = '';
    for (let i = 0; i < 24; i++) {
      const a = (i / 24) * Math.PI * 2;
      const r = 1 + 0.07 * Math.sin(3 * a + f / 9 + seed) + 0.05 * Math.sin(5 * a - f / 7 + seed * 2);
      d += `${i ? 'L' : 'M'}${(cx + Math.cos(a) * rx * r).toFixed(1)},${(cy + Math.sin(a) * ry * r).toFixed(1)}`;
    }
    return d + 'Z';
  };
  const body = blob(0, -130, 72, 125, 0);
  const head = blob(0, -268, 44, 48, 2);
  let armD = '';
  if (arm) {
    const tx = (arm[0] - x) / s;
    const ty = (arm[1] - y) / s;
    armD = `M-40,-170 Q${(tx - 40) / 2},${ty - 80} ${tx},${ty}`;
  }
  return (
    <g transform={`translate(${x},${y}) scale(${s})`} opacity={alpha}>
      <g filter="url(#b20)" opacity={0.7 * glow} fill="#FF2438" stroke="#FF2438" strokeWidth={26}>
        <path d={body} />
        <path d={head} />
        {arm && <path d={armD} fill="none" strokeWidth={34} strokeLinecap="round" />}
      </g>
      <g fill="#07050B" stroke="#07050B" strokeWidth={4} strokeLinejoin="round">
        <path d={body} />
        <path d={head} />
        {arm && <path d={armD} fill="none" strokeWidth={26} strokeLinecap="round" />}
      </g>
      <g opacity={eyes}>
        <ellipse cx={-16} cy={-272} rx={13} ry={5} fill="#FF3030" filter="url(#b3)" transform="rotate(14 -16 -272)" />
        <ellipse cx={16} cy={-272} rx={13} ry={5} fill="#FF3030" filter="url(#b3)" transform="rotate(-14 16 -272)" />
        <ellipse cx={-16} cy={-272} rx={10} ry={3.5} fill="#FF7A7A" transform="rotate(14 -16 -272)" />
        <ellipse cx={16} cy={-272} rx={10} ry={3.5} fill="#FF7A7A" transform="rotate(-14 16 -272)" />
      </g>
    </g>
  );
};

export const Stove: React.FC<{x: number}> = ({x}) => (
  <g>
    <rect x={x} y={FY - 90} width={200} height={90} fill="#8A6A4A" {...st} />
    <rect x={x} y={FY - 100} width={200} height={12} fill="#6E5338" {...st} />
    <rect x={x + 50} y={FY - 160} width={100} height={60} rx={8} fill="#9AA3AD" {...st} />
    <rect x={x + 44} y={FY - 168} width={112} height={12} rx={4} fill="#B9C1CA" {...st} />
  </g>
);

export const Thumb: React.FC<{x: number; y: number; rot?: number}> = ({x, y, rot = 0}) => (
  <rect x={x - 34} y={y} width={68} height={260} rx={34} fill="#D6A074" stroke={INK} strokeWidth={4} transform={`rotate(${rot} ${x} ${y + 130})`} />
);

export const Bag: React.FC<{x: number; y?: number}> = ({x, y = FY}) => (
  <g>
    <rect x={x - 38} y={y - 90} width={76} height={90} rx={14} fill="#E34A4A" {...st} />
    <rect x={x - 28} y={y - 52} width={56} height={32} rx={8} fill="#C23A3A" stroke={INK} strokeWidth={2.5} />
    <path d={`M${x - 20},${y - 90} Q${x},${y - 120} ${x + 20},${y - 90}`} fill="none" stroke={INK} strokeWidth={5} />
  </g>
);
