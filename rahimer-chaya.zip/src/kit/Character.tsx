import React from 'react';
import {FY, INK, useT} from './core';

export type Kind = 'rahim' | 'maa' | 'baba' | 'bon' | 'f1' | 'f2';

type Spec = {
  skin: string; hair: string; style: 'short' | 'bun' | 'braids' | 'cap' | 'messy';
  top: string; bottom: string; dress: 'none' | 'saree' | 'kurta' | 'skirt'; scale: number;
};

const SPEC: Record<Kind, Spec> = {
  rahim: {skin: '#D6A074', hair: '#1E1A1A', style: 'messy', top: '#3E6FB0', bottom: '#3B4252', dress: 'none', scale: 1},
  maa: {skin: '#D6A074', hair: '#1E1A1A', style: 'bun', top: '#B5476B', bottom: '#B5476B', dress: 'saree', scale: 1},
  baba: {skin: '#C98F63', hair: '#CFCFCF', style: 'cap', top: '#E9E2C8', bottom: '#E9E2C8', dress: 'kurta', scale: 1.03},
  bon: {skin: '#D9A87E', hair: '#1E1A1A', style: 'braids', top: '#FFFFFF', bottom: '#2D4A8A', dress: 'skirt', scale: 0.72},
  f1: {skin: '#C58E64', hair: '#1E1A1A', style: 'short', top: '#D8503F', bottom: '#4A5A3A', dress: 'none', scale: 0.96},
  f2: {skin: '#E0AF84', hair: '#3A2A1E', style: 'messy', top: '#3FA36B', bottom: '#6B5B4A', dress: 'none', scale: 1},
};

// [বাম কনুই(x,y), বাম হাত(x,y), ডান কনুই(x,y), ডান হাত(x,y)] — কাঁধ থেকে অফসেট
const ARMS: Record<string, number[]> = {
  down: [-6, 44, -8, 86, 6, 44, 8, 86],
  phone: [-2, 50, 44, 38, 2, 50, -44, 38],
  upphone: [-14, 18, 40, 6, 14, 18, -40, 6],
  desk: [-14, 26, 10, 26, 14, 26, -10, 26],
  cry: [-18, 25, 40, -40, 18, 25, -40, -40],
  wave: [-6, 44, -8, 86, 46, 20, 58, -34],
  cup: [-6, 44, -8, 86, 30, 48, 44, 34],
  hold: [-6, 50, 30, 50, 6, 50, -30, 50],
  point: [-6, 44, -8, 86, 50, 26, 96, 18],
  stir: [-6, 44, -8, 86, 40, 34, 64, 14],
};

const EX: Record<string, {b: number; m: string; e: string; c?: boolean; t?: boolean}> = {
  neutral: {b: 0, m: 'flat', e: 'open'},
  happy: {b: -6, m: 'smile', e: 'open'},
  sad: {b: 7, m: 'frown', e: 'open'},
  tired: {b: -2, m: 'flat', e: 'half', c: true},
  scared: {b: -9, m: 'o', e: 'wide'},
  cry: {b: 8, m: 'frown', e: 'open', t: true},
  surprised: {b: -10, m: 'o', e: 'wide'},
  sleep: {b: 0, m: 'smile', e: 'closed'},
  blank: {b: 0, m: 'flat', e: 'open', c: true},
};

export const HEAD_Y = -235;

type Props = {
  kind: Kind; x: number; y?: number; flip?: boolean; sit?: boolean; arms?: string; expr?: string;
  look?: [number, number]; s?: number; wag?: number; tilt?: number; walk?: boolean;
};

export const Character: React.FC<Props> = ({
  kind, x, y = FY, flip = false, sit = false, arms = 'down', expr = 'neutral',
  look = [0, 0], s = 1, wag = 0, tilt = 0, walk = false,
}) => {
  const {f} = useT();
  const sp = SPEC[kind];
  const ex = EX[expr] ?? EX.neutral;
  const dy = sit ? 52 : 0;
  const bob = Math.sin(f / 18) * 2 + (walk ? -Math.abs(Math.sin(f / 4)) * 8 : 0);
  const A = ARMS[arms] ?? ARMS.down;
  const w = wag ? Math.sin(f / 3) * wag : 0;
  const blink = (f + kind.charCodeAt(0) * 7) % 96 < 4;
  const legCol = sp.dress === 'skirt' ? sp.skin : sp.bottom;

  const leg = (side: number) => {
    const swing = walk ? Math.sin(f / 4 + (side > 0 ? 0 : Math.PI)) * 22 : 0;
    const fx = sit ? side * 44 : side * 16 + swing;
    const d = sit
      ? `M${side * 16},-50 L${side * 44},-48 L${fx},-12`
      : `M${side * 14},-100 L${fx},-12`;
    return (
      <g key={side}>
        <path d={d} stroke={INK} strokeWidth={26} strokeLinecap="round" strokeLinejoin="round" fill="none" />
        <path d={d} stroke={legCol} strokeWidth={20} strokeLinecap="round" strokeLinejoin="round" fill="none" />
        <ellipse cx={fx + side * 4} cy={-5} rx={15} ry={8} fill="#3a2d2d" stroke={INK} strokeWidth={2.5} />
      </g>
    );
  };

  const arm = (sx: number, e: number[], isRight: boolean) => {
    const sy = -182;
    const hy = e[3] + (isRight ? w : 0);
    const d = `M${sx},${sy} L${sx + e[0]},${sy + e[1]} L${sx + e[2]},${sy + hy}`;
    return (
      <g key={sx}>
        <path d={d} stroke={INK} strokeWidth={24} strokeLinecap="round" strokeLinejoin="round" fill="none" />
        <path d={d} stroke={sp.top} strokeWidth={18} strokeLinecap="round" strokeLinejoin="round" fill="none" />
        <circle cx={sx + e[2]} cy={sy + hy} r={10} fill={sp.skin} stroke={INK} strokeWidth={2.5} />
      </g>
    );
  };
  const armsEl = (
    <g transform={`translate(0,${dy + bob * 0.5})`}>
      {arm(-34, A.slice(0, 4), false)}
      {arm(34, A.slice(4, 8), true)}
    </g>
  );

  const torso = (
    <g transform={`translate(0,${dy + bob * 0.5})`}>
      {sp.dress === 'saree' && (
        <path d="M-34,-110 L-46,-8 L46,-8 L34,-110 Z" fill={sp.bottom} stroke={INK} strokeWidth={3} strokeLinejoin="round" />
      )}
      {sp.dress === 'skirt' && (
        <path d="M-34,-110 L-46,-50 L46,-50 L34,-110 Z" fill={sp.bottom} stroke={INK} strokeWidth={3} strokeLinejoin="round" />
      )}
      <rect x={-33} y={-192} width={66} height={sp.dress === 'kurta' ? 136 : 96} rx={20} fill={sp.top} stroke={INK} strokeWidth={3} />
      {sp.dress === 'saree' && (
        <path d="M-30,-186 L30,-110 L30,-70 L-4,-100 L-30,-130 Z" fill="#8E2F52" stroke={INK} strokeWidth={2.5} strokeLinejoin="round" />
      )}
    </g>
  );

  const hairTop = 'M-41,-236 A41,41 0 0 1 41,-236 Q30,-256 8,-250 Q-14,-258 -41,-236 Z';
  const hair = (() => {
    const c = sp.hair;
    if (sp.style === 'cap')
      return <path d="M-40,-248 Q0,-296 40,-248 L40,-244 L-40,-244 Z" fill="#F7F5EE" stroke={INK} strokeWidth={3} />;
    return (
      <g>
        {sp.style === 'bun' && <circle cx={0} cy={-288} r={15} fill={c} stroke={INK} strokeWidth={3} />}
        {sp.style === 'braids' && (
          <>
            <ellipse cx={-44} cy={-205} rx={8} ry={30} fill={c} stroke={INK} strokeWidth={2.5} />
            <ellipse cx={44} cy={-205} rx={8} ry={30} fill={c} stroke={INK} strokeWidth={2.5} />
          </>
        )}
        <path d={hairTop} fill={c} stroke={INK} strokeWidth={3} />
        {sp.style === 'messy' && (
          <path d="M-30,-270 L-24,-288 L-12,-272 L0,-292 L12,-272 L26,-288 L30,-270 Z" fill={c} stroke={INK} strokeWidth={2.5} strokeLinejoin="round" />
        )}
      </g>
    );
  })();

  const eyes = [-14, 14].map((sx) => {
    const cy = -238;
    if (ex.e === 'closed')
      return <path key={sx} d={`M${sx - 8},${cy} Q${sx},${cy + 6} ${sx + 8},${cy}`} stroke={INK} strokeWidth={3} fill="none" strokeLinecap="round" />;
    const ry = (ex.e === 'wide' ? 11 : 9) * (blink ? 0.12 : 1);
    return (
      <g key={sx}>
        {ex.c && <ellipse cx={sx} cy={cy + 12} rx={9} ry={4} fill="#8B5E6B" opacity={0.4} />}
        <ellipse cx={sx} cy={cy} rx={8} ry={ry} fill="#fff" stroke={INK} strokeWidth={2} />
        {!blink && <circle cx={sx + look[0]} cy={cy + look[1]} r={4} fill={INK} />}
        {ex.e === 'half' && <rect x={sx - 9} y={cy - 11} width={18} height={11} fill={sp.skin} />}
        {ex.e === 'half' && <line x1={sx - 9} y1={cy} x2={sx + 9} y2={cy} stroke={INK} strokeWidth={2} />}
      </g>
    );
  });

  const by = -256 + (ex.b < 0 ? ex.b : 0);
  const sl = ex.b > 0 ? ex.b : 0;
  const brows = (
    <g stroke={INK} strokeWidth={4} strokeLinecap="round">
      <line x1={-22} y1={by + sl * 0.5} x2={-6} y2={by - sl * 0.5} />
      <line x1={6} y1={by - sl * 0.5} x2={22} y2={by + sl * 0.5} />
    </g>
  );

  const mouth = (() => {
    const my = -212;
    if (ex.m === 'smile') return <path d={`M-11,${my - 2} Q0,${my + 10} 11,${my - 2}`} stroke={INK} strokeWidth={3} fill="none" strokeLinecap="round" />;
    if (ex.m === 'frown') return <path d={`M-9,${my + 4} Q0,${my - 5} 9,${my + 4}`} stroke={INK} strokeWidth={3} fill="none" strokeLinecap="round" />;
    if (ex.m === 'o') return <ellipse cx={0} cy={my} rx={5} ry={6.5} fill="#5A2A2A" stroke={INK} strokeWidth={2} />;
    return <line x1={-8} y1={my} x2={8} y2={my} stroke={INK} strokeWidth={3} strokeLinecap="round" />;
  })();

  const tears = ex.t
    ? [-14, 14].map((sx, i) => {
        const ph = (f * 1.6 + i * 20) % 44;
        return <ellipse key={sx} cx={sx + (sx < 0 ? -2 : 2)} cy={-228 + ph} rx={3.5} ry={5} fill="#8EC9F5" opacity={1 - ph / 52} />;
      })
    : null;

  const head = (
    <g transform={`translate(0,${dy + bob}) rotate(${tilt} 0 -200)`}>
      <rect x={-8} y={-206} width={16} height={18} fill={sp.skin} stroke={INK} strokeWidth={2.5} />
      <circle cx={-40} cy={-232} r={7} fill={sp.skin} stroke={INK} strokeWidth={2.5} />
      <circle cx={40} cy={-232} r={7} fill={sp.skin} stroke={INK} strokeWidth={2.5} />
      <circle cx={0} cy={HEAD_Y} r={41} fill={sp.skin} stroke={INK} strokeWidth={3} />
      {hair}
      {sp.style === 'cap' && <path d="M-14,-214 Q0,-206 14,-214" stroke="#8A8A8A" strokeWidth={5} fill="none" strokeLinecap="round" />}
      {eyes}
      {brows}
      {mouth}
      {tears}
    </g>
  );

  return (
    <g transform={`translate(${x},${y}) scale(${(flip ? -1 : 1) * s * sp.scale},${s * sp.scale})`}>
      {sp.dress !== 'saree' && leg(-1)}
      {sp.dress !== 'saree' && leg(1)}
      {sp.dress === 'saree' && [-1, 1].map((sd) => <ellipse key={sd} cx={sd * 18} cy={-5} rx={15} ry={8} fill="#3a2d2d" stroke={INK} strokeWidth={2.5} />)}
      {torso}
      {arms !== 'cry' && armsEl}
      {head}
      {arms === 'cry' && armsEl}
    </g>
  );
};
