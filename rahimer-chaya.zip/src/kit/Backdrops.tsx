import React from 'react';
import {FY, INK, SKY, SkyRect, rnd, st} from './core';
import {Door, Palm, Rain} from './Props';

const Win: React.FC<{x: number; y: number; w: number; h: number; sky: [string, string]; shut: number; rain: boolean}> = ({
  x, y, w, h, sky, shut, rain,
}) => (
  <g>
    <rect x={x - 12} y={y - 12} width={w + 24} height={h + 24} fill="#8A5E3B" {...st} />
    <defs>
      <clipPath id="wclip">
        <rect x={x} y={y} width={w} height={h} />
      </clipPath>
    </defs>
    <g clipPath="url(#wclip)">
      <rect x={x} y={y} width={w} height={h * 0.55} fill={sky[0]} />
      <rect x={x} y={y + h * 0.55} width={w} height={h * 0.45} fill={sky[1]} />
      {rain && <Rain n={30} x0={x} x1={x + w} y0={y} y1={y + h} o={0.6} sp={20} />}
      <rect x={x} y={y} width={(w / 2) * shut} height={h} fill="#7A5230" stroke={INK} strokeWidth={2} />
      <rect x={x + w - (w / 2) * shut} y={y} width={(w / 2) * shut} height={h} fill="#7A5230" stroke={INK} strokeWidth={2} />
    </g>
    {shut < 0.5 && (
      <g stroke="#8A5E3B" strokeWidth={6}>
        <line x1={x + w / 2} y1={y} x2={x + w / 2} y2={y + h} />
        <line x1={x} y1={y + h / 2} x2={x + w} y2={y + h / 2} />
      </g>
    )}
  </g>
);

/** শোবার ঘর / রান্নাঘর: মেঝে FY=560, জানালা x=700..920 */
export const Room: React.FC<{
  sky?: [string, string]; shut?: number; door?: boolean; rain?: boolean; dec?: boolean; wall?: string; floor?: string;
}> = ({sky = SKY.day, shut = 0, door = false, rain = false, dec = true, wall = '#F2DFC3', floor = '#B98558'}) => (
  <g>
    <rect x={-700} y={-500} width={2700} height={FY + 500} fill={wall} />
    <rect x={-700} y={FY - 120} width={2700} height={120} fill="#E4C9A0" />
    <rect x={-700} y={FY - 10} width={2700} height={10} fill="#8A5E3B" />
    <rect x={-700} y={FY} width={2700} height={400} fill={floor} />
    <line x1={-700} y1={FY + 70} x2={2000} y2={FY + 70} stroke="#9C6D43" strokeWidth={3} />
    <line x1={-700} y1={FY + 130} x2={2000} y2={FY + 130} stroke="#9C6D43" strokeWidth={3} />
    <Win x={700} y={110} w={220} h={250} sky={sky} shut={shut} rain={rain} />
    {dec && (
      <g>
        <rect x={130} y={200} width={230} height={12} fill="#8A5E3B" {...st} />
        {[0, 1, 2, 3, 4].map((i) => (
          <rect key={i} x={142 + i * 40} y={160 + (i % 2) * 8} width={32} height={40 - (i % 2) * 8} fill={['#C0504D', '#4F81BD', '#9BBB59', '#F79646', '#8064A2'][i]} stroke={INK} strokeWidth={2} />
        ))}
        <rect x={470} y={140} width={70} height={92} fill="#FFFDF4" {...st} />
        <rect x={470} y={140} width={70} height={22} fill="#C0504D" {...st} />
      </g>
    )}
    {door && <Door x={1040} />}
  </g>
);

export const HOUSES = [
  {x: 60, w: 230, h: 150},
  {x: 330, w: 210, h: 125},
  {x: 575, w: 270, h: 170},
  {x: 890, w: 220, h: 140},
  {x: 1140, w: 240, h: 160},
];

/** গ্রামের বাড়ি (বাইরে থেকে) */
export const Village: React.FC<{sky?: string; lit?: number[]; ground?: string; palms?: number}> = ({
  sky = 'night', lit = [], ground = '#4A6B42', palms = 0,
}) => {
  const sk = SKY[sky];
  return (
    <g>
      <SkyRect sky={sk} y0={-500} y1={FY} />
      {sky === 'night' &&
        Array.from({length: 50}, (_, i) => (
          <circle key={i} cx={rnd(i) * 1500 - 100} cy={rnd(i + 7) * 330} r={0.8 + rnd(i + 3) * 1.6} fill="#fff" opacity={0.5 + 0.5 * rnd(i + 9)} />
        ))}
      {sky === 'night' && (
        <>
          <circle cx={1000} cy={110} r={34} fill="#F5F0D0" />
          <circle cx={1014} cy={102} r={30} fill={sk[0]} />
        </>
      )}
      {sky === 'dawn' && <circle cx={420} cy={FY - 40} r={70} fill="#FFE4A0" opacity={0.9} />}
      <rect x={-700} y={FY - 40} width={2700} height={400} fill={ground} />
      {HOUSES.map((h, i) => (
        <g key={i}>
          <rect x={h.x} y={FY - h.h} width={h.w} height={h.h} fill="#C9B08A" {...st} />
          <path d={`M${h.x - 14},${FY - h.h} L${h.x + 20},${FY - h.h - 46} L${h.x + h.w - 20},${FY - h.h - 46} L${h.x + h.w + 14},${FY - h.h} Z`} fill="#6E7782" {...st} />
          <rect x={h.x + h.w / 2 - 20} y={FY - h.h + 50} width={40} height={40} fill={lit.includes(i) ? '#FFD56B' : '#27304A'} {...st} />
          <rect x={h.x + 20} y={FY - 70} width={36} height={70} fill="#6A4A32" />
        </g>
      ))}
      <Palm x={20} s={1.0} sway={palms} />
      <Palm x={870} s={0.9} sway={palms} />
    </g>
  );
};

/** উঠান / মাঠ */
export const Yard: React.FC<{sky?: [string, string]; wet?: boolean; field?: boolean}> = ({sky = SKY.day, wet = false, field = false}) => (
  <g>
    <SkyRect sky={sky} y0={-500} y1={FY - 60} />
    <path d="M-700,500 Q-300,430 100,490 T900,480 T1700,490 L1700,600 L-700,600 Z" fill="#5E9A55" />
    <rect x={-700} y={FY - 60} width={2700} height={500} fill={field ? '#6DAE5B' : '#9ACB6E'} />
    {!field && <path d="M-700,640 Q200,590 640,620 T1700,610 L1700,760 L-700,760 Z" fill="#C9A36B" />}
    {wet &&
      [[380, FY + 70, 120], [720, FY + 110, 150], [1000, FY + 80, 100]].map(([cx, cy, rx], i) => (
        <ellipse key={i} cx={cx} cy={cy} rx={rx} ry={18} fill={sky[0]} stroke="#6E9AB8" strokeWidth={2} opacity={0.85} />
      ))}
  </g>
);

/** বারান্দা (রাত) */
export const Veranda: React.FC<{sky?: [string, string]}> = ({sky = SKY.night}) => (
  <g>
    <SkyRect sky={sky} y0={-500} y1={FY} />
    <rect x={-700} y={-500} width={2700} height={590} fill="#7A5A3C" />
    <rect x={-700} y={FY - 110} width={2700} height={110} fill="#CDBFA4" {...st} />
    {[100, 640, 1180].map((px) => (
      <rect key={px} x={px - 22} y={80} width={44} height={FY - 80} fill="#B8A07C" {...st} />
    ))}
    <rect x={-700} y={FY} width={2700} height={400} fill="#8B6B4A" />
    <line x1={-700} y1={FY + 80} x2={2000} y2={FY + 80} stroke="#6E5238" strokeWidth={3} />
  </g>
);

/** চায়ের দোকান */
export const Stall: React.FC = () => (
  <g>
    <rect x={380} y={FY - 250} width={14} height={250} fill="#6B4A2E" />
    <rect x={930} y={FY - 250} width={14} height={250} fill="#6B4A2E" />
    <path d="M340,300 L430,230 L890,230 L980,300 Z" fill="#B5392E" {...st} />
    <rect x={340} y={300} width={640} height={16} fill="#8A2A22" {...st} />
    <rect x={420} y={FY - 110} width={500} height={110} fill="#8A5E3B" {...st} />
    <rect x={410} y={FY - 124} width={520} height={16} fill="#A8723F" {...st} />
    <path d="M520,436 Q520,396 560,396 L600,396 Q620,396 620,436 Z" fill="#9AA3AD" {...st} />
  </g>
);
