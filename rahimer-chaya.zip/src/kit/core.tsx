import React, {createContext, useContext} from 'react';
import {AbsoluteFill, Sequence, interpolate, interpolateColors, useCurrentFrame} from 'remotion';

export const W = 1280;
export const H = 720;
export const FPS = 30;
export const FY = 560; // মেঝের লাইন
export const INK = '#2B2230';
export const st = {stroke: INK, strokeWidth: 3, strokeLinejoin: 'round' as const};

export const DurCtx = createContext<number>(FPS);

export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * clamp(t);
export const ease = (t: number) => {
  t = clamp(t);
  return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
};
export const rnd = (n: number) => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

/** f = লোকাল ফ্রেম, s = সেকেন্ড, p = 0..1 অগ্রগতি, k(a,b) = a..b সেকেন্ডের মধ্যে 0..1 */
export const useT = () => {
  const f = useCurrentFrame();
  const d = useContext(DurCtx);
  const s = f / FPS;
  return {f, d, s, p: clamp(f / Math.max(1, d)), k: (a: number, b: number) => clamp((s - a) / (b - a))};
};

export const SKY: Record<string, [string, string]> = {
  day: ['#7CC8F0', '#DFF3FC'],
  dawn: ['#F4B37A', '#CFE3F2'],
  dusk: ['#E8864F', '#7A5C97'],
  night: ['#0A1230', '#1C2A55'],
  storm: ['#262D3B', '#465061'],
  gold: ['#FFD58A', '#FFF1CF'],
};
export const skyMix = (a: string, b: string, t: number): [string, string] => [
  interpolateColors(clamp(t), [0, 1], [SKY[a][0], SKY[b][0]]),
  interpolateColors(clamp(t), [0, 1], [SKY[a][1], SKY[b][1]]),
];

export const SkyRect: React.FC<{sky: [string, string]; y0?: number; y1?: number}> = ({sky, y0 = -500, y1 = FY}) => {
  const id = 'sg' + (sky[0] + sky[1]).replace(/\W/g, '');
  return (
    <g>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={sky[0]} />
          <stop offset="1" stopColor={sky[1]} />
        </linearGradient>
      </defs>
      <rect x={-700} y={y0} width={2700} height={y1 - y0} fill={`url(#${id})`} />
    </g>
  );
};

export const Fade: React.FC<{n?: number; children: React.ReactNode}> = ({n = 5, children}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{opacity: interpolate(f, [0, n], [0, 1], {extrapolateRight: 'clamp'})}}>{children}</AbsoluteFill>
  );
};

/** একই দৃশ্যের ভেতর একাধিক শট। w = প্রতিটি শটের আপেক্ষিক দৈর্ঘ্য */
export const Shots: React.FC<{w: number[]; children: React.ReactNode}> = ({w, children}) => {
  const d = useContext(DurCtx);
  const tot = w.reduce((a, b) => a + b, 0);
  const items = React.Children.toArray(children);
  let acc = 0;
  return (
    <>
      {items.map((c, i) => {
        const from = Math.round((acc / tot) * d);
        acc += w[i];
        const to = i === items.length - 1 ? d : Math.round((acc / tot) * d);
        return (
          <Sequence key={i} from={from} durationInFrames={Math.max(1, to - from)}>
            <DurCtx.Provider value={Math.max(1, to - from)}>
              <Fade>{c}</Fade>
            </DurCtx.Provider>
          </Sequence>
        );
      })}
    </>
  );
};

type Cam = {s?: [number, number]; at?: [number, number]; to?: [number, number]};

/** ১০০% ফুল-স্ক্রিন SVG মঞ্চ: ক্যামেরা, রাতের অন্ধকার (dark), আলো (lights), ঝাঁকুনি, বিদ্যুৎ-ঝলক */
export const Stage: React.FC<{
  dark?: number;
  tint?: string;
  cam?: Cam;
  shake?: number;
  flash?: number;
  lights?: React.ReactNode;
  children?: React.ReactNode;
}> = ({dark = 0, tint = '#050a22', cam = {}, shake = 0, flash = 0, lights, children}) => {
  const {f, p} = useT();
  const e = ease(p);
  const [s0, s1] = cam.s ?? [1, 1.06];
  const [x0, y0] = cam.at ?? [640, 360];
  const [x1, y1] = cam.to ?? [x0, y0];
  const s = lerp(s0, s1, e);
  const fx = lerp(x0, x1, e);
  const fy = lerp(y0, y1, e);
  const sx = shake * (Math.sin(f * 2.7) * 5 + Math.sin(f * 5.1) * 3);
  const sy = shake * Math.cos(f * 3.1) * 4;
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{display: 'block'}}>
        <defs>
          <filter id="b3" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="3" /></filter>
          <filter id="b8" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="8" /></filter>
          <filter id="b20" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="20" /></filter>
          <radialGradient id="vg" cx="50%" cy="50%" r="75%">
            <stop offset="0.55" stopColor="#000" stopOpacity="0" />
            <stop offset="1" stopColor="#000" stopOpacity="0.5" />
          </radialGradient>
        </defs>
        <g transform={`translate(${640 + sx},${360 + sy}) scale(${s}) translate(${-fx},${-fy})`}>
          {children}
          <rect x={-800} y={-600} width={2900} height={1900} fill={tint} opacity={dark * 0.66} />
          {lights}
          {flash > 0 && <rect x={-800} y={-600} width={2900} height={1900} fill="#DDE8FF" opacity={flash * 0.8} />}
        </g>
        <rect width={W} height={H} fill="url(#vg)" />
      </svg>
    </AbsoluteFill>
  );
};

/** আলোর আভা (screen blend) — dark overlay-র পরে আঁকা হয় */
export const Glow: React.FC<{x: number; y: number; r: number; ry?: number; c?: string; o?: number}> = ({
  x, y, r, ry, c = '#FFB347', o = 0.7,
}) => {
  const id = 'gl' + c.slice(1) + Math.round(clamp(o, 0, 1) * 100);
  return (
    <g style={{mixBlendMode: 'screen'}}>
      <defs>
        <radialGradient id={id}>
          <stop offset="0" stopColor={c} stopOpacity={clamp(o, 0, 1)} />
          <stop offset="1" stopColor={c} stopOpacity="0" />
        </radialGradient>
      </defs>
      <ellipse cx={x} cy={y} rx={r} ry={ry ?? r} fill={`url(#${id})`} />
    </g>
  );
};

/** জানালা থেকে আসা আলোর রেখা */
export const Shaft: React.FC<{x: number; y: number; w: number; len?: number; skew?: number; o?: number; c?: string}> = ({
  x, y, w, len = 440, skew = 220, o = 0.5, c = '#FFE8A8',
}) => {
  const id = 'sh' + c.slice(1) + Math.round(clamp(o, 0, 1) * 100);
  return (
    <g style={{mixBlendMode: 'screen'}} filter="url(#b8)">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={c} stopOpacity={clamp(o, 0, 1)} />
          <stop offset="1" stopColor={c} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={`${x},${y} ${x + w},${y} ${x + w + skew},${y + len} ${x + skew - 60},${y + len}`} fill={`url(#${id})`} />
    </g>
  );
};

export const hhmm = (h: number, m: number) =>
  `${String(Math.floor(h) % 24).padStart(2, '0')}:${String(Math.floor(m) % 60).padStart(2, '0')}`;
