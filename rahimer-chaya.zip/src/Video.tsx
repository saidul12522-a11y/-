import React from 'react';
import {AbsoluteFill, Sequence, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {CUTS} from './timing';
import {DurCtx, FPS} from './kit/core';
import * as P1 from './scenes/part1';
import * as P2 from './scenes/part2';

const SCENES: React.FC[] = [
  P1.S01, P1.S02, P1.S03, P1.S04, P1.S05, P1.S06, P1.S07, P1.S08, P1.S09,
  P1.S10, P1.S11, P1.S12, P1.S13, P1.S14, P1.S15, P1.S16, P1.S17,
  P2.S18, P2.S19, P2.S20, P2.S21, P2.S22, P2.S23, P2.S24, P2.S25, P2.S26,
  P2.S27, P2.S28, P2.S29, P2.S30, P2.S31, P2.S32, P2.S33, P2.S34,
];

const OV = 8; // দৃশ্যের মাঝে crossfade (ফ্রেম)

const SceneFade: React.FC<{ov: number; children: React.ReactNode}> = ({ov, children}) => {
  const f = useCurrentFrame();
  const o = ov > 0 ? interpolate(f, [0, ov], [0, 1], {extrapolateRight: 'clamp'}) : 1;
  return <AbsoluteFill style={{opacity: o}}>{children}</AbsoluteFill>;
};

const EndFade: React.FC = () => {
  const f = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const o = interpolate(f, [durationInFrames - 1.5 * FPS, durationInFrames - 4], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  return <AbsoluteFill style={{background: '#000', opacity: o}} />;
};

export const Video: React.FC = () => (
  <AbsoluteFill style={{background: '#000'}}>
    {SCENES.map((S, i) => {
      const a = CUTS[i] * FPS;
      const b = CUTS[i + 1] * FPS;
      const ov = i === 0 ? 0 : OV;
      return (
        <Sequence key={i} from={a - ov} durationInFrames={b - a + ov}>
          <DurCtx.Provider value={b - a + ov}>
            <SceneFade ov={ov}>
              <S />
            </SceneFade>
          </DurCtx.Provider>
        </Sequence>
      );
    })}
    <EndFade />
  </AbsoluteFill>
);
