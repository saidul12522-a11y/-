import React from 'react';
import {Stage, Shots, useT, lerp, ease, FY, SKY, skyMix, Glow, Shaft, hhmm} from '../kit/core';
import {Character} from '../kit/Character';
import {Bed, BedSleeper, Desk, Chair, Clock, Phone, Cup, Plate, Book, Box, Minaret, Arcs, Bike, Palm, Smoke, Motes, Shade, Stove, Thumb, Bag} from '../kit/Props';
import {Room, Village, Yard, Stall} from '../kit/Backdrops';
import {AtDesk, FaceGlow, Birds} from './common';

/* ───────── অংশ ১: ভূমিকা (রাত) ───────── */

// ০:০০ রাত দুটো, ঘুমন্ত পাড়া, একটি জানালায় আলো
export const S01: React.FC = () => {
  const {f} = useT();
  const fl = 0.85 + 0.1 * Math.sin(f / 5);
  return (
    <Stage dark={0.35} cam={{s: [1, 2.1], at: [640, 360], to: [710, 450]}}
      lights={<><Glow x={710} y={470} r={130} c="#FFD27A" o={fl} /><Glow x={710} y={470} r={40} c="#FFFFFF" o={0.6} /></>}>
      <Village sky="night" lit={[2]} />
    </Stage>
  );
};

// ০:০৮ রাহিম ফোনে, "আর পাঁচ মিনিট"
export const S02: React.FC = () => {
  const {f, k} = useT();
  const m = Math.floor(k(0, 8) * 5);
  return (
    <Stage dark={0.6} cam={{s: [1, 1.7], at: [640, 400], to: [500, 400]}}
      lights={<><Glow x={470} y={420} r={150} c="#9CC7FF" o={0.55 + 0.1 * Math.sin(f / 4)} /><Glow x={810} y={235} r={170} c="#5B78C8" o={0.35} /></>}>
      <Room sky={SKY.night} />
      <Bed x={70} />
      <Desk x={660} />
      <Clock x={720} y={438} t={`02:0${m}`} />
      <Character kind="rahim" x={470} sit arms="phone" expr="tired" look={[0, 3]} />
      <Phone x={470} y={462} w={52} h={88} id="a" />
    </Stage>
  );
};

// ০:১৫ পেছনে দেয়ালে কালো ছায়া
export const S03: React.FC = () => {
  const {f, k} = useT();
  const a = ease(k(0.5, 4));
  return (
    <Stage dark={0.62} cam={{s: [1.5, 1.05], at: [520, 400]}}
      lights={<><Glow x={470} y={420} r={150} c="#9CC7FF" o={0.5 + 0.1 * Math.sin(f / 4)} /><Glow x={810} y={235} r={170} c="#5B78C8" o={0.3} /></>}>
      <Room sky={SKY.night} />
      <Bed x={70} />
      <Desk x={660} />
      <Shade x={500} s={1.05} alpha={a * 0.95} eyes={ease(k(3, 5.5))} />
      <Character kind="rahim" x={470} sit arms="phone" expr="tired" look={[0, 3]} />
      <Phone x={470} y={462} w={52} h={88} id="a" />
    </Stage>
  );
};

/* ───────── অংশ ২: আগের সুখের জীবন (দিন) ───────── */

const S04A: React.FC = () => (
  <Stage dark={0.1} cam={{s: [1, 1.12], at: [760, 400]}} lights={<Glow x={420} y={FY - 40} r={280} c="#FFC27A" o={0.5} />}>
    <Village sky="dawn" />
    <Minaret x={960} s={1.2} />
    <Arcs x={960} y={210} />
    <Birds />
  </Stage>
);
const S04B: React.FC = () => {
  const {f} = useT();
  const hy = 392 + Math.sin(f / 3) * 6;
  return (
    <Stage cam={{s: [1, 1.15], at: [640, 380]}} lights={<><Glow x={700} y={400} r={170} c="#FFB766" o={0.35} /><Shaft x={700} y={110} w={220} o={0.35} c="#FFD9A0" /></>}>
      <Room sky={SKY.dawn} wall="#EAD3B2" dec={false} />
      <Stove x={620} />
      <line x1={618} y1={hy} x2={690} y2={FY - 130} stroke="#5A3B25" strokeWidth={6} strokeLinecap="round" />
      <Character kind="maa" x={520} arms="stir" wag={6} expr="neutral" />
      <g><path d="M690,404 q-6,-10 0,-20 q6,-10 0,-20" stroke="#fff" strokeWidth={4} fill="none" opacity={0.6} /></g>
    </Stage>
  );
};
const S04C: React.FC = () => (
  <Stage cam={{s: [1, 1.12], at: [700, 400]}}>
    <Yard sky={SKY.dawn} />
    <Palm x={180} s={1.1} />
    <Bike x={730} s={1.2} ring />
    <Character kind="baba" x={670} arms="cup" expr="happy" />
  </Stage>
);
// ০:২২ ভোরের আজান, মায়ের খুন্তি, বাবার সাইকেলের ঘণ্টা
export const S04: React.FC = () => (
  <Shots w={[1, 1, 1]}>
    <S04A />
    <S04B />
    <S04C />
  </Shots>
);

const S05A: React.FC = () => {
  const {f} = useT();
  const t = (f % 40) / 40;
  return (
    <Stage cam={{s: [1, 1.15], at: [640, 400]}} lights={<Shaft x={700} y={110} w={220} o={0.3} c="#FFE8A8" />}>
      <Room sky={SKY.day} />
      <Bag x={700} />
      <rect x={lerp(500, 690, t)} y={FY - 150 + t * 70 + Math.sin(t * 3.14) * -40} width={34} height={44} fill="#4F81BD" stroke="#2B2230" strokeWidth={3} />
      <Character kind="bon" x={590} arms="hold" expr="happy" look={[3, 2]} />
    </Stage>
  );
};
const S05B: React.FC = () => (
  <Stage cam={{s: [1.2, 1.5], at: [810, 400]}} lights={<Shaft x={700} y={110} w={220} o={0.35} c="#FFE8A8" />}>
    <Room sky={SKY.day} />
    <Bed x={70} />
    <AtDesk expr="happy" book look={[0, 4]} />
  </Stage>
);
const S05C: React.FC = () => {
  const {f, k} = useT();
  const rx = lerp(380, 700, k(0, 2));
  const by = FY - 20 - Math.abs(Math.sin(f / 6)) * 60;
  return (
    <Stage cam={{s: [1, 1.1], at: [660, 400]}}>
      <Yard sky={SKY.day} field />
      <Character kind="f1" x={920} arms="wave" wag={4} expr="happy" />
      <Character kind="rahim" x={rx} walk expr="happy" />
      <circle cx={rx + 70} cy={by} r={20} fill="#E8833A" stroke="#2B2230" strokeWidth={3} />
    </Stage>
  );
};
const S05D: React.FC = () => (
  <Stage dark={0.12} cam={{s: [1, 1.1], at: [660, 400]}} lights={<Glow x={660} y={330} r={300} c="#FFB060" o={0.4} />}>
    <Yard sky={SKY.dusk} />
    <Stall />
    <Character kind="f1" x={480} arms="wave" wag={4} expr="happy" />
    <Character kind="rahim" x={640} arms="cup" expr="happy" />
    <Cup x={718} y={424} s={0.6} hot={0.6} />
    <Character kind="f2" x={820} arms="point" expr="happy" />
  </Stage>
);
// ০:৩১ বোনের ব্যাগ গোছানো, বই পড়া, মাঠে খেলা, চায়ের দোকানে আড্ডা
export const S05: React.FC = () => (
  <Shots w={[2, 2, 2, 2]}>
    <S05A />
    <S05B />
    <S05C />
    <S05D />
  </Shots>
);

// ০:৩৯ সাদামাটা কিন্তু আনন্দে ভরা জীবন
export const S06: React.FC = () => (
  <Stage cam={{s: [1.3, 1.0], at: [680, 380]}} lights={<><Glow x={200} y={80} r={380} c="#FFE29A" o={0.5} /><Motes n={24} x0={300} x1={1000} y0={100} y1={520} /></>}>
    <Yard sky={SKY.gold} />
    <Palm x={150} s={1.1} />
    <Character kind="baba" x={430} arms="wave" wag={3} expr="happy" />
    <Character kind="maa" x={590} expr="happy" />
    <Character kind="rahim" x={770} arms="wave" wag={4} expr="happy" />
    <Character kind="bon" x={920} arms="wave" wag={5} expr="happy" />
  </Stage>
);

const S07A: React.FC = () => {
  const {k} = useT();
  const lid = ease(k(0.5, 2));
  const rise = ease(k(1.5, 3.5));
  return (
    <Stage cam={{s: [1, 1.3], at: [650, 420]}} lights={<Glow x={650} y={400} r={140} c="#FFF2B0" o={0.6 * lid} />}>
      <Room sky={SKY.day} />
      <Character kind="rahim" x={650} sit arms="desk" expr={k(0, 4) > 0.5 ? 'happy' : 'surprised'} look={[0, 4]} />
      <Desk x={500} />
      <Phone x={650} y={452 - rise * 74} w={44} h={74} id="bx" />
      <Box x={650} y={462} open={lid} />
    </Stage>
  );
};
const S07B: React.FC = () => {
  const {k} = useT();
  return (
    <Stage cam={{s: [1.9, 2.1], at: [810, 400]}} lights={<FaceGlow o={0.45} c="#FFD9A0" />}>
      <Room sky={SKY.day} />
      <AtDesk phone expr={k(0, 4) > 0.4 ? 'happy' : 'surprised'} look={[0, 4]} />
    </Stage>
  );
};
// ০:৪৬ নতুন ফোন এল
export const S07: React.FC = () => (
  <Shots w={[1, 1]}>
    <S07A />
    <S07B />
  </Shots>
);

const S08A: React.FC = () => {
  const {f} = useT();
  const sw = (f % 22) / 22;
  return (
    <Stage dark={0.15} cam={{s: [1, 1.08], at: [640, 380]}} lights={<Glow x={640} y={380} r={420} c="#FFA45B" o={0.35} />}>
      <g filter="url(#b8)">
        <Room sky={SKY.day} />
        <Bed x={70} />
      </g>
      <Phone x={640} y={380} w={300} h={560} sp={9} id="big" />
      <Thumb x={470} y={560} rot={-8} />
      <Thumb x={820} y={620 - sw * 110} rot={10} />
    </Stage>
  );
};
const S08B: React.FC = () => {
  const {f} = useT();
  return (
    <Stage dark={0.2} cam={{s: [2.4, 2.6], at: [810, 380]}} lights={<FaceGlow o={0.5 + 0.3 * Math.abs(Math.sin(f * 0.35))} c="#BFD8FF" />}>
      <Room sky={SKY.day} />
      <AtDesk phone expr="blank" look={[0, 4]} />
    </Stage>
  );
};
// ০:৫৪ একটার পর একটা ভিডিও, আঙুল উপরের দিকে
export const S08: React.FC = () => (
  <Shots w={[5, 3]}>
    <S08A />
    <S08B />
  </Shots>
);

// ১:০২ খোলা বই, চোখ ফোনের পর্দায়
export const S09: React.FC = () => (
  <Stage dark={0.1} cam={{s: [1, 1.45], at: [810, 420]}} lights={<FaceGlow o={0.4} />}>
    <Room sky={skyMix('day', 'dusk', 0.3)} />
    <Bed x={70} />
    <AtDesk phone book expr="blank" look={[0, 4]} />
  </Stage>
);

// ১:১০ ঘরের কোণে প্রথমবার ছোট ছায়া
export const S10: React.FC = () => {
  const {k} = useT();
  return (
    <Stage dark={0.08} cam={{s: [1, 1.5], at: [810, 380], to: [230, 430]}} lights={<FaceGlow o={0.3} />}>
      <Room sky={skyMix('day', 'dusk', 0.25)} />
      <Bed x={70} />
      <Shade x={170} s={0.35} alpha={ease(k(1, 5)) * 0.9} glow={0.8} />
      <AtDesk phone expr="blank" look={[0, 4]} />
    </Stage>
  );
};

// ১:১৯ ফোন নামাতে চাইলে ছায়া আবার ঠেলে দেয়
export const S11: React.FC = () => {
  const {f, k} = useT();
  const down = ease(k(0.5, 2.5));
  const back = ease(k(4.5, 7.5));
  const m = down * (1 - back);
  const px = 470 + (340 - 470) * m;
  const py = 462 + (478 - 462) * m;
  const held = m < 0.3;
  const reach = back > 0.01 && back < 0.99;
  return (
    <Stage dark={0.62} cam={{s: [1, 1.3], at: [400, 430]}}
      lights={<><Glow x={px} y={py} r={130} c="#9CC7FF" o={m > 0.5 ? 0.05 : 0.5 + 0.1 * Math.sin(f / 4)} /><Glow x={810} y={235} r={170} c="#5B78C8" o={0.3} /></>}>
      <Room sky={SKY.night} />
      <Shade x={230} s={0.9} eyes={0.9} arm={reach ? [px, py] : null} />
      <Bed x={70} />
      <Character kind="rahim" x={470} sit arms={held ? 'phone' : 'down'} expr="sad" look={[-3, 3]} />
      <Phone x={px} y={py} w={52} h={88} rot={90 * m} mode={m > 0.5 ? 'off' : 'feed'} id="b" />
    </Stage>
  );
};

// ১:২৯ দিন-রাত ঘুরছে, ছায়া বড় হচ্ছে
export const S12: React.FC = () => {
  const {f, s, k} = useT();
  const d = 0.5 - 0.5 * Math.cos(Math.PI * 2 * s * 0.4);
  const mins = (f * 11) % 1440;
  return (
    <Stage dark={d * 0.7} cam={{s: [1, 1.05], at: [640, 400]}} lights={<FaceGlow o={0.2 + d * 0.4} />}>
      <Room sky={skyMix('day', 'night', d)} />
      <Shaft x={700} y={110} w={220} o={(1 - d) * 0.35} c="#FFE8A8" />
      <Bed x={70} />
      <Shade x={260} s={0.6 + 0.4 * k(0, 8)} alpha={0.55 + 0.4 * d} />
      <AtDesk phone expr="blank" look={[0, 4]}>
        <Clock x={720} y={438} t={hhmm(mins / 60, mins % 60)} />
      </AtDesk>
    </Stage>
  );
};

const S13A: React.FC = () => {
  const {k} = useT();
  return (
    <Stage dark={0.1} cam={{s: [1, 1.25], at: [400, 450]}}
      lights={<><Shaft x={700} y={110} w={220} o={0.4} c="#FFD9A0" /><Glow x={200} y={500} r={90} c="#9CC7FF" o={0.4} /></>}>
      <Room sky={SKY.dawn} />
      <Arcs x={810} y={235} />
      <BedSleeper x={70} awake={k(3, 4) > 0.5} />
      <Phone x={205} y={494} w={44} h={74} rot={80} id="s" />
    </Stage>
  );
};
const S13B: React.FC = () => {
  const {k} = useT();
  return (
    <Stage cam={{s: [1.2, 1.5], at: [640, 450]}} lights={<Glow x={470} y={440} r={140} c="#9CC7FF" o={0.3} />}>
      <Room sky={SKY.day} />
      <Bed x={70} />
      <Character kind="rahim" x={470} sit arms="phone" expr="blank" look={[0, 3]} />
      <Phone x={470} y={462} w={52} h={88} id="c" />
      <Desk x={660} />
      <Plate x={810} y={456} hot={1 - k(0, 4)} />
    </Stage>
  );
};
// ১:৩৭ আজানে ঘুম ভাঙে না, দুপুরের খাবার ঠান্ডা
export const S13: React.FC = () => (
  <Shots w={[1, 1]}>
    <S13A />
    <S13B />
  </Shots>
);

// ১:৪৭ বন্ধুরা দরজা থেকে ফিরে যায়
export const S14: React.FC = () => {
  const {f, k} = useT();
  const leaving = k(5.5, 6) > 0.5;
  const x1 = lerp(790, 300, ease(k(6, 9)));
  const x2 = lerp(700, 210, ease(k(6.2, 9)));
  return (
    <Stage cam={{s: [1, 1.1], at: [760, 400], to: [640, 400]}}>
      <Yard sky={SKY.day} />
      <rect x={700} y={FY - 330} width={700} height={330} fill="#D2B48C" stroke="#2B2230" strokeWidth={3} />
      <path d="M680,230 L760,160 L1340,160 L1420,230 Z" fill="#6E7782" stroke="#2B2230" strokeWidth={3} />
      <Door x={860} />
      <Character kind="f2" x={x2} walk={leaving} expr={leaving ? 'sad' : 'neutral'} />
      <Character kind="f1" x={x1} walk={leaving} arms={leaving ? 'down' : 'wave'} wag={leaving ? 0 : 8} expr={leaving ? 'sad' : 'neutral'} />
      <circle cx={x2 + 46} cy={FY - 80 + Math.sin(f / 6) * 0} r={20} fill="#E8833A" stroke="#2B2230" strokeWidth={3} />
    </Stage>
  );
};

// ১:৫৬ বিকেল থেকে সন্ধ্যা, তারপর রাত
export const S15: React.FC = () => {
  const {k} = useT();
  const p = k(0, 9);
  const sky = p < 0.5 ? skyMix('day', 'dusk', p * 2) : skyMix('dusk', 'night', (p - 0.5) * 2);
  const mins = 16 * 60 + p * 460;
  return (
    <Stage dark={p * 0.75} cam={{s: [1, 1.08], at: [700, 400]}}
      lights={<><FaceGlow o={0.2 + p * 0.35} /><Shaft x={700} y={110} w={220} o={(1 - p) * 0.4} c="#FFB070" /></>}>
      <Room sky={sky} />
      <Bed x={70} />
      <Shade x={260} s={0.9} alpha={0.3 + p * 0.6} />
      <AtDesk phone expr="blank" look={[0, 4]}>
        <Clock x={720} y={438} t={hhmm(mins / 60, mins % 60)} />
      </AtDesk>
    </Stage>
  );
};

const S16A: React.FC = () => {
  const {f} = useT();
  return (
    <Stage dark={0.6} shake={0.4} cam={{s: [2.4, 2.7], at: [810, 380]}} lights={<FaceGlow o={0.45} />}>
      <Room sky={SKY.night} />
      <AtDesk phone expr="tired" look={[0, 4]} />
      {[0, 1, 2].map((i) => (
        <circle key={i} cx={810} cy={377} r={70 + i * 20} fill="none" stroke="#fff" strokeWidth={3} strokeDasharray="20 40" opacity={0.22} transform={`rotate(${f * (3 + i) * (i % 2 ? -1 : 1)} 810 377)`} />
      ))}
    </Stage>
  );
};
const S16B: React.FC = () => (
  <Stage dark={0.62} shake={0.1} cam={{s: [1, 1.05], at: [640, 330]}} lights={<FaceGlow o={0.3} />}>
    <Room sky={SKY.night} />
    <Bed x={70} />
    <Shade x={330} s={1.6} eyes={1} glow={1.3} />
    <AtDesk phone expr="tired" look={[0, 4]} />
  </Stage>
);
// ২:০৫ ঝাপসা মাথা, ছায়া ছাদ ছুঁয়েছে
export const S16: React.FC = () => (
  <Shots w={[4, 5]}>
    <S16A />
    <S16B />
  </Shots>
);

// ২:১৪ বাবা খালি চেয়ারের দিকে তাকিয়ে
export const S17: React.FC = () => {
  const {f, k} = useT();
  return (
    <Stage dark={0.55} cam={{s: [1.1, 1.5], at: [560, 400], to: [400, 440]}}
      lights={<><Glow x={530} y={190} r={340} c="#FFC070" o={0.7} /><Glow x={530} y={150} r={50} c="#FFF2C0" o={0.8 + 0.05 * Math.sin(f / 6)} /></>}>
      <Room sky={SKY.night} />
      <line x1={530} y1={-100} x2={530} y2={140} stroke="#2B2230" strokeWidth={3} />
      <circle cx={530} cy={154} r={16} fill="#FFE9A0" stroke="#2B2230" strokeWidth={3} />
      <Chair x={420} />
      <Character kind="baba" x={650} sit arms="desk" expr="sad" look={k(3.5, 4.5) > 0.5 ? [-4, 2] : [0, 3]} />
      <Desk x={330} w={420} />
      <Plate x={420} y={456} hot={0.3} />
      <Plate x={650} y={456} hot={0.4} />
    </Stage>
  );
};
