import React from 'react';
import {Stage, Shots, useT, lerp, ease, FY, SKY, skyMix, Glow, Shaft} from '../kit/core';
import {Character} from '../kit/Character';
import {Bed, BedSleeper, Desk, Chair, Clock, Phone, Cup, Book, Arcs, Candle, Stool, Rain, Palm, Smoke, Motes, Shade, Stove, Paper} from '../kit/Props';
import {Room, Village, Yard, Veranda} from '../kit/Backdrops';
import {AtDesk, FaceGlow} from './common';

const flashAt = (f: number, period: number, len = 4) => (f % period < len ? 1 - (f % period) / len : 0);

/* ───────── অংশ ৪: অবনতি (রাত) ───────── */

// ২:২৩ ছোট বোন ভাইয়ের দরজায় এসে ফিরে যায়
export const S18: React.FC = () => {
  const {k} = useT();
  const walking = k(5.5, 6) > 0.5;
  const bx = lerp(900, 420, ease(k(5.5, 8)));
  const arms = k(2, 4) > 0 && k(4, 5.5) < 1 ? 'wave' : 'down';
  return (
    <Stage dark={0.6} cam={{s: [1, 1.2], at: [980, 420]}} lights={<Glow x={1115} y={FY} r={120} ry={50} c="#9CC7FF" o={0.6} />}>
      <Room sky={SKY.night} door />
      <Door2 />
      <Character kind="bon" x={bx} walk={walking} arms={walking ? 'down' : arms} wag={0} expr="sad" look={[3, 2]} />
    </Stage>
  );
};
const Door2: React.FC = () => <rect x={1048} y={FY - 8} width={134} height={8} fill="#BFD8FF" opacity={0.8} />;

const S19A: React.FC = () => {
  const {k} = useT();
  const e = ease(k(1, 3));
  const mx = lerp(420, 560, ease(k(0, 1)));
  return (
    <Stage dark={0.6} cam={{s: [1, 1.2], at: [700, 420]}}
      lights={<><FaceGlow o={0.4} /><Glow x={lerp(640, 720, e)} y={420} r={90} c="#FFB060" o={0.35} /></>}>
      <Room sky={SKY.night} />
      <AtDesk phone expr="blank" look={[0, 4]} />
      <Character kind="maa" x={mx} walk={k(0, 1) < 1} arms="cup" expr="sad" />
      <Cup x={lerp(mx + 80, 720, e)} y={lerp(424, 458, e)} hot={1} s={0.8} />
    </Stage>
  );
};
const S19B: React.FC = () => {
  const {k} = useT();
  const e = ease(k(1.5, 4));
  return (
    <Stage dark={0.35} cam={{s: [1, 1.2], at: [500, 440]}} lights={<Shaft x={700} y={110} w={220} o={0.25} c="#FFB890" />}>
      <Room sky={SKY.dawn} />
      <BedSleeper x={70} />
      <Character kind="maa" x={610} arms="cup" expr="sad" />
      <Desk x={660} />
      <Cup x={lerp(740, 688, e)} y={lerp(458, 420, e)} hot={0} s={0.8} />
    </Stage>
  );
};
// ২:৩১ মায়ের রোজকার চা, সকালে ঠান্ডা কাপ
export const S19: React.FC = () => (
  <Shots w={[5, 5]}>
    <S19A />
    <S19B />
  </Shots>
);

/* ───────── অংশ ৫: ধাক্কা ও ফেরা ───────── */

// ২:৪১ পরীক্ষার ফল, খাতায় লাল দাগ
export const S20: React.FC = () => {
  const {k} = useT();
  return (
    <Stage cam={{s: [1, 1.2], at: [640, 380]}}>
      <rect x={-700} y={-500} width={2700} height={1800} fill="#D9BC93" />
      <Paper x={640} y={370} rot={-3} marks={ease(k(1, 6))} />
      <rect x={410} y={590} width={64} height={260} rx={30} fill="#D6A074" stroke="#2B2230" strokeWidth={4} />
      <rect x={810} y={590} width={64} height={260} rx={30} fill="#D6A074" stroke="#2B2230" strokeWidth={4} />
    </Stage>
  );
};

// ২:৪৯ রাহিম তাকাল, তারপর আবার ফোনে ডুবে গেল
export const S21: React.FC = () => {
  const {k} = useT();
  const onPhone = k(3.5, 4) > 0.5;
  return (
    <Stage dark={0.05} cam={{s: [1, 1.6], at: [780, 400]}} lights={onPhone ? <FaceGlow o={0.4} /> : undefined}>
      <Room sky={SKY.day} />
      <Bed x={70} />
      <Shade x={260} s={0.9} alpha={lerp(0.3, 0.6, k(0, 7))} />
      <AtDesk phone={onPhone} expr={onPhone ? 'blank' : 'sad'} look={onPhone ? [0, 4] : [-4, 4]} />
      <Paper x={715} y={440} w={120} rot={-8} marks={1} />
    </Stage>
  );
};

const S22A: React.FC = () => {
  const {f, s} = useT();
  const on = s < 2.6 || (s > 2.9 && s < 3.1);
  const fl = flashAt(f, 70);
  return (
    <Stage dark={0.3} flash={fl * 0.7} cam={{s: [1, 1.2], at: [700, 400]}} lights={on ? <Glow x={710} y={470} r={130} c="#FFD27A" o={0.8} /> : undefined}>
      <Village sky="storm" lit={on ? [2] : []} palms={14} />
      <Rain n={170} sp={42} o={0.55} />
    </Stage>
  );
};
const S22B: React.FC = () => {
  const {f, s} = useT();
  const lamp = s < 1.5 || (s > 1.7 && s < 1.9);
  const mode = s < 2.6 ? 'feed' : s < 3.8 ? 'lowbat' : 'off';
  const fl = flashAt(f, 90);
  return (
    <Stage dark={lamp ? 0.4 : 0.78} flash={fl * 0.5} cam={{s: [1, 1.25], at: [700, 400]}}
      lights={<>{lamp && <Glow x={640} y={120} r={420} c="#FFC070" o={0.7} />}{mode !== 'off' && <FaceGlow o={0.4} />}</>}>
      <Room sky={SKY.storm} rain />
      <Bed x={70} />
      <Shade x={260} s={1.0} alpha={0.85} />
      <AtDesk phone mode={mode} expr="blank" look={[0, 4]} />
    </Stage>
  );
};
// ২:৫৬ ঝড়, বিদ্যুৎ চলে গেল, ফোনের চার্জও ফুরাল
export const S22: React.FC = () => (
  <Shots w={[4, 5]}>
    <S22A />
    <S22B />
  </Shots>
);

// ৩:০৫ কালো পর্দা, অদ্ভুত নীরবতা
export const S23: React.FC = () => {
  const {f} = useT();
  return (
    <Stage dark={0.8} flash={flashAt(f, 110, 5) * 0.45} cam={{s: [1, 1.25], at: [810, 400]}}>
      <Room sky={SKY.storm} rain />
      <Bed x={70} />
      <Shade x={260} s={1.0} alpha={0.5 + 0.15 * Math.sin(f / 9)} eyes={0.4} glow={0.5} />
      <AtDesk phone mode="off" expr="blank" look={[0, 4]} />
    </Stage>
  );
};

const S24A: React.FC = () => {
  const {k} = useT();
  const up = ease(k(0.5, 3));
  return (
    <Stage dark={0.75} cam={{s: [1.8, 1.9], at: [810, 385]}} lights={<Glow x={600} y={400} r={320} c="#FFB45B" o={0.35 * up} />}>
      <Room sky={SKY.storm} />
      <AtDesk phone mode="off" expr={up > 0.5 ? 'sad' : 'blank'} look={[lerp(0, -6, up), lerp(4, -2, up)]} />
    </Stage>
  );
};
const S24B: React.FC = () => {
  const {f} = useT();
  return (
    <Stage dark={0.72} cam={{s: [1, 1.35], at: [610, 420]}} lights={<Glow x={500} y={FY - 135} r={280} c="#FFB45B" o={0.8 + 0.08 * Math.sin(f / 3)} />}>
      <Veranda />
      <Stool x={500} />
      <Candle x={500} y={FY - 70} />
      <Chair x={720} />
      <Character kind="maa" x={720} sit arms="hold" expr="sleep" tilt={8} />
      <Cup x={720} y={484} hot={0} s={0.8} />
    </Stage>
  );
};
// ৩:১৩ রাহিম মাথা তুলল, বারান্দায় মোমের আলোয় মা ঘুমিয়ে
export const S24: React.FC = () => (
  <Shots w={[4, 5]}>
    <S24A />
    <S24B />
  </Shots>
);

// ৩:২২ ঠান্ডা চায়ের কাপ, মুখে ক্লান্তি
export const S25: React.FC = () => {
  const {f} = useT();
  return (
    <Stage dark={0.72} cam={{s: [1.9, 2.1], at: [720, 420]}} lights={<Glow x={560} y={FY - 135} r={300} c="#FFB45B" o={0.8 + 0.08 * Math.sin(f / 3)} />}>
      <Veranda />
      <Stool x={500} />
      <Candle x={500} y={FY - 70} />
      <Chair x={720} />
      <Character kind="maa" x={720} sit arms="hold" expr="tired" tilt={5} />
      <Cup x={720} y={484} hot={0} s={0.8} />
    </Stage>
  );
};

// ৩:৩১ রাহিমের চোখ ভিজে এল
export const S26: React.FC = () => {
  const {f} = useT();
  return (
    <Stage dark={0.72} cam={{s: [2.2, 2.5], at: [480, 330]}} lights={<Glow x={700} y={400} r={340} c="#FFB45B" o={0.7 + 0.08 * Math.sin(f / 3)} />}>
      <Veranda />
      <Stool x={760} />
      <Candle x={760} y={FY - 70} />
      <Character kind="rahim" x={480} expr="cry" look={[4, 2]} />
    </Stage>
  );
};

// ৩:৩৯ ফোনটা বিছানায় নামিয়ে রাখল, ছায়া কেঁপে উঠল
export const S27: React.FC = () => {
  const {f, k} = useT();
  const m = ease(k(1, 4));
  const px = 470 + (340 - 470) * m;
  const py = 462 + (478 - 462) * m;
  return (
    <Stage dark={0.65} cam={{s: [1, 1.4], at: [420, 430]}} lights={<Glow x={px} y={py} r={130} c="#9CC7FF" o={m > 0.5 ? 0 : 0.4} />}>
      <Room sky={SKY.night} />
      <Shade x={240 + Math.sin(f * 2) * 4} s={lerp(0.9, 0.7, k(1, 7))} alpha={lerp(0.95, 0.6, k(1, 7))} eyes={0.5 + 0.5 * Math.sin(f)} />
      <Bed x={70} />
      <Character kind="rahim" x={470} sit arms={m < 0.3 ? 'phone' : 'down'} expr={m > 0.6 ? 'neutral' : 'sad'} look={[-3, 3]} />
      <Phone x={px} y={py} w={52} h={88} rot={90 * m} mode={m > 0.5 ? 'off' : 'feed'} id="b" />
    </Stage>
  );
};

/* ───────── অংশ ৬: নতুন সকাল (দিন) ───────── */

const S28A: React.FC = () => {
  const {k} = useT();
  return (
    <Stage dark={lerp(0.5, 0.25, k(0, 4))} cam={{s: [1, 1.25], at: [300, 470]}} lights={<Shaft x={700} y={110} w={220} o={0.2} c="#FFC890" />}>
      <Room sky={skyMix('night', 'dawn', k(0, 4))} shut={1} />
      <Arcs x={810} y={235} />
      <BedSleeper x={70} awake={k(2.8, 3.2) > 0.5} />
    </Stage>
  );
};
const S28B: React.FC = () => {
  const {k} = useT();
  const e = ease(k(0.8, 3));
  return (
    <Stage dark={lerp(0.25, 0, e)} cam={{s: [1, 1.35], at: [760, 330]}}
      lights={<><Shaft x={700} y={110} w={220} o={0.6 * e} c="#FFE0A0" /><Glow x={810} y={235} r={260} c="#FFD27A" o={0.5 * e} /></>}>
      <Room sky={skyMix('dawn', 'gold', e)} shut={1 - e} />
      <Character kind="rahim" x={620} arms="point" expr="happy" />
    </Stage>
  );
};
// ৩:৪৬ ভোরে আজান, জানালা খুলে দিল
export const S28: React.FC = () => (
  <Shots w={[4, 5]}>
    <S28A />
    <S28B />
  </Shots>
);

const S29A: React.FC = () => {
  const {f} = useT();
  return (
    <Stage cam={{s: [1, 1.15], at: [700, 420]}} lights={<Glow x={300} y={100} r={400} c="#FFE29A" o={0.4} />}>
      <Yard sky={SKY.gold} wet />
      <Palm x={200} s={1.1} />
      {[0, 1, 2].map((i) => {
        const t = ((f + i * 14) % 42) / 42;
        return (
          <g key={i}>
            <ellipse cx={380 + i * 8} cy={FY + 70} rx={t * 30} ry={t * 6} fill="none" stroke="#6E9AB8" strokeWidth={2} opacity={1 - t} />
            <ellipse cx={380 + i * 8} cy={300 + t * (FY - 230)} rx={4} ry={7} fill="#8EC9F5" opacity={t < 0.98 ? 1 : 0} />
          </g>
        );
      })}
      {[0, 1, 2].map((i) => (
        <path key={i} d={`M${700 + i * 90},${FY + 10} q-12,-30 0,-60 q12,-30 0,-60`} stroke="#8FBF7A" strokeWidth={4} fill="none" strokeLinecap="round" opacity={0.35 + 0.3 * Math.sin(f / 15 + i)} />
      ))}
      <Character kind="rahim" x={800} expr="happy" look={[0, -2]} />
    </Stage>
  );
};
const S29B: React.FC = () => {
  const {k} = useT();
  const pour = k(0.5, 3);
  return (
    <Stage cam={{s: [1, 1.2], at: [640, 400]}} lights={<Shaft x={700} y={110} w={220} o={0.3} c="#FFD9A0" />}>
      <Room sky={SKY.gold} wall="#EAD3B2" dec={false} />
      <Stove x={620} />
      <Character kind="rahim" x={520} arms="cup" expr="happy" look={[3, 3]} />
      <g transform="translate(600,405) rotate(25)">
        <path d="M-26,0 Q-26,-30 0,-30 Q26,-30 26,0 Z" fill="#9AA3AD" stroke="#2B2230" strokeWidth={3} />
        <path d="M24,-6 L44,6" stroke="#2B2230" strokeWidth={5} />
      </g>
      {pour > 0 && pour < 1 && <line x1={646} y1={426} x2={665} y2={FY - 96} stroke="#B8793E" strokeWidth={4} strokeLinecap="round" />}
      <Cup x={665} y={FY - 90} hot={pour > 0.8 ? 1 : 0} fill={pour} s={0.8} />
    </Stage>
  );
};
// ৩:৫৫ ভেজা মাটির গন্ধ, নিজ হাতে মায়ের জন্য চা
export const S29: React.FC = () => (
  <Shots w={[1, 1]}>
    <S29A />
    <S29B />
  </Shots>
);

const S30A: React.FC = () => {
  const {k} = useT();
  return (
    <Stage cam={{s: [1, 1.3], at: [350, 400]}}>
      <Room sky={SKY.gold} />
      <Character kind="rahim" x={300} arms="cup" expr="neutral" look={[3, 2]} />
      <Book x={384} y={420} open={false} />
      <Smoke x={384} y={400} p={k(0.4, 3.5)} n={14} spread={50} vx={30} c="#BFB49A" />
    </Stage>
  );
};
const S30B: React.FC = () => (
  <Stage cam={{s: [1, 1.35], at: [810, 400]}} lights={<Shaft x={700} y={110} w={220} o={0.5} c="#FFE0A0" />}>
    <Room sky={SKY.gold} />
    <Bed x={70} />
    <AtDesk expr="happy" book look={[0, 4]} />
  </Stage>
);
// ৪:০৪ বইয়ের ধুলো ঝেড়ে টেবিলে বসে পড়ল
export const S30: React.FC = () => (
  <Shots w={[1, 1]}>
    <S30A />
    <S30B />
  </Shots>
);

// ৪:১২ ছায়া যতবার এগোতে চায়, ততবার ছোট হয়
export const S31: React.FC = () => {
  const {k} = useT();
  const lunge = [0, 1, 2].map((i) => ease(k(1 + i * 2, 1.8 + i * 2)));
  const recoil = [0, 1, 2].map((i) => ease(k(1.8 + i * 2, 2.6 + i * 2)));
  const rs = recoil[0] + recoil[1] + recoil[2];
  const x = 230 + (lunge[0] + lunge[1] + lunge[2]) * 60 - rs * 20;
  return (
    <Stage cam={{s: [1, 1.1], at: [640, 400]}} lights={<Shaft x={700} y={110} w={220} o={0.5} c="#FFE0A0" />}>
      <Room sky={SKY.gold} />
      <Bed x={70} />
      <Shade x={x} s={0.9 - rs * 0.2} alpha={0.6} />
      <AtDesk expr="neutral" book look={[0, 4]} />
    </Stage>
  );
};

// ৪:২০ ছায়া ধোঁয়া হয়ে বাতাসে মিশে গেল
export const S32: React.FC = () => {
  const {k} = useT();
  return (
    <Stage cam={{s: [1, 1.1], at: [640, 400]}} lights={<Shaft x={700} y={110} w={220} o={0.5} c="#FFE0A0" />}>
      <Room sky={SKY.gold} />
      <Bed x={70} />
      <Shade x={410} s={0.35} alpha={1 - ease(k(0.5, 4))} />
      <Smoke x={410} y={FY - 60} p={k(0.8, 8)} n={26} spread={80} vx={60} />
      <AtDesk expr="happy" book look={[0, 4]} />
    </Stage>
  );
};

// ৪:২৯ সকালের রোদ, ছায়া কখনো বাইরে থেকে আসেনি
export const S33: React.FC = () => (
  <Stage cam={{s: [1.6, 1.0], at: [810, 380], to: [700, 380]}}
    lights={<><Shaft x={700} y={110} w={220} o={0.7} c="#FFE0A0" /><Glow x={810} y={235} r={300} c="#FFD27A" o={0.5} /><Motes n={34} x0={620} x1={1100} y0={120} y1={540} /></>}>
    <Room sky={SKY.gold} />
    <Bed x={70} />
    <AtDesk expr="happy" book look={[5, -3]} />
  </Stage>
);

// ৪:৩৭ জায়গা দিয়েছিল বলেই ছিল — ঘরে এখন শুধু আলো
export const S34: React.FC = () => {
  const {k} = useT();
  return (
    <Stage cam={{s: [1.15, 1.0], at: [640, 380]}}
      lights={<><Shaft x={700} y={110} w={220} o={0.6} c="#FFE0A0" /><Glow x={810} y={235} r={320} c="#FFD27A" o={0.5} /><Motes n={26} x0={500} x1={1100} y0={120} y1={540} /></>}>
      <Room sky={SKY.gold} />
      <Bed x={70} />
      <Smoke x={150} y={FY - 10} p={k(0, 4)} n={8} spread={40} vx={20} />
      <AtDesk expr="happy" book look={[0, 4]}>
        <Cup x={730} y={458} hot={1} s={0.7} />
      </AtDesk>
    </Stage>
  );
};
