import React from 'react';
import {Glow, useT} from '../kit/core';
import {Character} from '../kit/Character';
import {Book, Desk, Phone} from '../kit/Props';

/** রাহিম টেবিলে বসে আছে (x=810). ফোন/বই ঐচ্ছিক */
export const AtDesk: React.FC<{
  expr?: string; arms?: string; look?: [number, number]; phone?: boolean; mode?: string; book?: boolean; children?: React.ReactNode;
}> = ({expr = 'blank', arms, look = [0, 3], phone = false, mode = 'feed', book = false, children}) => (
  <g>
    <Character kind="rahim" x={810} sit arms={arms ?? (phone ? 'upphone' : 'desk')} expr={expr} look={look} />
    <Desk x={660} />
    {book && <Book x={810} y={452} />}
    {phone && <Phone x={810} y={452} w={46} h={76} mode={mode} id="d" />}
    {children}
  </g>
);

/** ফোনের আলো রাহিমের মুখে */
export const FaceGlow: React.FC<{o?: number; c?: string}> = ({o = 0.5, c = '#9CC7FF'}) => {
  const {f} = useT();
  return <Glow x={810} y={410} r={160} c={c} o={o * (0.85 + 0.15 * Math.sin(f / 3))} />;
};

export const Birds: React.FC = () => {
  const {f} = useT();
  return (
    <g stroke="#2B2230" strokeWidth={3} fill="none" strokeLinecap="round">
      {[0, 1, 2, 3].map((i) => {
        const x = ((f * 3 + i * 170) % 1500) - 100;
        const y = 120 + i * 34 + Math.sin(f / 10 + i) * 8;
        const fl = Math.sin(f / 3 + i) * 5;
        return <path key={i} d={`M${x - 12},${y} Q${x - 6},${y - 8 - fl} ${x},${y} Q${x + 6},${y - 8 - fl} ${x + 12},${y}`} />;
      })}
    </g>
  );
};
