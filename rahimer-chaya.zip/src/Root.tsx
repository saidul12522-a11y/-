import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';
import {CUTS} from './timing';
import {FPS, W, H} from './kit/core';

export const Root: React.FC = () => (
  <Composition
    id="RahimerChaya"
    component={Video}
    durationInFrames={CUTS[CUTS.length - 1] * FPS}
    fps={FPS}
    width={W}
    height={H}
  />
);
