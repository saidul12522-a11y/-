# MosquitoExplainer

Animated 2D diagram explainer: "Why does a mosquito bite some people more?" (Bengali voiceover, 16:9, 1920x1080, 30 fps, about 3:11).
Theme "Frosty light" (same as the reference project), font Hind Siliguri (bundled), SUL channel logo in the corner and in the outro, word-synced captions.

## Run on Windows
1. Install Node.js LTS (v20 or v22) from https://nodejs.org
2. Open a terminal in this folder (the one that contains package.json) and run:

```
npm install
```
3. Preview in Remotion Studio:
```
npm run dev
```
4. Render the MP4 (output: out\mosquito-explainer.mp4):
```
npm run render
```
Remotion finds Chrome automatically (it downloads its own Chromium on first run if needed). Internet is needed only for `npm install` and that first download.

Other scripts: `npm run still` (one PNG frame), `npm run typecheck`, `npm run timing` (rebuild src/timing.json and corrected.srt from public/subtitles/original.srt).

## Folders
- `src/` code. `Video.tsx` = composition, `sceneList.ts` = 20 scenes with start/end seconds, `scenes/` = scene components, `art/` = drawn objects (mosquito, bed, people, drops ...), `components/` = background and captions, `theme.ts` = colours (no hex anywhere else), `layout.ts` = 16:9 / 9:16 presets.
- `public/voice.mp3` voiceover (untouched), `public/subtitles/original.srt` and `corrected.srt`, `public/logo.jpg` SUL logo, `public/fonts/` Hind Siliguri.
- `src/timing.json` word timing, `src/corrections.json` SRT correction log and suspect list.
- `PROGRESS.md` project status for resuming work.

## Notes
Word timing is estimated from the SRT cue times (speech-only spreading using silence detection), not from speech recognition. No SFX or music: none was supplied.
