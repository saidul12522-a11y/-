import React from "react";
import { staticFile } from "remotion";
import { theme as C } from "../theme";
import { FONT } from "../fonts";
import { Svg, SceneProps, GROUND, W, track, Room } from "./common";
import { In, Chip, Ring, Ground, Cross, Check, Arrow, Bubble } from "../components/kit";
import { Person, Heart, Mini } from "../art/art";
import { Mosquito, Puff, Whiff, Thermo, Drop, Egg, Bed, Net, Bucket, Hand, Acid } from "../art/mosq";
import { prog, pop, lerp, INOUT } from "../motion";

const XS = [-2, -1, 0, 1, 2].map((i) => 960 + i * 340);
const CL = [C.cloth, C.cloth2, C.warn, C.data, C.flow];
const V = 3;

/** 155.3-165.3  Back in the room: why only one of five? Smell, breath gas, temperature */
export const SceneWhyOne: React.FC<SceneProps> = ({ t }) => {
  const tAsk = W("কেন", 157.5), tBecause = W("কারণ", 159), tSmell = W("গন্ধ,", 160.5), tBreath = W("নিঃশ্বাসের", 161), tTemp = W("তাপমাত্রা", 162);
  const dim = prog(t, tBecause - 0.2, tBecause + 0.3);
  return (
    <Svg>
      <Room />
      <Chip x={960} y={200} text="৫ জনের মধ্যে ১ জন" color={C.data} size={30} />
      {XS.map((x, i) => (
        <In key={i} t={t} cue={155.4 + i * 0.12} dy={50}>
          <g opacity={i === V ? 1 : 1 - 0.55 * dim}><Person x={x} y={GROUND} s={0.9} pose={i === V && t >= tAsk ? "worry" : "stand"} t={t} cloth={CL[i]} style={i === 1 ? "long" : "short"} /></g>
        </In>
      ))}
      <In t={t} cue={tAsk}><Ring x={XS[V]} y={GROUND - 150} t={t} cue={tAsk} r={170} loop /></In>
      <In t={t} cue={tSmell - 0.2}><g><Whiff x={1130} y={430} s={0.9} t={t} color={C.good} n={3} /><Chip x={1130} y={265} text="গন্ধ" color={C.good} size={28} /></g></In>
      <In t={t} cue={tBreath - 0.1}><g><Puff x={1300} y={340} r={50} /><Chip x={1300} y={265} text="নিঃশ্বাসের গ্যাস" color={C.flow} size={26} /></g></In>
      <In t={t} cue={tTemp - 0.1}><g><Thermo x={1500} y={470} s={0.8} level={0.3 + 0.7 * prog(t, tTemp, tTemp + 0.9)} /><Chip x={1500} y={265} text="তাপমাত্রা" color={C.warn} size={28} /></g></In>
      <Mosquito x={1130} y={600} s={1.1} t={t} opacity={prog(t, 157, 157.4)} />
    </Svg>
  );
};

/** 165.3-172.4  Nothing personal: the mosquito picks by need */
export const SceneNeed: React.FC<SceneProps> = ({ t }) => {
  const tNot = W("কাউকে"), tLike = W("পছন্দ", 167), tNeed = W("প্রয়োজন"), tPick = W("বেছে", 171);
  const hOut = 1 - prog(t, 168.8, 169.2);
  const arrow = prog(t, tNeed + 0.5, tNeed + 1.4, INOUT);
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={165.4}><Mosquito x={560} y={560} s={2.0} t={t} /></In>
      <In t={t} cue={165.5} dy={50}><Person x={1400} y={GROUND} s={1.0} t={t} cloth={C.cloth} pose="stand" /></In>
      <g opacity={hOut}>
        <In t={t} cue={tNot}><g><Heart x={900} y={330} s={2.6} /><Cross x={900} y={330} t={t} cue={tLike} s={1.6} /></g></In>
        <In t={t} cue={tNot}><Chip x={960} y={220} text="ব্যক্তিগত পছন্দ নয়" color={C.bad} size={32} /></In>
      </g>
      <In t={t} cue={tNeed - 0.5} dy={30}>
        <Bubble x={600} y={300} w={330} h={170} tail="d" color={C.accent}>
          <Drop x={540} y={318} s={1.0} />
          <Egg x={650} y={308} s={1.8} />
        </Bubble>
      </In>
      <In t={t} cue={tNeed}><Chip x={600} y={170} text="নিজের প্রয়োজন" color={C.accent} size={30} /></In>
      <Arrow x1={800} y1={560} x2={1250} y2={560} p={arrow} color={C.accent} w={10} />
      <In t={t} cue={tPick}><Ring x={1400} y={GROUND - 150} t={t} cue={tPick} r={140} /></In>
    </Svg>
  );
};

/** 172.4-178.9  Clean standing water, use a mosquito net at night */
export const ScenePrevent: React.FC<SceneProps> = ({ t }) => {
  const tPani = W("পানি", 175), tClean = W("পরিষ্কার"), tNet = W("মশারি"), tUse = W("ব্যবহার");
  const tilt = prog(t, tClean - 0.1, tClean + 1.0, INOUT);
  const px = 560 - 64 * 1.5, py = GROUND;
  const water = 1 - prog(t, tClean + 0.5, tClean + 1.5);
  const bounce = track(t, [tUse - 0.2, tUse + 0.4, tUse + 0.9], [1780, 1590, 1780]);
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={172.5} dy={50}>
        <g>
          <g transform={`translate(${px} ${py}) rotate(${-78 * tilt}) translate(${-px} ${-py})`}>
            <Bucket x={560} y={GROUND} s={1.5} level={water} />
          </g>
          {t >= tClean + 0.3 && Array.from({ length: 8 }).map((_, k) => {
            const ph = ((t - tClean - 0.3) * 1.2 + k / 8) % 1;
            return <circle key={k} cx={px - 50 - ph * 90} cy={py - 120 + ph * 110} r={10 - ph * 3} fill={C.water} stroke={C.text} strokeWidth={2} opacity={(1 - prog(t, tClean + 1.4, tClean + 1.8)) * (1 - ph * 0.4)} />;
          })}
        </g>
      </In>
      <In t={t} cue={tPani}><Chip x={470} y={300} text="জমে থাকা পানি" color={C.flow} size={30} /></In>
      <Check x={560} y={430} t={t} cue={tClean + 1.4} s={1.3} />
      <In t={t} cue={tNet - 0.2} dy={-90}><g><Bed x={1400} y={GROUND} s={1.0} t={t} cloth={C.cloth2} /><Net x={1400} y={GROUND - 10} s={1.0} /></g></In>
      <In t={t} cue={tNet}><Chip x={1400} y={250} text="মশারি" color={C.good} size={32} /></In>
      <g opacity={prog(t, tUse - 0.4, tUse - 0.2)}><Mosquito x={bounce} y={520} s={1.1} t={t} flip /></g>
      <Cross x={1560} y={440} t={t} cue={tUse + 0.35} s={1.1} />
    </Svg>
  );
};

/** 178.9-184.2  So much calculation, ended with one slap */
export const SceneSwat: React.FC<SceneProps> = ({ t }) => {
  const tCalc = W("হিসাব", 179.5), tBut = W("অথচ"), tOne = W("এক", 181.8), tEnd = W("হিসাব", 183);
  const slap = tOne + 0.75;
  const hy = track(t, [tBut, slap - 0.25, slap, slap + 0.5, slap + 1.0], [-260, -260, 360, 360, -300]);
  const hit = t >= slap;
  const fall = prog(t, slap, slap + 0.9);
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={tCalc - 0.5} dy={30}>
        <Bubble x={820} y={290} w={560} h={170} tail="d" color={C.data}>
          <Whiff x={620} y={345} s={0.5} t={t} color={C.good} n={2} />
          <Puff x={740} y={290} r={30} />
          <Thermo x={870} y={345} s={0.55} />
          <circle cx={960} cy={290} r={20} fill={C.swRed} stroke={C.text} strokeWidth={3} /><circle cx={1010} cy={290} r={20} fill={C.swTurq} stroke={C.text} strokeWidth={3} />
          <Acid x={1080} y={296} s={0.5} />
        </Bubble>
      </In>
      <g opacity={prog(t, tCalc - 0.5, tCalc - 0.2) * (1 - 0 * fall)}>
        <Mosquito x={820} y={lerp(560, 700, fall)} s={1.9} t={t} dead={hit} rot={hit ? 90 * fall : 0} opacity={1 - 0.8 * prog(t, slap + 0.5, slap + 1.2)} bob={!hit} />
      </g>
      {t >= tBut && (
        <g transform={`translate(1000 ${hy}) rotate(${hit ? 180 : 172}) translate(-1000 0)`}>
          <Hand x={1000} y={0} s={1.4} opacity={prog(t, tBut, tBut + 0.2)} />
        </g>
      )}
      {t >= slap && t < slap + 0.5 && (
        <g transform="translate(820 600)" opacity={1 - prog(t, slap, slap + 0.5)}>
          {Array.from({ length: 10 }).map((_, k) => <line key={k} x1={0} y1={0} x2={Math.cos(k * 0.628) * (60 + 140 * prog(t, slap, slap + 0.3))} y2={Math.sin(k * 0.628) * (60 + 140 * prog(t, slap, slap + 0.3))} stroke={C.accent} strokeWidth={9} strokeLinecap="round" />)}
        </g>
      )}
      <Cross x={820} y={290} t={t} cue={tEnd} s={2.0} />
      <In t={t} cue={tEnd}><Chip x={1330} y={290} text="হিসাব শেষ" color={C.bad} size={34} /></In>
    </Svg>
  );
};

/** 184.2-end  Outro: logo, like, comment, subscribe */
export const SceneOutro: React.FC<SceneProps> = ({ t }) => {
  const tLike = W("লাইক"), tCom = W("কমেন্ট"), tSub = W("সাবস্ক্রাইব");
  const bell = Math.sin(t * 18) * 10 * (prog(t, tSub + 0.3, tSub + 0.5) * (1 - prog(t, tSub + 1.8, tSub + 2.0)));
  return (
    <Svg>
      <In t={t} cue={184.4} dy={40}>
        <rect x={190} y={220} width={560} height={560} rx={48} fill="#fff" stroke={C.border} strokeWidth={3} />
        <image href={staticFile("logo.jpg")} x={200} y={230} width={540} height={540} preserveAspectRatio="xMidYMid meet" />
      </In>
      <In t={t} cue={tLike} dy={50}>
        <rect x={940} y={250} width={380} height={120} rx={60} fill={C.surface} stroke={C.data} strokeWidth={4} />
        <path d="M 1000 335 L 1000 295 L 1030 295 L 1045 262 Q 1065 262 1062 285 L 1062 295 L 1100 295 Q 1114 296 1110 312 L 1102 335 Z" fill={C.data} stroke={C.text} strokeWidth={3} strokeLinejoin="round" />
        <text x={1215} y={332} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={42} fill={C.text}>লাইক</text>
      </In>
      <In t={t} cue={tCom} dy={50}>
        <rect x={940} y={420} width={380} height={120} rx={60} fill={C.surface} stroke={C.good} strokeWidth={4} />
        <path d="M 995 475 Q 995 440 1030 440 L 1075 440 Q 1110 440 1110 475 Q 1110 505 1075 505 L 1040 505 L 1015 525 L 1020 505 Q 995 505 995 475 Z" fill={C.good} stroke={C.text} strokeWidth={3} strokeLinejoin="round" />
        <text x={1215} y={492} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={42} fill={C.text}>কমেন্ট</text>
      </In>
      <In t={t} cue={tSub} dy={50}>
        <rect x={940} y={590} width={640} height={130} rx={65} fill={C.bad} stroke={C.text} strokeWidth={4} />
        <g transform={`translate(1030 655) rotate(${bell})`}>
          <path d="M -26 14 Q -26 -34 0 -34 Q 26 -34 26 14 L 36 26 L -36 26 Z" fill="#fff" stroke={C.text} strokeWidth={3} />
          <circle cx={0} cy={36} r={8} fill="#fff" stroke={C.text} strokeWidth={3} />
        </g>
        <text x={1290} y={668} textAnchor="middle" fontSize={50} fontWeight={700} fontFamily={FONT} fill="#fff">সাবস্ক্রাইব</text>
      </In>
    </Svg>
  );
};
