import React from "react";
import { theme as C } from "../theme";
import { FONT } from "../fonts";
import { Svg, SceneProps, GROUND, W, track, orbit } from "./common";
import { In, Chip, Ring, Ground, Cross, Check, Arrow } from "../components/kit";
import { Person, Mini } from "../art/art";
import { Mosquito, Puff, Drop, Egg, Larva, Pupa, Vase, Bucket, Tyre, Hourglass, Belly } from "../art/mosq";
import { prog, pop, lerp, INOUT } from "../motion";

/** 106.3-112.9  Pregnant women: more CO2 -> more mosquitoes */
export const ScenePregnant: React.FC<SceneProps> = ({ t }) => {
  const tPreg = W("গর্ভবতী"), tAttr = W("আকর্ষণ"), tCo2 = W("কার্বন", 111), tMore = W("বেশি", 111);
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={tPreg - 0.1} dy={60}>
        <g><Person x={640} y={GROUND} s={1.2} t={t} cloth={C.cloth2} pose="stand" style="long" /><Belly x={640} y={GROUND} s={1.2} cloth={C.cloth2} /></g>
      </In>
      <In t={t} cue={tPreg}><Chip x={640} y={300} text="গর্ভবতী নারী" color={C.data} size={32} /></In>
      {Array.from({ length: 8 }).map((_, k) => {
        const c = tCo2 - 1.0 + k * 0.2;
        const ph = ((t - c) * 0.35) % 1;
        if (t < c) return null;
        return <Puff key={k} x={lerp(700, 1250, ph) + Math.sin(k * 2 + ph * 5) * 24} y={lerp(470, 340, ph) + (k % 3) * 30} r={26 + ph * 28} opacity={Math.min(1, ph * 6) * (1 - ph * 0.4)} />;
      })}
      <In t={t} cue={tMore}><Chip x={1280} y={250} text="বেশি CO₂" color={C.accent} size={32} /></In>
      {[0, 1, 2, 3].map((k) => {
        const o = orbit(640, 470, 330, 130, t, k, 4, 1.3);
        const c = tAttr + k * 0.3, pp = prog(t, c, c + 0.5);
        return <Mosquito key={k} x={lerp(k % 2 ? 1870 : 60, o.x, pp)} y={lerp(240, o.y, pp)} s={1.05} t={t + k} flip={o.flip} opacity={pp} />;
      })}
    </Svg>
  );
};

/** 112.9-123.8  Why must she search so carefully? Short life, blood again and again for eggs */
export const SceneWhy: React.FC<SceneProps> = ({ t }) => {
  const tQ = W("কেন?"), tLife = W("জীবন"), tEgg = W("ডিম", 120.5), tRep = W("বারবার");
  const p1 = Math.min(prog(t, 113.0, 113.4), 1 - prog(t, 117.9, 118.3));
  const p2 = Math.min(prog(t, 118.1, 118.5), 1 - prog(t, 121.0, 121.4));
  const p3 = prog(t, 121.0, 121.5);
  const scan = t >= 115.2 && t < 118 ? Math.floor((t - 115.2) / 0.55) % 3 : -1;
  const XP = [1280, 1500, 1720];
  const mx = 720 + Math.sin(t * 1.6) * 30;
  return (
    <Svg>
      <g opacity={p1}>
        <Ground y={GROUND} />
        {XP.map((x, i) => <In key={i} t={t} cue={113.2 + i * 0.3} dy={50}><Person x={x} y={GROUND} s={0.7} t={t} cloth={[C.cloth, C.cloth2, C.warn][i]} pose="stand" /></In>)}
        <Mosquito x={mx} y={500} s={2.0} t={t} />
        {scan >= 0 && <line x1={mx + 150} y1={540} x2={XP[scan] - 20} y2={GROUND - 230} stroke={C.muted} strokeWidth={5} strokeDasharray="14 12" strokeDashoffset={-t * 90} strokeLinecap="round" />}
        <In t={t} cue={114.3} out={tQ + 0.9}><text x={720} y={290 + Math.sin(t * 6) * -8} textAnchor="middle" fontSize={190} fontWeight={700} fill={C.accent} fontFamily={FONT} stroke={C.text} strokeWidth={5}>?</text></In>
      </g>
      <g opacity={p2}>
        <Hourglass x={1180} y={470} s={2.1} p={prog(t, tLife - 0.2, tLife + 2.0)} />
        <Mosquito x={640} y={480} s={1.8} t={t} opacity={1 - 0.6 * prog(t, tLife + 0.8, tLife + 2.2)} />
        <In t={t} cue={tLife}><Chip x={960} y={250} text="জীবন দীর্ঘ নয়" color={C.bad} size={34} /></In>
      </g>
      {p3 > 0.01 && (
        <g opacity={p3}>
          <circle cx={960} cy={480} r={215} fill="none" stroke={C.flow} strokeWidth={8} strokeDasharray="22 16" strokeDashoffset={-t * 60} opacity={0.6} />
          {[0, 1, 2, 3].map((k) => {
            const a = t * 1.1 + k * (Math.PI / 2);
            return <path key={k} d="M -16 -14 L 16 0 L -16 14 Z" fill={C.flow} transform={`translate(${960 + Math.cos(a) * 215} ${480 + Math.sin(a) * 215}) rotate(${(a * 180) / Math.PI + 90})`} />;
          })}
          <Mosquito x={960} y={700} s={0.9} t={t} blood={prog(t, tRep, tRep + 1)} />
          <In t={t} cue={tRep - 0.6}><Drop x={960} y={265} s={1.2} /></In>
          <In t={t} cue={tEgg}><g>{[0, 1, 2].map((k) => <Egg key={k} x={1175 + k * 34} y={470 + (k % 2) * 24} s={1.6} />)}</g></In>
          <In t={t} cue={tRep - 0.8}><Mini x={745} y={520} s={2.0} color={C.cloth} /></In>
          <In t={t} cue={tRep}><Chip x={960} y={500} text="বারবার" color={C.accent} size={44} /></In>
          <In t={t} cue={tEgg}><Chip x={1480} y={470} text="ডিমের জন্য রক্ত" color={C.data} size={30} /></In>
        </g>
      )}
    </Svg>
  );
};

/** 123.9-129.8  Eggs go into standing water: vase, bucket, old tyre */
export const SceneWater: React.FC<SceneProps> = ({ t }) => {
  const tStand = W("জমে", 124), tEgg = W("ডিম", 125.8), tVase = W("ফুলদানি,"), tBucket = W("বালতি"), tTyre = W("টায়ারে।");
  const K = [124.1, 125.9, tVase, tBucket, tTyre - 0.2];
  const mx = track(t, K, [1750, 960, 560, 960, 1400]);
  const my = track(t, K, [300, 540, 380, 350, 480]);
  const puddle = Math.min(prog(t, tStand, tStand + 0.4), 1 - prog(t, tVase - 0.2, tVase + 0.2));
  const drop = (cue: number, x: number, y0: number, y1: number, n = 3) =>
    Array.from({ length: n }).map((_, k) => {
      const p = prog(t, cue + k * 0.2, cue + k * 0.2 + 0.7, (x2) => x2);
      return p > 0 && p < 1 ? <Egg key={k} x={x + (k - 1) * 22} y={lerp(y0, y1, p)} s={1.2} /> : null;
    });
  return (
    <Svg>
      <Ground y={GROUND} />
      <g opacity={puddle}>
        <ellipse cx={960} cy={775} rx={300} ry={36} fill={C.water} stroke={C.text} strokeWidth={4} />
        <ellipse cx={900} cy={768} rx={80} ry={9} fill="#fff" opacity={0.55} />
        <Chip x={960} y={650} text="জমে থাকা পানি" color={C.flow} size={32} />
        {drop(tEgg, 960, 560, 765)}
      </g>
      <In t={t} cue={tVase - 0.1} dy={60}><Vase x={520} y={GROUND} s={1.35} /></In>
      <In t={t} cue={tBucket - 0.1} dy={60}><Bucket x={960} y={GROUND} s={1.4} /></In>
      <In t={t} cue={tTyre - 0.3} dy={60}><Tyre x={1400} y={725} s={1.25} /></In>
      <In t={t} cue={tVase}><Chip x={520} y={838} text="ফুলদানি" color={C.data} size={26} /></In>
      <In t={t} cue={tBucket}><Chip x={960} y={838} text="বালতি" color={C.data} size={26} /></In>
      <In t={t} cue={tTyre - 0.2}><Chip x={1400} y={838} text="পুরনো টায়ার" color={C.data} size={26} /></In>
      {drop(tVase + 0.3, 520, 610, 715)}
      {drop(tBucket + 0.3, 960, 540, 585)}
      {drop(tTyre, 1400, 600, 730)}
      <Mosquito x={mx} y={my} s={1.25} t={t} blood={0.5} flip={t > tVase - 0.2 && t < tBucket - 0.1} opacity={prog(t, 124.1, 124.4)} />
    </Svg>
  );
};

/** 129.9-140.8  Life cycle: egg -> larva -> pupa -> adult, about 7 to 10 days */
export const SceneCycle: React.FC<SceneProps> = ({ t }) => {
  const tEgg = W("ডিম", 129.9), tLarva = W("লার্ভা,"), tPupa = W("pupae"), tAdult = W("পূর্ণাঙ্গ"), tEnv = W("উপযুক্ত"), tDays = W("সাত");
  const X = [380, 760, 1140, 1520];
  const cues = [tEgg, tLarva, tPupa, tAdult];
  const NAME = ["ডিম", "লার্ভা", "pupae", "পূর্ণাঙ্গ মশা"];
  const dot = prog(t, tEnv + 0.4, 140.4, INOUT);
  return (
    <Svg>
      {X.map((x, i) => (
        <In key={i} t={t} cue={cues[i] - 0.1} dy={50}>
          <g>
            <circle cx={x} cy={500} r={150} fill={i < 3 ? C.water : C.wall} stroke={C.text} strokeWidth={4} opacity={i < 3 ? 0.9 : 1} />
            {i === 0 && <g>{[0, 1, 2].map((k) => <Egg key={k} x={x - 40 + k * 40} y={500 + (k % 2) * 28} s={1.9} />)}</g>}
            {i === 1 && <Larva x={x - 70} y={500} s={1.6} t={t} />}
            {i === 2 && <Pupa x={x} y={500} s={1.7} t={t} />}
            {i === 3 && <Mosquito x={x + 20} y={500} s={1.1} t={t} />}
            <Chip x={x} y={720} text={NAME[i]} color={i === 3 ? C.accent : C.data} size={30} />
          </g>
        </In>
      ))}
      {[0, 1, 2].map((i) => <Arrow key={i} x1={X[i] + 165} y1={500} x2={X[i + 1] - 165} y2={500} p={prog(t, cues[i + 1] - 0.5, cues[i + 1] - 0.1)} color={C.flow} w={9} />)}
      <g opacity={prog(t, tEnv, tEnv + 0.4)}>
        <line x1={X[0]} y1={810} x2={X[3]} y2={810} stroke={C.muted} strokeWidth={8} strokeLinecap="round" />
        <line x1={X[0]} y1={810} x2={X[0] + (X[3] - X[0]) * dot} y2={810} stroke={C.accent} strokeWidth={8} strokeLinecap="round" />
        <circle cx={X[0] + (X[3] - X[0]) * dot} cy={810} r={14} fill={C.accent} stroke={C.text} strokeWidth={3} />
      </g>
      <In t={t} cue={tDays - 0.4}><Chip x={960} y={240} text="প্রায় ৭ থেকে ১০ দিন" color={C.accent} size={38} /></In>
    </Svg>
  );
};

/** 140.8-155.3  Rest after blood, eggs in 3-5 days, hundreds of eggs, so she must find blood fast */
export const SceneEggs: React.FC<SceneProps> = ({ t }) => {
  const tBlood = W("রক্ত", 141.2), tRest = W("বিশ্রাম"), tDays = W("তিন"), tMany = W("কয়েকশো"), tShort = W("অল্প"), tFast = W("দ্রুত"), tSrc = W("উৎস");
  const pA = Math.min(prog(t, 140.9, 141.3), 1 - prog(t, 150.0, 150.4));
  const pB = prog(t, 150.2, 150.6);
  const ring = prog(t, tDays, tDays + 2.6, INOUT);
  const dash = prog(t, tFast - 0.1, tFast + 0.8, INOUT);
  const d = prog(t, tBlood, tBlood + 0.9);
  return (
    <Svg>
      <Ground y={GROUND} />
      <g opacity={pA}>
        <Mosquito x={560} y={500} s={1.9} t={t * 0.5} blood={prog(t, tBlood + 0.4, tBlood + 1.3)} />
        {d > 0 && d < 1 && <Drop x={lerp(300, 480, d)} y={lerp(380, 520, d)} s={lerp(0.9, 0.3, d)} />}
        {t >= tRest && [0, 1, 2].map((i) => {
          const ph = ((t - tRest) * 0.5 + i / 3) % 1;
          return <text key={i} x={640 + ph * 60 + i * 14} y={380 - ph * 80} fontFamily={FONT} fontWeight={700} fontSize={36 + i * 10} fill={C.data} opacity={Math.sin(ph * Math.PI)}>z</text>;
        })}
        <In t={t} cue={tRest}><Chip x={560} y={250} text="বিশ্রাম" color={C.data} size={32} /></In>
        {/* 3-5 day ring */}
        <g opacity={prog(t, tDays - 0.2, tDays + 0.3)}>
          <circle cx={1280} cy={500} r={110} fill="#fff" stroke={C.muted} strokeWidth={14} opacity={0.9} />
          <circle cx={1280} cy={500} r={110} fill="none" stroke={C.accent} strokeWidth={14} strokeLinecap="round" strokeDasharray={`${ring * 691} 691`} transform="rotate(-90 1280 500)" />
          <text x={1280} y={518} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={54} fill={C.text}>৩–৫</text>
          <text x={1280} y={560} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={26} fill={C.muted}>দিন</text>
          <Chip x={1280} y={320} text="ডিম তৈরি হয়" color={C.accent} size={30} />
        </g>
        {Array.from({ length: 40 }).map((_, k) => {
          const c = tMany + k * 0.025;
          return <Egg key={k} x={1000 + (k % 10) * 62} y={640 + Math.floor(k / 10) * 36 - ((k % 10) % 2) * 6} s={1.1} opacity={prog(t, c, c + 0.2)} />;
        })}
        <In t={t} cue={tMany}><Chip x={1300} y={780} text="একবারে কয়েকশো ডিম" color={C.data} size={30} /></In>
      </g>
      {pB > 0.01 && (
        <g opacity={pB}>
          <In t={t} cue={tShort}><g><Hourglass x={500} y={400} s={1.0} p={prog(t, tShort, tShort + 3)} /><Chip x={500} y={560} text="অল্প সময়" color={C.warn} size={30} /></g></In>
          <In t={t} cue={150.4} dy={50}><Person x={1520} y={GROUND} s={1.0} t={t} cloth={C.cloth} pose="stand" /></In>
          {[0, 1, 2].map((k) => <line key={k} x1={lerp(260, 1140, dash) - 60 - k * 40} y1={640 + k * 22 - 22} x2={lerp(260, 1140, dash) - 130 - k * 40} y2={640 + k * 22 - 22} stroke={C.flow} strokeWidth={7} strokeLinecap="round" opacity={0.8 * prog(t, tFast, tFast + 0.2) * (1 - prog(t, tFast + 0.7, tFast + 1.0))} />)}
          <g opacity={prog(t, tFast - 0.2, tFast)}><Mosquito x={lerp(260, 1220, dash)} y={lerp(520, 560, dash)} s={1.3} t={t} /></g>
          <In t={t} cue={tFast}><Chip x={900} y={250} text="দ্রুত" color={C.accent} size={44} /></In>
          <In t={t} cue={tSrc}><Drop x={1590} y={620} s={1.0} /></In>
          <Ring x={1590} y={620} t={t} cue={tSrc} r={60} color={C.bad} />
          <In t={t} cue={tSrc}><Chip x={1520} y={320} text="রক্তের উৎস" color={C.bad} size={30} /></In>
        </g>
      )}
    </Svg>
  );
};
