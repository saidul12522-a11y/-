import React from "react";
import { theme as C } from "../theme";
import { FONT } from "../fonts";
import { Svg, SceneProps, GROUND, W, track, orbit } from "./common";
import { In, Chip, Ring, Ground, Cross, Check, Card, Arrow, bn } from "../components/kit";
import { Person, Mini, Heart } from "../art/art";
import { Mosquito, Puff, Whiff, Acid, Germ, Oil, Drop, Dna, Bites } from "../art/mosq";
import { prog, pop, lerp, hash, INOUT } from "../motion";

/** 49.4-64.4  Skin oil + bacteria -> carboxylic acid; amount differs person to person */
export const SceneSkin: React.FC<SceneProps> = ({ t }) => {
  const tSkin = W("চামড়ায়", 49.5), tOil = W("তেলকে"), tBac = W("bacteria"), tBreak = W("ভেঙে"), tChem = W("রাসায়নিক"), tAcid = W("কার্বক্সিলিক");
  const tVar = 57.7, tLike = W("মানুষকে", 62);
  const p1 = Math.min(prog(t, 49.5, 49.9), 1 - prog(t, tVar - 0.2, tVar + 0.2));
  const p2 = prog(t, tVar, tVar + 0.5);
  const OX = [300, 470, 640, 810, 980, 1150, 1320, 1490, 1640];
  const GX = [380, 720, 1060, 1400];
  const brk = prog(t, tBreak, tBreak + 1.0);
  const cnt = [2, 5, 9];
  const cx = [390, 960, 1530];
  const ax = track(t, [tLike - 0.4, tLike + 1.4], [1840, 1380]);
  const ay = track(t, [tLike - 0.4, tLike + 1.4], [200, 330]);
  return (
    <Svg>
      <g opacity={p1}>
        <In t={t} cue={tSkin} dy={50}><g>
          <rect x={200} y={600} width={1520} height={190} rx={44} fill={C.skin} stroke={C.text} strokeWidth={4} />
          <rect x={200} y={600} width={1520} height={26} rx={13} fill={C.oil} opacity={0.0} />
          <Chip x={960} y={745} text="চামড়া" color={C.muted} size={28} />
        </g></In>
        {OX.map((x, k) => <In key={k} t={t} cue={tOil + k * 0.08} dy={-60}><Oil x={x} y={584} r={20 * (1 - 0.8 * brk * (k % 2 ? 1 : 0.9))} opacity={1 - 0.7 * brk} /></In>)}
        <In t={t} cue={tOil}><Chip x={420} y={470} text="তেল" color={C.warn} size={30} /></In>
        {GX.map((x, k) => <In key={k} t={t} cue={tBac + k * 0.18} dx={120}><Germ x={x} y={560} s={1.1} t={t + k} /></In>)}
        <In t={t} cue={tBac}><Chip x={1480} y={450} text="bacteria" color={C.good} size={30} /></In>
        {/* little chemical pieces float up */}
        {t >= tChem - 0.2 && t < tAcid && GX.map((x, k) => [0, 1, 2].map((j) => {
          const ph = ((t - tChem) * 0.5 + j / 3 + k * 0.17) % 1;
          return <circle key={k + "_" + j} cx={x + (j - 1) * 36 + Math.sin(ph * 8 + k) * 10} cy={500 - ph * 200} r={9} fill={[C.flow, C.accent, C.good][j]} stroke={C.text} strokeWidth={2} opacity={Math.sin(ph * Math.PI) * prog(t, tChem - 0.2, tChem + 0.2)} />;
        }))}
        <In t={t} cue={tChem} out={tAcid - 0.1}><Chip x={960} y={290} text="ভিন্ন রাসায়নিক পদার্থ" color={C.flow} size={32} /></In>
        {GX.map((x, k) => <In key={k} t={t} cue={tAcid + k * 0.12} dy={20}><Acid x={x} y={440 - (k % 2) * 40} s={0.9} hi={k === 1} /></In>)}
        <In t={t} cue={tAcid}><Chip x={960} y={290} text="কার্বক্সিলিক অ্যাসিড" color={C.accent} size={32} /></In>
      </g>
      {p2 > 0.01 && (
        <g opacity={p2}>
          <In t={t} cue={tVar}><Chip x={960} y={200} text="একেক মানুষে একেক রকম" color={C.data} size={30} /></In>
          {cx.map((x, i) => (
            <In key={i} t={t} cue={tVar + 0.2 + i * 0.25} dy={50}>
              <Card x={x - 220} y={250} w={440} h={420} color={i === 2 && t >= tLike + 1.2 ? C.accent : C.border}>
                <Mini x={x} y={640} s={2.5} color={[C.cloth2, C.cloth, C.warn][i]} />
                {Array.from({ length: cnt[i] }).map((_, k) => {
                  const a = (k / cnt[i]) * Math.PI * 2 + i;
                  return <Acid key={k} x={x + Math.cos(a) * (i === 0 ? 130 : 160) * (k % 2 ? 0.7 : 1) + Math.sin(t * 2 + k) * 4} y={420 + Math.sin(a) * 110 * (k % 2 ? 0.8 : 1)} s={0.42} />;
                })}
              </Card>
            </In>
          ))}
          <g opacity={prog(t, tLike - 0.3, tLike)}><Mosquito x={ax} y={ay} s={1.15} t={t} flip /></g>
          {t >= tLike + 1.2 && <In t={t} cue={tLike + 1.2}><Heart x={1530} y={225} s={1.8} /></In>}
        </g>
      )}
    </Svg>
  );
};

/** 64.4-79.9  US study: participant 33 is the most attractive; x4 and about x21 */
export const SceneStudy: React.FC<SceneProps> = ({ t }) => {
  const tUS = W("আমেরিকার"), tNum = W("তেত্রিশ"), tMost = W("সবচেয়ে", 69.5), tOther = W("অন্য"), tFour = W("চার"), tLeast = W("সবচেয়ে", 74.5), tTw = W("একুশ");
  const pA = Math.min(prog(t, 64.5, 64.9), 1 - prog(t, 71.8, 72.2));
  const pB = prog(t, 72.0, 72.5);
  const U = 56, X0 = 560;
  const barW = (cue: number, units: number, dur = 1.0) => units * U * prog(t, cue, cue + dur, INOUT);
  const lift = pop(t, tNum, "soft");
  return (
    <Svg>
      <Ground y={GROUND} />
      <g opacity={pA}>
        {Array.from({ length: 7 }).map((_, i) => {
          const x = 360 + i * 200, me = i === 3;
          return (
            <In key={i} t={t} cue={tUS + 0.2 + i * 0.1} dy={40}>
              <g><Mini x={x} y={GROUND - 30 - (me ? 18 * lift : 0)} s={me ? 1.7 + 0.5 * lift : 1.7} color={me ? C.accent : [C.cloth, C.cloth2, C.warn, C.flow][i % 4]} opacity={me ? 1 : t >= tNum ? 0.55 : 1} /></g>
            </In>
          );
        })}
        <In t={t} cue={tUS}><Chip x={960} y={240} text="আমেরিকার গবেষণা" color={C.data} size={32} /></In>
        <In t={t} cue={tNum}><Chip x={960} y={420} text="৩৩ নম্বর" color={C.accent} size={32} /></In>
        {t >= tNum && <Ring x={960} y={GROUND - 130} t={t} cue={tNum} r={110} loop />}
        {[0, 1, 2, 3, 4].map((k) => {
          const o = orbit(960, GROUND - 170, 170, 80, t, k, 5, 1.6);
          const c = tMost + k * 0.25;
          const pp = prog(t, c, c + 0.5);
          return <Mosquito key={k} x={lerp(k % 2 ? 1800 : 100, o.x, pp)} y={lerp(260, o.y, pp)} s={0.95} t={t + k} flip={o.flip} opacity={pp} />;
        })}
        <In t={t} cue={tMost}><Chip x={1480} y={420} text="সবচেয়ে বেশি আকর্ষণ" color={C.accent} size={30} /></In>
      </g>
      {pB > 0.01 && (
        <g opacity={pB}>
          <In t={t} cue={72.1}><Chip x={960} y={215} text="৩৩ নম্বর কতটা বেশি?" color={C.data} size={30} /></In>
          {/* comparison 1 */}
          <text x={X0 - 22} y={330} textAnchor="end" fontFamily={FONT} fontWeight={700} fontSize={32} fill={C.text}>৩৩ নম্বর</text>
          <text x={X0 - 22} y={405} textAnchor="end" fontFamily={FONT} fontWeight={700} fontSize={32} fill={C.muted}>অন্য একজন</text>
          <rect x={X0} y={300} width={barW(tFour - 0.2, 4)} height={46} rx={14} fill={C.accent} stroke={C.text} strokeWidth={3} />
          <rect x={X0} y={375} width={barW(tOther, 1, 0.5)} height={46} rx={14} fill={C.muted} stroke={C.text} strokeWidth={3} />
          <g opacity={prog(t, tFour + 0.3, tFour + 0.6)}><text x={X0 + 4 * U + 28} y={338} fontFamily={FONT} fontWeight={700} fontSize={64} fill={C.accent} stroke={C.text} strokeWidth={1.5}>৪ গুণ</text></g>
          {/* comparison 2 */}
          <g opacity={prog(t, tLeast, tLeast + 0.4)}>
            <text x={X0 - 22} y={580} textAnchor="end" fontFamily={FONT} fontWeight={700} fontSize={32} fill={C.text}>৩৩ নম্বর</text>
            <text x={X0 - 22} y={655} textAnchor="end" fontFamily={FONT} fontWeight={700} fontSize={32} fill={C.muted}>সবচেয়ে কম আকর্ষণীয়</text>
            <rect x={X0} y={625} width={U} height={46} rx={14} fill={C.muted} stroke={C.text} strokeWidth={3} />
          </g>
          <rect x={X0} y={550} width={barW(tTw - 0.3, 21, 1.4)} height={46} rx={14} fill={C.accent} stroke={C.text} strokeWidth={3} opacity={t >= tLeast ? 1 : 0} />
          <g opacity={prog(t, tTw + 0.9, tTw + 1.2)}><text x={1720} y={520} textAnchor="end" fontFamily={FONT} fontWeight={700} fontSize={64} fill={C.accent} stroke={C.text} strokeWidth={1.5}>প্রায় ২১ গুণ</text></g>
        </g>
      )}
    </Svg>
  );
};

/** 79.9-86.3  More of certain acids on the skin -> more bites */
export const SceneAcidBites: React.FC<SceneProps> = ({ t }) => {
  const tSkin = W("চামড়ায়", 81.5), tAcid = W("অ্যাসিড", 83), tBite = W("কামড়াতে");
  const A = 620, B = 1300;
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={80.0} dy={60}><Person x={A} y={GROUND} s={1.0} t={t} cloth={C.cloth2} pose="stand" /></In>
      <In t={t} cue={80.1} dy={60}><Person x={B} y={GROUND} s={1.0} t={t} cloth={C.cloth} pose="stand" style="long" /></In>
      {Array.from({ length: 3 }).map((_, k) => <In key={k} t={t} cue={tSkin + k * 0.15}><Acid x={A - 150 + k * 110} y={430 + (k % 2) * 70 + Math.sin(t * 2 + k) * 5} s={0.6} /></In>)}
      {Array.from({ length: 9 }).map((_, k) => <In key={k} t={t} cue={tAcid + k * 0.1}><Acid x={B - 220 + (k % 3) * 150 + Math.sin(t * 2 + k) * 5} y={380 + Math.floor(k / 3) * 85 + (k % 2) * 20} s={0.6} hi /></In>)}
      <In t={t} cue={tAcid}><Chip x={B} y={250} text="অ্যাসিড বেশি" color={C.accent} size={32} /></In>
      <Mosquito x={track(t, [tBite, tBite + 0.8], [900, A + 240])} y={track(t, [tBite, tBite + 0.8], [300, 450])} s={1.1} t={t} opacity={prog(t, tBite, tBite + 0.2)} />
      {[0, 1, 2, 3].map((k) => {
        const o = orbit(B, 470, 250, 90, t, k, 4, 1.4);
        const c = tBite + 0.1 + k * 0.2, pp = prog(t, c, c + 0.5);
        return <Mosquito key={k} x={lerp(1850, o.x, pp)} y={lerp(260, o.y, pp)} s={1.0} t={t + k} flip={o.flip} opacity={pp} />;
      })}
      <g opacity={prog(t, tBite + 0.9, tBite + 1.2)}><Bites x={B + 60} y={640} n={3} s={1} /><Bites x={B - 70} y={560} n={2} s={0.9} /></g>
    </Svg>
  );
};

/** 86.3-97  Eyes help: after detecting CO2, mosquitoes are drawn to red, orange, black, turquoise */
export const SceneColors: React.FC<SceneProps> = ({ t }) => {
  const tNot = W("গন্ধ", 86.5), tNo = W("নয়,"), tEye = W("চোখও"), tCo2 = W("কার্বন", 90), tDet = W("শনাক্ত"), tRed = W("লাল,"), tOr = W("কমলা,"), tBk = W("কালো"), tTq = W("ফিরোজা"), tAtt = W("আকৃষ্ট");
  const COL = [C.swRed, C.swOrange, C.swBlack, C.swTurq];
  const NAME = ["লাল", "কমলা", "কালো", "ফিরোজা"];
  const CUE = [tRed, tOr, tBk, tTq];
  const PX = [900, 1140, 1380, 1620];
  const mx = track(t, [86.4, tAtt, tAtt + 0.9], [330, 330, 520]);
  const my = 450;
  return (
    <Svg>
      <Ground y={GROUND} />
      <Mosquito x={mx} y={my} s={2.3} t={t} opacity={prog(t, 86.4, 86.8)} />
      <g opacity={1 - prog(t, tNo + 0.3, tNo + 0.7)}>
        <In t={t} cue={tNot} dx={-40}><Whiff x={820} y={600} s={1.4} t={t} color={C.good} n={3} /></In>
        <Cross x={820} y={470} t={t} cue={tNo - 0.2} s={1.5} />
      </g>
      <In t={t} cue={tEye}><g><Ring x={mx + 78} y={my + 12} t={t} cue={tEye} r={52} loop /><Chip x={mx + 40} y={250} text="চোখ" color={C.data} size={32} /></g></In>
      <g opacity={Math.min(prog(t, tCo2, tCo2 + 0.3), 1 - prog(t, tRed - 0.4, tRed))}>
        <Puff x={760} y={330} r={54} />
        <Check x={850} y={280} t={t} cue={tDet + 0.2} s={0.9} />
        <Chip x={760} y={440} text="CO₂ শনাক্ত" color={C.flow} size={28} />
      </g>
      {PX.map((x, i) => (
        <g key={i}>
          <In t={t} cue={CUE[i] - 0.1} dy={60}><Person x={x} y={GROUND} s={0.8} t={t} cloth={COL[i]} pose="stand" /></In>
          <In t={t} cue={CUE[i] - 0.05}><Chip x={x} y={837} text={NAME[i]} color={COL[i]} size={26} /></In>
          {t >= CUE[i] && t < CUE[i] + 1.4 && <line x1={mx + 100} y1={my + 20} x2={x - 20} y2={GROUND - 200} stroke={COL[i]} strokeWidth={6} strokeDasharray="14 12" strokeDashoffset={-t * 100} strokeLinecap="round" opacity={0.9 * prog(t, CUE[i], CUE[i] + 0.2) * (1 - prog(t, CUE[i] + 1.1, CUE[i] + 1.4))} />}
          <Ring x={x} y={GROUND - 200} t={t} cue={CUE[i]} r={70} color={COL[i]} />
        </g>
      ))}
    </Svg>
  );
};

/** 97-106.3  Genes, and blood group (O) */
export const SceneGenes: React.FC<SceneProps> = ({ t }) => {
  const tGene = W("জিনের"), tAttr = W("আকর্ষণীয়", 99.5), tBlood = W("রক্তের"), tGrp = W("গ্রুপের"), tBit = W("কামড়ানোর");
  const pA = Math.min(prog(t, 97.2, 97.6), 1 - prog(t, 101.3, 101.7));
  const pB = prog(t, 101.4, 101.9);
  return (
    <Svg>
      <Ground y={GROUND} />
      <g opacity={pA}>
        <In t={t} cue={tGene - 0.1}><Dna x={480} y={250} h={440} w={90} t={t} /></In>
        <In t={t} cue={tGene}><Chip x={480} y={780} text="জিন" color={C.data} size={32} /></In>
        <In t={t} cue={tGene + 0.5}><Arrow x1={640} y1={500} x2={900} y2={500} p={prog(t, tGene + 0.5, tGene + 1.1)} color={C.flow} /></In>
        <In t={t} cue={tGene + 0.7} dy={50}><Person x={1150} y={GROUND} s={1.0} t={t} cloth={C.cloth} pose="stand" /></In>
        {[0, 1, 2].map((k) => {
          const o = orbit(1150, 440, 230, 90, t, k, 3, 1.5);
          const c = tAttr + k * 0.2, pp = prog(t, c, c + 0.5);
          return <Mosquito key={k} x={lerp(1860, o.x, pp)} y={lerp(260, o.y, pp)} s={1.0} t={t + k} flip={o.flip} opacity={pp} />;
        })}
      </g>
      {pB > 0.01 && (
        <g opacity={pB}>
          <In t={t} cue={tBlood}><Chip x={960} y={235} text="রক্তের গ্রুপ" color={C.bad} size={32} /></In>
          <In t={t} cue={tBlood} dy={30}><Drop x={960} y={520} s={3.4} label="ও" /></In>
          {[0, 1, 2, 3].map((k) => {
            const o = orbit(960, 520, 330, 150, t, k, 4, 1.3);
            const c = tBit + k * 0.2 - 0.4, pp = prog(t, c, c + 0.5);
            return <Mosquito key={k} x={lerp(k % 2 ? 1870 : 50, o.x, pp)} y={lerp(240, o.y, pp)} s={1.0} t={t + k} flip={o.flip} opacity={pp} />;
          })}
        </g>
      )}
    </Svg>
  );
};
