import React from "react";
import { theme as C } from "../theme";
import { FONT } from "../fonts";
import { Svg, SceneProps, GROUND, W, track, Room } from "./common";
import { In, Chip, Ring, Ground, Cross, Check, Arrow } from "../components/kit";
import { Person } from "../art/art";
import { Mosquito, Bed, Window, Puff, Thermo, Whiff, Bites, Itch, Drop, Egg } from "../art/mosq";
import { prog, pop, lerp, hash } from "../motion";

const XS = [-2, -1, 0, 1, 2].map((i) => 960 + i * 340);
const CL = [C.cloth, C.cloth2, C.warn, C.data, C.flow];
const V = 3; // the person who gets bitten

/** 0-10.2  Night: five sleep, one mosquito bites one. Morning: four fine, one itchy. */
export const SceneBedroom: React.FC<SceneProps> = ({ t }) => {
  const tFive = W("পাঁচজন"), tMos = W("মশা", 2), tOne = W("একজনকেই"), tBite = W("কামড়ালো।");
  const tMorn = W("সকালে"), tWake = W("উঠলেও"), tHand = W("হাতে"), tLeg = W("পায়ে");
  const day = prog(t, tMorn, tMorn + 0.9);
  const swap = prog(t, tMorn + 0.5, tMorn + 1.1);
  const K = [tMos, tOne, tBite - 0.5, tBite + 0.6, tBite + 1.5];
  const fx = track(t, K, [980, 1160, 1250, 1250, 1600]);
  const fy = track(t, K, [330, 430, 655, 655, 300]);
  const mosOp = Math.min(prog(t, tMos, tMos + 0.25), 1 - prog(t, tMorn - 0.3, tMorn + 0.2));
  const blood = prog(t, tBite - 0.2, tBite + 0.6);
  return (
    <Svg>
      <Room tint={1 - day} />
      <Window x={960} y={330} day={day} t={t} />
      {XS.map((x, i) => (
        <g key={"b" + i} opacity={1 - swap}>
          <In t={t} cue={tFive + i * 0.16} dy={70}><Bed x={x} y={GROUND} s={0.9} t={t + i} cloth={CL[i]} /></In>
        </g>
      ))}
      {swap > 0.01 && XS.map((x, i) => {
        const hurt = i === V;
        const pose = hurt ? (t >= tHand - 0.3 ? "worry" : "stand") : t < tHand - 0.2 ? "up" : "stand";
        return <g key={"p" + i} opacity={swap}><Person x={x} y={GROUND} s={0.9} pose={pose} t={t} cloth={CL[i]} style={i === 1 ? "long" : "short"} /></g>;
      })}
      <g opacity={mosOp}><Mosquito x={fx} y={fy} s={1.3} t={t} blood={blood} /></g>
      <In t={t} cue={tFive}><Chip x={430} y={330} text="৫ জন" color={C.data} size={30} /></In>
      <In t={t} cue={tMos + 0.2} out={tMorn}><Chip x={1560} y={250} text="১টি মশা" color={C.accent} size={30} /></In>
      <Ring x={1362} y={694} t={t} cue={tBite - 0.1} r={46} color={C.bad} />
      {XS.map((x, i) => i !== V && <Check key={"c" + i} x={x} y={470} t={t} cue={tWake + 0.15 * i} s={0.8} />)}
      <In t={t} cue={tHand - 0.1}><Chip x={XS[V]} y={400} text="১ জন" color={C.bad} size={30} /></In>
      {t >= tHand && <Itch x={XS[V] + 50} y={525} s={0.8} t={t} />}
      <g><Bites x={XS[V] + 36} y={585} n={3} s={0.8} opacity={pop(t, tHand + 0.1, "snap")} /><Ring x={XS[V] + 36} y={575} t={t} cue={tHand + 0.1} r={34} color={C.bad} /></g>
      <g><Bites x={XS[V] + 18} y={735} n={2} s={0.8} opacity={pop(t, tLeg + 0.1, "snap")} /><Ring x={XS[V] + 18} y={735} t={t} cue={tLeg + 0.1} r={34} color={C.bad} /></g>
    </Svg>
  );
};

/** 10.2-20.2  "Does the mosquito really choose?" -> yes, by signals from the body */
export const SceneChoose: React.FC<SceneProps> = ({ t }) => {
  const tQ = W("মশা", 10.8), tPick = W("বেছে", 11.5), tYes = W("হ্যাঁ।"), tSig = W("শরীর", 15), tFind = W("খুঁজে", 19);
  const XP = [520, 960, 1400];
  const CH = 1;
  const dive = prog(t, tFind - 0.3, tFind + 0.5);
  const mx = lerp(960 + Math.sin(t * 1.6) * 40, 1030, dive);
  const my = lerp(300, 400, dive);
  const ms = lerp(1.8, 1.3, dive);
  const scan = t >= tPick && t < tYes ? Math.floor((t - tPick) / 0.5) % 3 : -1;
  const yes = pop(t, tYes);
  const dim = prog(t, tYes, tYes + 0.4);
  return (
    <Svg>
      <Ground y={GROUND} />
      {XP.map((x, i) => (
        <In key={i} t={t} cue={10.3 + i * 0.12} dy={60}>
          <g opacity={i === CH ? 1 : 1 - 0.55 * dim}><Person x={x} y={GROUND} s={0.9} t={t} cloth={CL[i]} style={i === 1 ? "long" : "short"} pose="stand" /></g>
        </In>
      ))}
      {scan >= 0 && (
        <line x1={mx} y1={my + 70} x2={XP[scan]} y2={500} stroke={C.muted} strokeWidth={5} strokeDasharray="14 12" strokeDashoffset={-t * 90} strokeLinecap="round" opacity={0.8} />
      )}
      {/* signals from the chosen person */}
      {t >= tSig && [0, 1, 2].map((k) => {
        const ph = ((t - tSig) * 0.7 + k / 3) % 1;
        return <circle key={k} cx={XP[CH]} cy={500} r={50 + ph * 250} fill="none" stroke={C.flow} strokeWidth={6} opacity={0.75 * (1 - ph) * prog(t, tSig, tSig + 0.4)} />;
      })}
      <In t={t} cue={tSig + 0.3}><Chip x={1210} y={650} text="শরীরের সংকেত" color={C.flow} size={30} /></In>
      <In t={t} cue={tYes}><Ring x={XP[CH]} y={560} t={t} cue={tYes} r={150} loop /></In>
      <g opacity={tQ <= t ? 1 : 0}><Mosquito x={mx} y={my} s={ms} t={t} flip={false} /></g>
      <In t={t} cue={tQ} out={tYes}>
        <text x={1260} y={300 + Math.sin(t * 6) * -8} textAnchor="middle" fontSize={210} fontWeight={700} fill={C.accent} fontFamily={FONT} stroke={C.text} strokeWidth={5}>?</text>
      </In>
      {yes > 0.01 && (
        <g transform={`translate(1260 300) rotate(-5) scale(${yes})`}>
          <rect x={-150} y={-62} width={300} height={124} rx={34} fill={C.good} stroke={C.text} strokeWidth={5} />
          <text x={0} y={30} textAnchor="middle" fontSize={84} fontWeight={700} fill="#fff" fontFamily={FONT}>হ্যাঁ</text>
        </g>
      )}
      <Ring x={mx + 60} y={my + 30} t={t} cue={tFind + 0.4} r={60} color={C.bad} />
    </Svg>
  );
};

/** 20.2-29.3  Only the female drinks human blood (to make eggs); the male does not */
export const SceneFemale: React.FC<SceneProps> = ({ t }) => {
  const tFem = W("স্ত্রী", 21), tBlood = W("রক্ত", 22.9), tEgg = W("ডিম", 24.5), tMale = W("পুরুষ"), tBM = W("রক্ত", 27.7), tNo = W("না।", 29);
  const d = prog(t, tBlood, tBlood + 0.9);
  const bl = prog(t, tBlood + 0.5, tBlood + 1.4);
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={20.3} dy={60}><Person x={960} y={GROUND} s={0.95} t={t} pose="stand" cloth={C.cloth} /></In>
      <In t={t} cue={tFem - 0.1} dy={30}><g><Mosquito x={790} y={650} s={1.2} t={t} blood={bl} /></g></In>
      <In t={t} cue={tFem}><Chip x={690} y={450} text="স্ত্রী মশা" color={C.accent} size={32} /></In>
      {d > 0 && d < 1 && <Drop x={lerp(905, 735, d)} y={lerp(676, 668, d) - Math.sin(d * Math.PI) * 40} s={lerp(0.5, 0.3, d)} />}
      {Array.from({ length: 5 }).map((_, k) => {
        const p = prog(t, tEgg + k * 0.18, tEgg + k * 0.18 + 1.0);
        if (p <= 0) return null;
        return <Egg key={k} x={lerp(700, 470 + (k % 3) * 52, p)} y={lerp(690, 520 - Math.floor(k / 3) * 56, p) - Math.sin(p * Math.PI) * 30} s={1.3} opacity={Math.min(1, p * 4)} />;
      })}
      <In t={t} cue={tEgg + 0.5}><Chip x={520} y={440} text="ডিম" color={C.data} size={30} /></In>
      <In t={t} cue={tMale - 0.1} dy={30}><Mosquito x={1270} y={620} s={1.2} t={t} flip female={false} /></In>
      <In t={t} cue={tMale}><Chip x={1350} y={450} text="পুরুষ মশা" color={C.data} size={32} /></In>
      <Cross x={1130} y={668} t={t} cue={tBM} s={1.1} />
      <In t={t} cue={tNo}><Chip x={1350} y={780} text="রক্ত নয়" color={C.bad} size={28} /></In>
    </Svg>
  );
};

/** 29.4-42  Carbon dioxide from the breath, detected from far away; more CO2 = more attractive */
export const SceneCo2: React.FC<SceneProps> = ({ t }) => {
  const tDur = W("দূর"), tBreath = W("নিঃশ্বাসের"), tCo2 = W("কার্বন", 33), tDet = W("শনাক্ত"), tMore = W("বেশি", 36.2), tAttr = W("আকর্ষণীয়", 39);
  const p1 = Math.min(prog(t, 29.5, 29.9), 1 - prog(t, 35.9, 36.3));
  const mx1 = track(t, [29.5, tBreath, tDet], [230, 330, 800]);
  const my1 = track(t, [29.5, tBreath, tDet], [330, 380, 430]);
  const ph2 = prog(t, 36.2, 36.6);
  return (
    <Svg>
      <Ground y={GROUND} />
      {/* phase 1: one person, breath trail, mosquito far away */}
      <g opacity={p1}>
        <Person x={1500} y={GROUND} s={1.0} t={t} cloth={C.cloth} pose="stand" />
        <Mosquito x={mx1} y={my1} s={1.3} t={t} flip={false} />
        <In t={t} cue={tDur}><g>
          <line x1={330} y1={600} x2={1420} y2={600} stroke={C.muted} strokeWidth={5} strokeDasharray="6 12" strokeLinecap="round" />
          <path d="M 340 580 L 320 600 L 340 620 M 1410 580 L 1430 600 L 1410 620" stroke={C.muted} strokeWidth={5} fill="none" strokeLinecap="round" />
          <Chip x={880} y={600} text="দূর থেকে" color={C.muted} size={30} />
        </g></In>
        {t >= tBreath && Array.from({ length: 6 }).map((_, k) => {
          const ph = ((t - tBreath) * 0.28 + k / 6) % 1;
          return <Puff key={k} x={1430 - ph * 980} y={500 + Math.sin(ph * 7 + k) * 26} r={22 + ph * 22} opacity={Math.min(1, ph * 6) * (1 - ph * 0.3)} />;
        })}
        <In t={t} cue={tCo2}><Chip x={1000} y={300} text="কার্বন ডাই অক্সাইড" color={C.flow} size={32} /></In>
        <Ring x={mx1 + 40} y={my1 + 10} t={t} cue={tDet} r={90} />
        <Check x={mx1 + 40} y={my1 - 110} t={t} cue={tDet + 0.2} s={1.1} />
      </g>
      {/* phase 2: more CO2 = more mosquitoes */}
      {ph2 > 0.01 && (
        <g opacity={ph2}>
          <Person x={640} y={GROUND} s={0.95} t={t} cloth={C.cloth2} pose="stand" />
          <Person x={1280} y={GROUND} s={0.95} t={t} cloth={C.cloth} pose="stand" />
          {[0, 1].map((k) => <Puff key={"a" + k} x={760 + k * 60} y={430 - k * 40 + Math.sin(t * 3 + k) * 6} r={24} opacity={prog(t, 36.6 + k * 0.2, 37 + k * 0.2) * 0.9} />)}
          {t >= W("কার্বন", 36.5) && [0, 1, 2, 3, 4, 5].map((k) => {
            const a = [0, 1, 2, 3, 4, 5][k];
            return <Puff key={"b" + k} x={1400 + (k % 3) * 78 + Math.sin(t * 2 + k) * 6} y={470 - Math.floor(k / 3) * 88 - (k % 3) * 20} r={36} opacity={prog(t, W("কার্বন", 36.5) + a * 0.15, W("কার্বন", 36.5) + a * 0.15 + 0.4)} />;
          })}
          <In t={t} cue={tMore}><Chip x={1280} y={260} text="বেশি CO₂" color={C.accent} size={32} /></In>
          <In t={t} cue={tMore} out={tMore + 6}><Chip x={640} y={260} text="কম" color={C.muted} size={30} /></In>
          <Mosquito x={track(t, [36.9, 38.4], [1000, 730])} y={track(t, [36.9, 38.4], [280, 400])} s={1.1} t={t} opacity={prog(t, 36.9, 37.2)} />
          {[[1160, 300], [1560, 340], [1180, 560], [1520, 520]].map(([tx, ty], k) => {
            const c = tMore + 0.6 + k * 0.45;
            return <Mosquito key={k} x={track(t, [c, c + 1.5], [1840, tx])} y={track(t, [c, c + 1.5], [240 + k * 40, ty])} s={1.1} t={t + k} flip={k % 2 === 1} opacity={prog(t, c, c + 0.2)} />;
          })}
          <In t={t} cue={tAttr}><g transform="translate(1280 150)"><path d="M 0 30 C -50 -10 -30 -50 0 -20 C 30 -50 50 -10 0 30 Z" fill={C.bad} stroke={C.text} strokeWidth={4} strokeLinejoin="round" transform="scale(1.4)" /></g></In>
        </g>
      )}
    </Svg>
  );
};

/** 42-49.4  Close up: body temperature and skin smell */
export const SceneTemp: React.FC<SceneProps> = ({ t }) => {
  const tArr = W("পৌঁছানোর"), tNote = W("খেয়াল"), tTemp = W("তাপমাত্রা", 46), tSmell = W("চামড়ার", 48);
  const mx = track(t, [42.2, tArr + 0.7], [1760, 1060]);
  const my = track(t, [42.2, tArr + 0.7], [260, 430]);
  const lvl = prog(t, tTemp, tTemp + 1.0);
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={42.1} dy={60}><Person x={600} y={GROUND} s={1.25} t={t} cloth={C.cloth2} pose="stand" /></In>
      <Mosquito x={mx} y={my} s={1.6} t={t} flip opacity={prog(t, 42.2, 42.5)} />
      <In t={t} cue={tNote}><g><Ring x={1010} y={400} t={t} cue={tNote} r={100} /><text x={1010} y={300} textAnchor="middle" fontSize={96} fontWeight={700} fill={C.accent} fontFamily={FONT} stroke={C.text} strokeWidth={4}>!</text></g></In>
      {t >= tTemp - 0.1 && <Whiff x={600} y={GROUND - 250} s={1.4} t={t} color={C.warn} n={3} opacity={prog(t, tTemp - 0.1, tTemp + 0.3)} />}
      <In t={t} cue={tTemp - 0.1}><g><Thermo x={1500} y={760} s={1.6} level={0.2 + 0.8 * lvl} /><Chip x={1500} y={310} text="শরীরের তাপমাত্রা" color={C.warn} size={30} /></g></In>
      {t >= tSmell - 0.1 && <Whiff x={780} y={GROUND - 420} s={1.1} t={t} color={C.good} n={3} opacity={prog(t, tSmell - 0.1, tSmell + 0.3)} />}
      <In t={t} cue={tSmell - 0.1}><Chip x={900} y={260} text="চামড়ার গন্ধ" color={C.good} size={30} /></In>
    </Svg>
  );
};
