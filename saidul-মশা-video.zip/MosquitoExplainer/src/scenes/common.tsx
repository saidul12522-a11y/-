import React from "react";
import { interpolate } from "remotion";
import { AbsoluteFill } from "remotion";
import { L } from "../layout";
import { FONT } from "../fonts";
import { wordTime } from "../captions";
import { theme as C } from "../theme";
import { glen } from "../captions";

export type SceneProps = { t: number };
export const Svg: React.FC<{ children?: React.ReactNode }> = ({ children }) => (
  <AbsoluteFill>
    <svg width={L.w} height={L.h} viewBox="0 0 1920 1080" style={{ fontFamily: FONT }}>{children}</svg>
  </AbsoluteFill>
);
export const GROUND = 790;

/** time (s) of the first caption word containing `needle` at or after `after` */
export const W = (needle: string, after = 0) => wordTime(needle, after);

/** fixed-width pill with a big value, e.g. "১০০ জন" */
export const Pill: React.FC<{ x: number; y: number; text: string; color?: string; size?: number; w?: number }> = ({ x, y, text, color = C.accent, size = 44, w }) => {
  const ww = w ?? glen(text) * size * (/[\u0980-\u09FF]/.test(text) ? 0.7 : 0.62) + 56;
  const h = size * 1.7;
  return (
    <g>
      <rect x={x - ww / 2} y={y - h / 2 + 5} width={ww} height={h} rx={h / 2} fill="rgba(16,35,58,0.10)" />
      <rect x={x - ww / 2} y={y - h / 2} width={ww} height={h} rx={h / 2} fill={C.surface} stroke={color} strokeWidth={4} />
      <text x={x} y={y + size * 0.36} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={size} fill={C.text}>{text}</text>
    </g>
  );
};

/** piecewise-linear value over time */
export const track = (t: number, times: number[], vals: number[]) => interpolate(t, times, vals, { extrapolateLeft: "clamp", extrapolateRight: "clamp" });

/** wall + floor of a room (behind people and beds) */
export const Room: React.FC<{ tint?: number }> = ({ tint = 0 }) => (
  <g>
    <rect x={0} y={150} width={1920} height={GROUND - 150} fill={C.wall} opacity={0.75} />
    <rect x={0} y={GROUND - 22} width={1920} height={22} fill={C.tint} />
    <rect x={0} y={GROUND} width={1920} height={1080 - GROUND} fill={C.floor} />
    <rect x={0} y={GROUND} width={1920} height={6} fill={C.border} />
    {tint > 0 && <rect x={0} y={150} width={1920} height={1000} fill={C.night} opacity={0.14 * tint} />}
  </g>
);

/** point on an ellipse orbit for swarming mosquitoes; flip = moving left */
export const orbit = (cx: number, cy: number, rx: number, ry: number, t: number, k: number, n: number, speed = 1.3) => {
  const a = t * speed + (k / n) * Math.PI * 2;
  return { x: cx + Math.cos(a) * rx, y: cy + Math.sin(a) * ry, flip: Math.sin(a) > 0 };
};
