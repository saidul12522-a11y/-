import React from "react";
import { theme as C } from "../theme";
import { FONT } from "../fonts";
import { cl } from "../motion";

const OUT = C.text;
const sw = 4;

/**
 * Icon-style mosquito (whole-object animation only: wing shimmer + hover bob). Faces RIGHT, origin = thorax centre.
 * Natural size ~175 x 110. female = long needle mouth; blood 0..1 fills the belly red.
 */
export const Mosquito: React.FC<{
  x: number; y: number; s?: number; t?: number; rot?: number; flip?: boolean; female?: boolean; blood?: number; opacity?: number; bob?: boolean; dead?: boolean;
}> = ({ x, y, s = 1, t = 0, rot = 0, flip = false, female = true, blood = 0, opacity = 1, bob = true, dead = false }) => {
  const wob = bob && !dead ? Math.sin(t * 9 + x * 0.013) * 5 : 0;
  const flap = dead ? 0 : Math.sin(t * 55) * 16;
  return (
    <g opacity={opacity} transform={`translate(${x} ${y + wob}) rotate(${rot}) scale(${flip ? -s : s} ${s})`}>
      <g stroke={OUT} strokeWidth={3} fill="none" strokeLinecap="round" strokeLinejoin="round">
        <path d="M -10 12 L -26 40 L -36 60" /><path d="M 2 14 L 4 44 L -2 64" /><path d="M 14 12 L 32 36 L 44 54" />
      </g>
      <ellipse cx={-14} cy={-24} rx={48} ry={13} transform={`rotate(${-28 + flap} 0 -8)`} fill="#fff" fillOpacity={0.78} stroke={OUT} strokeWidth={2.5} />
      <ellipse cx={-6} cy={-20} rx={44} ry={12} transform={`rotate(${-6 - flap * 0.6} 0 -8)`} fill="#fff" fillOpacity={0.6} stroke={OUT} strokeWidth={2.5} />
      <g transform="rotate(10 -30 8)">
        <ellipse cx={-52} cy={8} rx={44} ry={16} fill={C.night} stroke={OUT} strokeWidth={sw} />
        {blood > 0 && <ellipse cx={-52} cy={8} rx={42 * (0.6 + 0.4 * blood)} ry={14 * (0.6 + 0.5 * blood)} fill={C.blood} opacity={cl(blood * 1.4)} />}
        {[-34, -48, -62, -76].map((lx) => <line key={lx} x1={lx} y1={-6} x2={lx} y2={22} stroke={C.muted} strokeWidth={3} opacity={0.7} />)}
      </g>
      <ellipse cx={0} cy={0} rx={25} ry={18} fill={C.night} stroke={OUT} strokeWidth={sw} />
      <circle cx={32} cy={4} r={14} fill={C.night} stroke={OUT} strokeWidth={sw} />
      {dead ? (
        <path d="M 30 -3 l 9 9 M 39 -3 l -9 9" stroke="#fff" strokeWidth={3} strokeLinecap="round" />
      ) : (
        <g><circle cx={37} cy={1} r={5} fill="#fff" /><circle cx={38.5} cy={1.5} r={2.2} fill={OUT} /></g>
      )}
      {female ? (
        <path d="M 44 9 L 84 24" stroke={OUT} strokeWidth={4} strokeLinecap="round" />
      ) : (
        <g stroke={OUT} strokeWidth={3} strokeLinecap="round" fill="none">
          <path d="M 44 9 L 58 16" />
          <path d="M 36 -9 L 56 -32 M 48 -22 l 8 2 M 52 -27 l 8 3 M 42 -15 l 8 2" />
        </g>
      )}
      {female && <path d="M 36 -9 L 54 -30" stroke={OUT} strokeWidth={3} strokeLinecap="round" fill="none" />}
    </g>
  );
};

/** Bed with a sleeping person (side view). Origin = floor, bottom centre. ~300 wide x 130 high. */
export const Bed: React.FC<{ x: number; y: number; s?: number; t?: number; cloth?: string; zz?: boolean; opacity?: number }> = ({ x, y, s = 1, t = 0, cloth = C.cloth, zz = true, opacity = 1 }) => (
  <g opacity={opacity} transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-132} y={-30} width={22} height={30} rx={5} fill={C.gold} stroke={OUT} strokeWidth={3} />
    <rect x={110} y={-30} width={22} height={30} rx={5} fill={C.gold} stroke={OUT} strokeWidth={3} />
    <rect x={-150} y={-124} width={20} height={96} rx={8} fill={C.gold} stroke={OUT} strokeWidth={sw} />
    <rect x={-140} y={-62} width={280} height={34} rx={10} fill={C.gold} stroke={OUT} strokeWidth={sw} />
    <rect x={-128} y={-90} width={64} height={30} rx={14} fill="#fff" stroke={OUT} strokeWidth={3} />
    <circle cx={-96} cy={-96} r={26} fill={C.skin} stroke={OUT} strokeWidth={sw} />
    <path d="M -122 -100 A 26 26 0 0 1 -70 -100 Q -86 -122 -122 -100 Z" fill={C.night} stroke={OUT} strokeWidth={3} strokeLinejoin="round" />
    <path d="M -108 -92 q 6 5 12 0 M -90 -92 q 6 5 12 0" stroke={OUT} strokeWidth={3} fill="none" strokeLinecap="round" />
    <rect x={-72} y={-92} width={206} height={44} rx={22} fill={cloth} stroke={OUT} strokeWidth={sw} />
    <path d="M -40 -88 q 20 12 40 0 M 30 -88 q 20 12 40 0" stroke="rgba(255,255,255,0.45)" strokeWidth={3} fill="none" strokeLinecap="round" />
    {zz && [0, 1, 2].map((i) => {
      const ph = (t * 0.6 + i / 3) % 1;
      return <text key={i} x={-70 + ph * 40 + i * 8} y={-132 - ph * 54} fontFamily={FONT} fontWeight={700} fontSize={26 + i * 8} fill={C.data} opacity={Math.sin(ph * Math.PI) * 0.9}>z</text>;
    })}
  </g>
);

/** Wall window. day 0 = night (moon, stars), 1 = morning (sun). Origin = centre. */
export const Window: React.FC<{ x: number; y: number; s?: number; day?: number; t?: number }> = ({ x, y, s = 1, day = 0, t = 0 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-120} y={-140} width={240} height={280} rx={16} fill={C.surface} stroke={OUT} strokeWidth={sw} />
    <rect x={-104} y={-124} width={208} height={248} rx={8} fill={C.night} opacity={0.9 * (1 - day)} />
    <rect x={-104} y={-124} width={208} height={248} rx={8} fill={C.water} opacity={day} />
    <g opacity={1 - day}>
      <circle cx={46} cy={-66} r={26} fill={C.gold} /><circle cx={58} cy={-74} r={22} fill={C.night} />
      {[[-56, -80], [-20, -30], [-70, 10], [30, 20]].map(([sx, sy], i) => <circle key={i} cx={sx} cy={sy} r={3 + (i % 2)} fill="#fff" opacity={0.6 + 0.4 * Math.sin(t * 3 + i)} />)}
    </g>
    <g opacity={day} transform={`translate(-30 -60) rotate(${t * 12})`}>
      {Array.from({ length: 8 }).map((_, i) => <line key={i} x1={0} y1={-44} x2={0} y2={-64} stroke={C.gold} strokeWidth={6} strokeLinecap="round" transform={`rotate(${i * 45})`} />)}
      <circle r={32} fill={C.gold} stroke={OUT} strokeWidth={3} />
    </g>
    <line x1={0} y1={-124} x2={0} y2={124} stroke={OUT} strokeWidth={sw} /><line x1={-104} y1={0} x2={104} y2={0} stroke={OUT} strokeWidth={sw} />
  </g>
);

/** CO2 puff. Origin = centre. */
export const Puff: React.FC<{ x: number; y: number; r?: number; opacity?: number; color?: string }> = ({ x, y, r = 40, opacity = 1, color = C.flow }) => (
  <g opacity={opacity}>
    <circle cx={x} cy={y} r={r} fill="#fff" fillOpacity={0.92} stroke={color} strokeWidth={4} />
    <text x={x} y={y + r * 0.26} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={r * 0.72} fill={C.text}>CO₂</text>
  </g>
);

/** Thermometer. Origin = bottom centre of the bulb. level 0..1 */
export const Thermo: React.FC<{ x: number; y: number; s?: number; level?: number }> = ({ x, y, s = 1, level = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-16} y={-170} width={32} height={150} rx={16} fill="#fff" stroke={OUT} strokeWidth={sw} />
    <rect x={-8} y={-30 - 124 * level} width={16} height={30 + 124 * level} rx={8} fill={C.bad} />
    <circle cx={0} cy={-6} r={26} fill={C.bad} stroke={OUT} strokeWidth={sw} />
    {[-140, -110, -80].map((ty) => <line key={ty} x1={16} y1={ty} x2={32} y2={ty} stroke={OUT} strokeWidth={3} strokeLinecap="round" />)}
  </g>
);

/** Wavy heat / smell lines rising. Origin = bottom centre. */
export const Whiff: React.FC<{ x: number; y: number; s?: number; t?: number; color?: string; n?: number; opacity?: number }> = ({ x, y, s = 1, t = 0, color = C.good, n = 3, opacity = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={opacity} fill="none" stroke={color} strokeWidth={6} strokeLinecap="round">
    {Array.from({ length: n }).map((_, i) => {
      const ph = Math.sin(t * 4 + i * 1.3) * 5;
      return <path key={i} d={`M ${(i - (n - 1) / 2) * 40} 0 q ${14 + ph} -26 0 -52 q ${-14 - ph} -26 0 -52`} opacity={0.55 + 0.4 * Math.sin(t * 3 + i)} />;
    })}
  </g>
);

/** Carboxylic-acid style molecule icon (balls and sticks). Origin = centre. ~100 wide. */
export const Acid: React.FC<{ x: number; y: number; s?: number; opacity?: number; hi?: boolean }> = ({ x, y, s = 1, opacity = 1, hi = false }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={opacity}>
    <g stroke={OUT} strokeWidth={5} strokeLinecap="round">
      <line x1={-34} y1={14} x2={0} y2={-8} /><line x1={0} y1={-8} x2={30} y2={-38} /><line x1={6} y1={-4} x2={36} y2={-34} stroke={OUT} /><line x1={0} y1={-8} x2={34} y2={20} />
    </g>
    <circle cx={-34} cy={14} r={15} fill={hi ? C.accent : C.muted} stroke={OUT} strokeWidth={3} />
    <circle cx={0} cy={-8} r={17} fill={C.tint} stroke={OUT} strokeWidth={3} />
    <circle cx={32} cy={-38} r={15} fill={C.bad} stroke={OUT} strokeWidth={3} />
    <circle cx={34} cy={22} r={15} fill={C.data} stroke={OUT} strokeWidth={3} />
  </g>
);

/** Skin bacterium (capsule with tail). Origin = centre. */
export const Germ: React.FC<{ x: number; y: number; s?: number; rot?: number; t?: number; opacity?: number }> = ({ x, y, s = 1, rot = 0, t = 0, opacity = 1 }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot + Math.sin(t * 3 + x) * 6}) scale(${s})`} opacity={opacity}>
    <path d={`M -34 8 q -16 ${10 + Math.sin(t * 6) * 4} -30 0`} stroke={C.bacteria} strokeWidth={5} fill="none" strokeLinecap="round" />
    <rect x={-40} y={-20} width={80} height={40} rx={20} fill={C.bacteria} stroke={OUT} strokeWidth={4} />
    <circle cx={14} cy={-3} r={5} fill="#fff" /><circle cx={30} cy={-3} r={5} fill="#fff" /><circle cx={15} cy={-2} r={2.2} fill={OUT} /><circle cx={31} cy={-2} r={2.2} fill={OUT} />
    <path d="M 16 8 q 8 6 16 0" stroke={OUT} strokeWidth={3} fill="none" strokeLinecap="round" />
  </g>
);

/** Skin oil droplet. */
export const Oil: React.FC<{ x: number; y: number; r?: number; opacity?: number }> = ({ x, y, r = 20, opacity = 1 }) => (
  <g opacity={opacity}><circle cx={x} cy={y} r={r} fill={C.oil} stroke={OUT} strokeWidth={3} /><circle cx={x - r * 0.3} cy={y - r * 0.3} r={r * 0.22} fill="#fff" opacity={0.8} /></g>
);

/** Blood drop, optional letter. Origin = centre of the round part. ~70 wide. */
export const Drop: React.FC<{ x: number; y: number; s?: number; label?: string; opacity?: number }> = ({ x, y, s = 1, label, opacity = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={opacity}>
    <path d="M 0 -62 C 30 -24 38 -4 38 14 A 38 38 0 0 1 -38 14 C -38 -4 -30 -24 0 -62 Z" fill={C.blood} stroke={OUT} strokeWidth={sw} strokeLinejoin="round" />
    <path d="M -20 8 A 22 22 0 0 0 -4 34" stroke="#fff" strokeWidth={6} fill="none" strokeLinecap="round" opacity={0.6} />
    {label && <text x={0} y={30} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={44} fill="#fff">{label}</text>}
  </g>
);

export const Egg: React.FC<{ x: number; y: number; s?: number; opacity?: number; rot?: number }> = ({ x, y, s = 1, opacity = 1, rot = 0 }) => (
  <ellipse cx={x} cy={y} rx={14 * s} ry={20 * s} transform={`rotate(${rot} ${x} ${y})`} fill={C.surface} stroke={OUT} strokeWidth={3} opacity={opacity} />
);

/** Wriggling larva, head on the left. Origin = head centre. */
export const Larva: React.FC<{ x: number; y: number; s?: number; t?: number; opacity?: number }> = ({ x, y, s = 1, t = 0, opacity = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={opacity}>
    {Array.from({ length: 7 }).map((_, i) => {
      const k = 6 - i;
      return <circle key={i} cx={k * 22} cy={Math.sin(t * 6 - k * 0.9) * 10} r={14 - k * 1.1} fill={C.gold} stroke={OUT} strokeWidth={3} />;
    })}
    <circle cx={0} cy={Math.sin(t * 6) * 10} r={18} fill={C.gold} stroke={OUT} strokeWidth={4} />
    <circle cx={-5} cy={Math.sin(t * 6) * 10 - 3} r={3.5} fill={OUT} />
  </g>
);

/** Pupa (comma shape). Origin = centre. */
export const Pupa: React.FC<{ x: number; y: number; s?: number; t?: number; opacity?: number }> = ({ x, y, s = 1, t = 0, opacity = 1 }) => (
  <g transform={`translate(${x} ${y + Math.sin(t * 3) * 4}) scale(${s})`} opacity={opacity}>
    <path d={`M 30 -8 q 38 22 10 ${50 + Math.sin(t * 5) * 4} q -20 14 -30 -4`} stroke={OUT} strokeWidth={14} fill="none" strokeLinecap="round" />
    <path d={`M 30 -8 q 38 22 10 ${50 + Math.sin(t * 5) * 4} q -20 14 -30 -4`} stroke={C.gold} strokeWidth={8} fill="none" strokeLinecap="round" />
    <ellipse cx={0} cy={0} rx={34} ry={30} fill={C.gold} stroke={OUT} strokeWidth={4} />
    <circle cx={-10} cy={-6} r={5} fill={OUT} />
  </g>
);

/** Flower vase with water. Origin = bottom centre. ~120 x 230 */
export const Vase: React.FC<{ x: number; y: number; s?: number; opacity?: number }> = ({ x, y, s = 1, opacity = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={opacity}>
    <g stroke={C.good} strokeWidth={6} strokeLinecap="round" fill="none"><path d="M -4 -120 L -30 -210" /><path d="M 4 -120 L 28 -214" /><path d="M 0 -120 L 0 -230" /></g>
    {[[-30, -216, C.swRed], [28, -220, C.swOrange], [0, -238, C.accent]].map(([fx, fy, col], i) => <circle key={i} cx={fx as number} cy={fy as number} r={20} fill={col as string} stroke={OUT} strokeWidth={3} />)}
    <path d="M -26 -128 L 26 -128 L 28 -100 Q 66 -70 62 -30 Q 60 0 30 0 L -30 0 Q -60 0 -62 -30 Q -66 -70 -28 -100 Z" fill="#fff" stroke={OUT} strokeWidth={sw} strokeLinejoin="round" />
    <path d="M -56 -52 Q -62 -10 -30 -6 L 30 -6 Q 60 -10 56 -52 Z" fill={C.water} />
  </g>
);

/** Bucket with water. Origin = bottom centre. ~170 x 170 */
export const Bucket: React.FC<{ x: number; y: number; s?: number; opacity?: number; rot?: number; level?: number }> = ({ x, y, s = 1, opacity = 1, rot = 0, level = 1 }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot} 0 0) scale(${s})`} opacity={opacity}>
    <path d="M -76 -150 Q 0 -230 76 -150" fill="none" stroke={OUT} strokeWidth={6} />
    <path d="M -86 -150 L 86 -150 L 64 0 L -64 0 Z" fill={C.cloth} stroke={OUT} strokeWidth={sw} strokeLinejoin="round" />
    <path d={`M ${-86 + 20 * (1 - level)} ${-150 + 70 * (1 - level)} L ${86 - 20 * (1 - level)} ${-150 + 70 * (1 - level)} L 66 -10 L -66 -10 Z`} fill={C.water} opacity={level > 0.02 ? 1 : 0} />
    <ellipse cx={0} cy={-150} rx={86} ry={14} fill={C.waterDeep} stroke={OUT} strokeWidth={sw} opacity={level > 0.02 ? 1 : 0.0} />
    <rect x={-86} y={-156} width={172} height={10} rx={5} fill={C.surface} stroke={OUT} strokeWidth={3} opacity={level > 0.02 ? 0 : 1} />
  </g>
);

/** Old tyre lying flat, rain water in the middle. Origin = centre. ~280 x 160 */
export const Tyre: React.FC<{ x: number; y: number; s?: number; opacity?: number }> = ({ x, y, s = 1, opacity = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={opacity}>
    <ellipse cx={0} cy={22} rx={140} ry={74} fill={C.night} stroke={OUT} strokeWidth={sw} />
    <ellipse cx={0} cy={0} rx={140} ry={74} fill={C.swBlack} stroke={OUT} strokeWidth={sw} />
    <ellipse cx={0} cy={0} rx={70} ry={32} fill={C.water} stroke={OUT} strokeWidth={sw} />
    <ellipse cx={-14} cy={-6} rx={26} ry={8} fill="#fff" opacity={0.55} />
  </g>
);

/** Mosquito net canopy over a bed, origin = floor centre. ~380 wide x 300 high */
export const Net: React.FC<{ x: number; y: number; s?: number; opacity?: number; drop?: number }> = ({ x, y, s = 1, opacity = 1, drop = 1 }) => {
  const top = -300 + (1 - drop) * -40;
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} opacity={opacity}>
      <clipPath id="netclip"><path d={`M 0 ${top} L 190 -14 L -190 -14 Z`} /></clipPath>
      <path d={`M 0 ${top} L 190 -14 L -190 -14 Z`} fill="#fff" fillOpacity={0.45} stroke={C.flow} strokeWidth={5} strokeLinejoin="round" />
      <g clipPath="url(#netclip)" stroke={C.flow} strokeWidth={2} opacity={0.75}>
        {Array.from({ length: 22 }).map((_, i) => <line key={"a" + i} x1={-300 + i * 30} y1={top} x2={-100 + i * 30} y2={0} />)}
        {Array.from({ length: 22 }).map((_, i) => <line key={"b" + i} x1={300 - i * 30} y1={top} x2={100 - i * 30} y2={0} />)}
      </g>
      <circle cx={0} cy={top - 8} r={10} fill={C.accent} stroke={OUT} strokeWidth={3} />
    </g>
  );
};

/** Open palm (slap) in cartoon style. Origin = wrist centre, fingers point up. ~170 x 260 */
export const Hand: React.FC<{ x: number; y: number; s?: number; rot?: number; opacity?: number }> = ({ x, y, s = 1, rot = 0, opacity = 1 }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`} opacity={opacity} stroke={OUT} strokeWidth={sw} strokeLinejoin="round" fill={C.skin}>
    <rect x={-84} y={-150} width={34} height={110} rx={17} transform="rotate(-8 -67 -40)" />
    <rect x={-48} y={-190} width={34} height={150} rx={17} />
    <rect x={-10} y={-198} width={34} height={158} rx={17} />
    <rect x={28} y={-182} width={34} height={142} rx={17} transform="rotate(6 45 -40)" />
    <rect x={-104} y={-110} width={34} height={90} rx={17} transform="rotate(-48 -87 -30)" />
    <rect x={-80} y={-110} width={150} height={150} rx={46} />
    <rect x={-60} y={30} width={110} height={70} fill={C.cloth} />
  </g>
);

/** DNA helix (spins with t). Origin = top centre, hangs down h px. */
export const Dna: React.FC<{ x: number; y: number; h?: number; w?: number; t?: number; opacity?: number }> = ({ x, y, h = 360, w = 70, t = 0, opacity = 1 }) => {
  const N = 16;
  const pts = (ph: number) => Array.from({ length: N + 1 }).map((_, i) => `${i === 0 ? "M" : "L"} ${Math.sin(i * 0.8 + t * 2.2 + ph) * w} ${(i / N) * h}`).join(" ");
  return (
    <g transform={`translate(${x} ${y})`} opacity={opacity}>
      {Array.from({ length: N + 1 }).map((_, i) => <line key={i} x1={Math.sin(i * 0.8 + t * 2.2) * w} y1={(i / N) * h} x2={Math.sin(i * 0.8 + t * 2.2 + Math.PI) * w} y2={(i / N) * h} stroke={C.muted} strokeWidth={5} strokeLinecap="round" opacity={0.7} />)}
      <path d={pts(0)} stroke={C.data} strokeWidth={10} fill="none" strokeLinecap="round" />
      <path d={pts(Math.PI)} stroke={C.accent} strokeWidth={10} fill="none" strokeLinecap="round" />
    </g>
  );
};

/** Hourglass. Origin = centre. */
export const Hourglass: React.FC<{ x: number; y: number; s?: number; p?: number; opacity?: number }> = ({ x, y, s = 1, p = 0, opacity = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={opacity}>
    <path d="M -50 -90 L 50 -90 L 50 -70 Q 50 -20 10 0 Q 50 20 50 70 L 50 90 L -50 90 L -50 70 Q -50 20 -10 0 Q -50 -20 -50 -70 Z" fill="#fff" stroke={OUT} strokeWidth={sw} strokeLinejoin="round" />
    <path d={`M -34 ${-70 + p * 40} L 34 ${-70 + p * 40} Q 30 -30 0 -4 Q -30 -30 -34 ${-70 + p * 40} Z`} fill={C.oil} opacity={1 - p * 0.9} />
    <rect x={-34 + p * 14} y={86 - 60 * p} width={68 - p * 28} height={60 * p} rx={6} fill={C.oil} />
    <rect x={-64} y={-104} width={128} height={16} rx={8} fill={C.gold} stroke={OUT} strokeWidth={3} />
    <rect x={-64} y={88} width={128} height={16} rx={8} fill={C.gold} stroke={OUT} strokeWidth={3} />
  </g>
);

/** Pregnancy bump drawn over a Person (Person at same x,y,s). */
export const Belly: React.FC<{ x: number; y: number; s?: number; cloth?: string }> = ({ x, y, s = 1, cloth = C.cloth2 }) => (
  <ellipse cx={x + 30 * s} cy={y - 128 * s} rx={40 * s} ry={44 * s} fill={cloth} stroke={OUT} strokeWidth={4} />
);

/** Itch / scratch lines around a spot. */
export const Itch: React.FC<{ x: number; y: number; s?: number; t?: number }> = ({ x, y, s = 1, t = 0 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} stroke={C.bad} strokeWidth={5} strokeLinecap="round" opacity={0.6 + 0.4 * Math.sin(t * 10)}>
    <line x1={-40} y1={-30} x2={-60} y2={-46} /><line x1={0} y1={-44} x2={0} y2={-70} /><line x1={40} y1={-30} x2={60} y2={-46} />
  </g>
);

/** Red bite dots. */
export const Bites: React.FC<{ x: number; y: number; n?: number; s?: number; opacity?: number }> = ({ x, y, n = 3, s = 1, opacity = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={opacity}>
    {Array.from({ length: n }).map((_, i) => <circle key={i} cx={(i % 2) * 18 - 9} cy={i * 22 - 20} r={9} fill={C.bad} stroke={OUT} strokeWidth={2.5} />)}
  </g>
);
