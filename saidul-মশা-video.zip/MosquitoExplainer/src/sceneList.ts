import React from "react";
import { SceneBedroom, SceneChoose, SceneFemale, SceneCo2, SceneTemp } from "./scenes/s1";
import { SceneSkin, SceneStudy, SceneAcidBites, SceneColors, SceneGenes } from "./scenes/s2";
import { ScenePregnant, SceneWhy, SceneWater, SceneCycle, SceneEggs } from "./scenes/s3";
import { SceneWhyOne, SceneNeed, ScenePrevent, SceneSwat, SceneOutro } from "./scenes/s4";

export type SceneDef = { id: string; title: string; start: number; end: number; C: React.FC<{ t: number }> };

/**
 * Storyboard (seconds, from the voiceover / corrected SRT):
 * 01 bedroom   five sleep, one mosquito bites one; morning: four fine, one itchy
 * 02 choose    "does the mosquito choose?" -> yes, by signals from the body
 * 03 female    only the female drinks human blood (for eggs), the male does not
 * 04 co2       CO2 from the breath is detected from far; more CO2 = more attractive
 * 05 temp      close up: body temperature and skin smell
 * 06 skin      skin oil + bacteria -> carboxylic acid; amount differs per person
 * 07 study     US study: participant 33 is most attractive (x4, about x21)
 * 08 acidBites more of certain acids on the skin -> more bites
 * 09 colors    eyes: red, orange, black, turquoise
 * 10 genes     genes and blood group (O)
 * 11 pregnant  pregnant women: more CO2
 * 12 why       why search so carefully: short life, blood again and again for eggs
 * 13 water     eggs in standing water: vase, bucket, old tyre
 * 14 cycle     egg -> larva -> pupa -> adult, about 7-10 days
 * 15 eggs      rest, eggs in 3-5 days, hundreds of eggs, must find blood fast
 * 16 whyOne    back in the room: smell, breath gas, temperature
 * 17 need      nothing personal, only her own need
 * 18 prevent   clean standing water, mosquito net at night
 * 19 swat      so much calculation, one slap ends it
 * 20 outro     logo, like, comment, subscribe
 */
export const SCENES: SceneDef[] = [
  { id: "bedroom", title: "Bedroom", start: 0, end: 10.2, C: SceneBedroom },
  { id: "choose", title: "Does it choose", start: 10.2, end: 20.2, C: SceneChoose },
  { id: "female", title: "Only females", start: 20.2, end: 29.4, C: SceneFemale },
  { id: "co2", title: "Carbon dioxide", start: 29.4, end: 42.0, C: SceneCo2 },
  { id: "temp", title: "Heat and smell", start: 42.0, end: 49.4, C: SceneTemp },
  { id: "skin", title: "Skin acids", start: 49.4, end: 64.4, C: SceneSkin },
  { id: "study", title: "Study of 33", start: 64.4, end: 79.9, C: SceneStudy },
  { id: "acidBites", title: "More acid", start: 79.9, end: 86.3, C: SceneAcidBites },
  { id: "colors", title: "Colours", start: 86.3, end: 97.0, C: SceneColors },
  { id: "genes", title: "Genes", start: 97.0, end: 106.3, C: SceneGenes },
  { id: "pregnant", title: "Pregnancy", start: 106.3, end: 112.9, C: ScenePregnant },
  { id: "why", title: "Why choose", start: 112.9, end: 123.9, C: SceneWhy },
  { id: "water", title: "Standing water", start: 123.9, end: 129.9, C: SceneWater },
  { id: "cycle", title: "Life cycle", start: 129.9, end: 140.8, C: SceneCycle },
  { id: "eggs", title: "Eggs", start: 140.8, end: 155.3, C: SceneEggs },
  { id: "whyOne", title: "Why one", start: 155.3, end: 165.3, C: SceneWhyOne },
  { id: "need", title: "Need", start: 165.3, end: 172.4, C: SceneNeed },
  { id: "prevent", title: "Prevention", start: 172.4, end: 178.9, C: ScenePrevent },
  { id: "swat", title: "Slap", start: 178.9, end: 184.2, C: SceneSwat },
  { id: "outro", title: "Outro", start: 184.2, end: 192, C: SceneOutro },
];
