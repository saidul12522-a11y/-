// "Frosty light" theme, same as the reference zip (ChatGPTIndiaExplainer / WinterDawnExplainer). Never write hex values elsewhere.
export const theme = {
  bg: "#EEF4FA",
  surface: "#FFFFFF",
  surfaceHi: "#FFFFFF",
  tint: "#DCE8F5", // soft blue panel
  border: "rgba(16,35,58,0.14)",
  text: "#10233A",
  muted: "#5B6E86",
  accent: "#E07A1F", // dawn orange: "look here"
  onAccent: "#10233A",
  data: "#2B6CB0", // primary blue: information
  flow: "#4C9AD6",
  good: "#2E9A4A",
  warn: "#E89808",
  bad: "#D9443A",
  night: "#1B2F4D",
  gold: "#F2B33D",
  skin: "#F1C9A0",
  cloth: "#2B6CB0",
  cloth2: "#2E9A4A",
  // mosquito explainer extras (still roles, never raw hex in components)
  blood: "#D9443A",
  bloodDark: "#9E2420",
  water: "#9ACFF0",
  waterDeep: "#5BA8DB",
  wall: "#F8FBFE",
  floor: "#C9D9EA",
  swRed: "#D9443A",
  swOrange: "#F28A2E",
  swBlack: "#1E2430",
  swTurq: "#22B8B0",
  bacteria: "#58B368",
  oil: "#F2C14E",
} as const;
export type Theme = typeof theme;
