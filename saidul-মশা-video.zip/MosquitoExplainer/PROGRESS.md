# PROGRESS

- Project: MosquitoExplainer, version v01 (project ZIP: MosquitoExplainer_Final_v01.zip)
- Audio: voice.mp3 (from cc826bdc-saidulvocals.mp3), 190.041 s. SRT: original.srt (from 732596f6-saidulvocals_ben.srt, 49 cues, ends 3:09.80)
- SRT: original kept; corrected.srt made (48 cues). Fixes: cue 30 "মশা কে" -> "মশাকে" (stray space); one-word 0.38 s cue "রাখুন।" merged into the cue before. Suspects NOT changed (not verified against audio, speech recognition unavailable offline): "অ্যাসিড," in cue 24 (0:01:30), "ছোঁড়েই" in cue 47 (0:03:00, maybe "চড়েই"), "ও রক্তের গ্রুপের" (0:01:42, drawn as blood group O). Details: src/corrections.json
- Timing: SRT cues + ffmpeg silencedetect, 442 words, 0 words on long silences, avg 0.382 s/word. No ASR (offline)
- Ratio: 16:9, 1920x1080, 30 fps. Total 5732 frames (audio + 1 s hold)
- Theme: "Frosty light" taken from the reference zip: bg #EEF4FA, data #2B6CB0, accent #E07A1F, text #10233A. Font: Hind Siliguri (bundled). SUL logo: small badge top-right, large in outro
- Animation: icon-style 2D people, beds, mosquito, drops, eggs/larva/pupa, net; springs for main elements, smooth fades elsewhere, 0.4 s crossfade between scenes, word-synced captions (active word = accent)
- SFX: none (no SFX supplied). Voiceover untouched
- Scenes (20): bedroom, choose, female, co2, temp, skin, study, acidBites, colors, genes, pregnant, why, water, cycle, eggs, whyOne, need, prevent, swat, outro
- Completed: all 20 scenes. Partial: none. Remaining: final MP4 render (waits for user "রেন্ডার করো")
- Last workflow step: contact-sheet inspection of 20 scenes + chip-width fix (Bengali text was wider than its pill)
- Tests: tsc and Remotion NOT run here (npm install blocked: no network in this environment). Instead a stand-in "remotion" shim (esbuild + React + Playwright Chromium) rendered ~30 real frames (Bengali shaping OK) and all 5732 frames as markup: 0 errors, 0 NaN. Not tested: real Remotion install, render, Windows
- Backups: MosquitoExplainer_Backup_01_100pct.zip
- Open issues: word timing is an SRT-based estimate; suspect words kept as in SRT; study scene (participant 33) uses small figures; mp4 not rendered
- Next: wait for "রেন্ডার করো"; then run `npm install` + `npm run render`
