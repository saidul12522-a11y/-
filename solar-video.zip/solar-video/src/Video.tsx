import React from 'react';
import {AbsoluteFill, Audio, Easing, Sequence, staticFile, interpolate, useCurrentFrame} from 'remotion';
import {SCENES, Cam} from './scenes';
import {STARTS} from './timing';
import {C, FPS, TOTAL_FRAMES} from './theme';
import {fontFamily} from './fonts';
import {SceneCtx} from './kit';
import {Captions} from './Captions';

const Shell: React.FC<{index: number; dur: number; cam?: Cam; children: React.ReactNode}> = ({index, dur, cam, children}) => {
  const f = useCurrentFrame();
  const fade = interpolate(f, [0, index === 0 ? 4 : 9], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const z = cam ? cam.z0 + ((cam.z1 - cam.z0) * f) / dur : 1;
  const slide =
    index % 2 === 1
      ? interpolate(f, [0, 12], [26, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)})
      : 0;
  return (
    <AbsoluteFill
      style={{
        opacity: fade,
        transform: `translateY(${slide}px) scale(${z})`,
        transformOrigin: `${cam?.ox ?? 50}% ${cam?.oy ?? 50}%`,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

export const SolarVideo: React.FC = () => {
  const froms = STARTS.map((s) => Math.round(s * FPS));
  return (
    <AbsoluteFill style={{backgroundColor: C.bg, fontFamily}}>
      <Audio src={staticFile('audio.wav')} />
      {SCENES.map(({C: Scene, cam}, i) => {
        const from = froms[i];
        const end = i + 1 < froms.length ? froms[i + 1] : TOTAL_FRAMES;
        const dur = end - from;
        return (
          <Sequence key={i} from={from} durationInFrames={dur}>
            <SceneCtx.Provider value={{start: from / FPS, dur}}>
              <Shell index={i} dur={dur} cam={cam}>
                <Scene />
              </Shell>
            </SceneCtx.Provider>
          </Sequence>
        );
      })}
      <Captions />
    </AbsoluteFill>
  );
};
