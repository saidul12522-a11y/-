import React, {useContext} from 'react';
import {
  Easing,
  interpolate,
  interpolateColors,
  spring,
  useCurrentFrame,
} from 'remotion';
import {C, FPS, H, W} from './theme';
import {fontFamily} from './fonts';

/* ---------- timing helpers ---------- */
export const SceneCtx = React.createContext<{start: number; dur: number}>({
  start: 0,
  dur: 1,
});

export const useScene = () => {
  const f = useCurrentFrame();
  const {start, dur} = useContext(SceneCtx);
  return {f, dur, abs: start + f / FPS};
};

const CL = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
export const seg = (x: number, a: number, b: number) =>
  interpolate(x, [a, b], [0, 1], {...CL, easing: Easing.out(Easing.cubic)});
export const lin = (x: number, a: number, b: number) =>
  interpolate(x, [a, b], [0, 1], CL);
export const pop = (x: number, a: number) =>
  spring({
    frame: Math.max(0, Math.round((x - a) * FPS)),
    fps: FPS,
    config: {damping: 11, stiffness: 160, mass: 0.6},
  });
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const bn = (s: string | number) =>
  String(s).replace(/\d/g, (d) => '০১২৩৪৫৬৭৮৯'[+d]);
export const mix = (t: number, a: string, b: string) =>
  interpolateColors(Math.min(1, Math.max(0, t)), [0, 1], [a, b]);

/** point at progress p (0..1) along a polyline */
export const polyPoint = (pts: [number, number][], p: number): [number, number] => {
  const lens: number[] = [];
  let total = 0;
  for (let i = 1; i < pts.length; i++) {
    const l = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
    lens.push(l);
    total += l;
  }
  let d = (((p % 1) + 1) % 1) * total;
  for (let i = 0; i < lens.length; i++) {
    if (d <= lens[i]) {
      const t = d / lens[i];
      return [lerp(pts[i][0], pts[i + 1][0], t), lerp(pts[i][1], pts[i + 1][1], t)];
    }
    d -= lens[i];
  }
  return pts[pts.length - 1];
};

export const useT = () => {
  const {abs, f} = useScene();
  return {
    abs,
    f,
    s: (a: number, b: number) => seg(abs, a, b),
    l: (a: number, b: number) => lin(abs, a, b),
  };
};

/* ---------- basic building blocks ---------- */
export const Stage: React.FC<{children?: React.ReactNode}> = ({children}) => (
  <svg viewBox={`0 0 ${W} ${H}`} width="100%" height="100%" style={{display: 'block'}}>
    {children}
  </svg>
);

export const Bg: React.FC<{ground?: boolean; room?: boolean}> = ({ground, room}) => (
  <>
    <defs>
      <radialGradient id="vg" cx="0.5" cy="0.45" r="0.75">
        <stop offset="0" stopColor="#fff" stopOpacity="0.6" />
        <stop offset="1" stopColor="#fff" stopOpacity="0" />
      </radialGradient>
    </defs>
    <rect width={W} height={H} fill={C.bg} />
    <rect width={W} height={H} fill="url(#vg)" />
    {room && <rect width={W} height={600} fill={C.wall} />}
    {room && <rect x={0} y={560} width={W} height={40} fill="#D3E6FA" />}
    {(ground || room) && (
      <>
        <rect y={600} width={W} height={120} fill={C.floor} />
        <line x1={0} x2={W} y1={600} y2={600} stroke={C.ink} strokeWidth={3} opacity={0.5} />
      </>
    )}
  </>
);

export const G: React.FC<{
  x?: number;
  y?: number;
  s?: number;
  rot?: number;
  at?: number;
  op?: number;
  children?: React.ReactNode;
}> = ({x = 0, y = 0, s = 1, rot = 0, at, op = 1, children}) => {
  const {abs} = useScene();
  const p = at === undefined ? 1 : pop(abs, at);
  const o = at === undefined ? op : Math.min(1, p * 2) * op;
  return (
    <g
      transform={`translate(${x} ${y}) rotate(${rot}) scale(${Math.max(0.0001, s * p)})`}
      opacity={o}
    >
      {children}
    </g>
  );
};

export const T: React.FC<{
  x: number;
  y: number;
  children: React.ReactNode;
  size?: number;
  fill?: string;
  weight?: number;
  anchor?: 'start' | 'middle' | 'end';
}> = ({x, y, children, size = 32, fill = C.text, weight = 700, anchor = 'middle'}) => (
  <text
    x={x}
    y={y}
    fontSize={size}
    fontWeight={weight}
    fill={fill}
    textAnchor={anchor}
    fontFamily={fontFamily}
    dominantBaseline="central"
  >
    {children}
  </text>
);

export const Chip: React.FC<{
  x: number;
  y: number;
  text: string;
  at?: number;
  color?: string;
  size?: number;
  fill?: string;
}> = ({x, y, text, at, color = C.blueDark, size = 30, fill = '#fff'}) => {
  const w = text.length * size * 0.58 + 40;
  return (
    <G x={x} y={y} at={at}>
      <rect x={-w / 2} y={-size * 0.85} width={w} height={size * 1.7} rx={size * 0.85} fill={fill} stroke={C.ink} strokeWidth={3} />
      <T x={0} y={2} size={size} fill={color}>
        {text}
      </T>
    </G>
  );
};

export const Note: React.FC<{
  x: number;
  y: number;
  w: number;
  h: number;
  at?: number;
  rot?: number;
  color?: string;
  children?: React.ReactNode;
}> = ({x, y, w, h, at, rot = 0, color = C.sun, children}) => (
  <G x={x} y={y} at={at} rot={rot}>
    <rect x={-w / 2 + 7} y={-h / 2 + 9} width={w} height={h} rx={18} fill={C.ink} opacity={0.12} />
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={18} fill="#fff" stroke={C.ink} strokeWidth={3.5} />
    <rect x={-w / 2 + 4} y={-h / 2 + 4} width={w - 8} height={16} rx={8} fill={color} />
    <circle cx={0} cy={-h / 2 + 4} r={9} fill={C.red} stroke={C.ink} strokeWidth={3} />
    {children}
  </G>
);

export const Stamp: React.FC<{
  x: number;
  y: number;
  text: string;
  color?: string;
  at: number;
  rot?: number;
  size?: number;
}> = ({x, y, text, color = C.red, at, rot = -8, size = 56}) => {
  const w = text.length * size * 0.62 + 50;
  return (
    <G x={x} y={y} at={at} rot={rot}>
      <rect x={-w / 2} y={-size * 0.9} width={w} height={size * 1.8} rx={14} fill="#fff" fillOpacity={0.75} stroke={color} strokeWidth={7} />
      <T x={0} y={2} size={size} fill={color}>
        {text}
      </T>
    </G>
  );
};

export const Thought: React.FC<{
  x: number;
  y: number;
  w: number;
  h: number;
  at: number;
  children?: React.ReactNode;
}> = ({x, y, w, h, at, children}) => (
  <G x={x} y={y} at={at}>
    <circle cx={-w / 2 + 34} cy={h / 2 + 34} r={11} fill="#fff" stroke={C.ink} strokeWidth={3} />
    <circle cx={-w / 2 + 8} cy={h / 2 + 62} r={7} fill="#fff" stroke={C.ink} strokeWidth={3} />
    <ellipse rx={w / 2} ry={h / 2} fill="#fff" stroke={C.ink} strokeWidth={3.5} />
    {children}
  </G>
);

export const Cross: React.FC<{x: number; y: number; s?: number; at: number; color?: string}> = ({x, y, s = 1, at, color = C.red}) => (
  <G x={x} y={y} s={s} at={at}>
    <line x1={-40} y1={-40} x2={40} y2={40} stroke={color} strokeWidth={14} strokeLinecap="round" />
    <line x1={40} y1={-40} x2={-40} y2={40} stroke={color} strokeWidth={14} strokeLinecap="round" />
  </G>
);

export const Tick: React.FC<{x: number; y: number; s?: number; at: number}> = ({x, y, s = 1, at}) => (
  <G x={x} y={y} s={s} at={at}>
    <circle r={44} fill={C.mint} stroke={C.ink} strokeWidth={4} />
    <path d="M-20 2 L-6 18 L22 -14" fill="none" stroke="#fff" strokeWidth={11} strokeLinecap="round" strokeLinejoin="round" />
  </G>
);

export const Arrow: React.FC<{
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  color?: string;
  sw?: number;
  p?: number;
  dash?: boolean;
}> = ({x1, y1, x2, y2, color = C.ink, sw = 6, p = 1, dash}) => {
  const px = lerp(x1, x2, p);
  const py = lerp(y1, y2, p);
  const ang = (Math.atan2(y2 - y1, x2 - x1) * 180) / Math.PI;
  return (
    <g opacity={p > 0.02 ? 1 : 0}>
      <line x1={x1} y1={y1} x2={px} y2={py} stroke={color} strokeWidth={sw} strokeLinecap="round" strokeDasharray={dash ? '12 10' : undefined} />
      <g transform={`translate(${px} ${py}) rotate(${ang}) scale(${sw / 6})`}>
        <path d="M6 0 L-14 -10 L-14 10 Z" fill={color} />
      </g>
    </g>
  );
};

/* ---------- nature / physics elements ---------- */
export const Sun: React.FC<{x: number; y: number; r?: number; at?: number; hot?: number}> = ({x, y, r = 60, at, hot = 0}) => {
  const {f} = useScene();
  const col = mix(hot, C.sun, '#FF6A1F');
  return (
    <G x={x} y={y} at={at}>
      <g transform={`rotate(${f * 0.6})`}>
        {Array.from({length: 12}).map((_, i) => (
          <line key={i} x1={r * 1.3} y1={0} x2={r * 1.7} y2={0} stroke={col} strokeWidth={9} strokeLinecap="round" transform={`rotate(${i * 30})`} />
        ))}
      </g>
      <circle r={r * 1.45} fill={C.sunSoft} opacity={0.4} />
      <circle r={r} fill={col} stroke={C.ink} strokeWidth={4} />
    </G>
  );
};

export const Cloud: React.FC<{x: number; y: number; s?: number; speed?: number}> = ({x, y, s = 1, speed = 0.4}) => {
  const {f} = useScene();
  const px = ((x + f * speed + 200) % (W + 400)) - 200;
  return (
    <g transform={`translate(${px} ${y}) scale(${s})`} opacity={0.95}>
      <ellipse cx={0} cy={0} rx={70} ry={26} fill="#fff" />
      <circle cx={-20} cy={-18} r={28} fill="#fff" />
      <circle cx={24} cy={-24} r={34} fill="#fff" />
    </g>
  );
};

export const Heat: React.FC<{
  x: number;
  y: number;
  n?: number;
  op?: number;
  color?: string;
  len?: number;
  gap?: number;
}> = ({x, y, n = 3, op = 1, color = C.orange, len = 70, gap = 50}) => {
  const {abs} = useScene();
  return (
    <g opacity={op} fill="none" stroke={color} strokeWidth={6} strokeLinecap="round">
      {Array.from({length: n}).map((_, i) => {
        const pts: string[] = [];
        for (let k = 0; k <= 12; k++) {
          const yy = y - (k / 12) * len;
          const xx = x + i * gap + Math.sin(k * 0.9 - abs * 6 + i) * 7;
          pts.push(`${k ? 'L' : 'M'}${xx.toFixed(1)} ${yy.toFixed(1)}`);
        }
        return <path key={i} d={pts.join(' ')} />;
      })}
    </g>
  );
};

export const Bolt: React.FC<{x: number; y: number; s?: number; at?: number}> = ({x, y, s = 1, at}) => (
  <G x={x} y={y} s={s} at={at}>
    <polygon points="0,-24 -12,4 0,4 -7,26 14,-7 2,-7 9,-24" fill={C.sun} stroke={C.ink} strokeWidth={3} strokeLinejoin="round" />
  </G>
);

export const Cell: React.FC<{x: number; y: number; s?: number; hot?: number; at?: number}> = ({x, y, s = 1, hot = 0, at}) => (
  <G x={x} y={y} s={s} at={at}>
    <rect x={-50} y={-50} width={100} height={100} rx={7} fill={mix(hot, C.cell, '#E8743B')} stroke={C.ink} strokeWidth={4} />
    {[-17, 17].map((v) => (
      <line key={v} x1={v} y1={-46} x2={v} y2={46} stroke="#DCEBFF" strokeWidth={2.5} opacity={0.85} />
    ))}
    {[-26, 0, 26].map((v) => (
      <line key={v} x1={-46} y1={v} x2={46} y2={v} stroke="#DCEBFF" strokeWidth={1.5} opacity={0.55} />
    ))}
  </G>
);

export const PanelShape: React.FC<{
  x: number;
  y: number;
  w: number;
  h: number;
  cols?: number;
  rows?: number;
  rot?: number;
  hot?: number;
  glow?: number;
}> = ({x, y, w, h, cols = 6, rows = 3, rot = 0, hot = 0, glow = 0}) => {
  const cw = (w - 12) / cols;
  const ch = (h - 12) / rows;
  const col = mix(hot, C.cell, '#E8743B');
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot})`}>
      <rect width={w} height={h} rx={8} fill="#EEF3FA" stroke={C.ink} strokeWidth={4} />
      {Array.from({length: rows * cols}).map((_, i) => (
        <rect key={i} x={8 + (i % cols) * cw} y={8 + Math.floor(i / cols) * ch} width={cw - 4} height={ch - 4} rx={3} fill={col} stroke={C.ink} strokeWidth={1.5} />
      ))}
      <polygon points={`${w * 0.15},${h} ${w * 0.4},${h} ${w * 0.7},0 ${w * 0.45},0`} fill="#fff" opacity={0.12} />
      {glow > 0 && <rect width={w} height={h} rx={8} fill="#fff" opacity={glow * 0.45} />}
    </g>
  );
};

export const E: React.FC<{x: number; y: number; r?: number; op?: number}> = ({x, y, r = 9, op = 1}) => (
  <g transform={`translate(${x} ${y})`} opacity={op}>
    <circle r={r} fill={C.blue} stroke={C.ink} strokeWidth={2} />
    <rect x={-r * 0.5} y={-r * 0.12} width={r} height={r * 0.24} fill="#fff" />
  </g>
);

export const Photon: React.FC<{x: number; y: number; ang: number; op?: number; r?: number}> = ({x, y, ang, op = 1, r = 8}) => (
  <g transform={`translate(${x} ${y}) rotate(${ang})`} opacity={op}>
    <line x1={0} y1={0} x2={-30} y2={0} stroke={C.sun} strokeWidth={5} strokeLinecap="round" opacity={0.6} />
    <circle r={r * 1.6} fill={C.sunSoft} opacity={0.5} />
    <circle r={r} fill={C.sun} stroke={C.ink} strokeWidth={2.5} />
  </g>
);

export const Bulb: React.FC<{x: number; y: number; on: number; s?: number}> = ({x, y, on, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    {on > 0.02 && <circle r={95} fill={C.sunSoft} opacity={0.55 * on} />}
    <path
      d="M0 -42 C-32 -42 -38 -4 -19 14 L-19 34 L19 34 L19 14 C38 -4 32 -42 0 -42 Z"
      fill={mix(on, '#F4F7FB', '#FFE066')}
      stroke={C.ink}
      strokeWidth={4}
      strokeLinejoin="round"
    />
    <rect x={-15} y={34} width={30} height={15} rx={4} fill="#9AA9BF" stroke={C.ink} strokeWidth={3.5} />
    {on > 0.3 &&
      [-60, -30, 0, 30, 60].map((a) => (
        <line key={a} x1={0} y1={-64} x2={0} y2={-80} stroke={C.sun} strokeWidth={5} strokeLinecap="round" transform={`rotate(${a} 0 -8)`} opacity={on} />
      ))}
  </g>
);

export const Wave: React.FC<{
  x: number;
  y: number;
  w: number;
  amp?: number;
  ac?: boolean;
  draw?: number;
  color?: string;
  speed?: number;
  sw?: number;
}> = ({x, y, w, amp = 40, ac = true, draw = 1, color = C.blue, speed = 1.2, sw = 6}) => {
  const {abs} = useScene();
  const N = 80;
  const n = Math.max(1, Math.floor(N * draw));
  const pts: string[] = [];
  for (let i = 0; i <= n; i++) {
    const px = x + (i / N) * w;
    const py = ac ? y + amp * Math.sin((i / N) * Math.PI * 4 - abs * speed * Math.PI * 2) : y;
    pts.push(`${i ? 'L' : 'M'}${px.toFixed(1)} ${py.toFixed(1)}`);
  }
  return <path d={pts.join(' ')} opacity={draw > 0 ? 1 : 0} fill="none" stroke={color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" />;
};

export const Thermo: React.FC<{x: number; y: number; h: number; level: number; color?: string}> = ({x, y, h, level, color = C.red}) => (
  <g transform={`translate(${x} ${y})`}>
    <rect x={-17} y={-h} width={34} height={h + 10} rx={17} fill="#fff" stroke={C.ink} strokeWidth={4} />
    <circle cy={22} r={28} fill={color} stroke={C.ink} strokeWidth={4} />
    <rect x={-8} y={-h * level} width={16} height={h * level + 20} rx={8} fill={color} />
    {[0.25, 0.5, 0.75].map((t) => (
      <line key={t} x1={17} x2={30} y1={-h * t} y2={-h * t} stroke={C.ink} strokeWidth={3} />
    ))}
  </g>
);

const arcPath = (r: number, a0: number, a1: number) => {
  const p = (a: number) => [r * Math.cos((a * Math.PI) / 180), r * Math.sin((a * Math.PI) / 180)];
  const [x0, y0] = p(a0);
  const [x1, y1] = p(a1);
  return `M${x0} ${y0} A${r} ${r} 0 0 1 ${x1} ${y1}`;
};
export const Gauge: React.FC<{x: number; y: number; r: number; value: number}> = ({x, y, r, value}) => (
  <g transform={`translate(${x} ${y})`}>
    <path d={arcPath(r, 180, 360)} stroke={C.ink} strokeWidth={34} fill="none" strokeLinecap="round" />
    <path d={arcPath(r, 183, 237)} stroke={C.red} strokeWidth={24} fill="none" />
    <path d={arcPath(r, 243, 297)} stroke={C.sun} strokeWidth={24} fill="none" />
    <path d={arcPath(r, 303, 357)} stroke={C.mint} strokeWidth={24} fill="none" />
    <g transform={`rotate(${-90 + 180 * value})`}>
      <line x1={0} y1={0} x2={0} y2={-r * 0.85} stroke={C.ink} strokeWidth={8} strokeLinecap="round" />
    </g>
    <circle r={16} fill={C.ink} />
  </g>
);

/* ---------- character ---------- */
export type Expr = 'neutral' | 'happy' | 'surprise' | 'think' | 'worried' | 'angry';
const BR: Record<Expr, [number[], number[]]> = {
  neutral: [[-24, -210, -8, -210], [8, -210, 24, -210]],
  happy: [[-24, -213, -8, -215], [8, -215, 24, -213]],
  surprise: [[-24, -221, -8, -223], [8, -223, 24, -221]],
  think: [[-24, -216, -8, -220], [8, -208, 24, -211]],
  worried: [[-24, -207, -8, -215], [8, -215, 24, -207]],
  angry: [[-24, -216, -8, -208], [8, -208, 24, -216]],
};
const MOUTH: Record<Expr, string> = {
  neutral: 'M-8 -170 L8 -170',
  happy: 'M-13 -175 Q0 -157 13 -175',
  surprise: '',
  think: 'M-9 -168 Q0 -174 10 -166',
  worried: 'M-11 -166 Q-5.5 -172 0 -166 T11 -166',
  angry: 'M-10 -166 L10 -171',
};

export const Character: React.FC<{
  x: number;
  y: number;
  s?: number;
  flip?: boolean;
  expr?: Expr;
  raiseR?: number;
  raiseL?: number;
  look?: [number, number];
  tremble?: number;
  at?: number;
}> = ({x, y, s = 1, flip = false, expr = 'neutral', raiseR = 8, raiseL = 8, look = [0, 0], tremble = 0, at}) => {
  const {f, abs} = useScene();
  const bob = Math.sin(f / 14) * 2.2;
  const blink = f % 110 < 5 ? 0.12 : 1;
  const tx = tremble ? Math.sin(f * 2.3) * tremble : 0;
  const p = at === undefined ? 1 : pop(abs, at);
  const [bl, br] = BR[expr];
  const big = expr === 'surprise';
  const eye = (ex: number) => (
    <g transform={`translate(${ex} -194) scale(1 ${blink})`}>
      <ellipse rx={9} ry={big ? 12 : 10} fill="#fff" stroke={C.ink} strokeWidth={2.5} />
      <circle cx={look[0]} cy={look[1]} r={big ? 3 : 4.3} fill={C.ink} />
    </g>
  );
  const arm = (side: number, raise: number) => (
    <g transform={`translate(${side * 30} -122) rotate(${-side * raise})`}>
      <rect x={-8} y={-6} width={16} height={70} rx={8} fill={C.skin} stroke={C.ink} strokeWidth={3} />
    </g>
  );
  return (
    <g transform={`translate(${x + tx} ${y}) scale(${(flip ? -1 : 1) * s * Math.max(p, 0.0001)} ${s * Math.max(p, 0.0001)})`}>
      {[-20, 4].map((lx) => (
        <g key={lx}>
          <rect x={lx} y={-56} width={16} height={46} rx={8} fill={C.pants} stroke={C.ink} strokeWidth={3} />
          <ellipse cx={lx + 8} cy={-5} rx={15} ry={7} fill="#fff" stroke={C.ink} strokeWidth={3} />
        </g>
      ))}
      <g transform={`translate(0 ${bob})`}>
        {arm(-1, raiseL)}
        <rect x={-32} y={-142} width={64} height={98} rx={26} fill={C.shirt} stroke={C.ink} strokeWidth={3.5} />
        {arm(1, raiseR)}
        <ellipse cx={0} cy={-192} rx={40} ry={44} fill={C.skin} stroke={C.ink} strokeWidth={3.5} />
        <path d="M-14 -232 Q0 -248 14 -232" fill="none" stroke={C.ink} strokeWidth={3.5} strokeLinecap="round" />
        {eye(-15)}
        {eye(15)}
        <g stroke={C.ink} strokeWidth={3.5} strokeLinecap="round" fill="none">
          <line x1={bl[0]} y1={bl[1]} x2={bl[2]} y2={bl[3]} />
          <line x1={br[0]} y1={br[1]} x2={br[2]} y2={br[3]} />
          {expr === 'surprise' ? (
            <ellipse cx={0} cy={-168} rx={6} ry={8} fill="#fff" />
          ) : (
            <path d={MOUTH[expr]} />
          )}
        </g>
        {expr === 'worried' && <path d="M36 -222 q-7 12 0 17 q7 -5 0 -17 z" fill="#8EC5FF" stroke={C.ink} strokeWidth={2} />}
      </g>
    </g>
  );
};
