export const W = 1280;
export const H = 720;
export const FPS = 30;
export const AUDIO_SECONDS = 204.683896;
export const TOTAL_FRAMES = Math.ceil(AUDIO_SECONDS * FPS); // 6141

export const C = {
  bg: '#DCEEFF', // Light Blue theme (main background)
  ink: '#222222',
  text: '#1F3A5F',
  sun: '#FFB020',
  sunSoft: '#FFE08A',
  blue: '#2F80ED',
  blueDark: '#1B4F9C',
  mint: '#4FBF85',
  red: '#EB5757',
  orange: '#F2994A',
  white: '#FFFFFF',
  skin: '#F6E7D2',
  shirt: '#4A90D9',
  pants: '#3B5B8C',
  cell: '#3F78C4',
  wall: '#EAF4FF',
  floor: '#BBD6F4',
  hl: '#E8590C',
};
