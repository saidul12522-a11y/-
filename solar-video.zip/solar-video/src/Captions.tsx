import React from 'react';
import {Easing, interpolate, useCurrentFrame} from 'remotion';
import {CAPTIONS} from './captionData';
import {HIDE_CAPTIONS} from './timing';
import {C, FPS} from './theme';
import {fontFamily} from './fonts';

const KEY = /(silicon|photon|electron|inverter|voltage|volt|DC|AC|সৌর কোষ|বৈদ্যুতিক ক্ষেত্র|অতিরিক্ত তাপ)/g;

const Line: React.FC<{text: string}> = ({text}) => (
  <>
    {text.split(KEY).map((part, i) =>
      i % 2 === 1 ? (
        <span key={i} style={{color: C.hl, fontWeight: 700}}>
          {part}
        </span>
      ) : (
        <React.Fragment key={i}>{part}</React.Fragment>
      ),
    )}
  </>
);

export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  if (HIDE_CAPTIONS.some(([a, b]) => t >= a && t < b)) return null;
  const cur = CAPTIONS.find(([a, b]) => t >= a && t < b);
  if (!cur) return null;
  const k = interpolate(t, [cur[0], cur[0] + 0.18], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 34,
        textAlign: 'center',
        fontFamily,
        fontSize: 40,
        fontWeight: 600,
        color: C.text,
        whiteSpace: 'nowrap',
        opacity: k,
        transform: `translateY(${(1 - k) * 14}px)`,
        textShadow: '0 0 6px #fff, 0 0 12px #fff, 0 2px 0 rgba(255,255,255,.9)',
      }}
    >
      <Line text={cur[2]} />
    </div>
  );
};
