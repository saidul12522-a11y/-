import React from 'react';
import {
  Arrow, Bg, Bulb, Cell, Character, Chip, Cross, E, G, Gauge, Note, PanelShape,
  Stage, Stamp, T, Tick, Wave, bn, lerp, mix, polyPoint, useT, Expr,
} from '../kit';
import {C, W} from '../theme';

/* S08 64.92-76.12 : random electrons -> no usable current */
export const S08: React.FC = () => {
  const {abs, s} = useT();
  const clampv = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
  const expr: Expr = abs < 68.7 ? 'neutral' : 'worried';
  return (
    <Stage>
      <Bg ground />
      <G x={530} y={315} at={65.0}>
        <rect x={-270} y={-165} width={540} height={330} rx={26} fill="#fff" fillOpacity={0.55} stroke={C.ink} strokeWidth={4} strokeDasharray="14 10" />
      </G>
      <line x1={800} y1={320} x2={930} y2={320} stroke={C.ink} strokeWidth={7} opacity={s(65, 65.5)} />
      <Bulb x={1010} y={300} on={0} />
      {Array.from({length: 11}).map((_, i) => {
        const bx = 300 + ((i * 47) % 460);
        const by = 190 + ((i * 61) % 260);
        const x = clampv(bx + 70 * Math.sin(abs * (1.1 + 0.13 * i) + i * 2.3), 295, 770);
        const y = clampv(by + 60 * Math.cos(abs * (1.3 + 0.11 * i) + i), 180, 450);
        return <E key={i} x={x} y={y} r={12} op={s(65.5 + i * 0.1, 66 + i * 0.1)} />;
      })}
      <Chip x={530} y={120} text="Electron" at={65.8} color={C.blueDark} />
      <Cross x={1010} y={300} s={1.5} at={74.0} />
      <Character x={110} y={600} s={1.1} expr={expr} tremble={abs > 68.7 ? 1.5 : 0} look={[3, 0]} />
    </Stage>
  );
};

/* S09 76.12-89.74 : N/P layers + electric field */
export const S09: React.FC = () => {
  const {abs, s} = useT();
  const topY = lerp(-120, 0, s(76.4, 77.2));
  const botY = lerp(120, 0, s(77.6, 78.4));
  const fieldOn = s(80.6, 81.2);
  const drift = abs >= 85.28;
  const eles = Array.from({length: 9}).map((_, i) => {
    const x = 450 + i * 56;
    if (!drift) {
      const y = 410 + Math.sin(abs * 3 + i) * 10;
      return <E key={i} x={x} y={y} r={11} op={s(78.6, 79.2)} />;
    }
    const cyc = 3.2;
    const p = (((abs - 85.28 - i * 0.28) % cyc) + cyc) % cyc / cyc;
    const started = abs - 85.28 - i * 0.28 >= 0;
    const y = started ? lerp(450, 262, p) : 410;
    const op = started ? Math.min(1, p * 6, (1 - p) * 6) : 1;
    return <E key={i} x={x} y={y} r={11} op={op} />;
  });
  return (
    <Stage>
      <Bg />
      <g transform={`translate(0 ${topY})`} opacity={s(76.4, 77)}>
        <rect x={330} y={230} width={620} height={120} fill="#8EC1F7" stroke={C.ink} strokeWidth={4} />
        <T x={365} y={290} size={52} fill={C.blueDark}>N</T>
      </g>
      <g transform={`translate(0 ${botY})`} opacity={s(77.6, 78.2)}>
        <rect x={330} y={350} width={620} height={120} fill="#F7C98F" stroke={C.ink} strokeWidth={4} />
        <T x={365} y={410} size={52} fill={C.hl}>P</T>
      </g>
      {eles}
      <rect x={330} y={343} width={620} height={14} fill={C.sun} opacity={fieldOn * (0.6 + 0.3 * Math.sin(abs * 5))} />
      {[0, 1, 2, 3, 4].map((i) => (
        <Arrow key={i} x1={450 + i * 95} y1={300} x2={450 + i * 95} y2={400} color={C.red} sw={8} p={fieldOn} />
      ))}
      <Chip x={640} y={170} text="বৈদ্যুতিক ক্ষেত্র" at={81.2} color={C.red} size={36} />
      <Chip x={1080} y={290} text="N-স্তর" at={77.0} color={C.blueDark} size={26} />
      <Chip x={1080} y={410} text="P-স্তর" at={78.2} color={C.hl} size={26} />
    </Stage>
  );
};

/* S10 89.74-99.02 : metal fingers, current flows to bulb */
export const S10: React.FC = () => {
  const {abs, s} = useT();
  const loop: [number, number][] = [[550, 350], [1160, 350], [1160, 590], [360, 590], [360, 535]];
  const flowOn = s(94.0, 94.6);
  const bulbOn = s(95.6, 96.2);
  return (
    <Stage>
      <Bg />
      <rect x={160} y={170} width={400} height={360} rx={12} fill={C.cell} stroke={C.ink} strokeWidth={5} />
      {Array.from({length: 9}).map((_, i) => {
        const y = 200 + i * 37;
        const len = 380 * s(89.2 + i * 0.06, 89.8 + i * 0.06);
        return (
          <g key={i}>
            <line x1={170} y1={y} x2={170 + len} y2={y} stroke={C.ink} strokeWidth={8} strokeLinecap="round" />
            <line x1={170} y1={y} x2={170 + len} y2={y} stroke="#F4F8FF" strokeWidth={4} strokeLinecap="round" />
            {[0, 1, 2].map((r) => {
              const x = 180 + ((abs * 90 + r * 125 + i * 37) % 360);
              return <E key={r} x={x} y={y} r={6} op={s(91.2, 91.8)} />;
            })}
          </g>
        );
      })}
      <line x1={540} y1={176} x2={540} y2={524} stroke={C.ink} strokeWidth={13} strokeLinecap="round" opacity={s(90.6, 91.2)} />
      <line x1={540} y1={176} x2={540} y2={524} stroke="#F4F8FF" strokeWidth={7} strokeLinecap="round" opacity={s(90.6, 91.2)} />
      <g opacity={s(91.4, 92)}>
        <polyline points={loop.map((p) => p.join(',')).join(' ')} fill="none" stroke={C.ink} strokeWidth={7} strokeLinejoin="round" />
      </g>
      <Bulb x={900} y={350} on={bulbOn} />
      {Array.from({length: 12}).map((_, i) => {
        const [x, y] = polyPoint(loop, (abs - 94.0) * 0.13 + i / 12);
        return <E key={i} x={x} y={y} r={10} op={flowOn} />;
      })}
      <Chip x={360} y={120} text="সরু ধাতব রেখা" at={89.6} color={C.text} />
    </Stage>
  );
};

/* S11 99.02-104.5 : one cell ~ 0.5 V */
export const S11: React.FC = () => {
  const {s} = useT();
  return (
    <Stage>
      <Bg />
      <Cell x={330} y={330} s={2.2} at={99.2} />
      <Chip x={330} y={520} text="একটি সৌর কোষ" at={99.6} />
      <Arrow x1={470} y1={330} x2={680} y2={330} color={C.ink} sw={9} p={s(100.4, 101.2)} />
      <Note x={900} y={320} w={330} h={220} at={101.7} color={C.blue}>
        <T x={0} y={-10} size={110} fill={C.blueDark}>{bn('0.5')} V</T>
        <T x={0} y={72} size={34} weight={600} fill={C.text}>প্রায়</T>
      </Note>
      <Tick x={1090} y={200} s={0.9} at={103.4} />
    </Stage>
  );
};

/* S12 104.5-113.08 : cells in series, voltage adds */
export const S12: React.FC = () => {
  const {abs, s} = useT();
  const times = Array.from({length: 10}).map((_, i) => (i < 3 ? 104.9 + i * 0.7 : 110.0 + (i - 3) * 0.18));
  const count = times.filter((t) => abs >= t).length;
  const done = s(111.6, 112.2);
  return (
    <Stage>
      <Bg />
      <line x1={140} y1={380} x2={1140} y2={380} stroke={C.ink} strokeWidth={7} opacity={s(105, 105.5)} />
      {times.map((t, i) => (
        <Cell key={i} x={640 + (i - 4.5) * 108} y={380} s={0.9} at={t} />
      ))}
      {[0, 1].map((i) => (
        <G key={i} x={640 + (i - 4.5) * 108 + 54} y={300} at={108.6 + i * 0.3}>
          <T x={0} y={0} size={44} fill={C.red}>+</T>
        </G>
      ))}
      <T x={640} y={190} size={110} fill={mix(done, C.blueDark, C.mint)}>{bn((count * 0.5).toFixed(1))} V</T>
      <Chip x={640} y={520} text="১০টি সৌর কোষ" at={110.6} color={C.text} />
      <Chip x={640} y={90} text="Voltage যোগ হয়" at={108.9} color={C.hl} size={32} />
    </Stage>
  );
};

/* S13 113.08-121.96 : DC */
export const S13: React.FC = () => {
  const {abs, s} = useT();
  const needle = 0.5 * Math.min(1, s(113.2, 114.8) * 1.04);
  const draw = s(117.4, 119.4);
  return (
    <Stage>
      <Bg />
      <G x={350} y={150} at={115.8}>
        <PanelShape x={-80} y={-45} w={160} h={90} cols={5} rows={3} glow={0.15} />
      </G>
      <Arrow x1={350} y1={205} x2={350} y2={250} color={C.ink} sw={6} p={s(116.2, 116.7)} />
      <Gauge x={350} y={470} r={170} value={needle} />
      <T x={350} y={525} size={52} fill={C.blueDark}>{bn(5)} V</T>
      <G x={950} y={370} at={117.2}>
        <rect x={-250} y={-150} width={500} height={300} rx={20} fill="#fff" stroke={C.ink} strokeWidth={4} />
        <line x1={-220} y1={110} x2={220} y2={110} stroke={C.ink} strokeWidth={4} />
        <line x1={-220} y1={110} x2={-220} y2={-120} stroke={C.ink} strokeWidth={4} />
      </G>
      <Wave x={730} y={330} w={440} ac={false} draw={draw} color={C.red} sw={9} />
      {[0, 1, 2].map((i) => {
        const x = 740 + ((abs * 90 + i * 140) % 420);
        return <Arrow key={i} x1={x - 20} y1={330} x2={x + 10} y2={330} color={C.ink} sw={8} p={s(118, 118.4)} />;
      })}
      <Stamp x={950} y={240} text="DC" at={119.7} color={C.red} size={64} />
      <Chip x={950} y={540} text="একমুখী" at={120.2} color={C.red} />
    </Stage>
  );
};

/* S14 121.96-129.88 : home needs AC */
export const S14: React.FC = () => {
  const {abs, s} = useT();
  const point = 140 * (s(122.6, 123.2) - s(124.6, 125.2));
  return (
    <Stage>
      <Bg room />
      <G x={330} y={120} at={122.4}>
        <line x1={0} y1={-120} x2={0} y2={-14} stroke={C.ink} strokeWidth={7} />
        <g transform={`rotate(${abs * 420})`}>
          {[0, 120, 240].map((a) => (
            <ellipse key={a} cx={95} cy={0} rx={85} ry={15} fill="#fff" stroke={C.ink} strokeWidth={4} transform={`rotate(${a})`} />
          ))}
        </g>
        <circle r={22} fill={C.sun} stroke={C.ink} strokeWidth={4} />
      </G>
      <G x={700} y={0} at={123.3}>
        <line x1={0} y1={0} x2={0} y2={150} stroke={C.ink} strokeWidth={6} />
      </G>
      <Bulb x={700} y={195} on={s(123.8, 124.4)} />
      <G x={640} y={470} at={125.6}>
        <rect x={-200} y={-110} width={400} height={220} rx={18} fill="#fff" stroke={C.ink} strokeWidth={4} />
      </G>
      <Wave x={455} y={470} w={370} amp={55} ac draw={s(125.8, 127.2)} color={C.mint} />
      <Stamp x={1030} y={400} text="AC" at={127.4} color={C.mint} size={76} />
      <Character x={150} y={600} expr="neutral" raiseR={8 + point} look={[3, -3]} />
    </Stage>
  );
};
