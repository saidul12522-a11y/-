import React from 'react';
import {
  Arrow, Bg, Bolt, Bulb, Cell, Character, Chip, Cross, E, G, Heat, Note, PanelShape,
  Stage, Stamp, Sun, T, Thermo, Thought, Tick, Wave, lerp, polyPoint, useT, Expr,
} from '../kit';
import {C, W} from '../theme';

const House: React.FC<{x: number; y: number; lit: number}> = ({x, y, lit}) => (
  <g transform={`translate(${x} ${y})`}>
    <rect x={-100} y={-60} width={200} height={140} fill="#fff" stroke={C.ink} strokeWidth={4} />
    <polygon points="-120,-60 0,-150 120,-60" fill={C.orange} stroke={C.ink} strokeWidth={4} strokeLinejoin="round" />
    <rect x={-70} y={-30} width={50} height={50} fill={lit > 0.05 ? C.sunSoft : '#E5EDF7'} stroke={C.ink} strokeWidth={3.5} />
    <rect x={20} y={-30} width={50} height={110} fill={C.shirt} stroke={C.ink} strokeWidth={3.5} />
    {lit > 0.05 && <circle cx={-45} cy={-5} r={60 * lit} fill={C.sunSoft} opacity={0.4} />}
  </g>
);

/* S15 129.88-141.44 : inverter DC -> AC */
export const S15: React.FC = () => {
  const {abs, s} = useT();
  const lit = s(137.8, 138.6);
  return (
    <Stage>
      <Bg />
      <G x={90} y={235} at={130.0}>
        <PanelShape x={0} y={0} w={220} h={130} cols={5} rows={3} glow={0.1} />
      </G>
      <line x1={310} y1={300} x2={480} y2={300} stroke={C.ink} strokeWidth={7} opacity={s(130.3, 130.8)} />
      {[0, 1, 2].map((i) => (
        <E key={i} x={320 + ((abs * 70 + i * 55) % 150)} y={300} r={9} op={s(130.6, 131) * (1 - s(133.6, 134))} />
      ))}
      <G x={600} y={300} at={131.2}>
        <rect x={-120} y={-85} width={240} height={170} rx={20} fill={C.sunSoft} stroke={C.ink} strokeWidth={5} />
        <T x={0} y={-25} size={40} fill={C.text}>Inverter</T>
        <T x={0} y={35} size={34} fill={C.hl}>DC → AC</T>
      </G>
      <Wave x={720} y={300} w={220} amp={22} ac draw={s(133.7, 134.6)} color={C.mint} sw={7} />
      <G x={1050} y={300} at={135.5}>
        <House x={0} y={0} lit={lit} />
      </G>
      <Chip x={395} y={235} text="DC" at={131.6} color={C.red} size={28} />
      <Chip x={830} y={235} text="AC" at={134.2} color={C.mint} size={28} />
      <Bolt x={1050} y={150} s={1.4} at={138.4} />
    </Stage>
  );
};

/* S16 141.44-154.34 : the "more heat = more power" myth */
export const S16: React.FC = () => {
  const {abs, s} = useT();
  const level = lerp(0.2, 0.95, s(143, 148));
  const expr: Expr = abs < 150 ? 'think' : 'worried';
  return (
    <Stage>
      <Bg ground />
      <Sun x={1070} y={190} r={80} hot={s(144, 148)} at={141.8} />
      <Heat x={1000} y={350} n={3} gap={70} op={s(145, 146)} />
      <Character x={200} y={600} s={1.25} expr={expr} look={[2, -3]} />
      <Thought x={560} y={250} w={500} h={270} at={142.6}>
        <Thermo x={-150} y={70} h={130} level={level} />
        <Arrow x1={-95} y1={60} x2={-95} y2={-30} color={C.red} sw={8} p={s(144, 145)} />
        <T x={-10} y={5} size={64}>=</T>
        <Bolt x={110} y={0} s={2.2} />
        <Arrow x1={190} y1={50} x2={190} y2={-45} color={C.mint} sw={9} p={s(146, 147)} />
      </Thought>
      <Cross x={560} y={250} s={3.6} at={150.0} />
      <Stamp x={900} y={470} text="এমন নয়" at={150.5} size={60} />
    </Stage>
  );
};

/* S17 154.34-168.2 : heat lowers voltage -> lower output */
export const S17: React.FC = () => {
  const {abs, s} = useT();
  const heat = s(154.8, 158.6);
  const volt = 1 - 0.38 * s(159.2, 162.0);
  const power = 1 - 0.42 * s(163.7, 166.0);
  const base = 470;
  const bar = (x: number, h: number, color: string, at: number) => (
    <G x={x} y={base} at={at}>
      <rect x={-40} y={-h} width={80} height={h} fill={color} stroke={C.ink} strokeWidth={4} />
    </G>
  );
  return (
    <Stage>
      <Bg />
      <Thermo x={110} y={base - 28} h={250} level={0.2 + 0.78 * heat} />
      <G x={210} y={230} at={154.6}>
        <PanelShape x={0} y={0} w={300} h={190} cols={6} rows={3} hot={heat} />
      </G>
      <Chip x={360} y={170} text="অতিরিক্ত তাপ" at={155.2} color={C.red} />
      <Arrow x1={540} y1={330} x2={600} y2={330} color={C.ink} sw={7} p={s(158, 158.5)} />
      <G x={680} y={base} at={158.8}>
        <rect x={-45} y={-230} width={90} height={230} fill="#fff" stroke={C.ink} strokeWidth={4} />
        <rect x={-45} y={-230 * volt} width={90} height={230 * volt} fill={C.blue} stroke={C.ink} strokeWidth={4} />
      </G>
      <Chip x={680} y={base + 50} text="Voltage" at={159.0} color={C.blueDark} size={28} />
      <Arrow x1={760} y1={250} x2={760} y2={330} color={C.red} sw={10} p={s(160, 160.6)} />
      <Arrow x1={800} y1={330} x2={850} y2={330} color={C.ink} sw={7} p={s(162.6, 163.1)} />
      {bar(930, 230, C.sun, 163.3)}
      <G x={1060} y={base} at={163.5}>
        <rect x={-40} y={-230} width={80} height={230} fill="#fff" stroke={C.ink} strokeWidth={4} />
        <rect x={-40} y={-230 * power} width={80} height={230 * power} fill={C.mint} stroke={C.ink} strokeWidth={4} />
      </G>
      <Chip x={930} y={base + 50} text="আলো" at={163.6} color={C.hl} size={28} />
      <Chip x={1060} y={base + 50} text="বিদ্যুৎ" at={163.8} color={C.mint} size={28} />
      <Arrow x1={1060} y1={190} x2={1060} y2={250} color={C.red} sw={10} p={s(164.6, 165.2)} />
    </Stage>
  );
};

/* S18 168.2-172.6 : normal temperature works well */
export const S18: React.FC = () => {
  const {abs, s} = useT();
  return (
    <Stage>
      <Bg ground />
      <Sun x={1000} y={140} r={50} at={168.3} />
      <G x={360} y={230} at={168.5}>
        <PanelShape x={0} y={0} w={320} h={190} cols={6} rows={3} glow={0.15 + 0.1 * Math.sin(abs * 4)} />
      </G>
      <line x1={680} y1={330} x2={830} y2={330} stroke={C.ink} strokeWidth={7} opacity={s(169, 169.4)} />
      <Bulb x={900} y={320} on={s(169.3, 169.9)} />
      <Thermo x={1130} y={510} h={200} level={0.35} color={C.mint} />
      <Tick x={1130} y={250} s={0.95} at={170.6} />
      <Character x={200} y={600} s={1.2} expr="happy" raiseL={40 + 15 * Math.sin(abs * 5)} />
    </Stage>
  );
};

/* S19 172.6-187.66 : recap in three steps */
export const S19: React.FC = () => {
  const {abs, s} = useT();
  const xs = [200, 640, 1080];
  const ats = [172.8, 176.8, 180.2];
  const all = s(184.4, 185) * (0.5 + 0.5 * Math.sin(abs * 5));
  const titles = [['আলো দেয়', 'Electronকে শক্তি'], ['বৈদ্যুতিক ক্ষেত্র', 'দিক দেখায়'], ['তারে প্রবাহ', '= বিদ্যুৎ']];
  const loop: [number, number][] = [[-70, 20], [70, 20], [70, 80], [-70, 80], [-70, 20]];
  return (
    <Stage>
      <Bg />
      {xs.map((x, i) => (
        <Note key={i} x={x} y={330} w={350} h={400} at={ats[i]} color={[C.sun, C.blue, C.mint][i]}>
          <rect x={-175} y={-200} width={350} height={400} rx={18} fill="none" stroke={C.mint} strokeWidth={10} opacity={all} />
          <circle cx={-140} cy={-150} r={26} fill={[C.sun, C.blue, C.mint][i]} stroke={C.ink} strokeWidth={3} />
          <T x={-140} y={-148} size={30} fill="#fff">{['১', '২', '৩'][i]}</T>
          {i === 0 && (
            <g>
              <Sun x={0} y={-90} r={32} />
              <line x1={0} y1={-35} x2={0} y2={0} stroke={C.sun} strokeWidth={6} strokeDasharray="8 8" strokeDashoffset={-abs * 50} />
              <E x={0} y={30} r={16} />
              <Bolt x={50} y={30} s={0.9} />
            </g>
          )}
          {i === 1 && (
            <g>
              <rect x={-90} y={-95} width={180} height={50} fill="#8EC1F7" stroke={C.ink} strokeWidth={3} />
              <rect x={-90} y={-45} width={180} height={50} fill="#F7C98F" stroke={C.ink} strokeWidth={3} />
              <Arrow x1={-40} y1={-90} x2={-40} y2={-10} color={C.red} sw={6} />
              <Arrow x1={40} y1={-10} x2={40} y2={-90} color={C.blue} sw={6} />
            </g>
          )}
          {i === 2 && (
            <g>
              <polyline points={loop.map((p) => p.join(',')).join(' ')} fill="none" stroke={C.ink} strokeWidth={6} />
              <Bulb x={0} y={-40} on={0.9} s={0.8} />
              {[0, 1, 2, 3].map((k) => {
                const [px, py] = polyPoint(loop, abs * 0.25 + k / 4);
                return <E key={k} x={px} y={py} r={8} />;
              })}
            </g>
          )}
          <T x={0} y={120} size={34} fill={C.text}>{titles[i][0]}</T>
          <T x={0} y={165} size={34} fill={C.blueDark}>{titles[i][1]}</T>
        </Note>
      ))}
      <Arrow x1={395} y1={330} x2={445} y2={330} color={C.ink} sw={9} p={s(176.6, 177.1)} />
      <Arrow x1={835} y1={330} x2={885} y2={330} color={C.ink} sw={9} p={s(180, 180.5)} />
    </Stage>
  );
};

/* S20 187.66-195.44 : full chain + heat again */
export const S20: React.FC = () => {
  const {abs, s} = useT();
  const hot = s(193.2, 194.8);
  const flow = s(188.4, 189);
  const chain: [number, number][] = [[470, 300], [570, 300], [690, 300], [820, 300], [900, 300]];
  return (
    <Stage>
      <Bg />
      <Sun x={130} y={300} r={52} hot={hot} at={187.8} />
      <line x1={200} y1={300} x2={290} y2={300} stroke={C.sun} strokeWidth={7} strokeDasharray="12 10" strokeDashoffset={-abs * 70} opacity={flow} strokeLinecap="round" />
      <G x={290} y={235} at={188.2}>
        <PanelShape x={0} y={0} w={180} h={130} cols={4} rows={3} hot={hot} glow={0.1} />
      </G>
      <line x1={470} y1={300} x2={560} y2={300} stroke={C.ink} strokeWidth={7} opacity={flow} />
      {[0, 1, 2, 3].map((i) => {
        const [x, y] = polyPoint(chain, abs * 0.3 + i / 4);
        return <E key={i} x={x} y={y} r={9} op={flow} />;
      })}
      <G x={640} y={300} at={188.8}>
        <rect x={-80} y={-60} width={160} height={120} rx={16} fill={C.sunSoft} stroke={C.ink} strokeWidth={4.5} />
        <T x={0} y={0} size={30} fill={C.text}>Inverter</T>
      </G>
      <line x1={720} y1={300} x2={880} y2={300} stroke={C.ink} strokeWidth={7} opacity={flow} />
      <G x={1010} y={300} at={189.4}>
        <House x={0} y={0} lit={(1 - 0.7 * hot) * s(190, 190.6)} />
      </G>
      <Bolt x={380} y={190 + Math.sin(abs * 4) * 4} s={1.4} at={191.8} />
      <Heat x={310} y={225} n={3} gap={65} op={hot} color={C.red} />
      <Arrow x1={1010} y1={110} x2={1010} y2={165} color={C.red} sw={10} p={s(194, 194.8)} />
    </Stage>
  );
};

/* S21 195.44-204.68 : closing quote card + like / comment / subscribe */
export const S21: React.FC = () => {
  const {abs, s} = useT();
  const cardOut = s(198.4, 198.9);
  const btn = (x: number, at: number, label: string, color: string, icon: string, tc = '#fff') => {
    const pulse = 1 + 0.04 * Math.sin((abs - at) * 6);
    return (
      <G x={x} y={225} at={at} s={pulse}>
        <rect x={-150} y={-60} width={300} height={120} rx={60} fill={color} stroke={C.ink} strokeWidth={5} />
        <g transform="translate(-100 -24) scale(2)">
          <path d={icon} fill={tc} stroke={C.ink} strokeWidth={1} />
        </g>
        <T x={35} y={2} size={40} fill={tc}>{label}</T>
      </G>
    );
  };
  return (
    <Stage>
      <Bg ground />
      {abs < 198.95 && (
        <G x={640} y={300} s={1 - cardOut * 0.2} op={1 - cardOut}>
          <Note x={0} y={0} w={980} h={340} at={195.6} color={C.sun}>
            <Sun x={-410} y={-20} r={36} />
            <T x={40} y={-85} size={46} fill={C.text}>যে সূর্যের আলো বিদ্যুৎ দেয়,</T>
            <T x={40} y={-10} size={46} fill={C.text}>সেই সূর্যের <tspan fill={C.red}>অতিরিক্ত তাপই</tspan></T>
            <T x={40} y={65} size={46} fill={C.blueDark}>বিদ্যুৎ উৎপাদন কমিয়ে দিতে পারে</T>
          </Note>
        </G>
      )}
      {btn(300, 199.0, 'Like', C.blue, 'M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z')}
      {btn(640, 200.6, 'Comment', C.mint, 'M21.99 4c0-1.1-.89-2-1.99-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14l4 4-.01-18z')}
      {btn(980, 203.0, 'Subscribe', '#E53935', 'M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z')}
      <Character x={640} y={600} s={1.1} expr="happy" raiseR={abs > 198.9 ? 150 + 18 * Math.sin(abs * 7) : 8} at={198.9} />
    </Stage>
  );
};
