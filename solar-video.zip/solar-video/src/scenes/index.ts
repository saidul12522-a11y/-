import React from 'react';
import {S01, S02, S03, S04, S05, S06, S07} from './scenes1';
import {S08, S09, S10, S11, S12, S13, S14} from './scenes2';
import {S15, S16, S17, S18, S19, S20, S21} from './scenes3';

export type Cam = {z0: number; z1: number; ox?: number; oy?: number};
export const SCENES: {C: React.FC; cam?: Cam}[] = [
  {C: S01, cam: {z0: 1, z1: 1.06, ox: 30, oy: 60}},
  {C: S02, cam: {z0: 1, z1: 1.04, ox: 70, oy: 60}},
  {C: S03},
  {C: S04, cam: {z0: 1.04, z1: 1, ox: 60, oy: 50}},
  {C: S05},
  {C: S06, cam: {z0: 1, z1: 1.05, ox: 50, oy: 70}},
  {C: S07, cam: {z0: 1, z1: 1.06, ox: 45, oy: 50}},
  {C: S08},
  {C: S09, cam: {z0: 1, z1: 1.05, ox: 50, oy: 50}},
  {C: S10},
  {C: S11, cam: {z0: 1.05, z1: 1, ox: 50, oy: 50}},
  {C: S12},
  {C: S13},
  {C: S14, cam: {z0: 1, z1: 1.04, ox: 25, oy: 40}},
  {C: S15},
  {C: S16, cam: {z0: 1, z1: 1.05, ox: 25, oy: 60}},
  {C: S17},
  {C: S18},
  {C: S19},
  {C: S20},
  {C: S21},
];
