import React from 'react';
import {
  Arrow, Bg, Bolt, Bulb, Cell, Character, Chip, Cloud, Cross, G, Heat, Gauge, Note,
  PanelShape, Photon, E, Stage, Stamp, Sun, T, Thought, bn, lerp, mix, useT, Expr,
} from '../kit';
import {C, W} from '../theme';

/* S01 0.02-10.98 : rooftop hook */
export const S01: React.FC = () => {
  const {abs, s} = useT();
  const raise = 150 * (s(3.0, 3.6) - s(7.0, 7.6));
  const expr: Expr = abs < 8 ? 'neutral' : 'think';
  const beam = s(3.3, 3.8) * (1 - s(8, 8.5));
  const panels = [[380, 420], [660, 420]];
  return (
    <Stage>
      <Bg />
      <Cloud x={200} y={110} />
      <Cloud x={800} y={190} s={0.8} speed={0.3} />
      <Sun x={1080} y={130} r={56} at={0.3} />
      <rect x={0} y={540} width={W} height={180} fill={C.floor} />
      <line x1={0} y1={540} x2={W} y2={540} stroke={C.ink} strokeWidth={4} />
      {panels.map(([px, py], i) => (
        <g key={i}>
          <line x1={px + 50} y1={py + 100} x2={px + 44} y2={540} stroke={C.ink} strokeWidth={7} opacity={s(0.8, 1.2)} />
          <line x1={px + 180} y1={py + 92} x2={px + 186} y2={540} stroke={C.ink} strokeWidth={7} opacity={s(0.8, 1.2)} />
          <G x={px} y={py} at={0.8 + i * 0.3}>
            <PanelShape x={0} y={0} w={230} h={110} rot={-6} glow={beam * 0.6} />
          </G>
          <line x1={1080} y1={130} x2={px + 115} y2={py + 50} stroke={C.sun} strokeWidth={5} strokeDasharray="14 12" strokeDashoffset={-abs * 80} opacity={beam} strokeLinecap="round" />
          <Bolt x={px + 115} y={py - 40 + Math.sin(abs * 4 + i) * 5} s={1.3} at={6.0 + i * 0.3} />
        </g>
      ))}
      <Character x={170} y={575} expr={expr} raiseR={raise} look={[2, -3]} />
      <Thought x={330} y={230} w={270} h={150} at={8.0}>
        <g transform="translate(-60 6)">
          <rect x={-26} y={-18} width={42} height={46} rx={6} fill={C.orange} stroke={C.ink} strokeWidth={3.5} />
          <path d="M-10 -18 L-10 -30 H8 L16 -18" fill="none" stroke={C.ink} strokeWidth={3.5} />
          <Cross x={-5} y={5} s={0.9} at={9.6} />
        </g>
        <T x={62} y={6} size={96} fill={C.blue}>?</T>
      </Thought>
    </Stage>
  );
};

/* S02 10.98-22.92 : the questions */
export const S02: React.FC = () => {
  const {abs, s} = useT();
  const mx = 520 + 240 * (0.5 + 0.5 * Math.sin((abs - 15.8) * 0.9));
  const hot = s(19.4, 22.5);
  const expr: Expr = abs < 14.7 ? 'neutral' : abs < 19.2 ? 'surprise' : 'think';
  const bulbOn = abs < 14.7 ? 0 : abs < 21.5 ? 0.9 : 0.2;
  return (
    <Stage>
      <Bg ground />
      <Sun x={190} y={250} r={lerp(60, 78, hot)} hot={hot} at={11.0} />
      <Bulb x={1100} y={200} on={bulbOn} />
      <Arrow x1={290} y1={250} x2={1000} y2={210} color={C.sun} sw={6} dash p={s(11.6, 12.6) * (1 - s(14.5, 14.9))} />
      <G x={640} y={250} at={12.4} op={1 - s(14.5, 14.9)}>
        <T x={0} y={0} size={150} fill={C.blue}>?</T>
      </G>
      <G x={440} y={190} at={14.7}>
        <PanelShape x={0} y={0} w={400} h={220} cols={8} rows={4} glow={0.1} />
      </G>
      <line x1={840} y1={300} x2={1060} y2={230} stroke={C.ink} strokeWidth={6} opacity={s(14.9, 15.3)} />
      <line x1={290} y1={260} x2={440} y2={280} stroke={C.sun} strokeWidth={6} strokeDasharray="12 10" strokeDashoffset={-abs * 70} opacity={s(14.9, 15.3)} />
      <g opacity={s(15.6, 16) * (1 - s(19.0, 19.4))}>
        <circle cx={mx} cy={300} r={62} fill="#fff" fillOpacity={0.35} stroke={C.ink} strokeWidth={7} />
        <line x1={mx + 44} y1={344} x2={mx + 92} y2={392} stroke={C.ink} strokeWidth={14} strokeLinecap="round" />
        <T x={mx} y={304} size={70} fill={C.red}>?</T>
      </g>
      <Heat x={500} y={165} n={3} gap={140} op={s(20, 20.6)} color={C.orange} />
      <Character x={1040} y={600} s={1.3} expr={expr} look={[-3, -1]} />
    </Stage>
  );
};

/* S03 22.92-28.78 : heat paradox, then title card */
export const S03: React.FC = () => {
  const {abs, s} = useT();
  const needle = lerp(0.85, 0.3, s(23.2, 24.6));
  const card = s(25.16, 25.6);
  return (
    <Stage>
      <Bg />
      <Sun x={300} y={300} r={90} hot={1} />
      <Heat x={180} y={200} n={4} gap={80} len={80} op={s(23, 23.5)} />
      <Gauge x={900} y={430} r={170} value={needle} />
      <Chip x={900} y={500} text="বিদ্যুৎ উৎপাদন" at={23.6} />
      <Arrow x1={900} y1={170} x2={900} y2={230} color={C.red} sw={12} p={s(24, 24.6)} />
      <g opacity={card}>
        <rect width={W} height={720} fill={C.bg} />
        <rect width={W} height={720} fill="#fff" opacity={0.35} />
      </g>
      <G x={640} y={170} at={25.3}>
        <PanelShape x={-90} y={-45} w={180} h={90} cols={6} rows={3} glow={0.2} />
      </G>
      <G x={640} y={330} at={25.5}>
        <T x={0} y={0} size={84}>বিদ্যুৎ তৈরির</T>
      </G>
      <G x={640} y={440} at={25.8}>
        <T x={0} y={0} size={84} fill={C.blue}>সম্পূর্ণ প্রক্রিয়া</T>
      </G>
      <line x1={420} y1={510} x2={420 + 440 * s(26.2, 27)} y2={510} stroke={C.sun} strokeWidth={10} strokeLinecap="round" opacity={card} />
    </Stage>
  );
};

/* S04 28.78-36.5 : silicon */
export const S04: React.FC = () => {
  const {abs, s} = useT();
  const qOp = 1 - s(32.4, 32.7);
  const panelOp = 1 - s(34.1, 34.5);
  return (
    <Stage>
      <Bg />
      <G x={150} y={240} at={29.0} op={panelOp}>
        <PanelShape x={0} y={0} w={300} h={180} cols={6} rows={3} glow={0.1} />
      </G>
      <Bolt x={300} y={200} s={1.6} at={29.8} />
      <Arrow x1={470} y1={330} x2={700} y2={330} color={C.ink} sw={8} p={s(30.2, 30.8) * panelOp} />
      <G x={900} y={330} at={30.6} op={qOp}>
        <T x={0} y={0} size={190} fill={C.blue}>?</T>
      </G>
      <Note x={900} y={330} w={270} h={310} at={32.7} color={C.blue}>
        <T x={-95} y={-105} size={30} weight={600} fill={C.text}>{bn(14)}</T>
        <T x={0} y={-10} size={150} fill={C.blueDark}>Si</T>
        <T x={0} y={95} size={44} fill={C.text}>Silicon</T>
      </Note>
      <Arrow x1={760} y1={330} x2={640} y2={330} color={C.ink} sw={8} p={s(34.2, 34.6)} />
      {[0, 1, 2, 3].map((i) => (
        <Cell key={i} x={170 + i * 125} y={330} s={0.85} at={34.6 + i * 0.3} />
      ))}
    </Stage>
  );
};

/* S05 36.5-47.7 : cell -> panel -> sunlight */
export const S05: React.FC = () => {
  const {abs, s} = useT();
  const cols = 6;
  const rows = 4;
  const grid = (i: number): [number, number] => [
    640 + ((i % cols) - 2.5) * 116,
    360 + (Math.floor(i / cols) - 1.5) * 116,
  ];
  const frame = s(41.0, 41.6);
  const glow = s(45, 45.6) * (0.5 + 0.5 * Math.sin(abs * 5));
  return (
    <Stage>
      <Bg />
      <g opacity={frame}>
        <rect x={640 - 360} y={360 - 270} width={720} height={540} rx={22} fill="#EEF3FA" stroke={C.ink} strokeWidth={5} />
      </g>
      {Array.from({length: cols * rows}).map((_, i) => {
        const [gx, gy] = grid(i);
        if (i === 0) {
          const k = s(38.4, 39.4);
          return <Cell key={i} x={lerp(640, gx, k)} y={lerp(350, gy, k)} s={lerp(2.8, 1.04, k)} at={36.6} hot={0} />;
        }
        return <Cell key={i} x={gx} y={gy} s={1.04} at={38.9 + i * 0.09} />;
      })}
      <g opacity={1 - s(40.6, 41.2)}><Chip x={640} y={130} text="সৌর কোষ" at={37.0} /></g>
      <Chip x={640} y={60} text="Solar Panel" at={41.8} color={C.blue} />
      <g opacity={s(44.5, 45)}>
        <Sun x={1150} y={90} r={44} />
        <line x1={1120} y1={120} x2={900} y2={250} stroke={C.sun} strokeWidth={6} strokeDasharray="14 12" strokeDashoffset={-abs * 80} strokeLinecap="round" />
        <line x1={1100} y1={130} x2={880} y2={360} stroke={C.sun} strokeWidth={6} strokeDasharray="14 12" strokeDashoffset={-abs * 80} strokeLinecap="round" />
        <g opacity={glow}>
          <rect x={280} y={90} width={720} height={540} rx={22} fill="#fff" opacity={0.5} />
        </g>
      </g>
    </Stage>
  );
};

/* S06 47.7-55.96 : photons hit silicon */
export const S06: React.FC = () => {
  const {abs, s} = useT();
  const enter = s(51.4, 51.8);
  const sunX = 170;
  const sunY = 110;
  const photons = Array.from({length: 8}).map((_, i) => {
    const tx = 340 + i * 95;
    const cyc = 2.2;
    const raw = abs - 48.3 - i * 0.27;
    const p = raw < 0 ? 0 : (raw % cyc) / cyc;
    const ty = 440 + enter * 80;
    const x = lerp(sunX, tx, p);
    const y = lerp(sunY, ty, p);
    const ang = (Math.atan2(ty - sunY, tx - sunX) * 180) / Math.PI;
    const op = raw < 0 ? 0 : p > 0.9 ? 1 - (p - 0.9) * 10 : 1;
    const flash = raw >= 0 && enter > 0.5 && p > 0.88 ? (p - 0.88) / 0.12 : 0;
    return (
      <g key={i}>
        <Photon x={x} y={y} ang={ang} op={op} />
        {flash > 0 && <circle cx={tx} cy={440} r={10 + flash * 26} fill="none" stroke={C.sun} strokeWidth={5} opacity={1 - flash} />}
      </g>
    );
  });
  const dots: React.ReactNode[] = [];
  for (let r = 0; r < 3; r++)
    for (let c = 0; c < 19; c++)
      dots.push(<circle key={`${r}-${c}`} cx={290 + c * 40} cy={475 + r * 50} r={6} fill="#EAF1FB" stroke={C.ink} strokeWidth={2} />);
  return (
    <Stage>
      <Bg />
      <Sun x={sunX} y={sunY} r={54} at={47.8} />
      <G x={640} y={520} at={47.9}>
        <rect x={-380} y={-80} width={760} height={170} rx={16} fill="#8FA6C8" stroke={C.ink} strokeWidth={5} />
      </G>
      <g opacity={s(48.4, 49)}>{dots}</g>
      {photons}
      <Chip x={330} y={405} text="Silicon" at={48.6} color={C.text} />
      <Chip x={420} y={230} text="Photon" at={50.4} color={C.hl} />
      <Arrow x1={380} y1={265} x2={440} y2={330} color={C.ink} sw={5} p={s(50.7, 51.2)} />
    </Stage>
  );
};

/* S07 55.96-64.92 : electron freed */
export const S07: React.FC = () => {
  const {abs, s} = useT();
  const cx = 560;
  const cy = 340;
  const rot = (-20 * Math.PI) / 180;
  const orbit = (th: number): [number, number] => {
    const ex = 150 * Math.cos(th);
    const ey = 100 * Math.sin(th);
    return [cx + ex * Math.cos(rot) - ey * Math.sin(rot), cy + ex * Math.sin(rot) + ey * Math.cos(rot)];
  };
  const tRel = 58.2;
  const th0 = 0.6;
  const speed = 2.4;
  const [rx0, ry0] = orbit(th0 + tRel * speed);
  const freed = abs >= tRel;
  const [ox, oy] = orbit(th0 + Math.min(abs, tRel) * speed);
  const k = s(tRel, 60.6);
  const fx = lerp(rx0, 1000, k) + (freed ? Math.sin(abs * 7) * 6 * k : 0);
  const fy = lerp(ry0, 250, k) + (freed ? Math.cos(abs * 6) * 6 * k : 0);
  const zip = s(62.2, 64.4);
  const ph = s(57.3, 58.2);
  return (
    <Stage>
      <Bg />
      <Chip x={560} y={110} text="Siliconের পরমাণু" at={56.5} color={C.text} />
      <g transform={`translate(${cx} ${cy}) rotate(-20)`}>
        <ellipse rx={150} ry={100} fill="none" stroke={C.ink} strokeWidth={3.5} strokeDasharray="10 9" />
      </g>
      <G x={cx} y={cy} at={56.2}>
        <circle r={38} fill={C.orange} stroke={C.ink} strokeWidth={4} />
        <T x={0} y={2} size={34} fill="#fff">Si</T>
      </G>
      {[2.1, 4.2].map((o) => {
        const [x, y] = orbit(o + th0 + abs * speed);
        return <E key={o} x={x} y={y} r={11} />;
      })}
      {!freed && <E x={ox} y={oy} r={11} />}
      {freed && (
        <>
          <circle cx={rx0} cy={ry0} r={11} fill="none" stroke={C.ink} strokeWidth={2.5} strokeDasharray="4 4" opacity={s(58.4, 58.8)} />
          <E x={fx + zip * 150} y={fy} r={13} />
          <circle cx={rx0} cy={ry0} r={10 + s(tRel, tRel + 0.4) * 40} fill="none" stroke={C.sun} strokeWidth={6} opacity={1 - s(tRel, tRel + 0.5)} />
        </>
      )}
      {!freed && <Photon x={lerp(150, rx0, ph)} y={lerp(100, ry0, ph)} ang={(Math.atan2(ry0 - 100, rx0 - 150) * 180) / Math.PI} op={abs > 57.3 ? 1 : 0} r={9} />}
      <Chip x={1000} y={170} text="Electron" at={59.4} color={C.blueDark} />
      <Arrow x1={900} y1={330} x2={1180} y2={330} color={C.ink} sw={6} dash p={s(62.0, 62.8)} />
    </Stage>
  );
};
