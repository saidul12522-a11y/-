// Scene start times (seconds) taken from the SRT cue boundaries / audio.
export const STARTS = [
  0, 10.98, 22.92, 28.78, 36.5, 47.7, 55.96, 64.92, 76.12, 89.74, 99.02,
  104.5, 113.08, 121.96, 129.88, 141.44, 154.34, 168.2, 172.6, 187.66, 195.44,
];

// Time ranges (sec) where a full Text Card is on screen -> bottom caption hidden.
export const HIDE_CAPTIONS: [number, number][] = [
  [25.16, 28.78], // title card
  [172.6, 187.66], // recap cards
  [195.44, 198.8], // closing quote card
];
