import React from 'react';
import {Composition} from 'remotion';
import {SolarVideo} from './Video';
import {FPS, H, TOTAL_FRAMES, W} from './theme';

export const RemotionRoot: React.FC = () => (
  <Composition id="SolarVideo" component={SolarVideo} durationInFrames={TOTAL_FRAMES} fps={FPS} width={W} height={H} />
);
