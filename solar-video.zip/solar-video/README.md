# Solar Panel Video (Remotion)

1920x1080 নয়, 1280x720 @ 30fps, 6141 frames (= audio 204.68s)

    npm install
    npx remotion studio
    npx remotion render SolarVideo out/solar-video.mp4

- Audio: public/audio.wav (unchanged original)
- Timing: src/timing.ts (scene starts from SRT), src/captionData.ts (generated from public/subtitles.srt)
- Theme: Light Blue #DCEEFF (src/theme.ts)
