export const W = 1280;
export const H = 720;
export const FPS = 30;
export const C = {
  bg: '#14151c', wall: '#1d1f2b', floor: '#101118', line: '#222222',
  cream: '#e9e4d3', grey: '#8e8e96', greyBlue: '#8d93a8',
  blue: '#3f78d0', yellow: '#e8c53a', orange: '#ff8a1f',
  cardboard: '#c8975a', teal: '#2fbf9b', red: '#e24b4b', white: '#ffffff',
  metal: '#5a6072', glow: '#ff9a3c',
};
