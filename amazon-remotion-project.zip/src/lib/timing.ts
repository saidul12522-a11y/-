import {FPS} from './theme';

export const sec = (s: number) => Math.round(s * FPS);
export const AUDIO_SEC = 59.135;
export const TOTAL = Math.ceil(AUDIO_SEC * FPS); // 1774 frames

// Scene start times (seconds), derived from the SRT + sentence boundaries
const starts = [0, 5.17, 8.277, 11.66, 14.2, 18.4, 21.5, 29.68, 33.3, 40.341, 43.96, 49.32, 53.06];
export const SCENE_FRAMES = starts.map((s, i) => {
  const from = sec(s);
  const to = i === starts.length - 1 ? TOTAL : sec(starts[i + 1]);
  return {from, d: to - from};
});

// Captions only where no card/callout repeats the same words. **x** = highlighted keyword
export type Cue = {a: number; b: number; t: string};
export const CUES: Cue[] = [
  {a: 0.305, b: 3.4, t: 'আপনি ভাবেন **Amazon** নিজেই সব জিনিস বিক্রি করে'},
  {a: 3.4, b: 5.17, t: 'আসলে **Amazon**-এ…'},
  {a: 11.66, b: 14.2, t: 'আসল কাজ লুকিয়ে আছে একটা **গুদামে**'},
  {a: 14.2, b: 18.4, t: 'একজন বিক্রেতা একটা **ওয়াটার বোতল** পাঠালেন'},
  {a: 18.4, b: 21.5, t: 'বোতল রাখা হয় যেকোনো **খালি জায়গায়**'},
  {a: 21.5, b: 26.4, t: 'কম্পিউটার শুধু মনে রাখে **কোথায়** রাখা হলো'},
  {a: 26.4, b: 28.5, t: 'আর তুলাও **সহজ** হয়'},
  {a: 29.68, b: 33.3, t: 'আপনি **অর্ডার** দিলেন, **রোবট** তাকটা টেনে আনে'},
  {a: 33.3, b: 36.6, t: 'কর্মীর সামনে দাঁড়ায়, বোতলটা **তুলে নেন**'},
  {a: 36.6, b: 39.3, t: 'তাকে গুদামে **হাঁটতে** হয় না'},
  {a: 40.341, b: 43.96, t: 'বক্সে ভরা, **লেবেল** লাগানো, **ট্রাকে** তোলা'},
];
