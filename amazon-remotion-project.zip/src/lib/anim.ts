import {Easing, interpolate, spring} from 'remotion';

export const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
export const pop = (f: number, delay = 0) =>
  spring({frame: Math.max(0, f - delay), fps: 30, config: {damping: 11, stiffness: 150}});
export const fade = (f: number, s = 0, l = 10) => interpolate(f, [s, s + l], [0, 1], clamp);
export const ease = (f: number, a: number, b: number, from: number, to: number) =>
  interpolate(f, [a, b], [from, to], {...clamp, easing: Easing.inOut(Easing.cubic)});
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
