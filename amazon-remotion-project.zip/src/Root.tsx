import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';
import {TOTAL} from './lib/timing';
import {FPS, H, W} from './lib/theme';

export const Root: React.FC = () => (
  <Composition id="AmazonVideo" component={Video} durationInFrames={TOTAL} fps={FPS} width={W} height={H} />
);
