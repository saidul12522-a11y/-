import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {C} from './lib/theme';
import {SCENE_FRAMES} from './lib/timing';
import {Captions} from './components/Captions';
import {S01, S02, S03, S04} from './scenes/ScenesA';
import {S05, S06, S07, S08} from './scenes/ScenesB';
import {S09, S10, S11, S12, S13} from './scenes/ScenesC';

const SCENES = [S01, S02, S03, S04, S05, S06, S07, S08, S09, S10, S11, S12, S13];

export const Video: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: C.bg}}>
    <Audio src={staticFile('audio/Amazon-sul.m4a')} />
    {SCENES.map((Sc, i) => (
      <Sequence key={i} from={SCENE_FRAMES[i].from} durationInFrames={SCENE_FRAMES[i].d} name={`S${String(i + 1).padStart(2, '0')}`}>
        <Sc d={SCENE_FRAMES[i].d} />
      </Sequence>
    ))}
    <Captions />
  </AbsoluteFill>
);
