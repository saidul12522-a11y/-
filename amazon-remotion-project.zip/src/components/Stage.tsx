import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {clamp, fade} from '../lib/anim';

export type CamP = {z0?: number; z1?: number; x0?: number; x1?: number; y0?: number; y1?: number; ox?: number; oy?: number};

// Full-screen 1280x720 SVG stage with slow camera move + 6-frame fade-in
export const Stage: React.FC<{d: number; cam?: CamP; children: React.ReactNode}> = ({d, cam = {}, children}) => {
  const f = useCurrentFrame();
  const {z0 = 1, z1 = 1.06, x0 = 0, x1 = 0, y0 = 0, y1 = 0, ox = 640, oy = 360} = cam;
  const t = interpolate(f, [0, d], [0, 1], clamp);
  const z = z0 + (z1 - z0) * t;
  return (
    <AbsoluteFill style={{opacity: fade(f, 0, 6), background: '#14151c'}}>
      <div style={{position: 'absolute', inset: 0, transformOrigin: `${ox}px ${oy}px`, transform: `translate(${x0 + (x1 - x0) * t}px,${y0 + (y1 - y0) * t}px) scale(${z})`}}>
        <svg viewBox="0 0 1280 720" width="100%" height="100%">{children}</svg>
      </div>
    </AbsoluteFill>
  );
};
