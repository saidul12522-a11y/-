import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from '../lib/theme';
import {fontFamily} from '../lib/font';
import {CUES, sec} from '../lib/timing';
import {fade} from '../lib/anim';

const parse = (t: string) =>
  t.split(/(\*\*[^*]+\*\*)/).map((p, i) =>
    p.startsWith('**') ? <span key={i} style={{color: C.yellow, fontWeight: 700}}>{p.slice(2, -2)}</span> : <span key={i}>{p}</span>,
  );

// Floating overlay caption (one line, fade-up). Hidden when a card/bubble already shows the text.
export const Captions: React.FC = () => {
  const f = useCurrentFrame();
  const cue = CUES.find((c) => f >= sec(c.a) && f < sec(c.b));
  if (!cue) return null;
  const k = fade(f, sec(cue.a), 8);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 44, display: 'flex', justifyContent: 'center', opacity: k, transform: `translateY(${(1 - k) * 16}px)`}}>
      <div style={{fontFamily, fontWeight: 600, fontSize: 46, color: '#fff', background: 'rgba(0,0,0,0.5)', padding: '6px 28px', borderRadius: 14, whiteSpace: 'nowrap'}}>
        {parse(cue.t)}
      </div>
    </div>
  );
};
