import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from '../lib/theme';

export type Expr = 'neutral' | 'happy' | 'think' | 'surprise' | 'sad' | 'angry';
export type Pose = 'stand' | 'sit' | 'walk' | 'carry' | 'point' | 'thumbs';
type P = {
  x: number; y: number; s?: number; fill?: string; hat?: string; expr?: Expr; pose?: Pose;
  flip?: boolean; talk?: boolean; held?: React.ReactNode; seed?: number;
};
type V = [number, number];

export const Cap: React.FC<{a: V; b: V; w: number; fill: string}> = ({a, b, w, fill}) => (
  <g strokeLinecap="round">
    <line x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke={C.line} strokeWidth={w + 6} />
    <line x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke={fill} strokeWidth={w} />
  </g>
);

const BROWS: Record<Expr, {t: [number, number]; up: number}> = {
  neutral: {t: [2, 2], up: 0}, happy: {t: [-2, -2], up: -3}, think: {t: [0, -7], up: 0},
  surprise: {t: [-2, -2], up: -9}, sad: {t: [-8, -8], up: 0}, angry: {t: [9, 9], up: 2},
};

// Flat cartoon blob character (feet at x,y). Reference-style: bean body, capsule limbs, #222 outline.
export const Char: React.FC<P> = ({
  x, y, s = 1, fill = C.cream, hat, expr = 'neutral', pose = 'stand', flip, talk, held, seed = 0,
}) => {
  const f = useCurrentFrame() + seed * 17;
  const bob = Math.sin(f / 14) * 2.5;
  const eyeY = f % 100 < 4 ? 0.12 : 1;
  const w = Math.sin(f / 5);
  const sit = pose === 'sit';
  const dy = sit ? 45 : 0;
  let R: V = [46, -125 + Math.sin(f / 18) * 3];
  let L: V = [-46, -125 + Math.sin(f / 18 + 1) * 3];
  if (pose === 'walk') { R = [30 + w * 38, -128]; L = [-30 - w * 38, -128]; }
  if (pose === 'carry' || sit) { R = [66, -158]; L = [54, -148]; }
  if (pose === 'point') R = [120, -222];
  if (pose === 'thumbs') R = [74, -262];
  const lf = pose === 'walk' ? -16 - w * 22 : -16;
  const rf = pose === 'walk' ? 16 + w * 22 : 16;
  const b = BROWS[expr];
  const eyes = [-12, 24];
  const by = -292 + b.up;
  const mi = Math.floor(f / 4) % 3;
  const stroke = {stroke: C.line, strokeWidth: 3, fill: 'none', strokeLinecap: 'round'} as const;
  let mouth: React.ReactNode = <line x1={-4} y1={-238} x2={16} y2={-238} {...stroke} />;
  if (talk) {
    mouth = mi === 0 ? mouth : <ellipse cx={6} cy={-236} rx={mi === 1 ? 6 : 8} ry={mi === 1 ? 4 : 8} fill={C.line} />;
  } else if (expr === 'happy') mouth = <path d="M -8 -241 Q 6 -227 20 -241" {...stroke} />;
  else if (expr === 'sad') mouth = <path d="M -6 -233 Q 6 -245 18 -233" {...stroke} />;
  else if (expr === 'surprise') mouth = <ellipse cx={6} cy={-236} rx={6} ry={8} fill={C.line} />;
  else if (expr === 'think') mouth = <line x1={-2} y1={-236} x2={16} y2={-241} {...stroke} />;

  return (
    <g transform={`translate(${x},${y + bob}) scale(${flip ? -s : s},${s})`}>
      <g transform={`translate(0,${dy})`}>
        {sit ? (
          <>
            <Cap a={[-14, -105]} b={[44, -105]} w={24} fill={fill} />
            <Cap a={[44, -105]} b={[44, -52]} w={24} fill={fill} />
            <Cap a={[14, -105]} b={[72, -105]} w={24} fill={fill} />
            <Cap a={[72, -105]} b={[72, -52]} w={24} fill={fill} />
          </>
        ) : (
          <>
            <Cap a={[-16, -105]} b={[lf, -14]} w={24} fill={fill} />
            <Cap a={[16, -105]} b={[rf, -14]} w={24} fill={fill} />
          </>
        )}
        <rect x={-36} y={-232} width={72} height={132} rx={34} fill={fill} stroke={C.line} strokeWidth={5} />
        <ellipse cx={4} cy={-262} rx={50} ry={56} fill={fill} stroke={C.line} strokeWidth={5} />
        {hat && (
          <>
            <path d="M -46 -290 Q 4 -345 54 -290 Z" fill={hat} stroke={C.line} strokeWidth={4} />
            <line x1={-52} y1={-290} x2={62} y2={-290} stroke={hat} strokeWidth={8} strokeLinecap="round" />
          </>
        )}
        {eyes.map((ex, i) => (
          <g key={i}>
            <ellipse cx={ex} cy={-264} rx={4.5} ry={(expr === 'surprise' ? 8 : 5.5) * eyeY} fill={C.line} />
            <line x1={ex - 10} y1={by - (i === 0 ? b.t[0] : -b.t[1])} x2={ex + 10} y2={by + (i === 0 ? b.t[0] : -b.t[1])} {...stroke} />
          </g>
        ))}
        {mouth}
        <Cap a={[34, -205]} b={R} w={22} fill={fill} />
        <Cap a={[-34, -205]} b={L} w={22} fill={fill} />
        {pose === 'thumbs' && <Cap a={[R[0], R[1] - 4]} b={[R[0], R[1] - 28]} w={12} fill={fill} />}
        {held && <g transform={`translate(${R[0]},${R[1]})`}>{held}</g>}
      </g>
    </g>
  );
};
