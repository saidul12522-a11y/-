import React from 'react';
import {C} from '../lib/theme';
import {fontFamily} from '../lib/font';
import {lerp} from '../lib/anim';
import {Cap} from './Char';

const ln = {stroke: C.line, strokeWidth: 4} as const;

export const Box: React.FC<{x: number; y: number; w?: number; h?: number; label?: string; color?: string; rot?: number; s?: number}> = ({x, y, w = 90, h = 70, label, color = C.cardboard, rot = 0, s = 1}) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`}>
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={5} fill={color} {...ln} />
    <rect x={-8} y={-h / 2} width={16} height={h} fill="#e3c08a" opacity={0.8} />
    {label && <text x={0} y={h / 2 - 9} textAnchor="middle" fontSize={Math.max(10, w / 6)} fontWeight={700} fill="#3a2a14" fontFamily={fontFamily}>{label}</text>}
  </g>
);

export const Bottle: React.FC<{x: number; y: number; s?: number; rot?: number}> = ({x, y, s = 1, rot = 0}) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`}>
    <rect x={-14} y={-46} width={28} height={72} rx={12} fill="#5ab4ff" {...ln} />
    <rect x={-8} y={-60} width={16} height={14} rx={3} fill="#fff" {...ln} />
    <rect x={-14} y={-18} width={28} height={16} fill="#fff" opacity={0.5} />
  </g>
);

export type Kind = 'b' | 't' | 'p' | 'x' | null;
export const slotXY = (x: number, y: number, w: number, rowH: number, cols: number, r: number, c: number) => ({
  cx: x + (c + 0.5) * (w / cols),
  cy: y + (r + 1) * rowH - 4,
});

const Item: React.FC<{k: Kind; u: number}> = ({k, u}) => {
  if (k === 'b') return <Box x={0} y={-35 * u} w={100 * u} h={70 * u} />;
  if (k === 'p') return <Box x={0} y={-20 * u} w={120 * u} h={40 * u} color="#b98550" />;
  if (k === 't') return (
    <g>
      <rect x={-22 * u} y={-64 * u} width={44 * u} height={64 * u} rx={6 * u} fill="#c0463a" {...ln} />
      <rect x={-22 * u} y={-40 * u} width={44 * u} height={14 * u} fill="#f0e6c8" />
    </g>
  );
  if (k === 'x') return <Bottle x={0} y={-26 * u} s={u} />;
  return null;
};

export const Shelf: React.FC<{x: number; y: number; w: number; rows: number; rowH: number; cols: number; grid: Kind[][]; show?: (r: number, c: number) => number}> = ({x, y, w, rows, rowH, cols, grid, show}) => {
  const u = rowH / 170;
  return (
    <g>
      <rect x={x - 10} y={y} width={12} height={rows * rowH + 8} fill={C.metal} {...ln} />
      <rect x={x + w - 2} y={y} width={12} height={rows * rowH + 8} fill={C.metal} {...ln} />
      {Array.from({length: rows}).map((_, r) => (
        <g key={r}>
          {grid[r]?.map((k, c) => {
            const {cx, cy} = slotXY(x, y, w, rowH, cols, r, c);
            const sc = show ? show(r, c) : 1;
            return k ? <g key={c} transform={`translate(${cx},${cy}) scale(${sc})`}><Item k={k} u={u} /></g> : null;
          })}
          <rect x={x - 10} y={y + (r + 1) * rowH - 4} width={w + 20} height={12} fill={C.metal} {...ln} />
        </g>
      ))}
    </g>
  );
};

export const Robot: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x},${y})`}>
    <rect x={-80} y={-30} width={160} height={30} rx={15} fill={C.orange} {...ln} />
    <rect x={-58} y={-40} width={116} height={12} rx={6} fill="#c9680f" strokeWidth={3} stroke={C.line} />
    <circle cx={-50} cy={-14} r={5} fill="#fff7c2" />
    <circle cx={50} cy={-14} r={5} fill="#fff7c2" />
  </g>
);

export const Phone: React.FC<{x: number; y: number; w: number; h: number; children?: React.ReactNode}> = ({x, y, w, h, children}) => (
  <g transform={`translate(${x},${y})`}>
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={34} fill="#0d0e14" stroke="#3a3f55" strokeWidth={6} />
    <rect x={-w / 2 + 14} y={-h / 2 + 14} width={w - 28} height={h - 28} rx={24} fill="#1b1e2b" />
    {children}
  </g>
);

export const Hands: React.FC<{tap: number; tx: number; ty: number}> = ({tap, tx, ty}) => (
  <g>
    <Cap a={[430, 780]} b={[472, 560]} w={100} fill={C.cream} />
    <Cap a={[850, 780]} b={[808, 560]} w={100} fill={C.cream} />
    <Cap a={[440, 610]} b={[510, 570]} w={44} fill={C.cream} />
    <Cap a={[850, 640]} b={[lerp(850, tx, tap), lerp(640, ty, tap)]} w={44} fill={C.cream} />
  </g>
);

export const Monitor: React.FC<{x: number; y: number; w: number; h: number; children?: React.ReactNode}> = ({x, y, w, h, children}) => (
  <g transform={`translate(${x},${y})`}>
    <rect x={w / 2 - 14} y={h} width={28} height={40} fill={C.metal} {...ln} />
    <rect x={w / 2 - 60} y={h + 38} width={120} height={14} rx={7} fill={C.metal} {...ln} />
    <rect width={w} height={h} rx={14} fill="#0e1018" stroke="#3a3f55" strokeWidth={8} />
    {children}
  </g>
);

export const Shop: React.FC<{x: number; y: number; s?: number; color?: string}> = ({x, y, s = 1, color = C.teal}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x={-60} y={-40} width={120} height={90} fill="#2a2f45" {...ln} />
    <path d="M -70 -40 L 70 -40 L 58 -75 L -58 -75 Z" fill={color} {...ln} />
    <rect x={-18} y={0} width={36} height={50} fill="#0f1119" {...ln} />
  </g>
);

export const Depot: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M -110 60 L -110 -30 L -55 -60 L -55 -30 L 0 -60 L 0 -30 L 55 -60 L 55 -30 L 110 -60 L 110 60 Z" fill="#33384f" {...ln} />
    <rect x={-45} y={-5} width={90} height={65} fill="#0f1119" {...ln} />
    <rect x={-45} y={-5} width={90} height={14} fill={C.orange} />
  </g>
);

export const Bed: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g>
    <rect x={x - 10} y={y - 60} width={24} height={150} fill="#1a1d2b" {...ln} />
    <rect x={x} y={y + 60} width={560} height={30} fill="#1a1d2b" {...ln} />
    <rect x={x} y={y} width={560} height={60} rx={14} fill="#2b3350" {...ln} />
    <rect x={x + 12} y={y - 20} width={110} height={34} rx={14} fill="#3a4466" {...ln} />
  </g>
);

export const NoWalk: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x},${y})`}>
    <circle r={70} fill="#2a2f45" stroke={C.line} strokeWidth={5} />
    <ellipse cx={-20} cy={-8} rx={14} ry={24} fill={C.cream} />
    <ellipse cx={22} cy={12} rx={14} ry={24} fill={C.cream} />
    <circle r={70} fill="none" stroke={C.red} strokeWidth={10} />
    <line x1={-50} y1={50} x2={50} y2={-50} stroke={C.red} strokeWidth={10} />
  </g>
);
