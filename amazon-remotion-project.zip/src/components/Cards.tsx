import React from 'react';
import {C} from '../lib/theme';
import {fontFamily} from '../lib/font';
import {pop} from '../lib/anim';

export const Pop: React.FC<{f: number; delay?: number; cx: number; cy: number; children: React.ReactNode}> = ({f, delay = 0, cx, cy, children}) => {
  const p = pop(f, delay);
  return (
    <g opacity={Math.min(1, p * 2)} transform={`translate(${cx},${cy}) scale(${p}) translate(${-cx},${-cy})`}>
      {children}
    </g>
  );
};

export const T: React.FC<{x: number; y: number; size?: number; fill?: string; weight?: number; anchor?: 'start' | 'middle' | 'end'; children: React.ReactNode}> = ({x, y, size = 40, fill = C.white, weight = 600, anchor = 'middle', children}) => (
  <text x={x} y={y} fontSize={size} fill={fill} fontWeight={weight} textAnchor={anchor} fontFamily={fontFamily}>{children}</text>
);

export const Pin: React.FC<{x: number; y: number; w: number; h: number; rot?: number; color?: string; children?: React.ReactNode}> = ({x, y, w, h, rot = -3, color = '#f4d35e', children}) => (
  <g transform={`translate(${x},${y}) rotate(${rot})`}>
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={6} fill={color} stroke={C.line} strokeWidth={4} />
    <circle cx={0} cy={-h / 2 + 12} r={8} fill={C.red} stroke={C.line} strokeWidth={3} />
    {children}
  </g>
);

export const Stamp: React.FC<{x: number; y: number; rot?: number; color?: string; children: React.ReactNode}> = ({x, y, rot = -8, color = C.red, children}) => (
  <g transform={`translate(${x},${y}) rotate(${rot})`}>
    <rect x={-120} y={-36} width={240} height={72} rx={10} fill="none" stroke={color} strokeWidth={6} />
    <T x={0} y={14} size={40} weight={700} fill={color}>{children}</T>
  </g>
);

export const Arrow: React.FC<{x1: number; x2: number; y: number; p: number; color?: string}> = ({x1, x2, y, p, color = C.white}) => {
  const x = x1 + (x2 - x1) * p;
  return (
    <g stroke={color} strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" fill="none">
      <line x1={x1} y1={y} x2={x} y2={y} />
      {p > 0.9 && <path d={`M ${x2 - 22} ${y - 18} L ${x2} ${y} L ${x2 - 22} ${y + 18}`} />}
    </g>
  );
};

export const Check: React.FC<{x: number; y: number; r?: number}> = ({x, y, r = 46}) => (
  <g transform={`translate(${x},${y})`}>
    <circle r={r} fill={C.teal} stroke={C.line} strokeWidth={5} />
    <path d={`M ${-r * 0.45} 0 L ${-r * 0.1} ${r * 0.35} L ${r * 0.5} ${-r * 0.35}`} stroke="#fff" strokeWidth={9} fill="none" strokeLinecap="round" strokeLinejoin="round" />
  </g>
);
