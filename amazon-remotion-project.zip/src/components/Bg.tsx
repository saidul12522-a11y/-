import React from 'react';
import {C, H, W} from '../lib/theme';

export const Vignette: React.FC = () => (
  <>
    <defs>
      <radialGradient id="vg" cx="50%" cy="50%" r="75%">
        <stop offset="55%" stopColor="#000" stopOpacity={0} />
        <stop offset="100%" stopColor="#000" stopOpacity={0.6} />
      </radialGradient>
    </defs>
    <rect width={W} height={H} fill="url(#vg)" />
  </>
);

export const Glow: React.FC<{x: number; y: number; r?: number; o?: number}> = ({x, y, r = 420, o = 0.35}) => (
  <>
    <defs>
      <radialGradient id={`gl${x}${y}`}>
        <stop offset="0%" stopColor={C.glow} stopOpacity={o} />
        <stop offset="100%" stopColor={C.glow} stopOpacity={0} />
      </radialGradient>
    </defs>
    <circle cx={x} cy={y} r={r} fill={`url(#gl${x}${y})`} />
  </>
);

export const PlainBg: React.FC<{color?: string}> = ({color = C.bg}) => (
  <g><rect width={W} height={H} fill={color} /><Vignette /></g>
);

export const RoomBg: React.FC<{glow?: boolean}> = ({glow}) => (
  <g>
    <rect width={W} height={H} fill={C.wall} />
    <rect y={560} width={W} height={160} fill={C.floor} />
    <rect x={1000} y={70} width={150} height={170} rx={6} fill="#0f1220" stroke="#3a3f55" strokeWidth={6} />
    <line x1={1075} y1={70} x2={1075} y2={240} stroke="#3a3f55" strokeWidth={5} />
    <line x1={1000} y1={155} x2={1150} y2={155} stroke="#3a3f55" strokeWidth={5} />
    <circle cx={1110} cy={110} r={16} fill="#e8e6d0" opacity={0.8} />
    {glow && <Glow x={600} y={420} />}
    <Vignette />
  </g>
);

export const WarehouseBg: React.FC = () => (
  <g>
    <rect width={W} height={H} fill="#232634" />
    {Array.from({length: 8}).map((_, i) => (
      <g key={i}>
        <rect x={i * 170 + 20} y={200} width={140} height={340} fill="#1a1c28" stroke="#2c3042" strokeWidth={4} />
        {[1, 2, 3].map((r) => <line key={r} x1={i * 170 + 20} y1={200 + r * 85} x2={i * 170 + 160} y2={200 + r * 85} stroke="#2c3042" strokeWidth={4} />)}
      </g>
    ))}
    <rect y={540} width={W} height={180} fill="#14151d" />
    <rect y={640} width={W} height={8} fill="#6b5a1e" />
    {[200, 640, 1080].map((x) => (
      <g key={x}>
        <polygon points={`${x - 80},14 ${x + 80},14 ${x + 230},540 ${x - 230},540`} fill="#fff" opacity={0.05} />
        <rect x={x - 80} y={0} width={160} height={14} fill="#ffe9a8" />
      </g>
    ))}
    <Vignette />
  </g>
);
