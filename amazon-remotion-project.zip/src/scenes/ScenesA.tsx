import React, {FC} from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from '../lib/theme';
import {ease, fade, lerp} from '../lib/anim';
import {Stage} from '../components/Stage';
import {Glow, PlainBg, RoomBg, WarehouseBg} from '../components/Bg';
import {Char} from '../components/Char';
import {Bed, Box, Shelf, Shop, Kind} from '../components/Props';
import {Pin, Pop, T} from '../components/Cards';

type P = {d: number};

// S01 — "আপনি ভাবেন Amazon নিজেই সব জিনিস বিক্রি করে"
export const S01: FC<P> = ({d}) => {
  const f = useCurrentFrame();
  return (
    <Stage d={d} cam={{z0: 1, z1: 1.12, ox: 640, oy: 300}}>
      <RoomBg glow />
      <Bed x={330} y={470} />
      <Char x={600} y={548} pose="sit" expr={f > 90 ? 'think' : 'neutral'} />
      <Pop f={f} delay={12} cx={820} cy={170}>
        <circle cx={680} cy={270} r={13} fill="#fff" opacity={0.9} />
        <circle cx={655} cy={296} r={8} fill="#fff" opacity={0.9} />
        <ellipse cx={820} cy={170} rx={220} ry={105} fill="#f3f1e8" stroke={C.line} strokeWidth={5} />
        <Pop f={f} delay={28} cx={760} cy={205}><Box x={760} y={205} w={100} h={76} label="amazon" /></Pop>
        <Pop f={f} delay={38} cx={880} cy={205}><Box x={880} y={205} w={100} h={76} label="amazon" /></Pop>
        <Pop f={f} delay={48} cx={820} cy={130}><Box x={820} y={130} w={100} h={76} label="amazon" /></Pop>
      </Pop>
    </Stage>
  );
};

// S02 — "প্রতি দশটি জিনিসের ছয়টির মতো আসে অন্য বিক্রেতাদের কাছ থেকে"
export const S02: FC<P> = ({d}) => {
  const f = useCurrentFrame();
  return (
    <Stage d={d}>
      <PlainBg />
      {Array.from({length: 10}).map((_, i) => {
        const x = 640 + ((i % 5) - 2) * 170;
        const y = 230 + Math.floor(i / 5) * 170;
        const hot = i < 6 && f > 30 + i * 6;
        return (
          <Pop key={i} f={f} delay={i * 3} cx={x} cy={y}>
            <Box x={x} y={y} w={120} h={92} label="amazon" color={hot ? C.teal : C.cardboard} />
            {hot && <Shop x={x + 46} y={y - 50} s={0.32} color={C.orange} />}
          </Pop>
        );
      })}
      <Pop f={f} delay={62} cx={640} cy={580}>
        <Pin x={640} y={585} w={420} h={110}>
          <T x={0} y={14} size={56} fill="#222" weight={700}>১০টির ৬টি</T>
          <T x={0} y={46} size={24} fill="#5a4a10">অন্য বিক্রেতার</T>
        </Pin>
      </Pop>
    </Stage>
  );
};

// S03 — "বিক্রেতাদের কাছ থেকে। তাহলে Amazon নিজে কী করে?"
export const S03: FC<P> = ({d}) => {
  const f = useCurrentFrame();
  const shops = [260, 640, 1020];
  return (
    <Stage d={d}>
      <PlainBg />
      <g opacity={1 - fade(f, 44, 10)}>
        {shops.map((x, i) => {
          const t = Math.min(1, Math.max(0, (f - (14 + i * 8)) / 24));
          const bx = lerp(x, 640, t);
          const by = lerp(260, 500, t) - Math.sin(Math.PI * t) * 90;
          return (
            <g key={i}>
              <Pop f={f} delay={i * 6} cx={x} cy={200}><Shop x={x} y={200} s={1.1} /></Pop>
              {t > 0 && t < 1 && <Box x={bx} y={by} w={64} h={48} />}
            </g>
          );
        })}
        <Box x={640} y={540} w={170} h={120} label="amazon" />
      </g>
      <g opacity={fade(f, 50, 10)}>
        <Glow x={640} y={520} />
        <Char x={640} y={900} s={2} expr={f < 80 ? 'neutral' : 'think'} />
        <Pop f={f} delay={56} cx={640} cy={115}>
          <rect x={240} y={60} width={800} height={110} rx={24} fill={C.orange} stroke={C.line} strokeWidth={5} />
          <T x={640} y={135} size={54} weight={700}>Amazon নিজে কী করে?</T>
        </Pop>
      </g>
    </Stage>
  );
};

// S04 — "আসল কাজ লুকিয়ে আছে একটা গুদামে" (curtain reveal)
const G4: Kind[][] = [['b', 't', 'p'], ['t', 'b', 'b'], ['p', 'b', 't']];
export const S04: FC<P> = ({d}) => {
  const f = useCurrentFrame();
  const o = ease(f, 6, 34, 0, 1);
  return (
    <Stage d={d} cam={{z0: 1.18, z1: 1, ox: 640, oy: 360}}>
      <WarehouseBg />
      <Shelf x={150} y={150} w={420} rows={3} rowH={130} cols={3} grid={G4} />
      <Shelf x={720} y={150} w={420} rows={3} rowH={130} cols={3} grid={G4} />
      <polygon points="640,0 330,560 950,560" fill="#fff" opacity={0.08 * o} />
      <rect x={-640 * o} y={0} width={640} height={720} fill="#0b0c11" />
      <rect x={640 + 640 * o} y={0} width={640} height={720} fill="#0b0c11" />
    </Stage>
  );
};
