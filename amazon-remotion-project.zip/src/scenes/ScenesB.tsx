import React, {FC} from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from '../lib/theme';
import {ease, fade, lerp, pop} from '../lib/anim';
import {Stage} from '../components/Stage';
import {Glow, PlainBg, WarehouseBg} from '../components/Bg';
import {Char} from '../components/Char';
import {Bottle, Box, Hands, Kind, Monitor, NoWalk, Phone, Robot, Shelf, slotXY} from '../components/Props';
import {Check, Pop, Stamp, T} from '../components/Cards';

type P = {d: number};
const WORKER = {fill: C.greyBlue, hat: C.yellow};
const SELLER = {fill: C.grey, hat: C.blue};

// S05 — seller sends a water bottle to the warehouse
export const S05: FC<P> = ({d}) => {
  const f = useCurrentFrame();
  const sx = ease(f, 0, 60, 200, 470);
  const bx = 540 + Math.min(1, Math.max(0, (f - 60) / 66)) * 520;
  return (
    <Stage d={d} cam={{z0: 1, z1: 1.08, x0: 0, x1: -20}}>
      <WarehouseBg />
      <rect x={1040} y={300} width={180} height={260} fill="#0b0c10" stroke={C.line} strokeWidth={5} />
      <rect x={500} y={470} width={560} height={26} rx={13} fill={C.metal} stroke={C.line} strokeWidth={4} />
      {[540, 640, 740, 840, 940, 1020].map((x) => <circle key={x} cx={x} cy={500} r={10} fill="#3a3f55" />)}
      <Char x={sx} y={560} pose={f < 60 ? 'walk' : 'stand'} expr="happy" {...SELLER}
        held={f < 60 ? <g><Box x={0} y={0} w={80} h={60} /><Bottle x={0} y={-30} s={0.6} /></g> : null} />
      {f >= 60 && <g><Box x={bx} y={440} w={80} h={60} /><Bottle x={bx} y={410} s={0.6} /></g>}
      <Char x={900} y={620} flip {...WORKER} seed={2} />
    </Stage>
  );
};

// S06 — bottle goes into any empty slot
const G6: Kind[][] = [['b', 't', null, 'p', 'b'], ['t', null, null, 'b', 't'], ['p', 'b', 't', null, 'b']];
export const S06: FC<P> = ({d}) => {
  const f = useCurrentFrame();
  const {cx, cy} = slotXY(220, 80, 840, 170, 5, 1, 2);
  const drop = ease(f, 36, 62, -160, 0);
  const pulse = 0.5 + 0.5 * Math.sin(f / 4);
  return (
    <Stage d={d} cam={{z0: 1, z1: 1.15, ox: 640, oy: 300}}>
      <PlainBg />
      <Shelf x={220} y={80} w={840} rows={3} rowH={170} cols={5} grid={G6} />
      {[[0, 2], [1, 1], [2, 3]].map(([r, c]) => {
        const s = slotXY(220, 80, 840, 170, 5, r, c);
        return <rect key={`${r}${c}`} x={s.cx - 70} y={s.cy - 110} width={140} height={106} rx={10} fill="none" stroke={C.teal} strokeWidth={4} strokeDasharray="12 10" opacity={f > 14 ? 0.4 + 0.6 * pulse : 0} />;
      })}
      <Bottle x={cx} y={cy - 26 + drop} s={1} />
      {f > 64 && <rect x={cx - 70} y={cy - 110} width={140} height={106} rx={10} fill="none" stroke={C.teal} strokeWidth={6} />}
    </Stage>
  );
};

// S07 — computer remembers location; worker picks it easily
const G7: Kind[][] = [['b', 't', 'p', 'b'], ['t', 'b', 'x', 't'], ['p', 't', 'b', 'p']];
export const S07: FC<P> = ({d}) => {
  const f = useCurrentFrame();
  const wx = f < 140 ? 520 : ease(f, 140, 185, 520, 870);
  const pose = f < 140 ? 'stand' : f < 185 ? 'walk' : f < 205 ? 'point' : 'carry';
  const slot = slotXY(560, 150, 620, 130, 4, 1, 2);
  const pulse = 0.5 + 0.5 * Math.sin(f / 4);
  return (
    <Stage d={d} cam={{z0: 1, z1: 1.06}}>
      <PlainBg color="#1d1f2b" />
      <Pop f={f} delay={0} cx={265} cy={255}>
        <Monitor x={90} y={130} w={350} h={250}>
          {[0, 1, 2].map((r) => [0, 1, 2, 3].map((c) => (
            <rect key={`${r}${c}`} x={40 + c * 66} y={34 + r * 40} width={54} height={30} rx={5} fill={r === 1 && c === 2 ? C.teal : '#262b3d'} />
          )))}
          <T x={175} y={210} size={44} fill="#7CFFB2" weight={700}>B-14-07</T>
        </Monitor>
      </Pop>
      <Shelf x={560} y={150} w={620} rows={3} rowH={130} cols={4} grid={G7}
        show={(r, c) => (r === 1 && c === 2 ? (f >= 205 ? 0 : 1) : pop(f, 60 + (r * 4 + c) * 7))} />
      {f > 15 && f < 60 && <rect x={slot.cx - 66} y={slot.cy - 100} width={132} height={96} rx={10} fill="none" stroke="#7CFFB2" strokeWidth={5} opacity={0.4 + 0.6 * pulse} />}
      <Char x={wx} y={560} {...WORKER} pose={pose} expr={f > 215 ? 'happy' : 'neutral'}
        held={f >= 205 ? <Bottle x={0} y={-30} s={0.8} /> : null} />
      <Pop f={f} delay={215} cx={1120} cy={90}><Check x={1120} y={90} /></Pop>
    </Stage>
  );
};

// S08 — you place an order; robot pulls the shelf
const G8: Kind[][] = [['b', 't', 'p'], ['t', 'x', 'b'], ['p', 'b', 't']];
export const S08: FC<P> = ({d}) => {
  const f = useCurrentFrame();
  if (f < 62) {
    const tap = f < 44 ? ease(f, 22, 38, 0, 1) : ease(f, 44, 56, 1, 0.2);
    const press = f >= 38 && f < 46 ? 0.94 : 1;
    return (
      <Stage d={d} cam={{z0: 1, z1: 1.05}}>
        <PlainBg />
        <Glow x={640} y={360} o={0.25} />
        <Phone x={640} y={330} w={330} h={560}>
          <Bottle x={0} y={-70} s={2} />
          <g transform={`translate(0,172) scale(${press})`}>
            <rect x={-100} y={-32} width={200} height={64} rx={32} fill={C.orange} />
            <T x={0} y={12} size={34} weight={700}>Order</T>
          </g>
        </Phone>
        <Hands tap={tap} tx={660} ty={500} />
        <Pop f={f} delay={48} cx={640} cy={120}><Check x={640} y={120} r={52} /></Pop>
      </Stage>
    );
  }
  const g = f - 62;
  const cxS = g < 30 ? 640 : ease(g, 30, 46, 640, 780);
  const rx = g < 18 ? ease(g, 0, 18, 100, 640) : cxS;
  const lift = ease(g, 18, 26, 0, 14);
  return (
    <Stage d={d}>
      <WarehouseBg />
      <Shelf x={cxS - 100} y={520 - lift - 210} w={200} rows={3} rowH={70} cols={3} grid={G8} />
      <Robot x={rx} y={560} />
    </Stage>
  );
};
