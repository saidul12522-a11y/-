import React, {FC} from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from '../lib/theme';
import {ease, fade, lerp} from '../lib/anim';
import {Stage} from '../components/Stage';
import {PlainBg, WarehouseBg} from '../components/Bg';
import {Char} from '../components/Char';
import {Bottle, Box, Depot, Kind, NoWalk, Robot, Shelf, Shop, slotXY} from '../components/Props';
import {Arrow, Pop, Stamp, T} from '../components/Cards';

type P = {d: number};
const WORKER = {fill: C.greyBlue, hat: C.yellow};
const SELLER = {fill: C.grey, hat: C.blue};
const ln = {stroke: C.line, strokeWidth: 4} as const;

// S09 — robot arrives; worker picks the bottle; no walking needed
const G9: Kind[][] = [['b', 't', 'p'], ['t', 'x', 'b'], ['p', 'b', 't']];
export const S09: FC<P> = ({d}) => {
  const f = useCurrentFrame();
  const rx = ease(f, 0, 55, -100, 580);
  const sy = 526 - 300;
  const slot = slotXY(rx - 150, sy, 300, 100, 3, 1, 1);
  const k = ease(f, 95, 115, 0, 1);
  const pose = f < 70 ? 'stand' : f < 115 ? 'point' : 'carry';
  return (
    <Stage d={d} cam={{z0: 1, z1: 1.07}}>
      <WarehouseBg />
      <Shelf x={rx - 150} y={sy} w={300} rows={3} rowH={100} cols={3} grid={G9} show={(r, c) => (r === 1 && c === 1 && f >= 95 ? 0 : 1)} />
      <Robot x={rx} y={566} />
      {f >= 95 && f < 115 && <Bottle x={lerp(slot.cx, 674, k)} y={lerp(slot.cy - 16, 402, k)} s={lerp(0.59, 0.8, k)} />}
      <Char x={740} y={560} flip {...WORKER} pose={pose} expr={f > 125 ? 'happy' : 'neutral'}
        held={f >= 115 ? <Bottle x={0} y={-30} s={0.8} /> : null} />
      <Pop f={f} delay={125} cx={1040} cy={170}>
        <NoWalk x={1040} y={170} />
        <Stamp x={1040} y={290}>হাঁটা নয়</Stamp>
      </Pop>
    </Stage>
  );
};

// S10 — box, label, truck
export const S10: FC<P> = ({d}) => {
  const f = useCurrentFrame();
  const p1 = 1 - fade(f, 30, 6);
  const p2 = fade(f, 36, 6) * (1 - fade(f, 66, 6));
  const p3 = fade(f, 72, 6);
  const ph = f < 36 ? 0 : f < 72 ? 1 : 2;
  const bx2 = ease(f, 36, 72, 300, 980);
  const bx3 = ease(f, 72, 100, 360, 860);
  return (
    <Stage d={d}>
      <WarehouseBg />
      {[0, 1, 2].map((i) => <rect key={i} x={460 + i * 130} y={30} width={116} height={14} rx={7} fill={i <= ph ? C.orange : '#3a3f55'} />)}
      <g opacity={p1}>
        <Bottle x={640} y={ease(f, 0, 16, 230, 470)} />
        <rect x={530} y={405} width={220} height={130} fill={C.cardboard} {...ln} />
        <g transform={`translate(530,405) rotate(${ease(f, 14, 32, -100, 0)})`}><rect x={0} y={-14} width={110} height={14} fill="#b98550" {...ln} /></g>
        <g transform={`translate(750,405) rotate(${ease(f, 14, 32, 100, 0)})`}><rect x={-110} y={-14} width={110} height={14} fill="#b98550" {...ln} /></g>
      </g>
      <g opacity={p2}>
        <rect x={160} y={530} width={960} height={26} rx={13} fill={C.metal} {...ln} />
        <rect x={540} y={250} width={200} height={40} fill={C.metal} {...ln} />
        <rect x={548} y={290} width={16} height={240} fill={C.metal} {...ln} />
        <rect x={716} y={290} width={16} height={240} fill={C.metal} {...ln} />
        {f >= 54 && f < 58 && <rect x={632} y={290} width={16} height={190} fill="#fff" opacity={0.8} />}
        <Box x={bx2} y={480} w={150} h={100} />
        {f >= 56 && bx2 > 640 && <rect x={bx2 - 28} y={466} width={56} height={34} rx={4} fill="#fff" stroke={C.line} strokeWidth={3} />}
      </g>
      <g opacity={p3}>
        <rect x={160} y={530} width={560} height={26} rx={13} fill={C.metal} {...ln} />
        <rect x={700} y={270} width={380} height={260} rx={10} fill="#0b0c10" {...ln} />
        <Box x={bx3} y={480} w={150} h={100} />
        <rect x={1080} y={380} width={120} height={150} rx={14} fill="#d9d4c4" {...ln} />
        <rect x={700} y={500} width={500} height={34} fill="#d9d4c4" {...ln} />
        {[780, 1000, 1150].map((x) => <circle key={x} cx={x} cy={545} r={30} fill="#1a1c28" {...ln} />)}
      </g>
    </Stage>
  );
};

// S11 — seller → Amazon warehouse → you
export const S11: FC<P> = ({d}) => {
  const f = useCurrentFrame();
  const label = (txt: string, x: number, y: number, at: number) => (
    <Pop f={f} delay={at} cx={x} cy={y}>
      <rect x={x - 100} y={y - 34} width={200} height={54} rx={27} fill={C.orange} {...ln} />
      <T x={x} y={y + 5} size={32} weight={700}>{txt}</T>
    </Pop>
  );
  return (
    <Stage d={d}>
      <PlainBg />
      <Pop f={f} delay={15} cx={210} cy={330}><Char x={210} y={440} s={0.55} {...SELLER} expr="happy" /></Pop>
      <Pop f={f} delay={60} cx={640} cy={330}><Depot x={640} y={330} s={1.5} /></Pop>
      <Pop f={f} delay={135} cx={1070} cy={330}><Char x={1070} y={440} s={0.55} expr="happy" /></Pop>
      <Arrow x1={310} x2={500} y={330} p={ease(f, 30, 55, 0, 1)} />
      <Arrow x1={780} x2={970} y={330} p={ease(f, 125, 150, 0, 1)} />
      <T x={210} y={520} size={40}>বিক্রেতা</T>
      <T x={640} y={520} size={40}>Amazon</T>
      <T x={1070} y={520} size={40}>ক্রেতা</T>
      {label('জিনিস দেন', 405, 270, 40)}
      {label('রাখে', 640, 190, 85)}
      {label('খুঁজে', 640, 120, 105)}
      {label('পৌঁছে দেয়', 875, 270, 125)}
    </Stage>
  );
};

// S12 — shop is someone else's, only the warehouse is Amazon's
export const S12: FC<P> = ({d}) => {
  const f = useCurrentFrame();
  const t = ((f - 20) / 50) % 1;
  return (
    <Stage d={d}>
      <rect width={640} height={720} fill="#1c2030" />
      <rect x={640} width={640} height={720} fill="#1d2a2a" />
      <rect x={638} width={4} height={720} fill="#0b0c10" />
      <Pop f={f} delay={0} cx={320} cy={300}><Shop x={320} y={300} s={1.7} /></Pop>
      <Char x={480} y={620} s={0.85} {...SELLER} expr="happy" />
      <Pop f={f} delay={55} cx={960} cy={300}><Depot x={960} y={300} s={1.7} /></Pop>
      <Pop f={f} delay={5} cx={320} cy={120}><T x={320} y={130} size={46} weight={700}>অন্যের দোকান</T></Pop>
      <Pop f={f} delay={55} cx={960} cy={120}>
        <rect x={700} y={78} width={520} height={74} rx={20} fill="none" stroke={C.orange} strokeWidth={6} />
        <T x={960} y={130} size={46} weight={700} fill={C.orange}>Amazonের গুদাম</T>
      </Pop>
      <line x1={240} y1={520} x2={900} y2={520} stroke="#8d93a8" strokeWidth={6} strokeDasharray="14 12" />
      {f > 20 && <Box x={lerp(240, 900, Math.max(0, t))} y={490} w={70} h={52} />}
    </Stage>
  );
};

// S13 — like / comment / subscribe
export const S13: FC<P> = ({d}) => {
  const f = useCurrentFrame();
  const pulse = (at: number) => 1 + (f > at + 20 ? 0.05 * Math.sin((f - at) / 6) : 0);
  const item = (x: number, at: number, label: string, icon: React.ReactNode) => (
    <Pop f={f} delay={at} cx={x} cy={330}>
      <g transform={`translate(${x},330) scale(${pulse(at)})`}>
        <circle r={110} fill="#262b3d" stroke={C.line} strokeWidth={6} />
        {icon}
      </g>
      <T x={x} y={510} size={46} weight={700} fill={C.yellow}>{label}</T>
    </Pop>
  );
  return (
    <Stage d={d}>
      <PlainBg />
      {item(330, 10, 'লাইক',
        <g><rect x={-46} y={-8} width={34} height={60} rx={6} fill="#fff" {...ln} /><path d="M -10 -8 L 8 -58 Q 34 -58 28 -24 L 24 -8 L 52 -8 Q 62 -4 56 10 L 48 48 Q 44 54 36 54 L -10 54 Z" fill="#fff" {...ln} /></g>)}
      {item(640, 45, 'কমেন্ট',
        <g><rect x={-60} y={-48} width={120} height={80} rx={20} fill="#fff" {...ln} /><path d="M -20 30 L -34 62 L 10 30 Z" fill="#fff" {...ln} /><circle cx={-26} cy={-8} r={7} fill={C.line} /><circle cx={0} cy={-8} r={7} fill={C.line} /><circle cx={26} cy={-8} r={7} fill={C.line} /></g>)}
      {item(950, 85, 'সাবস্ক্রাইব',
        <g><path d="M -44 32 Q -44 -40 0 -46 Q 44 -40 44 32 Z" fill={C.yellow} {...ln} /><rect x={-54} y={30} width={108} height={12} rx={6} fill={C.yellow} {...ln} /><circle cx={0} cy={58} r={11} fill={C.red} {...ln} /></g>)}
      <Char x={1130} y={700} s={0.7} pose="thumbs" expr="happy" />
    </Stage>
  );
};
