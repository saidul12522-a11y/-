# Amazon Warehouse Video (Remotion)
- Composition: `AmazonVideo` — 1280x720, 30fps, 1774 frames (59.135s)
- Audio: public/audio/Amazon-sul.m4a  | SRT: public/srt/Amazon-sul_ben.srt
- Timing: src/lib/timing.ts (SCENE_FRAMES, CUES)
- Scenes: src/scenes/ScenesA|B|C.tsx (S01–S13)

npm install
npx remotion studio
npx remotion render src/index.ts AmazonVideo out/amazon.mp4
