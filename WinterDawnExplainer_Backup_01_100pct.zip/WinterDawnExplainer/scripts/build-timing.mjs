// Reads public/subtitles/original.srt -> writes corrected.srt, src/timing.json, src/corrections.json
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const seg = new Intl.Segmenter("bn", { granularity: "grapheme" });
const glen = (s) => [...seg.segment(s)].length;
const toBn = (s) => s.replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[d]);
const tc = (h, m, s, ms) => +h * 3600 + +m * 60 + +s + +ms.padEnd(3, "0") / 1000;
const fmt = (t) => {
  const ms = Math.round(t * 1000);
  const p = (n, l = 2) => String(n).padStart(l, "0");
  return `${p(Math.floor(ms / 3600000))}:${p(Math.floor(ms / 60000) % 60)}:${p(Math.floor(ms / 1000) % 60)},${p(ms % 1000, 3)}`;
};
const raw = fs.readFileSync(path.join(root, "public/subtitles/original.srt"), "utf8").replace(/^﻿/, "").replace(/\r/g, "").trim();
// The file has a quirk: blank lines appear between wrapped lines. Rebuild cues from the "-->" lines.
const lines = raw.split("\n").map((l) => l.trim());
const cues = [];
for (let i = 0; i < lines.length; i++) {
  const m = lines[i].match(/(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) continue;
  let j = i + 1, text = [];
  while (j < lines.length && !/-->/.test(lines[j]) ) {
    // stop when a bare cue number is followed by a timing line
    if (/^\d+$/.test(lines[j]) && j + 1 < lines.length && /-->/.test(lines[j + 1])) break;
    if (lines[j]) text.push(lines[j]);
    j++;
  }
  cues.push({ s: tc(m[1], m[2], m[3], m[4]), e: tc(m[5], m[6], m[7], m[8]), text: text.join(" ").replace(/\s+/g, " ").trim() });
}
// --- corrections (tier A only) ---
const log = [];
const fixed = cues.map((c, k) => {
  let t = c.text;
  const before = t;
  t = t.replace("ধরুনশীতের", "ধরুন শীতের");
  if (t !== before) log.push({ cue: k + 1, time: fmt(c.s), before: "ধরুনশীতের", after: "ধরুন শীতের", evidence: "missing space between two words", tier: "A" });
  const b2 = t;
  t = toBn(t);
  if (t !== b2) log.push({ cue: k + 1, time: fmt(c.s), before: b2.match(/\d+/g).join(", "), after: t.match(/[০-৯]+/g).join(", "), evidence: "voiceover is Bengali; digits unified to Bengali numerals", tier: "A" });
  return { ...c, text: t };
});
const suspects = [
  { time: "00:03:13", text: "'কোন কোন ব্যাখ্যাকার' - possibly 'কোনো কোনো'? Left unchanged (needs audio confirmation)" },
  { time: "00:01:40", text: "'ঘন্টা' - Bangla Academy spelling is 'ঘণ্টা'; left as in SRT" },
];
// --- words (distributed by grapheme inside each cue; no ASR available offline) ---
const words = [];
for (const c of fixed) {
  const ws = c.text.split(" ").filter(Boolean);
  const total = ws.reduce((a, w) => a + glen(w), 0) || 1;
  let t = c.s;
  for (const w of ws) { const d = ((c.e - c.s) * glen(w)) / total; words.push({ w, s: +t.toFixed(3), e: +(t + d).toFixed(3) }); t += d; }
}
fs.writeFileSync(path.join(root, "public/subtitles/corrected.srt"), fixed.map((c, i) => `${i + 1}\n${fmt(c.s)} --> ${fmt(c.e)}\n${c.text}\n`).join("\n"));
fs.writeFileSync(path.join(root, "src/timing.json"), JSON.stringify({ audioSeconds: 234.031, mode: "srt-only", cues: fixed, words }, null, 1));
fs.writeFileSync(path.join(root, "src/corrections.json"), JSON.stringify({ corrections: log, suspects }, null, 1));
console.log("cues", cues.length, "words", words.length, "corrections", log.length, "last", fmt(cues.at(-1).e));
