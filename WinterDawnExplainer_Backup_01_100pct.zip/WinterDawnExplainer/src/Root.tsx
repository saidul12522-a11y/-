import React from "react";
import { Composition } from "remotion";
import { Video } from "./Video";
import { FPS, L, TOTAL_FRAMES } from "./layout";

export const RemotionRoot: React.FC = () => (
  <Composition id="WinterDawn" component={Video} durationInFrames={TOTAL_FRAMES} fps={FPS} width={L.w} height={L.h} />
);
