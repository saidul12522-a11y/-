// 16:9 preset (1920x1080). 9:16 preset is kept for future videos.
export const RATIOS = {
  "16:9": { w: 1920, h: 1080, margin: 100, stage: { top: 160, bottom: 850 }, caption: { y: 940, font: 54, pillH: 100 }, reserveFrom: 1000, k: 0.7 },
  "9:16": { w: 1080, h: 1920, margin: 70, stage: { top: 280, bottom: 1300 }, caption: { y: 1398, font: 62, pillH: 115 }, reserveFrom: 1500, k: 1 },
} as const;
export const RATIO = "16:9" as const;
export const L = RATIOS[RATIO];
export const FPS = 30;
export const AUDIO_SECONDS = 234.031;
export const HOLD_SECONDS = 1.0;
export const TOTAL_FRAMES = Math.ceil((AUDIO_SECONDS + HOLD_SECONDS) * FPS);
