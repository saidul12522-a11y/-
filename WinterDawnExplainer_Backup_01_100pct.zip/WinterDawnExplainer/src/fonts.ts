import { loadFont } from "@remotion/google-fonts/HindSiliguri";

// Hind Siliguri is downloaded by Remotion on first run (internet needed once on your PC).
const { fontFamily } = loadFont("normal", { weights: ["600", "700"], subsets: ["bengali", "latin"] });
export const FONT = `${fontFamily}, "Hind Siliguri", "Noto Sans Bengali", sans-serif`;
