import React from "react";
import { SceneHook, SceneDawn, SceneHadith } from "./scenes/s1";
import { SceneDeeds, SceneNotHardship } from "./scenes/s2";
import { SceneDayNight, SceneFastHours, SceneExample, SceneSources } from "./scenes/s3";
import { SceneNight, SceneJahannam, SceneScience } from "./scenes/s4";
import { SceneRecap, SceneClosing, SceneOutro } from "./scenes/s5";

export type SceneDef = { id: string; title: string; start: number; end: number; C: React.FC<{ t: number }> };

/**
 * Storyboard (times in seconds, from the SRT / voiceover):
 * 01 hook        cold wudu, shaking hands, gift "?"
 * 02 dawn        bed -> adhan -> wake -> ice-cold tap
 * 03 hadith      Sahih Muslim book, sins erased, rank rises, first deed = full wudu
 * 04 deeds       3 cards (wudu, steps to mosque, waiting) -> ribat tower -> answer
 * 05 notHardship obey when heart refuses / don't seek hardship / fingertips only
 * 06 dayNight    day/night ring; "cold ghanimah" chest vs swords
 * 07 fastHours   14 vs 11 hour blocks, 3 less, less thirst
 * 08 example     voluntary fast: summer vs winter + balance scale
 * 09 sources     Tirmidhi/Ahmad, grading dispute, lunar Ramadan wheel
 * 10 night       long night, late-night prayer, blanket (not hadith)
 * 11 jahannam    two breaths, zamharir, many interpretations
 * 12 science     axial tilt + multiple causes
 * 13 recap       three cards
 * 14 closing     yearly winter, blanket bargain, good news, adhan -> lift a corner
 * 15 outro       logo, like, comment, subscribe
 */
export const SCENES: SceneDef[] = [
  { id: "hook", title: "Hook", start: 0, end: 10.4, C: SceneHook },
  { id: "dawn", title: "Dawn", start: 10.4, end: 30.0, C: SceneDawn },
  { id: "hadith", title: "Hadith", start: 30.0, end: 44.6, C: SceneHadith },
  { id: "deeds", title: "Three deeds", start: 44.6, end: 70.4, C: SceneDeeds },
  { id: "notHardship", title: "Not seeking hardship", start: 70.4, end: 84.0, C: SceneNotHardship },
  { id: "dayNight", title: "Day and night", start: 84.0, end: 100.3, C: SceneDayNight },
  { id: "fastHours", title: "Fasting hours", start: 100.3, end: 118.4, C: SceneFastHours },
  { id: "example", title: "Summer vs winter", start: 118.4, end: 127.6, C: SceneExample },
  { id: "sources", title: "Sources", start: 127.6, end: 150.0, C: SceneSources },
  { id: "night", title: "Night", start: 150.0, end: 163.2, C: SceneNight },
  { id: "jahannam", title: "Source of cold", start: 163.2, end: 189.5, C: SceneJahannam },
  { id: "science", title: "Science", start: 189.5, end: 197.5, C: SceneScience },
  { id: "recap", title: "Recap", start: 197.5, end: 215.2, C: SceneRecap },
  { id: "closing", title: "Closing", start: 215.2, end: 227.3, C: SceneClosing },
  { id: "outro", title: "Outro", start: 227.3, end: 236, C: SceneOutro },
];
