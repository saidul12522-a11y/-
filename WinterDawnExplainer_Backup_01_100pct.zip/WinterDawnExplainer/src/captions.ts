import timing from "./timing.json";

export type Word = { w: string; s: number; e: number };
export type Chunk = { words: Word[]; start: number; end: number };

const seg = new Intl.Segmenter("bn", { granularity: "grapheme" });
export const glen = (s: string) => [...seg.segment(s)].length;

export function chunkWords(words: Word[], maxWords = 3, maxChars = 24, gap = 0.45): Chunk[] {
  const chunks: Word[][] = [];
  let cur: Word[] = [];
  const flush = () => { if (cur.length) { chunks.push(cur); cur = []; } };
  for (const w of words) {
    const chars = glen([...cur, w].map((x) => x.w).join(" "));
    if (cur.length && (cur.length >= maxWords || chars > maxChars)) flush();
    if (cur.length && w.s - cur[cur.length - 1].e > gap) flush();
    cur.push(w);
    if (/[।,?!;:—]$/.test(w.w)) flush();
  }
  flush();
  return chunks.map((c) => ({ words: c, start: c[0].s, end: c[c.length - 1].e }));
}

export const CHUNKS: Chunk[] = chunkWords(timing.words as Word[]);

export function captionState(t: number, hold = 0.35) {
  for (let i = 0; i < CHUNKS.length; i++) {
    const c = CHUNKS[i], next = CHUNKS[i + 1];
    const until = next ? Math.min(next.start, c.end + hold) : c.end + hold;
    if (t >= c.start - 0.02 && t < until) {
      let active = -1;
      c.words.forEach((w, k) => { if (t >= w.s) active = k; });
      return { chunk: c, active };
    }
  }
  return null;
}

/** start time (s) of the first word in the SRT whose text contains `needle`, at or after `after`. */
export function wordTime(needle: string, after = 0): number {
  const w = (timing.words as Word[]).find((x) => x.s >= after - 0.001 && x.w.includes(needle));
  if (!w) throw new Error("word not found: " + needle);
  return w.s;
}
