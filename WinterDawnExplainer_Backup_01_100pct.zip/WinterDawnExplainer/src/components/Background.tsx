import React from "react";
import { AbsoluteFill } from "remotion";
import { theme as C } from "../theme";
import { L } from "../layout";

export const Background: React.FC = () => (
  <AbsoluteFill style={{ background: C.bg }}>
    <svg width={L.w} height={L.h} viewBox="0 0 1920 1080">
      <defs>
        <pattern id="dots" width="48" height="48" patternUnits="userSpaceOnUse">
          <circle cx="24" cy="24" r="2.2" fill="rgba(43,108,176,0.16)" />
        </pattern>
        <radialGradient id="glow" cx="50%" cy="42%" r="60%">
          <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.9" />
          <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="1920" height="1080" fill="url(#dots)" />
      <rect width="1920" height="1080" fill="url(#glow)" />
    </svg>
  </AbsoluteFill>
);
