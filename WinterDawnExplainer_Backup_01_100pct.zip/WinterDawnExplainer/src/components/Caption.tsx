import React from "react";
import { useCurrentFrame, interpolate } from "remotion";
import { theme as C } from "../theme";
import { FONT } from "../fonts";
import { FPS, L } from "../layout";
import { captionState } from "../captions";

export const Caption: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  const st = captionState(t);
  if (!st) return null;
  const enter = interpolate(t - st.chunk.start, [0, 0.12], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <div style={{ position: "absolute", left: 0, right: 0, top: L.caption.y, transform: `translateY(-50%) translateY(${(1 - enter) * 10}px)`, display: "flex", justifyContent: "center", opacity: enter }}>
      <div style={{ display: "flex", gap: 10, padding: "0 28px", height: L.caption.pillH, alignItems: "center", borderRadius: 52, background: C.surface, border: `2px solid ${C.border}`, boxShadow: "0 8px 24px rgba(16,35,58,0.14)", fontFamily: FONT, fontWeight: 700, fontSize: L.caption.font, lineHeight: 1.15, maxWidth: 1400 }}>
        {st.chunk.words.map((w, k) => {
          const on = k === st.active, done = k < st.active;
          return (
            <span key={k} style={{ padding: "4px 16px", borderRadius: 20, background: on ? C.accent : "transparent", color: on ? C.onAccent : done ? C.text : C.muted, opacity: on || done ? 1 : 0.65, whiteSpace: "nowrap" }}>
              {w.w}
            </span>
          );
        })}
      </div>
    </div>
  );
};
