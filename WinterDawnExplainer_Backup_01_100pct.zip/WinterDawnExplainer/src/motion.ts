import { Easing, interpolate, spring } from "remotion";
import { FPS } from "./layout";

export const SPRING = {
  pop: { damping: 11, stiffness: 170, mass: 0.8 },
  soft: { damping: 20, stiffness: 120, mass: 1.0 },
  snap: { damping: 14, stiffness: 260, mass: 0.6 },
};
export const SMOOTH = Easing.bezier(0.22, 1, 0.36, 1);
export const INOUT = Easing.bezier(0.65, 0, 0.35, 1);

/** 0..1 progress between absolute seconds a and b (clamped). */
export const prog = (t: number, a: number, b: number, easing: (x: number) => number = SMOOTH) =>
  interpolate(t, [a, b], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing });

/** spring 0->1 starting at cue (seconds). */
export const pop = (t: number, cue: number, cfg: keyof typeof SPRING = "pop") =>
  t < cue ? 0 : spring({ frame: Math.round((t - cue) * FPS), fps: FPS, config: SPRING[cfg] });

/** value is 1 between a and b with 0.3s fades. */
export const window = (t: number, a: number, b: number, fade = 0.3) =>
  Math.min(prog(t, a, a + fade), 1 - prog(t, b - fade, b));

/** deterministic pseudo-random 0..1 from an integer */
export const hash = (i: number) => {
  const x = Math.sin(i * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};
export const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
export const cl = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
