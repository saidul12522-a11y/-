import React from "react";
import { AbsoluteFill, Audio, Img, staticFile, useCurrentFrame } from "remotion";
import { Background } from "./components/Background";
import { Caption } from "./components/Caption";
import { SCENES } from "./sceneList";
import { FPS } from "./layout";
import { prog } from "./motion";

const FADE = 0.4;

export const Video: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const logoOp = t < 227.3 ? Math.min(1, prog(t, 0.5, 1.0)) : 0;
  return (
    <AbsoluteFill>
      <Background />
      {SCENES.map((s, i) => {
        // a scene is visible from its start until the next scene has fully faded in
        const next = SCENES[i + 1];
        const visible = t >= s.start && t < (next ? next.start + FADE : s.end);
        if (!visible) return null;
        const inOp = i === 0 ? 1 : prog(t, s.start, s.start + FADE);
        return (
          <AbsoluteFill key={s.id} style={{ opacity: inOp }}>
            <s.C t={t} />
          </AbsoluteFill>
        );
      })}
      <div style={{ position: "absolute", right: 56, top: 28, width: 96, height: 96, borderRadius: 22, background: "#fff", border: "2px solid rgba(16,35,58,0.14)", overflow: "hidden", opacity: logoOp, boxShadow: "0 6px 18px rgba(16,35,58,0.12)" }}>
        <Img src={staticFile("logo.jpg")} style={{ width: "100%", height: "100%", objectFit: "contain" }} />
      </div>
      <Caption />
      <Audio src={staticFile("voice.mp3")} />
    </AbsoluteFill>
  );
};
