import React from "react";
import { AbsoluteFill } from "remotion";
import { L } from "../layout";
import { FONT } from "../fonts";

export type SceneProps = { t: number };
export const Svg: React.FC<{ children?: React.ReactNode }> = ({ children }) => (
  <AbsoluteFill>
    <svg width={L.w} height={L.h} viewBox="0 0 1920 1080" style={{ fontFamily: FONT }}>{children}</svg>
  </AbsoluteFill>
);
export const GROUND = 790;
