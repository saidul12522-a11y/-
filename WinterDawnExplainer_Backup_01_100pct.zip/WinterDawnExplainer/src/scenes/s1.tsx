import React from "react";
import { FONT } from "../fonts";
import { theme as C } from "../theme";
import { Svg, SceneProps, GROUND } from "./common";
import { In, Chip, Ring, Ground, Label } from "../components/kit";
import { Person, Tap, SnowField, Thermo, Gift, Snowflake, Drop, Mosque, Bed, Cloud, Book } from "../art/art";
import { prog, pop, lerp, INOUT } from "../motion";

/** 0.0-10.4  Hook: cold wudu, shaking hands, "what is the reward?" */
export const SceneHook: React.FC<SceneProps> = ({ t }) => {
  const q = 0.5 + 0.5 * Math.sin(t * 6);
  return (
    <Svg>
      <Ground y={GROUND} />
      <SnowField t={t} n={16} />
      <In t={t} cue={0.3}><Thermo x={330} y={GROUND - 60} level={0.12} /></In>
      <In t={t} cue={1.2}><Chip x={330} y={GROUND + 30} text="ঠান্ডা পানি" color={C.flow} /></In>
      <In t={t} cue={0.6} dy={80}>
        <Tap x={860} y={GROUND} t={t} />
        <Person x={640} y={GROUND} pose="wash" t={t} shiver={t > 3.5 && t < 6} cloth={C.cloth} />
      </In>
      <In t={t} cue={3.5}><Chip x={640} y={GROUND - 390} text="হাত কাঁপে" color={C.bad} /></In>
      <In t={t} cue={4.4}><Chip x={900} y={GROUND - 470} text="দাঁত কাঁপে" color={C.bad} /></In>
      <In t={t} cue={5.3} dx={160} dy={0} ox={1400} oy={GROUND}>
        <Gift x={1420} y={GROUND} s={1.5} />
      </In>
      <In t={t} cue={7.4}><Chip x={1420} y={GROUND - 290} text="পুরস্কার" color={C.accent} size={36} /></In>
      <In t={t} cue={9.1} s0={0.4}>
        <text x={1420} y={GROUND - 340 + q * -8} textAnchor="middle" fontSize={150} fontWeight={700} fill={C.accent} fontFamily={FONT} stroke={C.text} strokeWidth={4}>?</text>
      </In>
      <Ring x={1420} y={GROUND - 120} t={t} cue={7.4} r={110} loop />
    </Svg>
  );
};

/** 10.4-30.0  Imagine a winter dawn: bed, adhan, wake up, cold tap */
export const SceneDawn: React.FC<SceneProps> = ({ t }) => {
  const sunP = prog(t, 14.7, 22, INOUT);
  const sunY = lerp(GROUND + 60, GROUND - 150, sunP);
  const wake = t >= 24.1;
  const walkP = prog(t, 24.1, 25.6, INOUT);
  const px = lerp(430, 1010, walkP);
  const arrived = walkP >= 1;
  const sky = prog(t, 12, 22);
  return (
    <Svg>
      <rect x={0} y={150} width={1920} height={GROUND - 150} fill={C.tint} opacity={0.5 + 0.3 * sky} />
      <In t={t} cue={14.7} dy={0} spring={false}>
        <g opacity={0.9}><circle cx={760} cy={sunY} r={120} fill={C.gold} opacity={0.35} /><circle cx={760} cy={sunY} r={84} fill={C.warn} opacity={0.8} /></g>
      </In>
      <ellipse cx={700} cy={GROUND + 60} rx={820} ry={170} fill="#CFE0F2" />
      <ellipse cx={1350} cy={GROUND + 80} rx={760} ry={140} fill="#C3D7EC" />
      <Ground y={GROUND} />
      <In t={t} cue={10.8}><Cloud x={420} y={260} s={1.2} /><Cloud x={1500} y={230} s={1} /></In>
      <In t={t} cue={16.1} dy={70}>
        <Bed x={360} y={GROUND} s={1.25} asleep={!wake} blanketUp={wake ? 0.2 : 0} t={t} />
      </In>
      <In t={t} cue={16.6}><Chip x={360} y={GROUND + 50} text="কম্বলের নিচে" color={C.data} /></In>
      <In t={t} cue={17.7} dy={70} ox={1650} oy={GROUND}>
        <Mosque x={1650} y={GROUND} s={1.05} t={t} />
      </In>
      {t >= 17.7 && [0, 1, 2].map((i) => {
        const p = ((t - 17.7) * 0.8 + i / 3) % 1;
        return <path key={i} d={`M ${1440 - p * 150} ${520 - 60 - p * 40} Q ${1400 - p * 150} 520 ${1440 - p * 150} ${520 + 60 + p * 40}`} stroke={C.accent} strokeWidth={6} fill="none" strokeLinecap="round" opacity={(1 - p) * 0.9} />;
      })}
      <In t={t} cue={17.9}><Chip x={1470} y={GROUND - 450} text="আজান" color={C.accent} /></In>
      {!wake && <>
        <In t={t} cue={19.9}><Chip x={250} y={GROUND - 380} text="ওঠো" color={C.good} /></In>
        <In t={t} cue={21.9}><Chip x={470} y={GROUND - 430} text="কাল থেকে" color={C.warn} /></In>
      </>}
      {wake && <Tap x={1100} y={GROUND} t={t} flowing={arrived} />}
      {wake && <Person x={px} y={GROUND} pose={arrived ? "wash" : "walk"} t={t} bob={!arrived} />}
      <In t={t} cue={26.1}><Chip x={1000} y={GROUND - 400} text="প্রথম ফোঁটা" color={C.flow} /></In>
      {t >= 26.6 && t < 28.7 && <Drop x={1154} y={lerp(GROUND - 360, GROUND - 190, prog(t, 26.6, 28.4))} r={12} />}
      {t >= 28.4 && (
        <g>
          <Ring x={1110} y={GROUND - 170} t={t} cue={28.4} r={40} color={C.flow} />
          <In t={t} cue={28.7} s0={0.3}><Snowflake x={1090} y={GROUND - 190} r={46} rot={t * 30} /></In>
        </g>
      )}
      <In t={t} cue={28.7}><Chip x={1100} y={GROUND - 520} text="হাতে বরফ" color={C.flow} /></In>
    </Svg>
  );
};

/** 30.0-44.6  Hadith question; first deed */
export const SceneHadith: React.FC<SceneProps> = ({ t }) => {
  const phaseA = 1 - prog(t, 39.9, 40.2);
  const sweep = prog(t, 37.7, 38.6);
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={30.2} dy={70}><Book x={380} y={500} s={1.6} color={C.good} /></In>
      <In t={t} cue={30.6}><Chip x={380} y={690} text="সহিহ মুসলিম" color={C.good} /></In>
      {t < 40.2 && (
        <g opacity={phaseA}>
          <In t={t} cue={35.3}>
            <Label x={1100} y={250} text="এমন কাজ কি আছে?" size={34} color={C.muted} />
          </In>
          {[0, 1, 2].map((i) => (
            <g key={i} opacity={1 - sweep}>
              <In t={t} cue={37.1 + i * 0.12}>
                <Chip x={1000 + i * 0} y={380 + i * 85} text="গুনাহ" color={C.muted} fill={C.tint} />
              </In>
            </g>
          ))}
          {t >= 37.7 && <rect x={800 + sweep * 420} y={340} width={36} height={300} rx={18} fill={C.accent} opacity={0.85 * (1 - prog(t, 38.5, 38.9))} />}
          <In t={t} cue={38.1}><Chip x={1000} y={690} text="গুনাহ মুছে দেন" color={C.good} /></In>
          {[0, 1, 2, 3].map((i) => (
            <In key={i} t={t} cue={38.8 + i * 0.15} dy={30}>
              <rect x={1380 + i * 110} y={640 - i * 90} width={110} height={90 + i * 90} fill={C.tint} stroke={C.text} strokeWidth={4} />
            </In>
          ))}
          <In t={t} cue={38.8}><Chip x={1560} y={250} text="মর্যাদা বাড়ান" color={C.accent} /></In>
          <In t={t} cue={39.1}><Person x={1480 + prog(t, 39.1, 39.9) * 220} y={640 - prog(t, 39.1, 39.9) * 270 + 0} s={0.5} pose="up" cloth={C.cloth2} /></In>
        </g>
      )}
      {t >= 40.2 && (
        <g>
          <In t={t} cue={40.4} dy={50}>
            <circle cx={1010} cy={300} r={56} fill={C.accent} stroke={C.text} strokeWidth={4} />
            <text x={1010} y={322} textAnchor="middle" fontSize={64} fontWeight={700} fontFamily={FONT} fill={C.onAccent}>১</text>
          </In>
          <In t={t} cue={40.9}><Label x={1180} y={304} text="প্রথম কাজ" size={36} color={C.text} anchor="start" /></In>
          <SnowField t={t} n={8} x0={800} x1={1800} y0={200} y1={780} op={0.55} />
          <In t={t} cue={41.7} dy={60}>
            <Tap x={1420} y={GROUND} t={t} />
            <Person x={1220} y={GROUND} pose="wash" t={t} shiver cloth={C.cloth} />
          </In>
          <In t={t} cue={42.4}><Chip x={1330} y={GROUND - 440} text="কষ্ট সত্ত্বেও" color={C.flow} /></In>
          <In t={t} cue={43.2}><Chip x={1330} y={GROUND + 40} text="পূর্ণভাবে ওজু" color={C.good} size={34} /></In>
        </g>
      )}
    </Svg>
  );
};

