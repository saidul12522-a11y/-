import React from "react";
import { FONT } from "../fonts";
import { theme as C } from "../theme";
import { Svg, SceneProps, GROUND } from "./common";
import { In, Chip, Ring, Ground, Label, Card, Check, Cross } from "../components/kit";
import { Person, Tap, SnowField, Snowflake, Footprint, Tower, Star, Hand, Mosque } from "../art/art";
import { prog, pop, lerp, INOUT, hash } from "../motion";

const CX = [90, 690, 1290]; // 3 cards, 540 wide

const Clock: React.FC<{ x: number; y: number; t: number; r?: number }> = ({ x, y, t, r = 80 }) => (
  <g transform={`translate(${x} ${y})`}>
    <circle r={r} fill="#fff" stroke={C.text} strokeWidth={5} />
    {[0, 90, 180, 270].map((a) => <line key={a} x1={0} y1={-r + 8} x2={0} y2={-r + 20} transform={`rotate(${a})`} stroke={C.text} strokeWidth={5} />)}
    <line x1={0} y1={0} x2={0} y2={-r * 0.55} transform={`rotate(${t * 40})`} stroke={C.text} strokeWidth={6} strokeLinecap="round" />
    <line x1={0} y1={0} x2={0} y2={-r * 0.8} transform={`rotate(${t * 480})`} stroke={C.accent} strokeWidth={4} strokeLinecap="round" />
    <circle r={7} fill={C.text} />
  </g>
);

/** 44.6-70.4  Three deeds, ribat, the answer */
export const SceneDeeds: React.FC<SceneProps> = ({ t }) => {
  const cardsOut = 1 - prog(t, 58.7, 59.1);
  const towerOut = 1 - prog(t, 62.6, 63.0);
  return (
    <Svg>
      <Ground y={GROUND} />
      {t < 59.1 && (
        <g opacity={cardsOut}>
          <In t={t} cue={44.6} dy={50}>
            <Card x={CX[0]} y={190} w={540} h={600} />
            <circle cx={CX[0] + 60} cy={250} r={34} fill={C.accent} stroke={C.text} strokeWidth={3} />
            <text x={CX[0] + 60} y={264} textAnchor="middle" fontSize={40} fontWeight={700} fontFamily={FONT} fill={C.onAccent}>১</text>
            <SnowField t={t} n={5} x0={CX[0] + 40} x1={CX[0] + 500} y0={290} y1={700} op={0.5} />
            <Tap x={CX[0] + 330} y={620} t={t} s={0.95} />
            <Person x={CX[0] + 170} y={620} s={0.9} pose="wash" t={t} shiver cloth={C.cloth} />
            <Chip x={CX[0] + 270} y={730} text="কষ্টেও পূর্ণ ওজু" color={C.flow} size={30} />
          </In>
          <In t={t} cue={50.5} dy={50}>
            <Card x={CX[1]} y={190} w={540} h={600} />
            <circle cx={CX[1] + 60} cy={250} r={34} fill={C.accent} stroke={C.text} strokeWidth={3} />
            <text x={CX[1] + 60} y={264} textAnchor="middle" fontSize={40} fontWeight={700} fontFamily={FONT} fill={C.onAccent}>২</text>
            <Mosque x={CX[1] + 400} y={560} s={0.5} lit={false} />
            {[0, 1, 2, 3, 4, 5].map((i) => {
              const vis = prog(t, 51.0 + i * 0.22, 51.2 + i * 0.22);
              return <Footprint key={i} x={CX[1] + 90 + i * 52} y={540 + (i % 2) * 26} rot={90} opacity={vis} />;
            })}
            <Chip x={CX[1] + 270} y={730} text="মসজিদে বেশি পা" color={C.data} size={30} />
          </In>
          <In t={t} cue={52.4} dy={50}>
            <Card x={CX[2]} y={190} w={540} h={600} />
            <circle cx={CX[2] + 60} cy={250} r={34} fill={C.accent} stroke={C.text} strokeWidth={3} />
            <text x={CX[2] + 60} y={264} textAnchor="middle" fontSize={40} fontWeight={700} fontFamily={FONT} fill={C.onAccent}>৩</text>
            <Clock x={CX[2] + 270} y={420} t={Math.max(0, t - 52.4)} r={90} />
            <rect x={CX[2] + 120} y={560} width={300} height={70} rx={14} fill={C.cloth2} stroke={C.text} strokeWidth={4} />
            <Chip x={CX[2] + 270} y={730} text="নামাজের অপেক্ষা" color={C.good} size={30} />
          </In>
        </g>
      )}
      {t >= 59.0 && t < 63.0 && (
        <g opacity={towerOut}>
          <In t={t} cue={59.1} dy={80} ox={960} oy={GROUND}><Tower x={960} y={GROUND} s={1.35} /></In>
          <In t={t} cue={59.6}><Person x={640} y={GROUND} s={0.9} pose="stand" cloth={C.cloth2} /></In>
          <In t={t} cue={59.9}>
            <line x1={1240} y1={GROUND - 20} x2={1800} y2={GROUND - 20} stroke={C.bad} strokeWidth={6} strokeDasharray="22 16" strokeDashoffset={-t * 40} />
            <Label x={1520} y={GROUND - 50} text="সীমান্ত" size={30} color={C.bad} />
          </In>
          <In t={t} cue={59.1}><Chip x={960} y={200} text="রিবাত = সীমান্ত পাহারা" color={C.accent} size={38} /></In>
        </g>
      )}
      {t >= 63.0 && (
        <g>
          <In t={t} cue={63.1}><Chip x={960} y={200} text="উত্তর এটাই" color={C.accent} size={36} /></In>
          <SnowField t={t} n={6} x0={200} x1={900} y0={250} y1={760} op={0.5} />
          <In t={t} cue={63.7} dy={60}>
            <Tap x={620} y={GROUND} t={t} />
            <Person x={420} y={GROUND} pose="wash" t={t} shiver={t < 65.1} cloth={C.cloth} />
          </In>
          {/* sins fall away */}
          {[0, 1, 2].map((i) => {
            const p = prog(t, 66.8 + i * 0.15, 68.2);
            return t >= 66.8 ? <g key={i} opacity={1 - p} transform={`translate(${380 + i * 70} ${GROUND - 330 + p * 280}) rotate(${p * 90})`}><rect x={-30} y={-14} width={60} height={28} rx={14} fill={C.muted} /></g> : null;
          })}
          <In t={t} cue={66.8}><Chip x={500} y={GROUND + 45} text="গুনাহ মোচন" color={C.good} /></In>
          {[0, 1, 2, 3].map((i) => (
            <In key={i} t={t} cue={67.7 + i * 0.12} dy={30}>
              <rect x={1180 + i * 110} y={720 - i * 90} width={110} height={70 + i * 90} fill={C.tint} stroke={C.text} strokeWidth={4} />
            </In>
          ))}
          <In t={t} cue={68.0}><Person x={1230 + prog(t, 68.0, 69.0) * 270} y={720 - prog(t, 68.0, 69.0) * 270} s={0.5} pose="up" cloth={C.cloth2} /></In>
          <In t={t} cue={68.0}><Chip x={1440} y={GROUND + 45} text="মর্যাদা বৃদ্ধি" color={C.accent} /></In>
          <In t={t} cue={68.9} s0={0.3}><Star x={1700} y={260} r={60} /></In>
          <In t={t} cue={68.9}><Chip x={1560} y={440} text="সুসংবাদ" color={C.accent} size={34} /></In>
          <In t={t} cue={69.6} s0={0.4}><text x={960} y={560} textAnchor="middle" fontSize={140} fontWeight={700} fontFamily={FONT} fill={C.accent} stroke={C.text} strokeWidth={4}>?</text></In>
        </g>
      )}
    </Svg>
  );
};

/** 70.4-84.0  Obey when the heart does not want; do not seek hardship; fingertips only */
export const SceneNotHardship: React.FC<SceneProps> = ({ t }) => {
  const X = [110, 700, 1290];
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={71.0}><Chip x={960} y={215} text="হাদিসের ভাব" color={C.data} size={34} /></In>
      <In t={t} cue={72.2} dy={50}>
        <Card x={X[0]} y={270} w={520} h={470} />
        <Person x={X[0] + 200} y={690} s={0.85} pose="stand" cloth={C.cloth} />
        <Chip x={X[0] + 330} y={380} text="মন না চায়" color={C.warn} size={28} />
      </In>
      <Check x={X[0] + 440} y={640} t={t} cue={73.4} />
      <In t={t} cue={73.4}><Chip x={X[0] + 260} y={790} text="তখনও আদেশ মানা" color={C.good} size={28} /></In>
      <In t={t} cue={75.0} dy={50}>
        <Card x={X[1]} y={270} w={520} h={470} />
        <rect x={X[1] + 320} y={470} width={140} height={220} rx={20} fill="#CFE6F7" stroke={C.text} strokeWidth={4} />
        <Snowflake x={X[1] + 390} y={580} r={40} />
        <Person x={X[1] + 150} y={690} s={0.85} pose="walk" t={t} bob cloth={C.cloth} />
      </In>
      <Cross x={X[1] + 400} y={440} t={t} cue={76.2} />
      <In t={t} cue={76.0}><Chip x={X[1] + 260} y={790} text="ইচ্ছা করে কষ্ট খোঁজা নয়" color={C.bad} size={26} /></In>
      <In t={t} cue={78.1} dy={50}>
        <Card x={X[2]} y={270} w={520} h={470} />
        <Hand x={X[2] + 260} y={560} s={1.6} wet={prog(t, 79.2, 79.9)} />
        <SnowField t={t} n={4} x0={X[2] + 40} x1={X[2] + 480} y0={290} y1={420} op={0.5} />
      </In>
      <In t={t} cue={78.6}><Chip x={X[2] + 260} y={790} text="শুধু আঙুলের ডগা" color={C.warn} size={28} /></In>
      <In t={t} cue={81.5} dy={20}><Chip x={X[2] + 260} y={215} text="ওজুর ভদ্রতা" color={C.accent} size={34} /></In>
    </Svg>
  );
};

export { Check, Cross };
