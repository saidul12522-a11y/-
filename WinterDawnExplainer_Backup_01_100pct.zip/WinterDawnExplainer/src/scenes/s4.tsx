import React from "react";
import { theme as C } from "../theme";
import { FONT } from "../fonts";
import { Svg, SceneProps, GROUND } from "./common";
import { In, Chip, Ring, Ground, Label, Card, Check, Cross, Arrow } from "../components/kit";
import { Person, Snowflake, Sun, Moon, Star, Book, Flame, Globe, Bed, Mosque, Gift, Thermo, Tap, Cloud, Drop, SnowField } from "../art/art";
import { prog, pop, lerp, INOUT, hash } from "../motion";

const Blanket: React.FC<{ x: number; y: number; s?: number; heart?: boolean }> = ({ x, y, s = 1, heart }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-130} y={-90} width={260} height={180} rx={30} fill={C.data} stroke={C.text} strokeWidth={4} />
    {[-80, -30, 20, 70].map((bx) => <line key={bx} x1={bx} y1={-84} x2={bx} y2={84} stroke="#fff" strokeWidth={6} opacity={0.5} />)}
    {heart && <path d="M 0 30 C -60 -10 -30 -60 0 -25 C 30 -60 60 -10 0 30 Z" fill={C.accent} stroke={C.text} strokeWidth={3} />}
  </g>
);

/** 150.0-163.2  Long night: late-night optional prayer; blanket time is "our own invention" */
export const SceneNight: React.FC<SceneProps> = ({ t }) => {
  const up = t >= 153.1;
  const bar = prog(t, 151.0, 152.6, INOUT);
  const naflP = prog(t, 153.1, 154.0);
  return (
    <Svg>
      <In t={t} cue={150.1} dy={30} spring={false}>
        <rect x={120} y={190} width={1680} height={420} rx={40} fill={C.tint} stroke={C.text} strokeWidth={4} />
        {Array.from({ length: 22 }).map((_, i) => <Star key={i} x={170 + hash(i) * 1580} y={220 + hash(i + 7) * 200} r={4 + hash(i + 3) * 6} color={C.warn} opacity={0.5 + 0.5 * Math.sin(t * 2 + i)} />)}
        <Moon x={1650} y={290} r={58} cut={C.tint} />
        <rect x={120} y={540} width={1680} height={70} rx={0} fill={C.surface} opacity={0.6} />
      </In>
      <In t={t} cue={150.6}><Chip x={960} y={150} text="রাত" color={C.night} size={34} /></In>
      <Bed x={400} y={600} s={1.0} asleep={!up} blanketUp={up ? 1 : 0} t={t} />
      {up && (
        <In t={t} cue={153.3} dy={30}>
          <rect x={720} y={588} width={260} height={16} rx={8} fill={C.cloth2} stroke="#fff" strokeWidth={3} />
          <Person x={850} y={590} s={0.82} pose="pray" cloth={C.cloth2} />
        </In>
      )}
      <In t={t} cue={154.0}><Chip x={850} y={250} text="নফল নামাজ" color={C.accent} size={32} /></In>
      <In t={t} cue={153.1}><Chip x={400} y={250} text="রাতের শেষ ভাগ" color={C.gold} size={28} /></In>
      {/* timeline of the night */}
      <In t={t} cue={151.0} dy={20} spring={false}>
        <rect x={200} y={690} width={1520} height={46} rx={23} fill={C.tint} stroke={C.text} strokeWidth={3} />
        <rect x={200} y={690} width={1130 * bar} height={46} rx={23} fill={C.data} />
        <rect x={1330} y={690} width={390 * naflP} height={46} rx={23} fill={C.accent} />
        <Label x={760} y={770} text="ঘুম" size={28} color={C.data} />
      </In>
      <In t={t} cue={155.3}><Label x={1525} y={770} text="নফল নামাজের সময়" size={28} color={C.accent} /></In>
      <In t={t} cue={157.0} dy={40}>
        <Blanket x={1330} y={440} s={0.95} heart />
      </In>
      <In t={t} cue={157.2}><Chip x={1330} y={300} text="কম্বলের সঙ্গে সময়" color={C.data} size={28} /></In>
      <In t={t} cue={160.2}><Chip x={1330} y={590} text="হাদিসের নয়" color={C.bad} size={28} /></In>
      <In t={t} cue={161.5}><Chip x={960} y={810} text="আমাদের নিজেদের আবিষ্কার" color={C.warn} size={32} /></In>
    </Svg>
  );
};

/** 163.2-189.5  Where does the cold come from? Jahannam's two breaths */
export const SceneJahannam: React.FC<SceneProps> = ({ t }) => {
  const caveCue = 169.3;
  const breathL = prog(t, 177.3, 178.4), breathR = prog(t, 178.1, 179.2);
  return (
    <Svg>
      <Ground y={GROUND} />
      {t < 166.6 && (
        <g opacity={1 - prog(t, 166.2, 166.6)}>
          <In t={t} cue={163.4}><Thermo x={700} y={GROUND - 60} level={0.12} s={1.2} /></In>
          <In t={t} cue={164.3}><Chip x={1100} y={420} text="ঠান্ডা কোথা থেকে?" color={C.flow} size={44} /></In>
          <In t={t} cue={165.1} s0={0.3}><text x={1260} y={640} fontSize={200} fontWeight={700} fill={C.accent} stroke={C.text} strokeWidth={5} fontFamily={FONT} textAnchor="middle">?</text></In>
          <SnowField t={t} n={10} />
        </g>
      )}
      <In t={t} cue={166.6} dy={50}><Book x={250} y={420} s={1.0} color={C.good} /></In>
      <In t={t} cue={167.1}><Chip x={250} y={540} text="বুখারী ও মুসলিম" color={C.good} size={26} /></In>
      <In t={t} cue={caveCue} dy={80} ox={960} oy={GROUND}>
        <path d={`M 740 ${GROUND} L 740 ${GROUND - 150} Q 740 ${GROUND - 330} 960 ${GROUND - 330} Q 1180 ${GROUND - 330} 1180 ${GROUND - 150} L 1180 ${GROUND} Z`} fill="#F3D5CC" stroke={C.text} strokeWidth={5} />
        <Flame x={880} y={GROUND - 5} s={1.0} t={t} />
        <Flame x={960} y={GROUND - 5} s={1.4} t={t + 1} />
        <Flame x={1040} y={GROUND - 5} s={1.0} t={t + 2} />
      </In>
      <In t={t} cue={caveCue}><Chip x={960} y={GROUND - 390} text="জাহান্নাম" color={C.bad} size={34} /></In>
      <In t={t} cue={171.4}><Chip x={960} y={215} text="“আমার একাংশ আরেক অংশকে খেয়ে ফেলছে”" color={C.bad} size={30} /></In>
      <In t={t} cue={175.2}><Chip x={960} y={330} text="দুটি নিঃশ্বাসের অনুমতি" color={C.accent} size={34} /></In>
      {/* two breaths */}
      <Arrow x1={760} y1={GROUND - 160} x2={470} y2={GROUND - 160} p={breathL} color={C.flow} w={14} />
      <Arrow x1={1160} y1={GROUND - 160} x2={1450} y2={GROUND - 160} p={breathR} color={C.warn} w={14} />
      <In t={t} cue={177.7} dy={40}>
        <Snowflake x={400} y={GROUND - 190} r={70} rot={t * 20} />
        <Chip x={400} y={GROUND - 60} text="শীতে" color={C.flow} size={30} />
      </In>
      <In t={t} cue={178.4} dy={40}>
        <Sun x={1550} y={GROUND - 190} r={44} t={t} />
        <Chip x={1550} y={GROUND - 60} text="গ্রীষ্মে" color={C.warn} size={30} />
      </In>
      <Ring x={400} y={GROUND - 190} t={t} cue={181.7} r={90} color={C.flow} loop={t < 186.5} />
      <In t={t} cue={185.3}><Chip x={400} y={GROUND - 340} text="জামহারির" color={C.flow} size={36} /></In>
      <In t={t} cue={187.6}><Chip x={960} y={GROUND + 55} text="ব্যাখ্যায় একাধিক মত" color={C.data} size={30} /></In>
    </Svg>
  );
};

/** 189.5-197.5  Science says the tilt; one event can have several causes */
export const SceneScience: React.FC<SceneProps> = ({ t }) => {
  const tilt = lerp(0, 23.5, prog(t, 191.2, 192.4, INOUT));
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={189.7}><Sun x={190} y={420} r={70} t={t} /></In>
      {[-60, 0, 60].map((dy, i) => <Arrow key={i} x1={300} y1={420 + dy} x2={470} y2={420 + dy * 0.6} p={prog(t, 190.1 + i * 0.1, 190.9)} color={C.warn} w={6} />)}
      <In t={t} cue={190.9} s0={0.6}><Globe x={650} y={420} r={115} tilt={tilt} t={t} /></In>
      <In t={t} cue={190.1}><Chip x={650} y={190} text="ঋতুর কারণ" color={C.data} size={32} /></In>
      <In t={t} cue={191.8}><Chip x={650} y={640} text="পৃথিবীর হেলে থাকা অক্ষ" color={C.accent} size={30} /></In>
      <In t={t} cue={193.4}><Book x={650} y={760} s={0.55} color={C.good} /></In>
      <In t={t} cue={193.4}><Chip x={900} y={760} text="ব্যাখ্যাকারদের মত" color={C.good} size={26} /></In>
      <Arrow x1={800} y1={420} x2={1300} y2={420} p={prog(t, 194.6, 195.3)} color={C.data} w={8} />
      <Arrow x1={900} y1={740} x2={1330} y2={500} p={prog(t, 195.0, 195.8)} color={C.good} w={8} />
      <In t={t} cue={195.0} s0={0.4}>
        <circle cx={1450} cy={440} r={100} fill={C.surface} stroke={C.flow} strokeWidth={6} />
        <Snowflake x={1450} y={440} r={64} rot={t * 15} />
      </In>
      <In t={t} cue={195.5}><Chip x={1450} y={600} text="একটি ঘটনা, একাধিক কারণ" color={C.accent} size={30} /></In>
    </Svg>
  );
};
