import React from "react";
import { theme as C } from "../theme";
import { FONT } from "../fonts";
import { Svg, SceneProps, GROUND } from "./common";
import { In, Chip, Ring, Ground, Label, Card, Check, Cross } from "../components/kit";
import { Person, Snowflake, Sun, Moon, Star, Flame, Bed, Mosque, Gift, Tap, Drop } from "../art/art";
import { prog, pop, lerp, INOUT } from "../motion";
import { staticFile, Img } from "remotion";

const Badge: React.FC<{ x: number; y: number; n: string }> = ({ x, y, n }) => (
  <g>
    <circle cx={x} cy={y} r={34} fill={C.accent} stroke={C.text} strokeWidth={3} />
    <text x={x} y={y + 14} textAnchor="middle" fontSize={40} fontWeight={700} fontFamily={FONT} fill={C.onAccent}>{n}</text>
  </g>
);

/** 197.5-215.2  Three-line recap */
export const SceneRecap: React.FC<SceneProps> = ({ t }) => {
  const X = [90, 690, 1290];
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={197.6}><Chip x={960} y={200} text="তিন লাইনে হিসাব" color={C.accent} size={38} /></In>
      <In t={t} cue={200.4} dy={50}>
        <Card x={X[0]} y={260} w={540} h={540} />
        <Badge x={X[0] + 60} y={320} n="১" />
        <Tap x={X[0] + 340} y={640} t={t} s={0.75} />
        <Person x={X[0] + 200} y={640} s={0.8} pose="wash" t={t} cloth={C.cloth} />
        <Label x={X[0] + 300} y={330} text="যত্নে ওজু" size={30} anchor="middle" />
      </In>
      <In t={t} cue={202.3}><Chip x={X[0] + 270} y={690} text="গুনাহ মোচন" color={C.good} size={28} /></In>
      <In t={t} cue={203.1}><Chip x={X[0] + 270} y={760} text="মর্যাদা বৃদ্ধি" color={C.accent} size={28} /></In>
      <In t={t} cue={205.1} dy={50}>
        <Card x={X[1]} y={260} w={540} h={540} />
        <Badge x={X[1] + 60} y={320} n="২" />
        <Label x={X[1] + 300} y={330} text="দিন ও রাত" size={30} />
        <Sun x={X[1] + 130} y={460} r={40} t={t} />
        <Moon x={X[1] + 130} y={640} r={44} cut={C.surface} />
      </In>
      <In t={t} cue={205.4}><Chip x={X[1] + 380} y={460} text="দিন ছোট" color={C.warn} size={26} /></In>
      <In t={t} cue={206.1}><Chip x={X[1] + 380} y={520} text="নফল রোজা সহজ" color={C.good} size={26} /></In>
      <In t={t} cue={207.5}><Chip x={X[1] + 380} y={640} text="রাত বড়" color={C.night} size={26} /></In>
      <In t={t} cue={208.4}><Chip x={X[1] + 380} y={700} text="নফল নামাজের সময় বেশি" color={C.accent} size={24} /></In>
      <In t={t} cue={210.4} dy={50}>
        <Card x={X[2]} y={260} w={540} h={540} />
        <Badge x={X[2] + 60} y={320} n="৩" />
        <Label x={X[2] + 300} y={330} text="ঠান্ডার উৎস" size={30} />
        <Flame x={X[2] + 270} y={560} s={1.4} t={t} />
      </In>
      <In t={t} cue={211.8}><Chip x={X[2] + 270} y={650} text="জাহান্নামের নিঃশ্বাস" color={C.bad} size={28} /></In>
      <In t={t} cue={213.8}><Chip x={X[2] + 270} y={730} text="ব্যাখ্যায় একাধিক মত" color={C.data} size={26} /></In>
    </Svg>
  );
};

/** 215.2-227.3  Winter returns every year; the blanket bargain; the good news; first step */
export const SceneClosing: React.FC<SceneProps> = ({ t }) => {
  const A = 1 - prog(t, 219.3, 219.7);
  const B = prog(t, 219.6, 220.2) * (1 - prog(t, 222.5, 222.9));
  const lift = prog(t, 224.4, 225.4, INOUT);
  return (
    <Svg>
      <Ground y={GROUND} />
      {t < 219.7 && (
        <g opacity={A}>
          <In t={t} cue={215.4}>
            <rect x={240} y={260} width={420} height={380} rx={28} fill={C.surface} stroke={C.text} strokeWidth={4} />
            <rect x={240} y={260} width={420} height={80} rx={28} fill={C.flow} stroke={C.text} strokeWidth={4} />
            <Snowflake x={450} y={490} r={80} rot={t * 20} />
          </In>
          <In t={t} cue={216.0}><Chip x={450} y={700} text="প্রতি বছর শীত আসে" color={C.flow} size={30} /></In>
          <In t={t} cue={217.0} dy={60}>
            <Bed x={1100} y={GROUND} s={1.1} asleep blanketUp={0} t={t} />
            <Person x={1500} y={GROUND} pose="front" flip cloth={C.cloth} />
          </In>
          <In t={t} cue={217.3}><Chip x={1180} y={GROUND - 270} text="কম্বলের সঙ্গে দর কষাকষি" color={C.warn} size={30} /></In>
        </g>
      )}
      {t >= 219.6 && t < 222.9 && (
        <g opacity={B}>
          <In t={t} cue={220.9} dy={60}><Gift x={960} y={600} s={1.8} /></In>
          {[0, 1, 2, 3, 4, 5].map((i) => <Star key={i} x={960 + Math.cos(i * 1.05) * 230} y={430 + Math.sin(i * 1.05) * 150} r={14} opacity={0.5 + 0.5 * Math.sin(t * 4 + i)} />)}
          <In t={t} cue={221.3}><Chip x={960} y={740} text="ওপাশে সুসংবাদ" color={C.accent} size={42} /></In>
        </g>
      )}
      {t >= 222.9 && (
        <g>
          <In t={t} cue={223.0} dy={60}><Mosque x={1560} y={GROUND} s={1.0} t={t} /></In>
          {[0, 1, 2].map((i) => { const p = ((t - 223) * 0.8 + i / 3) % 1; return t >= 223 ? <path key={i} d={`M ${1360 - p * 150} 400 Q ${1330 - p * 150} 460 ${1360 - p * 150} 520`} stroke={C.accent} strokeWidth={6} fill="none" strokeLinecap="round" opacity={1 - p} /> : null; })}
          <In t={t} cue={223.0}><Chip x={1480} y={220} text="আজান" color={C.accent} size={34} /></In>
          <Bed x={560} y={GROUND} s={1.35} asleep={lift < 0.5} blanketUp={0} t={t} />
          {/* blanket corner lifts */}
          <g transform={`translate(${560 + 120} ${GROUND - 200}) rotate(${-lift * 38})`} opacity={prog(t, 223.9, 224.3)}>
            <path d="M 0 0 L 110 0 L 0 -90 Z" fill={C.warn} stroke={C.text} strokeWidth={4} />
          </g>
          <In t={t} cue={224.4}><Chip x={560} y={GROUND - 330} text="কম্বলের এক কোণ আলগা" color={C.accent} size={32} /></In>
          <Ring x={680} y={GROUND - 190} t={t} cue={225.0} r={50} />
          <In t={t} cue={226.0}><Chip x={960} y={GROUND + 60} text="শুরুটা ওখান থেকেই" color={C.good} size={34} /></In>
        </g>
      )}
    </Svg>
  );
};

/** 227.3-235.1  Outro: like, comment, subscribe */
export const SceneOutro: React.FC<SceneProps> = ({ t }) => {
  const bell = Math.sin(t * 18) * 10 * (prog(t, 232.5, 232.7) * (1 - prog(t, 234.2, 234.4)));
  return (
    <Svg>
      <In t={t} cue={227.4} dy={40}>
        <rect x={150} y={220} width={560} height={560} rx={48} fill="#fff" stroke={C.border} strokeWidth={3} />
        <image href={staticFile("logo.jpg")} x={160} y={230} width={540} height={540} preserveAspectRatio="xMidYMid meet" />
      </In>
      <In t={t} cue={227.9} dy={50}>
        <rect x={860} y={250} width={380} height={120} rx={60} fill={C.surface} stroke={C.data} strokeWidth={4} />
        <path d="M 920 335 L 920 295 L 950 295 L 965 262 Q 985 262 982 285 L 982 295 L 1020 295 Q 1034 296 1030 312 L 1022 335 Z" fill={C.data} stroke={C.text} strokeWidth={3} strokeLinejoin="round" />
        <Label x={1135} y={332} text="লাইক" size={42} color={C.text} />
      </In>
      <In t={t} cue={229.3} dy={50}>
        <rect x={860} y={420} width={380} height={120} rx={60} fill={C.surface} stroke={C.good} strokeWidth={4} />
        <path d="M 915 475 Q 915 440 950 440 L 995 440 Q 1030 440 1030 475 Q 1030 505 995 505 L 960 505 L 935 525 L 940 505 Q 915 505 915 475 Z" fill={C.good} stroke={C.text} strokeWidth={3} strokeLinejoin="round" />
        <Label x={1135} y={492} text="কমেন্ট" size={42} color={C.text} />
      </In>
      <In t={t} cue={230.5}><Chip x={1520} y={480} text="আপনার কম্বল কতবার জিতেছে?" color={C.warn} size={30} /></In>
      <In t={t} cue={232.0} dy={50}>
        <rect x={860} y={590} width={560} height={130} rx={65} fill={C.bad} stroke={C.text} strokeWidth={4} />
        <g transform={`translate(950 655) rotate(${bell})`}>
          <path d="M -26 14 Q -26 -34 0 -34 Q 26 -34 26 14 L 36 26 L -36 26 Z" fill="#fff" stroke={C.text} strokeWidth={3} />
          <circle cx={0} cy={36} r={8} fill="#fff" stroke={C.text} strokeWidth={3} />
        </g>
        <text x={1180} y={668} textAnchor="middle" fontSize={50} fontWeight={700} fontFamily={FONT} fill="#fff">সাবস্ক্রাইব</text>
      </In>
    </Svg>
  );
};
