import React from "react";
import { FONT } from "../fonts";
import { theme as C } from "../theme";
import { Svg, SceneProps, GROUND } from "./common";
import { In, Chip, Ring, Ground, Label, Card, Check, Cross } from "../components/kit";
import { Person, Snowflake, Sun, Moon, Star, Chest, Swords, Book, Drop, SnowField } from "../art/art";
import { prog, pop, lerp, INOUT } from "../motion";

/** donut arc via stroke-dasharray; angle in degrees starting at the top */
const Arc: React.FC<{ cx: number; cy: number; r: number; from: number; sweep: number; color: string; w?: number }> = ({ cx, cy, r, from, sweep, color, w = 56 }) => {
  const circ = 2 * Math.PI * r;
  return (
    <circle cx={cx} cy={cy} r={r} fill="none" stroke={color} strokeWidth={w} strokeDasharray={`${(sweep / 360) * circ} ${circ}`} transform={`rotate(${from - 90} ${cx} ${cy})`} />
  );
};
const polar = (cx: number, cy: number, r: number, deg: number) => ({ x: cx + r * Math.cos(((deg - 90) * Math.PI) / 180), y: cy + r * Math.sin(((deg - 90) * Math.PI) / 180) });

/** 84.0-100.3  Short day, long night; cold ghanimah */
export const SceneDayNight: React.FC<SceneProps> = ({ t }) => {
  const mv = prog(t, 92.2, 93.2, INOUT);
  const cx = lerp(960, 380, mv), cy = lerp(480, 480, mv), sc = lerp(1, 0.78, mv);
  const grow = prog(t, 86.4, 88.6, INOUT);
  const dayDeg = 150, nightDeg = 210;
  const sun = polar(0, 0, 0, 0);
  const sp = polar(0, 0, 150, dayDeg / 2);
  const mp = polar(0, 0, 150, dayDeg + nightDeg / 2);
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={84.1} s0={0.7}>
        <g transform={`translate(${cx} ${cy}) scale(${sc})`}>
          <circle r={150} fill={C.surface} stroke={C.border} strokeWidth={3} />
          <g transform="translate(0 0)">
            <Arc cx={0} cy={0} r={150} from={0} sweep={dayDeg * grow} color={C.gold} />
            <Arc cx={0} cy={0} r={150} from={dayDeg} sweep={nightDeg * grow} color={C.night} />
          </g>
          <circle r={96} fill={C.bg} />
          {grow > 0.9 && <g><Sun x={sp.x} y={sp.y} r={22} t={t} /><Moon x={mp.x} y={mp.y} r={26} cut={C.night} /></g>}
          <Label x={0} y={14} text="২৪ ঘন্টা" size={40} color={C.muted} />
        </g>
      </In>
      <In t={t} cue={87.0}><Chip x={cx + 330 * sc * (1 - mv) - 40} y={300} text="দিন ছোট" color={C.warn} size={36} /></In>
      <In t={t} cue={88.3}><Chip x={cx + 330 * sc * (1 - mv) - 40} y={660} text="রাত বড়" color={C.night} size={36} /></In>
      <In t={t} cue={92.2} dy={70} ox={960} oy={GROUND}>
        <Chest x={960} y={GROUND - 40} s={1.6} open={prog(t, 93.5, 94.2)} />
        <Snowflake x={960} y={GROUND - 290} r={46} rot={t * 20} />
      </In>
      <In t={t} cue={93.5}><Chip x={960} y={GROUND + 40} text="ঠান্ডা গণিমত" color={C.flow} size={38} /></In>
      <In t={t} cue={94.6} dx={80} dy={0}>
        <Swords x={1560} y={540} s={1.5} />
      </In>
      <In t={t} cue={95.6}><Chip x={1560} y={720} text="যুদ্ধে পাওয়া সম্পদ" color={C.muted} size={28} /></In>
      <Cross x={1560} y={540} t={t} cue={97.9} s={1.4} />
      <In t={t} cue={98.2}><Chip x={1560} y={GROUND + 40} text="বিনা লড়াইয়ে" color={C.good} size={32} /></In>
    </Svg>
  );
};

const Cup: React.FC<{ x: number; y: number; level: number; color?: string }> = ({ x, y, level, color = C.flow }) => (
  <g transform={`translate(${x} ${y})`}>
    <path d="M -50 -140 L 50 -140 L 40 0 L -40 0 Z" fill="#fff" stroke={C.text} strokeWidth={4} />
    <path d={`M ${-50 + (1 - level) * 6} ${-140 + (1 - level) * 130} L ${50 - (1 - level) * 6} ${-140 + (1 - level) * 130} L 40 0 L -40 0 Z`} fill={color} opacity={0.8} />
  </g>
);

/** 100.3-118.4  Fasting hours 14 vs 11 */
export const SceneFastHours: React.FC<{ t: number }> = ({ t }) => {
  const phaseA = 1 - prog(t, 106.2, 106.8);
  const bx = (i: number) => 300 + i * 104;
  const blocks = (n: number, y: number, cue: number, color: string, hi = 0) =>
    Array.from({ length: n }).map((_, i) => {
      const p = pop(t, cue + i * 0.1, "snap");
      const isHi = hi > 0 && i >= n - 3;
      const hl = isHi ? prog(t, 112.4, 113.0) : 0;
      return p > 0 ? (
        <g key={i} transform={`translate(${bx(i) + 46} ${y + 40}) scale(${p})`}>
          <rect x={-46} y={-40} width={92} height={80} rx={14} fill={hl > 0.5 ? C.accent : color} stroke={C.text} strokeWidth={3} />
        </g>
      ) : null;
    });
  return (
    <Svg>
      <Ground y={GROUND} />
      {t < 106.8 && (
        <g opacity={phaseA}>
          <In t={t} cue={100.5}>
            <rect x={300} y={430} width={1320} height={26} rx={13} fill={C.tint} stroke={C.text} strokeWidth={3} />
            <rect x={300} y={430} width={1320 * prog(t, 100.5, 102.9, INOUT)} height={26} rx={13} fill={C.accent} />
            <Chip x={300} y={540} text="ফজর" color={C.data} />
            <Chip x={1620} y={540} text="সূর্যাস্ত" color={C.warn} />
            <Sun x={1620} y={330} r={46} t={t} />
            <path d="M 255 400 A 46 46 0 0 1 345 400 Z" fill={C.gold} stroke={C.text} strokeWidth={4} />
          </In>
          <In t={t} cue={103.7}><Chip x={960} y={640} text="দিন ছোট → ব্যবধান ছোট" color={C.flow} size={34} /></In>
        </g>
      )}
      {t >= 106.8 && (
        <g>
          <In t={t} cue={106.9}><Sun x={170} y={310} r={42} t={t} /></In>
          <In t={t} cue={107.3}><Label x={170} y={400} text="গ্রীষ্ম" size={30} color={C.muted} /></In>
          {blocks(14, 270, 107.6, C.gold, 1)}
          <In t={t} cue={108.6}><Chip x={1740} y={310} text="১৪ ঘন্টা" color={C.warn} size={32} /></In>
          <In t={t} cue={109.4}><Snowflake x={170} y={510} r={44} rot={t * 15} /></In>
          <In t={t} cue={109.6}><Label x={170} y={600} text="শীত" size={30} color={C.muted} /></In>
          {blocks(11, 470, 109.7, C.flow)}
          <In t={t} cue={109.9}><Chip x={1740} y={510} text="১১ ঘন্টা" color={C.flow} size={32} /></In>
          <In t={t} cue={110.8}><Chip x={560} y={720} text="১৪ − ১১ = ৩" color={C.accent} size={42} /></In>
          <In t={t} cue={115.3}><Chip x={560} y={810} text="তিন ঘন্টা কম" color={C.good} size={32} /></In>
          <In t={t} cue={116.2}>
            <Cup x={1250} y={770} level={prog(t, 116.9, 118.0) * -0.6 + 0.9} />
            <Chip x={1450} y={700} text="পিপাসা কম" color={C.flow} size={30} />
          </In>
        </g>
      )}
    </Svg>
  );
};

const Gauge: React.FC<{ x: number; y: number; level: number; color: string }> = ({ x, y, level, color }) => (
  <g transform={`translate(${x} ${y})`}>
    <rect x={-22} y={-260} width={44} height={260} rx={22} fill="#fff" stroke={C.text} strokeWidth={4} />
    <rect x={-14} y={-8 - 244 * level} width={28} height={244 * level} rx={14} fill={color} />
  </g>
);

/** 118.4-127.6  Same voluntary fast in summer vs winter */
export const SceneExample: React.FC<SceneProps> = ({ t }) => {
  const tilt = lerp(-14, 0, prog(t, 125.4, 126.0)) + lerp(0, 12, prog(t, 126.4, 127.3));
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={118.5}><Chip x={960} y={200} text="নফল রোজা" color={C.good} size={36} /></In>
      <In t={t} cue={120.1} dy={50}>
        <Card x={110} y={250} w={800} h={540} />
        <Sun x={230} y={360} r={50} t={t} />
        <Chip x={420} y={350} text="গ্রীষ্মে দুপুর" color={C.warn} size={30} />
        <Person x={500} y={730} s={0.95} pose="stand" cloth={C.cloth} />
        <Gauge x={760} y={700} level={0.85 * prog(t, 121.6, 122.6)} color={C.bad} />
        {[0, 1, 2].map((i) => <Drop key={i} x={600 + i * 20} y={500 - ((t * 60 + i * 30) % 90)} r={8} color={C.muted} />)}
      </In>
      <In t={t} cue={122.1}><Chip x={500} y={810} text="গলা শুকায়" color={C.bad} size={28} /></In>
      <In t={t} cue={123.0} dy={50}>
        <Card x={1010} y={250} w={800} h={540} />
        <Snowflake x={1130} y={360} r={50} rot={t * 15} />
        <Chip x={1330} y={350} text="শীতে একই সময়" color={C.flow} size={30} />
        <Person x={1400} y={730} s={0.95} pose="stand" cloth={C.cloth} />
        <Gauge x={1660} y={700} level={0.25 * prog(t, 124.2, 125.0)} color={C.good} />
      </In>
      <In t={t} cue={124.2}><Chip x={1400} y={810} text="তেমন শুকায় না" color={C.good} size={28} /></In>
      <In t={t} cue={125.4} dy={0}>
        <g transform={`translate(960 ${GROUND - 90}) rotate(${tilt})`}>
          <rect x={-130} y={-6} width={260} height={12} rx={6} fill={C.text} />
          <rect x={-150} y={-6} width={10} height={0} />
        </g>
        <polygon points="960,700 930,790 990,790" fill={C.text} />
      </In>
      <In t={t} cue={126.4}><Chip x={960} y={640} text="কষ্টের ওজন কম" color={C.accent} size={34} /></In>
    </Svg>
  );
};

/** 127.6-150.0  Sources, grading dispute, Ramadan is lunar */
export const SceneSources: React.FC<SceneProps> = ({ t }) => {
  const A = 1 - prog(t, 140.8, 141.3);
  const rot = prog(t, 143.3, 149, INOUT) * 540;
  const ang = [0, 90, 180, 270];
  return (
    <Svg>
      <Ground y={GROUND} />
      {t < 141.3 && (
        <g opacity={A}>
          <In t={t} cue={127.8} dy={60}><Book x={330} y={480} s={1.4} color={C.data} /></In>
          <In t={t} cue={128.4}><Chip x={330} y={650} text="তিরমিজি ও আহমাদ" color={C.data} size={30} /></In>
          <In t={t} cue={130.4} dy={60}>
            <Person x={760} y={GROUND} s={0.9} pose="front" cloth={C.cloth2} />
            <Person x={1060} y={GROUND} s={0.9} pose="front" cloth={C.cloth} flip />
          </In>
          <In t={t} cue={131.1}><Chip x={910} y={250} text="সনদ নিয়ে মতভেদ" color={C.warn} size={36} /></In>
          <In t={t} cue={133.6}><Chip x={730} y={420} text="সহিহ" color={C.good} /></In>
          <Check x={730} y={490} t={t} cue={133.9} />
          <In t={t} cue={134.8}><Chip x={1090} y={420} text="দুর্বল" color={C.warn} /></In>
          <In t={t} cue={135.4} dy={60}>
            <g transform="translate(1520 560)">
              <circle r={70} fill={C.tint} stroke={C.text} strokeWidth={4} />
              {[0, 72, 144, 216, 288].map((a) => <ellipse key={a} cx={0} cy={-52} rx={20} ry={34} transform={`rotate(${a})`} fill="#F6B8C9" stroke={C.text} strokeWidth={3} />)}
              <circle r={22} fill={C.gold} stroke={C.text} strokeWidth={3} />
            </g>
          </In>
          <In t={t} cue={137.1}><Chip x={1520} y={690} text="শীত = মুমিনের বসন্ত" color={C.accent} size={28} /></In>
          <In t={t} cue={139.5} s0={1.6}>
            <g transform="translate(1520 460) rotate(-8)"><rect x={-110} y={-34} width={220} height={68} rx={10} fill="none" stroke={C.warn} strokeWidth={6} /><text textAnchor="middle" y={14} fontSize={40} fontWeight={700} fill={C.warn} fontFamily="inherit">সনদ দুর্বল</text></g>
          </In>
        </g>
      )}
      {t >= 141.3 && (
        <g>
          <In t={t} cue={141.6}><Chip x={960} y={215} text="রমজানের রোজা" color={C.good} size={36} /></In>
          <In t={t} cue={142.3} s0={0.6}>
            <g transform="translate(620 520)">
              <circle r={170} fill={C.surface} stroke={C.border} strokeWidth={3} />
              <Arc cx={0} cy={0} r={170} from={0} sweep={180} color={C.gold} w={40} />
              <Arc cx={0} cy={0} r={170} from={180} sweep={180} color={C.flow} w={40} />
              <Sun x={-0} y={-170} r={26} t={t} />
              <Snowflake x={0} y={170} r={30} />
              <g transform={`rotate(${rot})`}>
                <circle cx={0} cy={-170} r={0} />
                <g transform="translate(0 -170)"><Moon x={0} y={0} r={30} cut={C.surface} /></g>
              </g>
              <Label x={0} y={14} text="ঋতু" size={36} color={C.muted} />
            </g>
          </In>
          <In t={t} cue={143.6}><Chip x={1280} y={330} text="চান্দ্র মাসের হিসাব" color={C.data} size={34} /></In>
          <In t={t} cue={145.6}><Chip x={1280} y={440} text="কখনো শীতে" color={C.flow} size={32} icon={<Snowflake x={0} y={0} r={14} />} /></In>
          <In t={t} cue={146.4}><Chip x={1280} y={550} text="কখনো গ্রীষ্মে" color={C.warn} size={32} icon={<Sun x={0} y={0} r={10} t={t} />} /></In>
          <In t={t} cue={147.6}><Chip x={1280} y={690} text="কথাগুলো নফল রোজার জন্য" color={C.accent} size={32} /></In>
        </g>
      )}
    </Svg>
  );
};
