import React from "react";
import { theme as C } from "../theme";
import { hash } from "../motion";

const OUT = C.text;
const sw = 4;

/** Icon-style full-body person. Feet at (0,0), natural height ~300. */
export type Pose = "stand" | "walk" | "front" | "wash" | "pray" | "up" | "think";
export const Person: React.FC<{
  x: number; y: number; s?: number; pose?: Pose; t?: number; shiver?: boolean; cloth?: string; flip?: boolean; bob?: boolean; cap?: boolean; opacity?: number;
}> = ({ x, y, s = 1, pose = "stand", t = 0, shiver = false, cloth = C.cloth, flip = false, bob = false, cap = true, opacity = 1 }) => {
  const sh = shiver ? Math.sin(t * 40) * 3 : 0;
  const by = bob ? Math.abs(Math.sin(t * 6)) * -6 : 0;
  const legA = pose === "walk" ? Math.sin(t * 8) * 16 : 0;
  const arm = (side: 1 | -1) => {
    const sx = side * 44, sy = -210;
    let hx = side * 58, hy = -118;
    if (pose === "front" || pose === "wash") { hx = side * 20 + 40; hy = pose === "wash" ? -150 : -190; }
    if (pose === "pray") { hx = side * 12; hy = -180; }
    if (pose === "up") { hx = side * 52; hy = -285; }
    if (pose === "think") { hx = side === 1 ? 30 : side * 58; hy = side === 1 ? -270 : -118; }
    if (pose === "walk") { hx = side * 52 + Math.sin(t * 8) * side * -14; hy = -125; }
    return (
      <g>
        <line x1={sx} y1={sy} x2={hx} y2={hy} stroke={cloth} strokeWidth={24} strokeLinecap="round" />
        <circle cx={hx} cy={hy} r={13} fill={C.skin} stroke={OUT} strokeWidth={3} />
      </g>
    );
  };
  return (
    <g opacity={opacity} transform={`translate(${x + sh} ${y + by}) scale(${flip ? -s : s} ${s})`}>
      <ellipse cx={0} cy={4} rx={62} ry={9} fill="rgba(16,35,58,0.14)" />
      <g transform={`rotate(${legA} 0 -110)`}><rect x={-32} y={-112} width={26} height={112} rx={13} fill={C.night} stroke={OUT} strokeWidth={sw} /></g>
      <g transform={`rotate(${-legA} 0 -110)`}><rect x={6} y={-112} width={26} height={112} rx={13} fill={C.night} stroke={OUT} strokeWidth={sw} /></g>
      {arm(-1)}
      <rect x={-48} y={-234} width={96} height={150} rx={30} fill={cloth} stroke={OUT} strokeWidth={sw} />
      {arm(1)}
      <rect x={-12} y={-250} width={24} height={26} fill={C.skin} stroke={OUT} strokeWidth={3} />
      <circle cx={0} cy={-276} r={36} fill={C.skin} stroke={OUT} strokeWidth={sw} />
      {cap && <path d="M -35 -284 A 36 36 0 0 1 35 -284 Z" fill="#fff" stroke={OUT} strokeWidth={sw} />}
      <circle cx={-12} cy={-270} r={4} fill={OUT} />
      <circle cx={12} cy={-270} r={4} fill={OUT} />
      <path d={shiver ? "M -10 -254 q 5 -6 10 0 q 5 6 10 0" : "M -9 -255 q 9 7 18 0"} stroke={OUT} strokeWidth={3} fill="none" strokeLinecap="round" />
    </g>
  );
};

export const Snowflake: React.FC<{ x: number; y: number; r?: number; rot?: number; color?: string; opacity?: number }> = ({ x, y, r = 30, rot = 0, color = C.flow, opacity = 1 }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot})`} opacity={opacity} stroke={color} strokeWidth={Math.max(3, r / 8)} strokeLinecap="round" fill="none">
    {[0, 60, 120].map((a) => (
      <g key={a} transform={`rotate(${a})`}>
        <line x1={-r} y1={0} x2={r} y2={0} />
        <path d={`M ${r * 0.55} ${-r * 0.3} L ${r * 0.8} 0 L ${r * 0.55} ${r * 0.3}`} />
        <path d={`M ${-r * 0.55} ${-r * 0.3} L ${-r * 0.8} 0 L ${-r * 0.55} ${r * 0.3}`} />
      </g>
    ))}
  </g>
);

/** drifting snow, deterministic */
export const SnowField: React.FC<{ t: number; n?: number; x0?: number; x1?: number; y0?: number; y1?: number; op?: number }> = ({ t, n = 14, x0 = 0, x1 = 1920, y0 = 140, y1 = 860, op = 0.7 }) => (
  <g>
    {Array.from({ length: n }).map((_, i) => {
      const sp = 24 + hash(i) * 30;
      const yy = y0 + (((hash(i + 9) * (y1 - y0) + t * sp) % (y1 - y0)) + (y1 - y0)) % (y1 - y0);
      const xx = x0 + hash(i + 3) * (x1 - x0) + Math.sin(t * 0.8 + i) * 18;
      return <Snowflake key={i} x={xx} y={yy} r={8 + hash(i + 5) * 10} rot={t * 20 + i * 30} opacity={op} />;
    })}
  </g>
);

export const Sun: React.FC<{ x: number; y: number; r?: number; t?: number; color?: string }> = ({ x, y, r = 60, t = 0, color = C.gold }) => (
  <g transform={`translate(${x} ${y})`}>
    <g transform={`rotate(${t * 12})`}>
      {Array.from({ length: 12 }).map((_, i) => (
        <line key={i} x1={r * 1.3} y1={0} x2={r * 1.7} y2={0} transform={`rotate(${i * 30})`} stroke={color} strokeWidth={r / 7} strokeLinecap="round" />
      ))}
    </g>
    <circle r={r} fill={color} stroke={OUT} strokeWidth={sw} />
  </g>
);

export const Moon: React.FC<{ x: number; y: number; r?: number; cut?: string }> = ({ x, y, r = 60, cut = C.night }) => (
  <g transform={`translate(${x} ${y})`}>
    <circle r={r} fill={C.gold} />
    <circle cx={r * 0.45} cy={-r * 0.2} r={r * 0.85} fill={cut} />
  </g>
);

export const Star: React.FC<{ x: number; y: number; r?: number; color?: string; opacity?: number }> = ({ x, y, r = 8, color = C.gold, opacity = 1 }) => (
  <path transform={`translate(${x} ${y})`} opacity={opacity} fill={color} d={`M 0 ${-r} L ${r * 0.3} ${-r * 0.3} L ${r} 0 L ${r * 0.3} ${r * 0.3} L 0 ${r} L ${-r * 0.3} ${r * 0.3} L ${-r} 0 L ${-r * 0.3} ${-r * 0.3} Z`} />
);

export const Mosque: React.FC<{ x: number; y: number; s?: number; lit?: boolean; t?: number }> = ({ x, y, s = 1, lit = true, t = 0 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    {/* minarets */}
    {[-150, 150].map((mx) => (
      <g key={mx}>
        <rect x={mx - 20} y={-330} width={40} height={330} fill="#fff" stroke={OUT} strokeWidth={sw} />
        <rect x={mx - 30} y={-250} width={60} height={14} fill={C.data} stroke={OUT} strokeWidth={3} />
        <path d={`M ${mx - 26} -330 L ${mx} -400 L ${mx + 26} -330 Z`} fill={C.data} stroke={OUT} strokeWidth={sw} />
        <path d={`M ${mx} -400 L ${mx} -425`} stroke={OUT} strokeWidth={4} />
        <rect x={mx - 7} y={-300} width={14} height={30} rx={7} fill={lit ? C.gold : C.tint} stroke={OUT} strokeWidth={2} />
      </g>
    ))}
    <rect x={-120} y={-150} width={240} height={150} fill="#fff" stroke={OUT} strokeWidth={sw} />
    <path d="M -100 -150 A 100 100 0 0 1 100 -150 Z" fill={C.data} stroke={OUT} strokeWidth={sw} />
    <path d="M 0 -250 L 0 -290" stroke={OUT} strokeWidth={4} />
    <path d="M -10 -300 A 14 14 0 1 0 8 -280 A 11 11 0 1 1 -10 -300 Z" fill={C.gold} stroke={OUT} strokeWidth={2} />
    <path d="M -34 0 L -34 -60 A 34 34 0 0 1 34 -60 L 34 0 Z" fill={lit ? C.gold : C.tint} stroke={OUT} strokeWidth={sw} />
    {[-90, 90].map((wx) => <rect key={wx} x={wx - 16} y={-110} width={32} height={50} rx={16} fill={lit ? C.gold : C.tint} stroke={OUT} strokeWidth={3} />)}
  </g>
);

export const Tap: React.FC<{ x: number; y: number; t?: number; flowing?: boolean; s?: number }> = ({ x, y, t = 0, flowing = true, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    {/* wall pipe + faucet; (0,0) is the ground under the spout */}
    <rect x={-60} y={-330} width={120} height={330} rx={10} fill={C.tint} stroke={OUT} strokeWidth={sw} />
    <rect x={-80} y={-260} width={160} height={36} rx={10} fill={C.data} stroke={OUT} strokeWidth={sw} />
    <path d="M -20 -224 L -20 -190 Q -20 -170 0 -170 Q 20 -170 20 -190 L 20 -224" fill="none" />
    <path d="M 0 -224 L 0 -200 L 54 -200 L 54 -170" fill="none" stroke={OUT} strokeWidth={22} strokeLinecap="round" strokeLinejoin="round" />
    <path d="M 0 -224 L 0 -200 L 54 -200 L 54 -170" fill="none" stroke={C.data} strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" />
    <rect x={-14} y={-300} width={28} height={40} rx={8} fill={C.accent} stroke={OUT} strokeWidth={3} />
    {flowing && (
      <g>
        <line x1={54} y1={-160} x2={54} y2={-20} stroke={C.flow} strokeWidth={12} strokeLinecap="round" strokeDasharray="18 14" strokeDashoffset={-t * 120} />
      </g>
    )}
    <path d="M -50 -10 Q 54 40 160 -10 L 150 0 Q 54 50 -40 0 Z" fill={C.flow} opacity={0.5} />
  </g>
);

export const Bed: React.FC<{ x: number; y: number; s?: number; asleep?: boolean; blanketUp?: number; t?: number }> = ({ x, y, s = 1, asleep = true, blanketUp = 0, t = 0 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-190} y={-150} width={26} height={150} rx={8} fill={C.night} stroke={OUT} strokeWidth={sw} />
    <rect x={164} y={-90} width={26} height={90} rx={8} fill={C.night} stroke={OUT} strokeWidth={sw} />
    <rect x={-190} y={-70} width={380} height={46} rx={14} fill="#fff" stroke={OUT} strokeWidth={sw} />
    <rect x={-160} y={-96} width={90} height={32} rx={16} fill={C.tint} stroke={OUT} strokeWidth={sw} />
    {asleep && (
      <g>
        <circle cx={-118} cy={-124} r={32} fill={C.skin} stroke={OUT} strokeWidth={sw} />
        <path d="M -132 -122 q 8 6 16 0 M -108 -122 q 8 6 16 0" stroke={OUT} strokeWidth={3} fill="none" />
      </g>
    )}
    {/* blanket */}
    <g transform={`translate(0 ${-blanketUp * 60})`}>
      <path d="M -96 -100 Q -96 -140 -60 -140 L 150 -140 Q 190 -140 190 -100 L 190 -70 L -96 -70 Z" fill={C.data} stroke={OUT} strokeWidth={sw} />
      {[-30, 30, 90, 150].map((bx) => <line key={bx} x1={bx} y1={-135} x2={bx} y2={-76} stroke="#fff" strokeWidth={5} opacity={0.5} />)}
    </g>
    {asleep && (
      <g opacity={0.9}>
        {[0, 1, 2].map((i) => {
          const p = ((t * 0.5 + i / 3) % 1);
          return <text key={i} x={-90 + i * 28 + p * 30} y={-170 - p * 90} fontSize={24 + i * 8} fontFamily="sans-serif" fontWeight={700} fill={C.muted} opacity={1 - p}>z</text>;
        })}
      </g>
    )}
  </g>
);

export const Drop: React.FC<{ x: number; y: number; r?: number; color?: string }> = ({ x, y, r = 14, color = C.flow }) => (
  <path transform={`translate(${x} ${y})`} d={`M 0 ${-r * 1.6} C ${r} ${-r * 0.4} ${r} ${r * 0.9} 0 ${r} C ${-r} ${r * 0.9} ${-r} ${-r * 0.4} 0 ${-r * 1.6} Z`} fill={color} stroke={OUT} strokeWidth={2} />
);

export const Gift: React.FC<{ x: number; y: number; s?: number }> = ({ x, y, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-70} y={-90} width={140} height={90} rx={10} fill={C.accent} stroke={OUT} strokeWidth={sw} />
    <rect x={-80} y={-130} width={160} height={42} rx={10} fill={C.gold} stroke={OUT} strokeWidth={sw} />
    <rect x={-12} y={-130} width={24} height={130} fill="#fff" stroke={OUT} strokeWidth={3} />
    <path d="M 0 -130 C -50 -190 -70 -130 0 -130 C 70 -130 50 -190 0 -130" fill="none" stroke={OUT} strokeWidth={sw} />
  </g>
);

export const Thermo: React.FC<{ x: number; y: number; level: number; s?: number }> = ({ x, y, level, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-22} y={-240} width={44} height={230} rx={22} fill="#fff" stroke={OUT} strokeWidth={sw} />
    <circle cx={0} cy={0} r={40} fill={level < 0.5 ? C.flow : C.bad} stroke={OUT} strokeWidth={sw} />
    <rect x={-10} y={-230 + (1 - level) * 210} width={20} height={(level) * 210} rx={10} fill={level < 0.5 ? C.flow : C.bad} />
    {[0, 1, 2, 3].map((i) => <line key={i} x1={26} y1={-210 + i * 55} x2={44} y2={-210 + i * 55} stroke={OUT} strokeWidth={3} />)}
  </g>
);

export const Book: React.FC<{ x: number; y: number; s?: number; color?: string }> = ({ x, y, s = 1, color = C.good }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <path d="M -120 -80 Q -60 -100 0 -70 L 0 70 Q -60 40 -120 60 Z" fill={color} stroke={OUT} strokeWidth={sw} strokeLinejoin="round" />
    <path d="M 120 -80 Q 60 -100 0 -70 L 0 70 Q 60 40 120 60 Z" fill="#fff" stroke={OUT} strokeWidth={sw} strokeLinejoin="round" />
    {[-30, 0, 30].map((ly) => <line key={ly} x1={30} y1={ly - 20} x2={100} y2={ly - 20 + (ly === 0 ? 0 : 0)} stroke={C.muted} strokeWidth={4} strokeLinecap="round" />)}
  </g>
);

export const Flame: React.FC<{ x: number; y: number; s?: number; t?: number }> = ({ x, y, s = 1, t = 0 }) => (
  <g transform={`translate(${x} ${y}) scale(${s * (1 + Math.sin(t * 9) * 0.04)})`}>
    <path d="M 0 -120 C 60 -60 70 -10 40 20 C 20 40 -20 40 -40 20 C -70 -10 -50 -60 0 -120 Z" fill={C.bad} stroke={OUT} strokeWidth={sw} />
    <path d="M 0 -60 C 30 -30 34 0 18 16 C 6 26 -10 26 -18 16 C -34 0 -24 -30 0 -60 Z" fill={C.gold} />
  </g>
);

export const Chest: React.FC<{ x: number; y: number; s?: number; open?: number }> = ({ x, y, s = 1, open = 0 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-90} y={-80} width={180} height={80} rx={10} fill={C.accent} stroke={OUT} strokeWidth={sw} />
    <g transform={`rotate(${-open * 35} -90 -80)`}>
      <path d="M -90 -80 Q -90 -150 0 -150 Q 90 -150 90 -80 Z" fill={C.warn} stroke={OUT} strokeWidth={sw} />
    </g>
    <rect x={-14} y={-90} width={28} height={36} rx={6} fill={C.gold} stroke={OUT} strokeWidth={3} />
    {open > 0.3 && [-40, 0, 40].map((cx, i) => <circle key={i} cx={cx} cy={-100 - open * 12} r={14} fill={C.gold} stroke={OUT} strokeWidth={3} />)}
  </g>
);

export const Swords: React.FC<{ x: number; y: number; s?: number }> = ({ x, y, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} stroke={OUT} strokeWidth={sw} strokeLinecap="round">
    <g transform="rotate(40)"><rect x={-9} y={-90} width={18} height={140} fill={C.muted} /><rect x={-30} y={40} width={60} height={12} fill={C.warn} /><rect x={-8} y={52} width={16} height={34} fill={C.night} /></g>
    <g transform="rotate(-40)"><rect x={-9} y={-90} width={18} height={140} fill={C.muted} /><rect x={-30} y={40} width={60} height={12} fill={C.warn} /><rect x={-8} y={52} width={16} height={34} fill={C.night} /></g>
  </g>
);

export const Cloud: React.FC<{ x: number; y: number; s?: number; color?: string }> = ({ x, y, s = 1, color = "#fff" }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} fill={color} stroke={OUT} strokeWidth={3}>
    <path d="M -70 0 Q -90 -30 -55 -38 Q -40 -75 0 -60 Q 30 -85 60 -50 Q 100 -50 90 -10 Q 90 10 60 10 L -55 10 Q -70 10 -70 0 Z" />
  </g>
);

export const Footprint: React.FC<{ x: number; y: number; rot?: number; color?: string; opacity?: number }> = ({ x, y, rot = 0, color = C.data, opacity = 1 }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot})`} opacity={opacity} fill={color}>
    <ellipse cx={0} cy={0} rx={13} ry={20} />
    <ellipse cx={0} cy={26} rx={10} ry={8} />
  </g>
);

export const Tower: React.FC<{ x: number; y: number; s?: number }> = ({ x, y, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <path d="M -70 0 L -50 -260 L 50 -260 L 70 0 Z" fill={C.tint} stroke={OUT} strokeWidth={sw} strokeLinejoin="round" />
    <rect x={-80} y={-300} width={160} height={46} fill="#fff" stroke={OUT} strokeWidth={sw} />
    {[-70, -30, 10, 50].map((bx) => <rect key={bx} x={bx} y={-326} width={22} height={28} fill="#fff" stroke={OUT} strokeWidth={3} />)}
    <path d="M 0 -300 L 0 -420 L 70 -400 L 0 -380" fill={C.accent} stroke={OUT} strokeWidth={sw} strokeLinejoin="round" />
    <rect x={-22} y={-110} width={44} height={110} rx={22} fill={C.night} />
  </g>
);

export const Globe: React.FC<{ x: number; y: number; r?: number; tilt?: number; t?: number }> = ({ x, y, r = 120, tilt = 23.5, t = 0 }) => (
  <g transform={`translate(${x} ${y})`}>
    <g transform={`rotate(${tilt})`}>
      <line x1={0} y1={-r * 1.45} x2={0} y2={r * 1.45} stroke={OUT} strokeWidth={5} strokeLinecap="round" />
      <circle r={r} fill={C.flow} stroke={OUT} strokeWidth={sw} />
      <ellipse cx={Math.sin(t) * 20} rx={r * 0.55} ry={r} fill="none" stroke="#fff" strokeWidth={3} opacity={0.6} />
      <ellipse rx={r} ry={r * 0.25} fill="none" stroke="#fff" strokeWidth={3} opacity={0.6} />
      <path d={`M ${-r * 0.5} ${-r * 0.5} q 40 -30 70 0 q 20 40 -30 60 q -50 10 -40 -60 Z`} fill={C.cloth2} opacity={0.9} />
      <path d={`M ${r * 0.1} ${r * 0.2} q 50 -20 70 20 q 0 50 -50 40 q -40 -10 -20 -60 Z`} fill={C.cloth2} opacity={0.9} />
    </g>
  </g>
);

export const Hand: React.FC<{ x: number; y: number; s?: number; wet?: number; cold?: number }> = ({ x, y, s = 1, wet = 0, cold = 0 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-45} y={-10} width={90} height={80} rx={26} fill={cold > 0.5 ? "#CFE6F7" : C.skin} stroke={OUT} strokeWidth={sw} />
    {[-33, -11, 11, 33].map((fx, i) => (
      <rect key={fx} x={fx - 10} y={-80 + (i === 1 || i === 2 ? -14 : 0)} width={20} height={80 + (i === 1 || i === 2 ? 14 : 0)} rx={10} fill={cold > 0.5 ? "#CFE6F7" : C.skin} stroke={OUT} strokeWidth={sw} />
    ))}
    {wet > 0 && [-33, -11, 11, 33].map((fx, i) => <Drop key={i} x={fx} y={-86 + (i === 1 || i === 2 ? -14 : 0)} r={7 * wet} />)}
  </g>
);

export const Gap: React.FC = () => null;
