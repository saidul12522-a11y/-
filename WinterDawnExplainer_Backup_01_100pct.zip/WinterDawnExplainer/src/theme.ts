// Scheme 4 "Frosty light" (user wanted a light background). Never write hex values elsewhere.
export const theme = {
  bg: "#EEF4FA",
  surface: "#FFFFFF",
  surfaceHi: "#FFFFFF",
  tint: "#DCE8F5", // soft blue panel
  border: "rgba(16,35,58,0.14)",
  text: "#10233A",
  muted: "#5B6E86",
  accent: "#E07A1F", // dawn orange: "look here"
  onAccent: "#10233A",
  data: "#2B6CB0", // primary blue: information
  flow: "#4C9AD6",
  good: "#2E9A4A",
  warn: "#E89808",
  bad: "#D9443A",
  night: "#1B2F4D",
  gold: "#F2B33D",
  skin: "#F1C9A0",
  cloth: "#2B6CB0",
  cloth2: "#2E9A4A",
} as const;
export type Theme = typeof theme;
