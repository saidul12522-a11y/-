# Winter Dawn Explainer (SUL channel) - Remotion project

16:9, 1920x1080, 30 FPS, MP4. Bengali voiceover (234.03 s) + in-video captions + 15 animated 2D diagram scenes.
Theme: light "Frosty" (bg #EEF4FA, primary #2B6CB0, accent #E07A1F, text #10233A). Font: Hind Siliguri.

## Windows PC setup
1. Install Node.js LTS (v20 or v22) from nodejs.org. Chrome/Chromium is found or downloaded by Remotion automatically.
2. Open a terminal in this folder (the one containing package.json).

First time only:

    npm install

Preview in Remotion Studio:

    npm run dev

Render MP4 (output: out/winter-dawn.mp4):

    npm run render

Composition id: `WinterDawn`, entry: `src/index.ts`. Internet is needed on the first run
(npm packages + Google font Hind Siliguri).

## Structure
- `public/voice.mp3` voiceover, `public/logo.jpg` SUL logo, `public/subtitles/original.srt` and `corrected.srt`
- `src/sceneList.ts` scene timings + storyboard, `src/scenes/s1..s5.tsx` scenes, `src/art/art.tsx` icon-style art
- `src/components/` Caption, Background, kit (Chip, Card, In ...), `src/timing.json` word timing, `src/corrections.json`
- `scripts/build-timing.mjs` regenerates corrected SRT + timing from original.srt (`npm run timing`)
- `PROGRESS.md` full work log

## Notes
Word timings come from the SRT cues (words split by letter count inside each cue); no speech recognition was available.
