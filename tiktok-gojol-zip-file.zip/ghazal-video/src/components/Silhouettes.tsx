import React from 'react';
import {alpha, theme} from '../theme';
import {ramp, rng, useScene, useUid} from '../lib';
import {Glow} from './Art';

const c = theme.colors;

/** Smartphone with scrolling feed (abstract cards — no text). */
export const Phone: React.FC<{x: number; y: number; s?: number; on?: number; scroll?: number; tilt?: number; glow?: string}> = ({x, y, s = 1, on = 1, scroll = 0, tilt = 0, glow = c.heroMist}) => {
  const id = useUid('ph');
  const r = rng(11);
  const cards = Array.from({length: 9}, () => ({h: 70 + r() * 110, hue: r()}));
  let acc = 0;
  const layout = cards.map((k) => { const o = {y: acc, ...k}; acc += k.h + 22; return o; });
  const total = acc;
  return (
    <g transform={`translate(${x},${y}) rotate(${tilt}) scale(${s})`}>
      <Glow cx={0} cy={0} r={560} color={glow} opacity={0.5 * on} />
      <defs><clipPath id={id}><rect x={-128} y={-250} width={256} height={500} rx={26} /></clipPath></defs>
      <rect x={-142} y={-264} width={284} height={528} rx={38} fill={c.text} stroke={alpha(c.heroMist, 0.5)} strokeWidth={3} />
      <rect x={-128} y={-250} width={256} height={500} rx={26} fill={mixScreen(on)} />
      <g clipPath={`url(#${id})`} opacity={on}>
        <g transform={`translate(0,${-((scroll % total)) })`}>
          {[0, 1].map((rep) => layout.map((k, i) => (
            <g key={`${rep}-${i}`} transform={`translate(-112,${-232 + k.y + rep * total})`}>
              <rect width={224} height={k.h} rx={14} fill={alpha(c.bg, 0.16)} />
              <circle cx={22} cy={22} r={13} fill={alpha(c.accent, 0.8)} />
              <rect x={44} y={14} width={90} height={8} rx={4} fill={alpha(c.bg, 0.5)} />
              <rect x={44} y={28} width={56} height={6} rx={3} fill={alpha(c.bg, 0.3)} />
              <rect x={12} y={48} width={200} height={Math.max(14, k.h - 64)} rx={9} fill={alpha(c.heroMist, 0.2 + k.hue * 0.2)} />
            </g>
          )))}
        </g>
      </g>
      <rect x={-34} y={-262} width={68} height={10} rx={5} fill={c.text} />
    </g>
  );
};
const mixScreen = (on: number) => (on > 0.05 ? c.nightMid : c.text);

const Hand: React.FC<{flip?: boolean}> = ({flip}) => (
  <g transform={flip ? 'scale(-1,1)' : undefined} stroke="currentColor" strokeLinecap="round" fill="currentColor">
    <rect x={-40} y={-4} width={80} height={110} rx={34} stroke="none" />
    {[[-30, -8, -36, -78], [-10, -10, -12, -104], [10, -10, 12, -96], [30, -6, 38, -68]].map(([x1, y1, x2, y2], i) => (
      <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} strokeWidth={19} fill="none" />
    ))}
    <line x1={-34} y1={60} x2={-76} y2={16} strokeWidth={21} fill="none" />
  </g>
);

/** Raised dua hands silhouette (two open palms forming a cup) with sleeves + rim light. */
export const DuaHands: React.FC<{x: number; y: number; s?: number; color?: string; rim?: string}> = ({x, y, s = 1, color = c.text, rim = c.accent}) => {
  const {f} = useScene();
  const sway = Math.sin(f / 34) * 1.2;
  return (
    <g transform={`translate(${x},${y}) scale(${s}) rotate(${sway})`}>
      <g style={{color}} fill={color}>
        <path d="M -104 70 Q 0 214 104 70 L 104 130 Q 0 250 -104 130 Z" />
        <g transform="translate(-96,0) rotate(-15)">
          <path d="M -46 96 L -70 340 L 44 340 L 42 96 Z" />
          <Hand flip />
        </g>
        <g transform="translate(96,0) rotate(15)">
          <path d="M 46 96 L 70 340 L -44 340 L -42 96 Z" />
          <Hand />
        </g>
      </g>
      <g fill="none" stroke={rim} strokeWidth={2.4} opacity={0.7} strokeLinecap="round">
        <path d="M -104 70 Q 0 214 104 70" />
      </g>
    </g>
  );
};

/** Person in sujood (side view), facing left. */
export const Sujood: React.FC<{x: number; y: number; s?: number; color?: string; rim?: string; appear?: number}> = ({x, y, s = 1, color = c.text, rim = c.accent, appear = 1}) => {
  const {f} = useScene();
  const breathe = 1 + Math.sin(f / 40) * 0.006;
  return (
    <g transform={`translate(${x},${y}) scale(${s * breathe}) translate(0,${(1 - appear) * 24})`} opacity={appear}>
      <g stroke={color} strokeLinecap="round" fill={color}>
        <circle cx={44} cy={-34} r={27} stroke="none" />
        <path d="M 100 -58 Q 180 -158 262 -116" fill="none" strokeWidth={70} />
        <path d="M 262 -116 L 316 -36" fill="none" strokeWidth={62} />
        <path d="M 316 -36 L 408 -26" fill="none" strokeWidth={36} />
        <path d="M 102 -60 L 78 -16" fill="none" strokeWidth={26} />
      </g>
      <path d="M 100 -92 Q 180 -190 262 -148" fill="none" stroke={rim} strokeWidth={2.4} opacity={0.75} />
      <ellipse cx={210} cy={2} rx={250} ry={5} fill={alpha(c.text, 0.5)} />
    </g>
  );
};

/** Simple standing figure (robe silhouette). */
export const Figure: React.FC<{x: number; y: number; s?: number; color?: string; walk?: number; arms?: boolean}> = ({x, y, s = 1, color = c.text, walk = 0}) => (
  <g transform={`translate(${x},${y}) scale(${s})`} fill={color}>
    <circle cx={0} cy={-104 + Math.sin(walk) * 1.5} r={14} />
    <path d={`M -16 -86 Q 0 -94 16 -86 L 26 0 L -26 0 Z`} />
    <rect x={-9} y={-100} width={18} height={6} rx={3} />
  </g>
);

export const Hourglass: React.FC<{x: number; y: number; s?: number; t: number; color?: string; sand?: string}> = ({x, y, s = 1, t, color = c.bg, sand = c.accent}) => {
  const id = useUid('hg');
  const top = 1 - t, bot = t;
  return (
    <g transform={`translate(${x},${y}) scale(${s})`}>
      <Glow cx={0} cy={0} r={330} opacity={0.28} />
      <defs>
        <clipPath id={id + 't'}><path d="M -92 -150 L 92 -150 L 10 -4 L -10 -4 Z" /></clipPath>
        <clipPath id={id + 'b'}><path d="M -10 4 L 10 4 L 92 150 L -92 150 Z" /></clipPath>
      </defs>
      <g clipPath={`url(#${id}t)`}><rect x={-100} y={-4 - 146 * top} width={200} height={146 * top + 2} fill={sand} /></g>
      <g clipPath={`url(#${id}b)`}><rect x={-100} y={150 - 146 * bot} width={200} height={146 * bot} fill={sand} /></g>
      {t > 0.01 && t < 0.99 && <rect x={-1.6} y={-4} width={3.2} height={156 - 146 * bot + 0} fill={sand} opacity={0.9} />}
      <path d="M -92 -150 L 92 -150 L 10 -4 L 10 4 L 92 150 L -92 150 L -10 4 L -10 -4 Z" fill="none" stroke={color} strokeWidth={5} strokeLinejoin="round" opacity={0.95} />
      <rect x={-112} y={-166} width={224} height={16} rx={8} fill={color} />
      <rect x={-112} y={150} width={224} height={16} rx={8} fill={color} />
    </g>
  );
};

/** Stylised eye; `lid` 0 = open, 1 = closed. */
export const Eye: React.FC<{x: number; y: number; s?: number; lid: number; look?: number; reflect?: number}> = ({x, y, s = 1, lid, look = 0, reflect = 1}) => {
  const id = useUid('ey');
  const shape = 'M -190 0 Q 0 -150 190 0 Q 0 150 -190 0 Z';
  return (
    <g transform={`translate(${x},${y}) scale(${s})`}>
      <defs><clipPath id={id}><path d={shape} /></clipPath></defs>
      <path d={shape} fill={c.bg} />
      <g clipPath={`url(#${id})`}>
        <g transform={`translate(0,${look})`}>
          <circle r={78} fill={c.hero} />
          <circle r={78} fill="none" stroke={c.accent} strokeWidth={5} />
          <circle r={34} fill={c.text} />
          <g opacity={reflect}><rect x={-40} y={-44} width={34} height={52} rx={6} fill={alpha(c.bg, 0.85)} /><rect x={-34} y={-36} width={22} height={6} rx={3} fill={c.accent} /></g>
        </g>
        <path d={`M -200 -160 L 200 -160 L 200 ${-160 + lid * 160} Q 0 ${-160 + lid * 160 + 60 + lid * 90} -200 ${-160 + lid * 160} Z`} fill={c.nightSoft} />
      </g>
      <path d={shape} fill="none" stroke={c.accent} strokeWidth={5} strokeLinejoin="round" />
      {Array.from({length: 7}, (_, i) => {
        const a = (-55 + i * 18) * Math.PI / 180;
        const bx = Math.sin(a) * 150, by = -Math.cos(a) * 118 * (1 - lid * 0.9) + lid * 70;
        return <line key={i} x1={bx} y1={by} x2={bx * 1.12} y2={by - 26 * (1 - lid * 0.6)} stroke={c.accent} strokeWidth={4} strokeLinecap="round" opacity={0.8} />;
      })}
    </g>
  );
};

/** Battery with fill 0..1, optional star mark. */
export const Battery: React.FC<{x: number; y: number; s?: number; fill: number; color?: string; fillColor?: string; mark?: boolean; pulse?: number}> = ({x, y, s = 1, fill, color = c.bg, fillColor = c.accent, mark, pulse = 0}) => {
  const id = useUid('bt');
  return (
    <g transform={`translate(${x},${y}) scale(${s})`}>
      <defs><clipPath id={id}><rect x={-150} y={-70} width={300} height={140} rx={22} /></clipPath></defs>
      <rect x={-150} y={-70} width={300} height={140} rx={22} fill={alpha(c.text, 0.5)} />
      <g clipPath={`url(#${id})`}>
        <rect x={-150} y={-70} width={300 * fill} height={140} fill={fillColor} opacity={0.88 + pulse * 0.12} />
      </g>
      <rect x={-150} y={-70} width={300} height={140} rx={22} fill="none" stroke={color} strokeWidth={8} />
      <rect x={156} y={-24} width={20} height={48} rx={8} fill={color} />
      {mark && (
        <g opacity={ramp(fill, 0.2, 0.6)} transform="scale(0.72)" fill="none" stroke={c.text} strokeWidth={4}>
          <rect x={-40} y={-40} width={80} height={80} /><rect x={-40} y={-40} width={80} height={80} transform="rotate(45)" />
        </g>
      )}
    </g>
  );
};

export const Lantern: React.FC<{x: number; y: number; s?: number; lit: number; color?: string}> = ({x, y, s = 1, lit, color = c.text}) => {
  const {f} = useScene();
  const fl = lit * (0.85 + 0.15 * Math.sin(f / 6 + x));
  return (
    <g transform={`translate(${x},${y}) scale(${s})`}>
      <Glow cx={0} cy={70} r={240} opacity={0.55 * fl} />
      <line x1={0} y1={-400} x2={0} y2={0} stroke={alpha(c.bg, 0.4)} strokeWidth={2} />
      <circle cx={0} cy={4} r={9} fill="none" stroke={c.accent} strokeWidth={3} />
      <path d="M -34 14 L 34 14 L 52 48 L -52 48 Z" fill={color} />
      <path d="M -52 48 L 52 48 L 62 130 L 0 160 L -62 130 Z" fill={alpha(c.accent, 0.25 + 0.75 * fl)} stroke={color} strokeWidth={7} strokeLinejoin="round" />
      <path d="M -62 130 L 62 130 L 40 164 L -40 164 Z" fill={color} />
      <path d="M 0 60 L 0 130 M -30 90 L 30 90" stroke={color} strokeWidth={5} />
    </g>
  );
};

export const Alarm: React.FC<{x: number; y: number; s?: number; off: number}> = ({x, y, s = 1, off}) => {
  const {f} = useScene();
  const ring = (1 - off) * Math.sin(f * 1.4) * 8;
  return (
    <g transform={`translate(${x},${y}) scale(${s})`}>
      <g transform={`rotate(${ring})`}>
        <path d="M -60 40 Q -60 -70 0 -80 Q 60 -70 60 40 L 74 62 L -74 62 Z" fill={c.accent} />
        <circle cx={0} cy={74} r={13} fill={c.accent} />
        <circle cx={0} cy={-88} r={9} fill={c.accent} />
      </g>
      <line x1={-84} y1={-84} x2={84 * off} y2={84 * off - 0} stroke={c.bg} strokeWidth={10} strokeLinecap="round" opacity={off} transform={`scale(1,1)`} />
    </g>
  );
};

export const Drop: React.FC<{x: number; y: number; s?: number; color?: string; opacity?: number}> = ({x, y, s = 1, color = c.bg, opacity = 1}) => (
  <path d="M 0 -20 C 14 -2 14 14 0 14 C -14 14 -14 -2 0 -20 Z" transform={`translate(${x},${y}) scale(${s})`} fill={color} opacity={opacity} />
);
