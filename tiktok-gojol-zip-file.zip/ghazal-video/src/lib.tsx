import React, {createContext, useContext, useId} from 'react';
import {interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme} from './theme';

export const ramp = (
  f: number, a: number, b: number, v0 = 0, v1 = 1, easing: (t: number) => number = theme.ease.out,
) => interpolate(f, [a, b], [v0, v1], {easing, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

export const rng = (seed: number) => {
  let s = (seed * 9301 + 49297) % 233280 || 1;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
};

export const useUid = (p = 'u') => p + useId().replace(/[^a-zA-Z0-9]/g, '');

export type Tone = 'night' | 'dawn' | 'light';
export const SceneCtx = createContext<{from: number; to: number; tone: Tone}>({from: 0, to: 1, tone: 'night'});

/** Scene clock: local frame, absolute frame/seconds, and sec->local-frame converter. */
export const useScene = () => {
  const f = useCurrentFrame();
  const c = useContext(SceneCtx);
  const {fps} = useVideoConfig();
  return {
    ...c, f, fps, abs: f + c.from, sec: (f + c.from) / fps, len: c.to - c.from,
    local: (sec: number) => Math.round(sec * fps) - c.from,
  };
};

export const SW = 1400; // stage width
export const SH = 800; // stage height

export const SvgStage: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <svg viewBox={`0 0 ${SW} ${SH}`} width={SW} height={SH} style={{position: 'absolute', left: 0, top: 0, ...style}}>
    {children}
  </svg>
);

/** Slow cinematic camera: zoom + pan applied to a whole layer. */
export const Camera: React.FC<{
  children: React.ReactNode; zoom?: [number, number]; pan?: [number, number]; origin?: string; depth?: number;
}> = ({children, zoom = [1, 1.07], pan = [0, 0], origin = '50% 60%', depth = 1}) => {
  const {f, len} = useScene();
  const t = interpolate(f, [0, len], [0, 1], {easing: theme.ease.soft, extrapolateRight: 'clamp'});
  const z = 1 + (zoom[0] - 1) * depth + (zoom[1] - zoom[0]) * t * depth;
  return (
    <div style={{position: 'absolute', inset: 0, transformOrigin: origin,
      transform: `translate(${pan[0] * t * depth}px, ${pan[1] * t * depth}px) scale(${z})`}}>
      {children}
    </div>
  );
};

export const archPath = (w: number, h: number, inset = 0) => {
  const a = inset, W = w - inset, H = h - inset, cx = w / 2, sh = Math.round(h * 0.4);
  return `M ${a} ${H} L ${a} ${sh} C ${a} ${sh - 200} ${cx - 300} ${a + 60} ${cx} ${a} C ${cx + 300} ${a + 60} ${W} ${sh - 200} ${W} ${sh} L ${W} ${H} Z`;
};
