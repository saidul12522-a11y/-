// Dev helper: renders every scene function for every frame with react-dom/server (no browser) to catch runtime errors.
// Run via:  npx esbuild scripts/smoke-test.tsx --bundle --platform=node --outfile=out/smoke.cjs --loader:.json=json && node out/smoke.cjs
import React from "react";
import { renderToString } from "react-dom/server";
import { SCENES } from "../src/sceneList";
import { CHUNKS, captionState } from "../src/captions";
import { TOTAL_FRAMES, FPS } from "../src/layout";

let errors = 0, rendered = 0;
for (let f = 0; f < TOTAL_FRAMES; f++) {
  const t = f / FPS;
  for (let i = 0; i < SCENES.length; i++) {
    const s = SCENES[i], next = SCENES[i + 1];
    if (!(t >= s.start && t < (next ? next.start + 0.4 : s.end))) continue;
    try { renderToString(React.createElement(s.C, { t })); rendered++; }
    catch (e) { errors++; if (errors < 6) console.log("ERR", s.id, f, String(e)); }
  }
  captionState(t);
}
console.log({ frames: TOTAL_FRAMES, sceneRenders: rendered, errors, chunks: CHUNKS.length });
