// Dev helper: render a few stills for visual checks.  node scripts/preview-frames.mjs 3.0 12.5 40 ...  (seconds)
// Optional env: BROWSER_EXE=/path/to/chrome  (Remotion normally finds/downloads Chrome itself)
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import { bundle } from "@remotion/bundler";
import { renderStill, selectComposition } from "@remotion/renderer";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const secs = process.argv.slice(2).map(Number);
const out = path.join(root, "out", "preview");
fs.mkdirSync(out, { recursive: true });
const serveUrl = await bundle({ entryPoint: path.join(root, "src/index.ts") });
const opts = { serveUrl, browserExecutable: process.env.BROWSER_EXE || undefined, chromiumOptions: { gl: "swangle" }, logLevel: "error" };
const comp = await selectComposition({ ...opts, id: "ChatGPTIndia" });
for (const s of secs) {
  const frame = Math.min(comp.durationInFrames - 1, Math.round(s * 30));
  await renderStill({ ...opts, composition: comp, frame, output: path.join(out, `t${s.toFixed(1).padStart(6, "0")}.png`), imageFormat: "png" });
  console.log("frame", frame);
}
