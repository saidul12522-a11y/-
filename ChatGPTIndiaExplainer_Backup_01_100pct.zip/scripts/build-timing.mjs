// Reads public/subtitles/original.srt (+ scripts/silences.json)
// -> writes public/subtitles/corrected.srt, src/timing.json, src/corrections.json
// Word timing = SRT cue time, distributed over the *speech* part of the cue (pauses found with ffmpeg silencedetect are skipped).
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const AUDIO_SECONDS = 178.756;
// Set to true to turn "ChatGPT's" / "AI's" into "ChatGPT-র" / "AI-র" (unverified guess, so OFF by default).
const FIX_POSSESSIVE = false;

const seg = new Intl.Segmenter("bn", { granularity: "grapheme" });
const glen = (s) => [...seg.segment(s)].length;
const toBn = (s) => s.replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[d]);
const tc = (h, m, s, ms) => +h * 3600 + +m * 60 + +s + +ms.padEnd(3, "0") / 1000;
const fmt = (t) => {
  const ms = Math.round(t * 1000);
  const p = (n, l = 2) => String(n).padStart(l, "0");
  return `${p(Math.floor(ms / 3600000))}:${p(Math.floor(ms / 60000) % 60)}:${p(Math.floor(ms / 1000) % 60)},${p(ms % 1000, 3)}`;
};

// ---- parse SRT (rebuild cues from the "-->" lines) ----
const raw = fs.readFileSync(path.join(root, "public/subtitles/original.srt"), "utf8").replace(/^﻿/, "").replace(/\r/g, "").trim();
const lines = raw.split("\n").map((l) => l.trim());
let cues = [];
for (let i = 0; i < lines.length; i++) {
  const m = lines[i].match(/(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) continue;
  let j = i + 1;
  const text = [];
  while (j < lines.length && !/-->/.test(lines[j])) {
    if (/^\d+$/.test(lines[j]) && j + 1 < lines.length && /-->/.test(lines[j + 1])) break;
    if (lines[j]) text.push(lines[j]);
    j++;
  }
  cues.push({ n: cues.length + 1, s: tc(m[1], m[2], m[3], m[4]), e: tc(m[5], m[6], m[7], m[8]), text: text.join(" ").replace(/\s+/g, " ").trim() });
}
const origCount = cues.length;

// ---- corrections (tier A = certain) ----
const log = [];
// 1) merge the 0.38 s cue "উঠছে।" into the cue before it (cue 40 + 41)
{
  const k = cues.findIndex((c) => c.text === "উঠছে।");
  if (k > 0 && cues[k].e - cues[k].s < 0.6) {
    log.push({ cue: cues[k].n, time: fmt(cues[k].s), before: `cue ${cues[k - 1].n} + cue ${cues[k].n} (0.38 s)`, after: "one cue", evidence: "a one-word 0.38 s cue; merged for readable captions, no word removed", tier: "A" });
    cues[k - 1] = { ...cues[k - 1], e: cues[k].e, text: cues[k - 1].text + " " + cues[k].text };
    cues.splice(k, 1);
  }
}
// 2) text fixes
cues = cues.map((c) => {
  let t = c.text;
  const step = (before, after, evidence) => { if (before !== after) log.push({ cue: c.n, time: fmt(c.s), before: before.length > 60 ? before.slice(0, 60) + "..." : before, after: after.length > 60 ? after.slice(0, 60) + "..." : after, evidence, tier: "A" }); };
  let u = t.replace(/\[[^\]]*শব্দ[^\]]*\]\s*/g, "");
  step("[শ্বাস নেওয়ার শব্দ]", u === t ? "[শ্বাস নেওয়ার শব্দ]" : "(removed)", "bracketed sound note, not a spoken word");
  t = u;
  if (FIX_POSSESSIVE) {
    u = t.replace(/(AI|ChatGPT)'s/g, "$1-র");
    step("'s", "-র", "English possessive inside a Bengali sentence");
    t = u;
  }
  u = toBn(t);
  if (u !== t) log.push({ cue: c.n, time: fmt(c.s), before: t.match(/\d+/g).join(", "), after: u.match(/[০-৯]+/g).join(", "), evidence: "voiceover is Bengali; digits unified to Bengali numerals", tier: "A" });
  return { ...c, text: u };
});

// ---- suspects (not changed) ----
const suspects = [];
cues.forEach((c) => {
  if (/(AI|ChatGPT)'s/.test(c.text)) suspects.push({ time: fmt(c.s), text: `'${c.text.match(/(AI|ChatGPT)'s/)[0]}' - English possessive 's in a Bengali sentence; the spoken form could not be verified (no speech recognition offline). Kept as in SRT. Set FIX_POSSESSIVE=true in scripts/build-timing.mjs to turn it into -র` });
});
suspects.push({ time: "00:00:00-00:02:58", text: "English words inside Bengali captions (retention, App, product, content, subscribe, February, Altman এর) kept exactly as in the SRT" });

// ---- speech spans from ffmpeg silencedetect ----
const sil = JSON.parse(fs.readFileSync(path.join(root, "scripts/silences.json"), "utf8")).silences;
// snap cue start back to speech onset when a silence ends just before the cue start
let prevEnd = 0;
cues = cues.map((c) => {
  const near = sil.filter((x) => x.e >= c.s - 0.45 && x.e <= c.s + 0.1).sort((a, b) => b.e - a.e)[0];
  const s = near ? near.e : c.s;
  prevEnd = c.e;
  return { ...c, s: Math.min(s, c.s), sOrig: c.s };
});
// a cue must not run past the (snapped) start of the next cue
for (let i = 1; i < cues.length; i++) if (cues[i - 1].e > cues[i].s) cues[i - 1].e = cues[i].s;
function spansOf(a, b) {
  let spans = [[a, b]];
  for (const x of sil) {
    spans = spans.flatMap(([p, q]) => {
      if (x.e <= p || x.s >= q) return [[p, q]];
      const out = [];
      if (x.s > p) out.push([p, x.s]);
      if (x.e < q) out.push([x.e, q]);
      return out;
    });
  }
  spans = spans.filter(([p, q]) => q - p > 0.04);
  // a tiny leftover at the very edge of a cue is not a spoken word (it is the start of the next cue's speech)
  while (spans.length > 1 && spans.at(-1)[1] - spans.at(-1)[0] < 0.15) spans.pop();
  while (spans.length > 1 && spans[0][1] - spans[0][0] < 0.15) spans.shift();
  return spans;
}
const spanLen = (sp) => sp.reduce((a, [p, q]) => a + (q - p), 0);
// map speech-time offset (0..T) inside `spans` to absolute time
function toAbs(spans, off) {
  let o = off;
  for (const [p, q] of spans) { if (o <= q - p + 1e-9) return p + o; o -= q - p; }
  return spans.at(-1)[1];
}
const words = [];
for (const c of cues) {
  const ws = c.text.split(" ").filter(Boolean);
  const wt = ws.map((w) => Math.max(1, glen(w)));
  const spans = spansOf(c.s, c.e);
  if (!spans.length) spans.push([c.s, c.e]);
  const T = spanLen(spans);
  const tot = wt.reduce((a, b) => a + b, 0);
  // cumulative proportional word boundaries in speech time
  const cum = [0]; wt.forEach((x) => cum.push(cum.at(-1) + (x / tot) * T));
  // anchors: internal gaps between speech spans -> nearest word boundary (prefer after punctuation)
  const anchors = []; // {j, spanIdx} word j starts the span spanIdx
  let acc = 0;
  for (let k = 0; k < spans.length - 1; k++) {
    acc += spans[k][1] - spans[k][0];
    let best = null;
    for (let j = 1; j < ws.length; j++) {
      if (anchors.length && j <= anchors.at(-1).j) continue;
      const d = Math.abs(cum[j] - acc);
      const punct = /[।,?!;:]$/.test(ws[j - 1]);
      const score = d - (punct ? 0.5 : 0);
      if (d <= 0.9 && (!best || score < best.score)) best = { j, score };
    }
    if (best) anchors.push({ j: best.j, spanIdx: k + 1 });
  }
  // allocate words to span groups
  const groups = []; // {w0,w1,spans}
  let w0 = 0, sp0 = 0;
  for (const a of anchors) { groups.push({ w0, w1: a.j, spans: spans.slice(sp0, a.spanIdx) }); w0 = a.j; sp0 = a.spanIdx; }
  groups.push({ w0, w1: ws.length, spans: spans.slice(sp0) });
  for (const g of groups) {
    const gw = wt.slice(g.w0, g.w1), gt = gw.reduce((a, b) => a + b, 0), GT = spanLen(g.spans);
    let off = 0;
    for (let i = g.w0; i < g.w1; i++) {
      const d = (wt[i] / gt) * GT;
      words.push({ w: ws[i], s: +toAbs(g.spans, off).toFixed(3), e: +toAbs(g.spans, off + d).toFixed(3) });
      off += d;
    }
  }
}

// ---- checks ----
let onSilence = 0;
for (const w of words) for (const x of sil) { const ov = Math.min(w.e, x.e) - Math.max(w.s, x.s); if (ov > 0.15 && x.e - x.s >= 0.3) onSilence++; }
const avg = words.reduce((a, w) => a + (w.e - w.s), 0) / words.length;

fs.writeFileSync(path.join(root, "public/subtitles/corrected.srt"), cues.map((c, i) => `${i + 1}\n${fmt(c.sOrig)} --> ${fmt(c.e)}\n${c.text}\n`).join("\n"));
fs.writeFileSync(path.join(root, "src/timing.json"), JSON.stringify({ audioSeconds: AUDIO_SECONDS, mode: "srt+silence", cues: cues.map(({ sOrig, ...c }) => c), words }, null, 1));
fs.writeFileSync(path.join(root, "src/corrections.json"), JSON.stringify({ corrections: log, suspects, checks: { originalCues: origCount, finalCues: cues.length, words: words.length, wordsOnLongSilence: onSilence, avgWordSeconds: +avg.toFixed(3), lastCueEnd: fmt(cues.at(-1).e), audioSeconds: AUDIO_SECONDS } }, null, 1));
console.log({ origCount, cues: cues.length, words: words.length, corrections: log.length, onSilence, avg: avg.toFixed(3), last: fmt(cues.at(-1).e) });
