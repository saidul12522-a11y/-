import React from "react";
import { SceneHook, SceneShopStart, SceneShopRatio } from "./scenes/s1";
import { SceneRankSwap, SceneDoubt, SceneTool } from "./scenes/s2";
import { SceneAppRetention, SceneLoyal, SceneFear1, SceneFear2 } from "./scenes/s3";
import { SceneDoThis, SceneStudents, SceneAsset, SceneRace } from "./scenes/s4";
import { SceneOutro } from "./scenes/s5";

export type SceneDef = { id: string; title: string; start: number; end: number; C: React.FC<{ t: number }> };

/**
 * Storyboard (seconds, from the voiceover / corrected SRT):
 * 01 hook        India passes America in users, "why?"
 * 02 shopStart   step 1: chai shop, 100 customers, 5 return = retention
 * 03 shopRatio   5 of 100, one in every 20, shop cannot survive
 * 04 appRetention same for an app: ChatGPT ~5%
 * 05 loyal       he did not stop; the few who returned were satisfied
 * 06 rankSwap    step 2: 10 crore weekly users in February, India passes America
 * 07 doubt       America doubts big tech power
 * 08 tool        India uses AI as a tool; worry ahead
 * 09 fear1       step 3: control handed to AI
 * 10 fear2       power in a few hands
 * 11 doThis      step 4: make AI part of work, build skill
 * 12 students    from students to business people
 * 13 asset       a good question is a big asset
 * 14 race        some still thinking, some already moving
 * 15 outro       logo, like, comment, subscribe
 */
export const SCENES: SceneDef[] = [
  { id: "hook", title: "Hook", start: 0, end: 21.2, C: SceneHook },
  { id: "shopStart", title: "Chai shop", start: 21.2, end: 35.7, C: SceneShopStart },
  { id: "shopRatio", title: "One in 20", start: 35.7, end: 46.3, C: SceneShopRatio },
  { id: "appRetention", title: "App retention", start: 46.3, end: 54.1, C: SceneAppRetention },
  { id: "loyal", title: "Loyal users", start: 54.1, end: 64.3, C: SceneLoyal },
  { id: "rankSwap", title: "India ahead", start: 64.3, end: 83.4, C: SceneRankSwap },
  { id: "doubt", title: "America doubts", start: 83.4, end: 92.4, C: SceneDoubt },
  { id: "tool", title: "India uses AI", start: 92.4, end: 113.2, C: SceneTool },
  { id: "fear1", title: "Fear 1", start: 113.2, end: 126.2, C: SceneFear1 },
  { id: "fear2", title: "Fear 2", start: 126.2, end: 136.9, C: SceneFear2 },
  { id: "doThis", title: "What to do", start: 136.9, end: 152.4, C: SceneDoThis },
  { id: "students", title: "Everyone", start: 152.4, end: 157.5, C: SceneStudents },
  { id: "asset", title: "Good questions", start: 157.5, end: 163.0, C: SceneAsset },
  { id: "race", title: "Thinking vs doing", start: 163.0, end: 170.7, C: SceneRace },
  { id: "outro", title: "Outro", start: 170.7, end: 181, C: SceneOutro },
];
