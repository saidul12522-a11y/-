import React from "react";
import { FONT } from "../fonts";
import { theme as C } from "../theme";
import { Svg, SceneProps, GROUND, W, Pill } from "./common";
import { In, Chip, Ring, Ground, Cross, Check, Quote, Arrow, Label, bn } from "../components/kit";
import { Person, Mini, Crowd, Phone, ChatWindow, Shop, Heart, Smile, AIChip, Wheel, Cloud, Footprint } from "../art/art";
import { prog, pop, lerp, INOUT, SMOOTH, hash } from "../motion";

/** 46.3-54.1  Same for an app: ChatGPT retention was about 5% */
export const SceneAppRetention: React.FC<SceneProps> = ({ t }) => {
  const tApp = W("App", 46.4), tSame = W("একই", 47.1), tSam = W("Sam", 48.3), tGpt = W("ChatGPT's", 50), tRate = W("হার", 52.1), tPct = W("শতাংশ।", 53.0);
  const oldOut = prog(t, tGpt, tGpt + 0.4);
  const p5 = prog(t, tRate, tPct, SMOOTH);
  const gx = 1330, gy = 520, gr = 150;
  const arcLen = 2 * Math.PI * gr;
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={tApp} dy={80}><Phone x={560} y={GROUND} s={1.35} t={t} /></In>
      <In t={t} cue={tApp} out={tGpt}><Chip x={560} y={GROUND + 50} text="App" color={C.data} size={28} /></In>
      <In t={t} cue={tGpt}><Chip x={560} y={GROUND + 50} text="ChatGPT" color={C.data} size={28} /></In>
      {oldOut < 0.99 && (
        <g opacity={1 - oldOut}>
          <In t={t} cue={tSame - 0.3} dy={60}><Shop x={1500} y={GROUND} s={0.62} t={t} /></In>
          <In t={t} cue={tSame}><text x={1020} y={540} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={150} fill={C.accent} stroke={C.text} strokeWidth={4}>=</text></In>
        </g>
      )}
      <In t={t} cue={tSam}><Quote x={960} y={235} /></In>
      {t >= tRate - 0.2 && (
        <g opacity={prog(t, tRate - 0.2, tRate + 0.2)}>
          <circle cx={gx} cy={gy} r={gr} fill="none" stroke={C.tint} strokeWidth={40} />
          <circle cx={gx} cy={gy} r={gr} fill="none" stroke={C.accent} strokeWidth={40} strokeLinecap="round" strokeDasharray={`${arcLen * 0.05 * p5} ${arcLen}`} transform={`rotate(-90 ${gx} ${gy})`} />
          <text x={gx} y={gy + 38} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={110} fill={C.text}>{bn(Math.round(5 * p5))}%</text>
          <Chip x={gx} y={gy + gr + 75} text="retention" color={C.data} size={32} />
        </g>
      )}
      <Ring x={gx} y={gy} t={t} cue={tPct} r={gr + 20} />
    </Svg>
  );
};

/** 54.1-64.3  He did not stop: the few who came back loved the product */
export const SceneLoyal: React.FC<SceneProps> = ({ t }) => {
  const tStop = W("থামেননি।", 54.5), tBecause = W("কারণ", 55.8), tBack = W("এসেছিল", 56.5), tProd = W("product", 57.2), tLike = W("পছন্দ", 58.3), tFew = W("কম", 59.9), tSat = W("সন্তুষ্ট", 62.9);
  const walkP = prog(t, 54.26, 56.0, INOUT);
  const walkOut = 1 - prog(t, 55.9, 56.3);
  const wx = lerp(250, 760, walkP);
  const xs = [1050, 1200, 1350, 1500, 1650];
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={0.0 + 54.1} dy={0}><Pill x={470} y={470} text="৫%" color={C.muted} size={60} w={200} /></In>
      {/* he keeps going */}
      {walkOut > 0.01 && (
        <g opacity={walkOut}>
          {[0, 1, 2, 3, 4, 5].map((i) => {
            const fx = 330 + i * 80;
            return wx > fx ? <Footprint key={i} x={fx} y={GROUND + 16} rot={90} color={C.muted} opacity={0.6} /> : null;
          })}
          <Person x={wx} y={GROUND} s={1.0} pose="walk" t={t} cloth={C.accent} />
          <Arrow x1={wx + 90} y1={GROUND - 330} x2={wx + 230} y2={GROUND - 330} p={prog(t, 54.6, 55.3)} color={C.accent} w={10} />
        </g>
      )}
      <In t={t} cue={tStop}><Chip x={560} y={300} text="থামেননি" color={C.accent} size={34} /></In>
      {/* the few who returned */}
      {xs.map((px, i) => (
        <g key={px}>
          <In t={t} cue={tBecause + i * 0.12} dy={60}><Person x={px} y={GROUND} s={0.62} pose="stand" t={t} cloth={C.accent} style={i % 2 ? "long" : "short"} mood="smile" bob={t >= tSat} /></In>
          {t >= tLike && t < tSat && (
            <g>{[0, 1].map((k) => {
              const p = ((t - tLike - i * 0.1 - k * 0.5) * 0.9) % 1;
              return p > 0 ? <Heart key={k} x={px + (k ? 16 : -16)} y={GROUND - 210 - p * 90} s={0.7} opacity={1 - p} /> : null;
            })}</g>
          )}
          {t >= tSat && <In t={t} cue={tSat + i * 0.1}><Smile x={px} y={GROUND - 235} s={0.9} /></In>}
        </g>
      ))}
      <In t={t} cue={tBack}><Chip x={1350} y={270} text="ফিরে এসেছিল" color={C.accent} size={30} /></In>
      <In t={t} cue={tProd} dy={50}><Phone x={1350} y={GROUND - 250} s={0.5} t={t} /></In>
      <In t={t} cue={tProd}><Chip x={1350} y={360} text="product" color={C.data} size={28} /></In>
      <In t={t} cue={tFew}><Chip x={470} y={590} text="মানুষ কম" color={C.muted} size={30} /></In>
      <In t={t} cue={tSat}><Chip x={1350} y={GROUND + 50} text="সন্তুষ্ট" color={C.good} size={30} /></In>
    </Svg>
  );
};

/** 113.2-126.2  Step 3: Altman's two fears; fear 1 = people hand control to AI */
export const SceneFear1: React.FC<SceneProps> = ({ t }) => {
  const tAlt = W("Altman", 114.5), tSure = W("নিশ্চিন্ত", 117.9), tNon = W("নন।", 118.4), tTwo = W("দুটি", 119.9);
  const tFirst = W("প্রথমত,", 121.5), tCtrl = W("নিয়ন্ত্রণ", 123.6), tAI = W("AI", 124.2), tHand = W("হাতে", 124.8);
  const intro = Math.min(1, 1 - prog(t, tFirst - 0.2, tFirst + 0.3));
  const smileOp = Math.min(prog(t, tSure, tSure + 0.3), 1 - prog(t, tTwo - 0.2, tTwo + 0.1));
  const give = prog(t, tHand, tHand + 0.95, INOUT);
  const wx = lerp(618, 925, give), wy = lerp(584, 560, give) - Math.sin(Math.PI * give) * 90;
  const arrived = give >= 1;
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={tAlt}><Quote x={960} y={235} /></In>
      {smileOp > 0.01 && (
        <g opacity={smileOp}>
          <Smile x={960} y={470} s={4} />
          <Cross x={1070} y={560} t={t} cue={tNon} s={1.6} />
          <In t={t} cue={tSure}><Chip x={960} y={660} text="নিশ্চিন্ত নন" color={C.warn} size={36} /></In>
        </g>
      )}
      {t >= tTwo && intro > 0.01 && (
        <g opacity={intro}>
          <In t={t} cue={tTwo}><g><Cloud x={600} y={480} s={2.3} /><text x={600} y={535} textAnchor="middle" fontSize={130} fontWeight={700} fontFamily={FONT} fill={C.warn} stroke={C.text} strokeWidth={4}>১</text></g></In>
          <In t={t} cue={tTwo + 0.25}><g><Cloud x={1320} y={480} s={2.3} /><text x={1320} y={535} textAnchor="middle" fontSize={130} fontWeight={700} fontFamily={FONT} fill={C.warn} stroke={C.text} strokeWidth={4}>২</text></g></In>
          <In t={t} cue={tTwo + 0.4}><Chip x={960} y={680} text="দুটি ভয়" color={C.warn} size={38} /></In>
        </g>
      )}
      {/* fear 1: control goes to AI */}
      {t >= tFirst - 0.1 && (
        <g>
          <In t={t} cue={tFirst}><g><circle cx={190} cy={310} r={40} fill={C.accent} stroke={C.text} strokeWidth={4} /><text x={190} y={326} textAnchor="middle" fontSize={50} fontWeight={700} fontFamily={FONT} fill={C.onAccent}>১</text></g></In>
          <In t={t} cue={tFirst} dy={60}><Person x={480} y={GROUND} s={1.05} pose={t < tHand ? "give" : "worry"} t={t} cloth={C.cloth} /></In>
          <In t={t} cue={tAI} dy={40}><AIChip x={1120} y={GROUND - 250} s={1.5} glow={arrived ? 1 : 0} t={t} /></In>
          <In t={t} cue={tAI}><Chip x={1120} y={GROUND + 50} text="AI" color={C.data} size={28} /></In>
          <In t={t} cue={tFirst + 0.5}><Wheel x={wx} y={wy} r={60} rot={give * 200} /></In>
          <In t={t} cue={tCtrl}><Chip x={wx} y={wy - 120} text="নিয়ন্ত্রণ" color={C.accent} size={32} /></In>
          {arrived && <Ring x={1120} y={GROUND - 250} t={t} cue={tHand + 0.95} r={110} />}
          <In t={t} cue={tHand + 0.4}><Chip x={900} y={GROUND - 440} text="AI এর হাতে" color={C.bad} size={32} /></In>
        </g>
      )}
    </Svg>
  );
};

/** 126.2-136.9  Fear 2: huge AI power ends up with a few people; he dislikes concentration */
export const SceneFear2: React.FC<SceneProps> = ({ t }) => {
  const tSecond = W("দ্বিতীয়ত,", 126.4), tAI = W("AI", 127.2), tBig = W("বিশাল", 127.8), tGone = W("চলে", 128.7), tFew = W("কয়েকজন", 129.7);
  const tCentral = W("কেন্দ্রীভূত", 133.7), tDislike = W("পছন্দ", 134.9);
  const px = [1260, 1410, 1560];
  const glow = prog(t, tCentral - 0.4, tCentral + 0.8);
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={tSecond}><g><circle cx={190} cy={310} r={40} fill={C.accent} stroke={C.text} strokeWidth={4} /><text x={190} y={326} textAnchor="middle" fontSize={50} fontWeight={700} fontFamily={FONT} fill={C.onAccent}>২</text></g></In>
      <In t={t} cue={tAI} dy={40}><AIChip x={520} y={440} s={1.9} glow={prog(t, tBig, tBig + 0.5)} t={t} /></In>
      <In t={t} cue={tBig}><Chip x={520} y={262} text="বিশাল ক্ষমতা" color={C.data} size={32} /></In>
      {/* everyone else (dim crowd) */}
      <In t={t} cue={tGone - 0.2}><Crowd x={640} y={GROUND - 12} cols={6} count={12} t={t} opacity={0.4} colors={[C.muted]} gapX={74} /></In>
      {/* the few */}
      {glow > 0 && <circle cx={1410} cy={GROUND - 160} r={80 + 140 * glow} fill={C.warn} opacity={0.22 * glow} />}
      {px.map((x, i) => (
        <In key={x} t={t} cue={tGone + i * 0.12} dy={60}><Person x={x} y={GROUND} s={0.72} pose={t >= tCentral ? "up" : "stand"} t={t} cloth={[C.cloth, C.cloth2, C.warn][i]} style={i === 1 ? "long" : "short"} /></In>
      ))}
      <In t={t} cue={tFew}><Chip x={1410} y={300} text="মাত্র কয়েকজন" color={C.warn} size={32} /></In>
      {/* orbs of power flowing to them */}
      {t >= tGone && Array.from({ length: 9 }).map((_, i) => {
        const p = ((t - tGone) * 0.55 + i / 9) % 1;
        const k = t >= tCentral ? 1 : i % 3;
        const tx = px[k], ty = GROUND - 200;
        const ax = lerp(600, tx, p), ay = lerp(420, ty, p) - Math.sin(Math.PI * p) * 150;
        return <circle key={i} cx={ax} cy={ay} r={11} fill={C.gold} stroke={C.text} strokeWidth={3} opacity={Math.min(1, p * 5) * (1 - 0.3 * p)} />;
      })}
      <In t={t} cue={tCentral}><Chip x={1410} y={GROUND + 50} text="এক জায়গায়" color={C.warn} size={28} /></In>
      <Cross x={1410} y={470} t={t} cue={tDislike} s={1.9} />
      <In t={t} cue={tDislike}><Chip x={960} y={235} text="পছন্দ করেন না" color={C.bad} size={36} /></In>
    </Svg>
  );
};
