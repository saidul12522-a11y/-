import React from "react";
import { AbsoluteFill } from "remotion";
import { L } from "../layout";
import { FONT } from "../fonts";
import { wordTime } from "../captions";
import { theme as C } from "../theme";
import { glen } from "../captions";

export type SceneProps = { t: number };
export const Svg: React.FC<{ children?: React.ReactNode }> = ({ children }) => (
  <AbsoluteFill>
    <svg width={L.w} height={L.h} viewBox="0 0 1920 1080" style={{ fontFamily: FONT }}>{children}</svg>
  </AbsoluteFill>
);
export const GROUND = 790;

/** time (s) of the first caption word containing `needle` at or after `after` */
export const W = (needle: string, after = 0) => wordTime(needle, after);

/** fixed-width pill with a big value, e.g. "১০০ জন" */
export const Pill: React.FC<{ x: number; y: number; text: string; color?: string; size?: number; w?: number }> = ({ x, y, text, color = C.accent, size = 44, w }) => {
  const ww = w ?? glen(text) * size * 0.62 + 56;
  const h = size * 1.7;
  return (
    <g>
      <rect x={x - ww / 2} y={y - h / 2 + 5} width={ww} height={h} rx={h / 2} fill="rgba(16,35,58,0.10)" />
      <rect x={x - ww / 2} y={y - h / 2} width={ww} height={h} rx={h / 2} fill={C.surface} stroke={color} strokeWidth={4} />
      <text x={x} y={y + size * 0.36} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={size} fill={C.text}>{text}</text>
    </g>
  );
};
