import React from "react";
import { FONT } from "../fonts";
import { theme as C } from "../theme";
import { Svg, SceneProps, GROUND, W, Pill } from "./common";
import { In, Chip, Ring, Ground, Cross, Check, Quote, bn } from "../components/kit";
import { Person, Building, Crown, Badge, Magnifier, AIChip, Wrench, Checklist, Book, Cloud } from "../art/art";
import { prog, lerp, INOUT, SMOOTH } from "../motion";

/** 64.3-83.4  Step 2: India ahead? February 10 crore weekly users, America ahead then, now India passes */
export const SceneRankSwap: React.FC<SceneProps> = ({ t }) => {
  const tInd = W("ভারত", 65.5), tAhead = W("এগিয়ে?", 66), tCome = W("আসি", 67.5), tFeb = W("February", 71), tIn = W("ভারতে", 72);
  const tWeekly = W("সাপ্তাহিক", 73), tTen = W("১০", 74.8), tOnly = W("শুধু", 77), tUS = W("আমেরিকা।", 77.5);
  const tNow = W("এখন", 79), tOver = W("ভারত", 80.9), tGone = W("গেছে।", 82.2);
  const q = 0.5 + 0.5 * Math.sin(t * 6);
  const partA = Math.min(prog(t, tInd - 0.2, tInd + 0.3), 1 - prog(t, 70.4, 70.9));
  // chart
  const swap = prog(t, tOver, tOver + 1.3, INOUT);
  const yA = lerp(400, 560, swap), yI = lerp(560, 400, swap);
  const lenI = lerp(480, 1000, swap) * prog(t, tIn, tIn + 1.4, INOUT) * 1 + (swap > 0 ? 0 : 0);
  const lenIndia = swap > 0 ? lerp(480, 1000, swap) : 480 * prog(t, tIn, tIn + 1.4, INOUT);
  const lenAmerica = 780 * prog(t, tOnly, tOnly + 1.2, INOUT);
  const count = Math.round(10 * prog(t, tTen - 0.2, tTen + 0.9));
  const x0 = 520;
  const showChart = t >= tFeb - 0.3;
  const leadIsIndia = swap > 0.5;
  const crownT = prog(t, tOver, tOver + 1.3, INOUT);
  const crownX = lerp(x0 + 780 - 40, x0 + 1000 - 40, crownT), crownY = lerp(yA - 72, yI - 72, crownT);
  return (
    <Svg>
      <Ground y={GROUND} />
      {/* A: "why is India ahead?" */}
      {partA > 0.01 && (
        <g opacity={partA}>
          <In t={t} cue={tInd}><Badge x={720} y={430} text="ভারত" color={C.data} size={62} /></In>
          <In t={t} cue={tAhead} dy={30}>
            <path d="M 940 520 L 940 400 L 900 400 L 960 330 L 1020 400 L 980 400 L 980 520 Z" fill={C.accent} stroke={C.text} strokeWidth={5} strokeLinejoin="round" transform={`translate(0 ${-q * 10})`} />
          </In>
          <In t={t} cue={tAhead + 0.15} s0={0.4}>
            <text x={1180} y={500 - q * 10} textAnchor="middle" fontSize={230} fontWeight={700} fill={C.accent} fontFamily={FONT} stroke={C.text} strokeWidth={5}>?</text>
          </In>
          <Ring x={1180} y={430} t={t} cue={tCome} r={120} loop />
        </g>
      )}
      {/* B: weekly users chart */}
      {showChart && (
        <g>
          <In t={t} cue={tFeb} out={tNow}><Chip x={420} y={250} text="February" color={C.warn} size={34} /></In>
          <In t={t} cue={tNow}><Chip x={420} y={250} text="এখন" color={C.accent} size={34} /></In>
          <In t={t} cue={tWeekly}><Chip x={1000} y={250} text="সাপ্তাহিক ব্যবহারকারী" color={C.data} size={34} /></In>
          {/* India row */}
          <In t={t} cue={tIn - 0.1}><Badge x={285} y={yI} text="ভারত" color={C.accent} size={34} /></In>
          <rect x={x0} y={yI - 42} width={Math.max(0, lenIndia)} height={84} rx={22} fill={C.accent} stroke={C.text} strokeWidth={4} />
          {t >= tTen - 0.2 && (
            <g opacity={Math.min(1, prog(t, tTen - 0.2, tTen))}><Pill x={x0 + lenIndia - 150} y={yI} text={`${bn(count)} কোটি`} color={C.text} size={44} w={260} /></g>
          )}
          {/* America row */}
          {t >= tOnly && <In t={t} cue={tOnly}><Badge x={285} y={yA} text="আমেরিকা" color={C.data} size={34} /></In>}
          {t >= tOnly && <rect x={x0} y={yA - 42} width={Math.max(0, lenAmerica)} height={84} rx={22} fill={C.data} stroke={C.text} strokeWidth={4} />}
          {/* rank medals */}
          {t >= tUS && (
            <g>
              <In t={t} cue={tUS} spring><g transform={`translate(440 ${yA})`}><circle r={30} fill={leadIsIndia ? C.surface : C.gold} stroke={C.text} strokeWidth={4} /><text y={12} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={38} fill={C.text}>{leadIsIndia ? "২" : "১"}</text></g></In>
              <In t={t} cue={tUS}><g transform={`translate(440 ${yI})`}><circle r={30} fill={leadIsIndia ? C.gold : C.surface} stroke={C.text} strokeWidth={4} /><text y={12} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={38} fill={C.text}>{leadIsIndia ? "১" : "২"}</text></g></In>
            </g>
          )}
          {t >= tUS + 0.3 && <g transform={`translate(0 ${Math.sin(t * 3) * 3})`}><Crown x={crownX} y={crownY} s={1.0} opacity={prog(t, tUS + 0.3, tUS + 0.6)} /></g>}
          <Ring x={x0 + 1000 - 60} y={400} t={t} cue={tGone} r={70} />
        </g>
      )}
    </Svg>
  );
};

/** 83.4-92.4  America: people doubt big tech power; Altman sees it somewhat positively */
export const SceneDoubt: React.FC<SceneProps> = ({ t }) => {
  const tHis = W("মতে,", 83), tUS = W("আমেরিকায়", 84), tBig = W("বড়", 85), tPower = W("ক্ষমতা", 86.4), tDoubt = W("সন্দেহ", 87.5);
  const tAnd = W("আর", 88.8), tPos = W("ইতিবাচকভাবেই", 90.3);
  const glow = prog(t, tPower, tPower + 0.6);
  const doubt = prog(t, tDoubt - 0.3, tDoubt + 0.2);
  const pos = prog(t, tPos - 0.2, tPos + 0.5);
  const qc = pos > 0.5 ? C.good : C.warn;
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={tHis}><Quote x={800} y={235} /></In>
      <In t={t} cue={tUS}><Chip x={520} y={GROUND + 50} text="আমেরিকায়" color={C.data} size={28} /></In>
      {/* big tech towers */}
      <In t={t} cue={tBig} dy={120}><Building x={1070} y={GROUND} w={190} h={330} seed={2} t={t} glow={glow} /></In>
      <In t={t} cue={tBig + 0.1} dy={120}><Building x={1330} y={GROUND} w={250} h={540} seed={5} t={t} glow={glow} /></In>
      <In t={t} cue={tBig + 0.2} dy={120}><Building x={1590} y={GROUND} w={200} h={400} seed={9} t={t} glow={glow} /></In>
      <In t={t} cue={tBig + 0.3}><Chip x={1330} y={GROUND + 50} text="বড় প্রযুক্তি কোম্পানি" color={C.data} size={28} /></In>
      {t >= tPower && [0, 1].map((i) => <Ring key={i} x={1330} y={GROUND - 270} t={t} cue={tPower + i * 0.6} r={190} color={C.warn} loop />)}
      {/* doubtful people */}
      {[330, 520, 710].map((px, i) => (
        <g key={px}>
          <In t={t} cue={tUS + 0.1 * i} dy={60}><Person x={px} y={GROUND} s={0.85} pose={doubt > 0.5 ? "think" : "stand"} t={t} cloth={[C.cloth, C.cloth2, C.warn][i]} style={i === 1 ? "long" : "short"} /></In>
          {doubt > 0 && (
            <g opacity={doubt} transform={`translate(0 ${(1 - doubt) * 20})`}>
              <text x={px} y={GROUND - 330} textAnchor="middle" fontSize={86} fontWeight={700} fontFamily={FONT} fill={qc} stroke={C.text} strokeWidth={3}>{pos > 0.5 ? "✓" : "?"}</text>
              <Magnifier x={px + 62} y={GROUND - 230} s={0.9} rot={-25} />
            </g>
          )}
        </g>
      ))}
      <In t={t} cue={tDoubt} out={tPos - 0.2}><Chip x={520} y={380} text="সন্দেহ" color={C.warn} size={34} /></In>
      <In t={t} cue={tPos}><Chip x={520} y={380} text="কিছুটা ইতিবাচক" color={C.good} size={32} /></In>
    </Svg>
  );
};

/** 92.4-113.2  India: AI as a tool, new companies, daily work, students; then the big worry */
export const SceneTool: React.FC<SceneProps> = ({ t }) => {
  const tDiff = W("আলাদা।", 93), tFear = W("ভয়", 95.8), tNo = W("না", 96.4), tTool = W("হাতিয়ার", 96.9), tUse = W("ব্যবহার", 97.9);
  const tCo = W("নতুন", 99.8), tDaily = W("দৈনন্দিন", 102), tEasy = W("সহজ", 102.7), tStud = W("ছাত্র", 105.5), tMost = W("সবচেয়ে", 107.3);
  const tWorry = W("তবে", 109.1), tBig = W("বড়", 111);
  const dimAll = prog(t, tWorry, tWorry + 0.6);
  const bob = Math.sin(t * 2.5) * 3;
  const ticks = interpolate3(t, W("সহজ", 102.6), W("করছে।", 103.1));
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={W("ভারতে", 92.3)}><Badge x={250} y={225} text="ভারত" color={C.accent} size={30} /></In>
      <In t={t} cue={tDiff}><Chip x={560} y={225} text="ছবিটা আলাদা" color={C.accent} size={30} /></In>
      <g opacity={1 - 0.7 * dimAll}>
        {/* zone 1: tool, not fear */}
        <In t={t} cue={W("এখানে", 94.5)} dy={60}><Person x={290} y={GROUND} s={0.95} pose={t >= tTool ? "give" : "stand"} t={t} cloth={C.cloth} /></In>
        {t >= tFear - 0.2 && t < tTool + 0.1 && <g opacity={1 - prog(t, tTool - 0.2, tTool + 0.1)}><In t={t} cue={tFear - 0.2}><Chip x={300} y={400} text="ভয়" color={C.bad} size={34} /></In><Cross x={300} y={400} t={t} cue={tNo} s={1.4} /></g>}
        <In t={t} cue={tTool} dx={-50} dy={0}><g transform={`translate(0 ${bob})`}><Wrench x={500} y={650} s={1.0} rot={35} /><AIChip x={430} y={600} s={0.7} glow={0.7} t={t} /></g></In>
        <In t={t} cue={tUse}><Chip x={420} y={350} text="হাতিয়ার" color={C.data} size={32} /></In>
        {/* zone 2: new company */}
        <In t={t} cue={W("কেউ", 99)} dy={60}><Person x={690} y={GROUND} s={0.95} pose="point" t={t} cloth={C.cloth2} style="long" /></In>
        {t >= tCo && <Building x={930} y={GROUND} w={150} h={300} grow={prog(t, tCo, tCo + 1.1, INOUT)} star seed={4} t={t} />}
        <In t={t} cue={W("কোম্পানি", 100.2)}><Chip x={820} y={340} text="নতুন কোম্পানি" color={C.data} size={30} /></In>
        {/* zone 3: daily work */}
        <In t={t} cue={W("কেউ", 101.5)} dy={60}><Person x={1160} y={GROUND} s={0.95} pose="hold" t={t} cloth={C.warn} /></In>
        <In t={t} cue={tDaily} dy={50}><Checklist x={1360} y={GROUND} s={0.95} ticks={ticks} /></In>
        <In t={t} cue={tEasy}><Chip x={1280} y={330} text="দৈনন্দিন কাজ সহজ" color={C.good} size={28} /></In>
        {/* zone 4: students */}
        <In t={t} cue={tStud} dy={60}><Person x={1650} y={GROUND} s={0.95} pose="stand" t={t} cloth={C.cloth} style="grad" /></In>
        <In t={t} cue={tStud + 0.2} dy={30}><Book x={1500} y={GROUND - 40} s={0.5} /></In>
        <In t={t} cue={tStud}><Chip x={1650} y={300} text="ছাত্র" color={C.data} size={32} /></In>
        {t >= tMost && <g transform={`translate(0 ${Math.sin(t * 3) * 3})`}><In t={t} cue={tMost}><Crown x={1650} y={452} s={1.1} /></In></g>}
      </g>
      {/* the big worry */}
      <In t={t} cue={tWorry} dy={60}>
        <Cloud x={960} y={470} s={3.4} />
        <text x={960} y={522} textAnchor="middle" fontSize={190} fontWeight={700} fontFamily={FONT} fill={C.warn} stroke={C.text} strokeWidth={4}>!</text>
      </In>
      <In t={t} cue={tBig}><Chip x={960} y={660} text="একটা বড় চিন্তা" color={C.warn} size={36} /></In>
    </Svg>
  );
};

function interpolate3(t: number, a: number, b: number) {
  // ticks 0..3 spread over [a-0.3, b+0.3]
  const p = Math.min(1, Math.max(0, (t - (a - 0.3)) / (b + 0.3 - (a - 0.3))));
  return p * 3;
}
