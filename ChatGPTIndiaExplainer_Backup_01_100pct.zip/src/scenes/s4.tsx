import React from "react";
import { FONT } from "../fonts";
import { theme as C } from "../theme";
import { Svg, SceneProps, GROUND, W } from "./common";
import { In, Chip, Ring, Ground, Cross, Check, Arrow } from "../components/kit";
import { Person, Coin, Chest, AIChip, Cloud, Flag } from "../art/art";
import { prog, lerp, INOUT, hash } from "../motion";

/** 136.9-152.4  Step 4: what should we do? make AI part of our work, build skill */
export const SceneDoThis: React.FC<SceneProps> = ({ t }) => {
  const tOrd = W("সাধারণ", 139.4), tWhat = W("উচিত?", 141.9), tFirst = W("প্রথম", 142.8), tAI = W("AI", 143.8), tPart = W("অংশ", 145.8);
  const tOnly = W("শুধু", 147.3), tNot = W("নয়,", 148.8), tSkill = W("দক্ষতা", 150), tUse = W("ব্যবহার", 151.1);
  const q = 0.5 + 0.5 * Math.sin(t * 6);
  const part2 = Math.min(prog(t, tFirst, tFirst + 0.3), 1 - prog(t, tOnly - 0.1, tOnly + 0.3));
  const slide = prog(t, tPart - 0.4, tPart + 0.5, INOUT);
  const chipX = lerp(1500, 1170, slide);
  const bars = prog(t, tSkill, tSkill + 1.0, INOUT);
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={tOrd} dy={60}><Person x={360} y={GROUND} s={1.05} pose={t < tWhat + 0.3 ? "think" : "stand"} t={t} cloth={C.cloth} /></In>
      <In t={t} cue={tWhat - 0.3} out={tFirst + 0.6}>
        <Cloud x={360} y={330} s={1.9} />
        <text x={360} y={375 - q * 8} textAnchor="middle" fontSize={120} fontWeight={700} fontFamily={FONT} fill={C.accent} stroke={C.text} strokeWidth={4}>?</text>
      </In>
      {/* part 2: AI becomes part of my work */}
      {part2 > 0.01 && (
        <g opacity={part2}>
          <In t={t} cue={tFirst}><Chip x={900} y={330} text="প্রথম কথা" color={C.accent} size={32} /></In>
          <In t={t} cue={tFirst + 0.2} dy={40}>
            <rect x={730} y={455} width={330} height={150} rx={28} fill={C.surface} stroke={C.data} strokeWidth={5} />
            <text x={895} y={546} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={46} fill={C.text}>নিজের কাজ</text>
          </In>
          <In t={t} cue={tAI} dy={0} dx={0}><g transform={`translate(${chipX - 1170} 0)`}><AIChip x={1170} y={530} s={1.0} glow={slide >= 1 ? 1 : 0} t={t} /></g></In>
          {slide >= 1 && <g><line x1={1060} y1={530} x2={1112} y2={530} stroke={C.accent} strokeWidth={10} strokeLinecap="round" /><Check x={1170} y={420} t={t} cue={tPart + 0.5} /></g>}
          {slide >= 1 && <Ring x={1170} y={530} t={t} cue={tPart + 0.5} r={90} />}
        </g>
      )}
      {/* part 3: not only pictures/content - also skill */}
      {t >= tOnly && (
        <g>
          <In t={t} cue={tOnly}><Chip x={900} y={330} text="ছবি বা content" color={C.muted} size={30} /></In>
          <In t={t} cue={tOnly + 0.1} dy={40}>
            <g opacity={0.55}>
              <rect x={750} y={440} width={150} height={120} rx={18} fill="#fff" stroke={C.text} strokeWidth={4} />
              <path d="M 765 545 L 805 490 L 835 525 L 855 500 L 885 545 Z" fill={C.good} stroke={C.text} strokeWidth={3} strokeLinejoin="round" />
              <circle cx={866} cy={470} r={12} fill={C.gold} />
              <rect x={930} y={440} width={110} height={150} rx={14} fill="#fff" stroke={C.text} strokeWidth={4} />
              {[0, 1, 2, 3].map((i) => <line key={i} x1={948} y1={470 + i * 28} x2={1022} y2={470 + i * 28} stroke={C.muted} strokeWidth={5} strokeLinecap="round" />)}
            </g>
          </In>
          <Cross x={895} y={500} t={t} cue={tNot} s={1.7} />
          {t >= tSkill && (
            <g>
              <In t={t} cue={tSkill}><Chip x={1470} y={330} text="নিজের দক্ষতা" color={C.accent} size={32} /></In>
              {[0, 1, 2].map((i) => <rect key={i} x={1330 + i * 90} y={GROUND - 40 - (90 + i * 90) * bars} width={64} height={(90 + i * 90) * bars} rx={14} fill={i === 2 ? C.accent : C.data} stroke={C.text} strokeWidth={4} />)}
              <Arrow x1={1320} y1={GROUND - 90} x2={1610} y2={GROUND - 330} p={prog(t, tSkill + 0.5, tSkill + 1.3)} color={C.good} w={9} />
            </g>
          )}
          <In t={t} cue={tUse} dy={30}><AIChip x={1660} y={GROUND - 100} s={0.8} glow={0.8} t={t} /></In>
        </g>
      )}
    </Svg>
  );
};

/** 152.4-157.5  From students to businesspeople, AI can play an important role */
export const SceneStudents: React.FC<SceneProps> = ({ t }) => {
  const tStud = W("ছাত্র", 152.6), tBiz = W("ব্যবসায়ী", 153.5), tAI = W("AI", 155.1), tImp = W("গুরুত্বপূর্ণ", 155.3), tRole = W("ভূমিকা", 155.8);
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={tStud} dy={60}><Person x={560} y={GROUND} s={1.0} pose="stand" t={t} cloth={C.cloth} style="grad" bob /></In>
      <In t={t} cue={tStud}><Chip x={560} y={330} text="ছাত্র" color={C.data} size={34} /></In>
      <In t={t} cue={tBiz} dy={60}><Person x={1360} y={GROUND} s={1.0} pose="stand" t={t} cloth={C.night} biz bob /></In>
      <In t={t} cue={tBiz}><Chip x={1360} y={330} text="ব্যবসায়ী" color={C.data} size={34} /></In>
      <In t={t} cue={tAI} dy={40}><AIChip x={960} y={480} s={1.4} glow={prog(t, tImp, tImp + 0.5)} t={t} /></In>
      <Arrow x1={880} y1={520} x2={660} y2={590} p={prog(t, tAI + 0.3, tImp + 0.3)} color={C.flow} w={8} />
      <Arrow x1={1040} y1={520} x2={1260} y2={590} p={prog(t, tAI + 0.3, tImp + 0.3)} color={C.flow} w={8} />
      <Ring x={960} y={480} t={t} cue={tRole} r={110} />
    </Svg>
  );
};

/** 157.5-163.0  A good question is now a big asset */
export const SceneAsset: React.FC<SceneProps> = ({ t }) => {
  const tGood = W("ভালো", 158.7), tQ = W("প্রশ্ন", 159), tSkill = W("দক্ষতাই", 159.7), tAsset = W("সম্পদ", 160.9);
  const go = prog(t, tSkill + 0.2, tSkill + 1.3, INOUT);
  const bx = lerp(600, 1260, go), by = lerp(470, 560, go) - Math.sin(Math.PI * go) * 160;
  const open = prog(t, tSkill + 1.1, tAsset + 0.3);
  const bs = 1 - 0.55 * prog(t, tSkill + 1.0, tSkill + 1.4);
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={tGood}>
        <g transform={`translate(${bx} ${by}) scale(${bs})`} opacity={1 - prog(t, tSkill + 1.2, tSkill + 1.5)}>
          <rect x={-130} y={-90} width={260} height={180} rx={50} fill={C.surface} stroke={C.accent} strokeWidth={6} />
          <path d="M -30 88 L -50 130 L 10 90 Z" fill={C.surface} stroke={C.accent} strokeWidth={6} strokeLinejoin="round" />
          <rect x={-40} y={80} width={60} height={14} fill={C.surface} />
          <text x={0} y={52} textAnchor="middle" fontSize={150} fontWeight={700} fontFamily={FONT} fill={C.accent} stroke={C.text} strokeWidth={4}>?</text>
        </g>
      </In>
      <In t={t} cue={tGood} out={tSkill + 0.8}><Chip x={600} y={705} text="ভালো প্রশ্ন" color={C.accent} size={36} /></In>
      <In t={t} cue={tQ} dy={60}><Chest x={1300} y={GROUND} s={1.9} open={open} /></In>
      {open > 0.3 && [0, 1, 2, 3, 4, 5].map((i) => {
        const p = Math.min(1, Math.max(0, (t - (tAsset - 0.2 + i * 0.12)) / 0.7));
        return p > 0 ? <Coin key={i} x={1300 + (i - 2.5) * 46} y={GROUND - 270 - Math.sin(p * Math.PI) * (60 + hash(i) * 50)} r={24} opacity={Math.min(1, p * 4)} /> : null;
      })}
      <In t={t} cue={tAsset}><Chip x={1300} y={300} text="বড় সম্পদ" color={C.accent} size={40} /></In>
      <Ring x={1300} y={GROUND - 120} t={t} cue={tAsset} r={130} />
    </Svg>
  );
};

/** 163.0-170.7  Some are still afraid and thinking; others already move ahead using AI */
export const SceneRace: React.FC<SceneProps> = ({ t }) => {
  const tFear = W("ভয়", 163.4), tThink = W("ভাবছেন।", 164.7), tSome = W("কেউ", 165.5), tAI = W("AI", 167.2), tPush = W("এগিয়ে", 169.3);
  const q = 0.5 + 0.5 * Math.sin(t * 5);
  const run = prog(t, tAI, 170.4, INOUT);
  const px = lerp(980, 1520, run);
  const flags = [1180, 1340, 1500];
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={tFear} dy={60}><Person x={380} y={GROUND} s={1.05} pose={t < tThink ? "worry" : "think"} t={t} cloth={C.cloth} /></In>
      <In t={t} cue={tFear + 0.4}>
        <Cloud x={380} y={330} s={1.9} />
        <text x={380} y={375 - q * 8} textAnchor="middle" fontSize={110} fontWeight={700} fontFamily={FONT} fill={C.muted} stroke={C.text} strokeWidth={3}>?</text>
      </In>
      <In t={t} cue={tThink}><Chip x={380} y={GROUND + 50} text="ভাবছেন" color={C.muted} size={28} /></In>
      {/* lane for the doers */}
      <In t={t} cue={tSome}><rect x={820} y={GROUND + 4} width={960} height={10} rx={5} fill={C.data} opacity={0.5} /></In>
      {flags.map((fx, i) => (px > fx + 40 || t >= tPush + i * 0.35) && px > fx - 40 ? <Flag key={fx} x={fx + 40} y={GROUND} s={0.9} color={C.accent} /> : null)}
      <In t={t} cue={tSome} dy={60}><Person x={px} y={GROUND} s={1.05} pose={run > 0 && run < 1 ? "walk" : "stand"} t={t} cloth={C.accent} style="long" /></In>
      {t >= tAI && <g transform={`translate(0 ${Math.sin(t * 3) * 4})`}><AIChip x={px + 120} y={GROUND - 300} s={0.7} glow={1} t={t} /></g>}
      <In t={t} cue={tSome}><Chip x={1300} y={300} text="কাজ এগিয়ে নিচ্ছেন" color={C.good} size={30} /></In>
    </Svg>
  );
};
