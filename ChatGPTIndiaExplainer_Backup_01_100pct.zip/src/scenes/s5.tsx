import React from "react";
import { staticFile } from "remotion";
import { FONT } from "../fonts";
import { theme as C } from "../theme";
import { Svg, SceneProps, W } from "./common";
import { In, Label } from "../components/kit";
import { Heart } from "../art/art";
import { prog } from "../motion";

/** 170.7-end  Outro: logo, like, comment, subscribe, thanks */
export const SceneOutro: React.FC<SceneProps> = ({ t }) => {
  const tLike = W("লাইক", 171.7), tCom = W("মন্তব্যে", 172.4), tSub = W("subscribe", 175.7), tThanks = W("ধন্যবাদ।", 177.7);
  const bell = Math.sin(t * 18) * 10 * (prog(t, tSub + 0.5, tSub + 0.7) * (1 - prog(t, tSub + 2.0, tSub + 2.2)));
  return (
    <Svg>
      <In t={t} cue={170.9} dy={40}>
        <rect x={150} y={220} width={560} height={560} rx={48} fill="#fff" stroke={C.border} strokeWidth={3} />
        <image href={staticFile("logo.jpg")} x={160} y={230} width={540} height={540} preserveAspectRatio="xMidYMid meet" />
      </In>
      <In t={t} cue={tLike} dy={50}>
        <rect x={860} y={250} width={380} height={120} rx={60} fill={C.surface} stroke={C.data} strokeWidth={4} />
        <path d="M 920 335 L 920 295 L 950 295 L 965 262 Q 985 262 982 285 L 982 295 L 1020 295 Q 1034 296 1030 312 L 1022 335 Z" fill={C.data} stroke={C.text} strokeWidth={3} strokeLinejoin="round" />
        <Label x={1135} y={332} text="লাইক" size={42} color={C.text} />
      </In>
      <In t={t} cue={tCom} dy={50}>
        <rect x={860} y={420} width={380} height={120} rx={60} fill={C.surface} stroke={C.good} strokeWidth={4} />
        <path d="M 915 475 Q 915 440 950 440 L 995 440 Q 1030 440 1030 475 Q 1030 505 995 505 L 960 505 L 935 525 L 940 505 Q 915 505 915 475 Z" fill={C.good} stroke={C.text} strokeWidth={3} strokeLinejoin="round" />
        <Label x={1135} y={492} text="মন্তব্য" size={42} color={C.text} />
      </In>
      <In t={t} cue={tSub} dy={50}>
        <rect x={860} y={590} width={560} height={130} rx={65} fill={C.bad} stroke={C.text} strokeWidth={4} />
        <g transform={`translate(950 655) rotate(${bell})`}>
          <path d="M -26 14 Q -26 -34 0 -34 Q 26 -34 26 14 L 36 26 L -36 26 Z" fill="#fff" stroke={C.text} strokeWidth={3} />
          <circle cx={0} cy={36} r={8} fill="#fff" stroke={C.text} strokeWidth={3} />
        </g>
        <text x={1180} y={668} textAnchor="middle" fontSize={50} fontWeight={700} fontFamily={FONT} fill="#fff">subscribe</text>
      </In>
      <In t={t} cue={tThanks}>
        <Heart x={1560} y={470} s={2.4} />
        <text x={1560} y={600} textAnchor="middle" fontSize={56} fontWeight={700} fontFamily={FONT} fill={C.text}>ধন্যবাদ</text>
      </In>
    </Svg>
  );
};
