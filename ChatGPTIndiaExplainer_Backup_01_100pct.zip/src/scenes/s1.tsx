import React from "react";
import { interpolate } from "remotion";
import { FONT } from "../fonts";
import { theme as C } from "../theme";
import { Svg, SceneProps, GROUND, W, Pill } from "./common";
import { In, Chip, Ring, Ground, Cross, Arrow, Label, Quote, bn } from "../components/kit";
import { Person, Mini, Crowd, ChatWindow, Shop, Crown, Book, Star, Cloud } from "../art/art";
import { prog, pop, lerp, INOUT, SMOOTH, hash } from "../motion";

const track = (t: number, times: number[], vals: number[]) => interpolate(t, times, vals, { extrapolateLeft: "clamp", extrapolateRight: "clamp" });

/** 0-21.2  Hook: India passes America in ChatGPT users; "why?" */
export const SceneHook: React.FC<SceneProps> = ({ t }) => {
  const tIndia = W("ভারত", 1), tAmer = W("আমেরিকাকে", 2), tOver = W("ছাড়িয়ে", 2.5);
  const tThink = W("অনেকে", 4), tBest = W("সবচেয়ে", 5), tAmerica = W("আমেরিকা।", 6.5);
  const tBut = W("কিন্তু", 8), tSam = W("Sam", 8), tGpt = W("ChatGPT's", 10);
  const tIndiaNow = W("ভারতে,", 13), tThan = W("আমেরিকার", 14.5);
  const tWhy = W("কেন?", 16.5), tStory = W("গল্পটা", 18), tAmaz = W("চমকপ্রদ।", 19);
  const BASE = GROUND - 12;
  const ind = track(t, [tIndia, tIndia + 1.2, tOver, tOver + 0.9, tThink, tThink + 0.6, tIndiaNow, tIndiaNow + 1.3], [0, 6, 6, 12, 12, 6, 6, 14]);
  const amr = track(t, [tAmer, tAmer + 1.0, tThink, tThink + 0.8, tThan, tThan + 0.9], [0, 8, 8, 14, 14, 7]);
  const S = 1.2;
  const rowsTop = (n: number) => BASE - (Math.ceil(n / 3) - 1) * 74 * S - 62 * S - 50;
  const chatBig = Math.min(prog(t, 0.08, 0.5), 1 - prog(t, 4.0, 4.4));
  const chatSmall = Math.min(prog(t, tGpt, tGpt + 0.4), 1 - prog(t, tWhy - 0.1, tWhy + 0.2));
  const q = 0.5 + 0.5 * Math.sin(t * 6);
  const thinkOut = tBut + 0.1;
  return (
    <Svg>
      <Ground y={GROUND} />
      {/* ChatGPT chat window */}
      {chatBig > 0.01 && <g opacity={chatBig} transform={`translate(0 ${(1 - chatBig) * 30})`}><ChatWindow x={960} y={440} s={0.85} t={t} /></g>}
      {chatSmall > 0.01 && <g opacity={chatSmall}><ChatWindow x={960} y={560} s={0.6} t={t} /></g>}
      {/* the two user crowds */}
      <Crowd x={450} y={BASE} count={amr} s={S} t={t} />
      <Crowd x={1470} y={BASE} count={ind} s={S} t={t} colors={[C.accent, C.warn, C.cloth2, C.data]} opacity={t >= tThink && t < tIndiaNow ? 0.35 : 1} />
      <In t={t} cue={tAmer}><Chip x={450} y={GROUND + 50} text="আমেরিকা" color={C.data} size={28} /></In>
      <In t={t} cue={tIndia}><Chip x={1470} y={GROUND + 50} text="ভারত" color={C.accent} size={28} /></In>
      {t >= tOver + 0.4 && t < tThink && <Ring x={1470} y={BASE - 220} t={t} cue={tOver + 0.4} r={100} />}
      {t >= tOver && t < tThink && (
        <g opacity={prog(t, tOver, tOver + 0.3)} transform={`translate(0 ${-Math.abs(Math.sin(t * 5)) * 8})`}><path d="M 1470 250 L 1520 320 L 1488 320 L 1488 360 L 1452 360 L 1452 320 L 1420 320 Z" fill={C.accent} stroke={C.text} strokeWidth={4} strokeLinejoin="round" /></g>
      )}
      {/* "many think ... America is the biggest market" */}
      <In t={t} cue={tThink} out={thinkOut}>
        <Person x={930} y={GROUND} pose="think" t={t} cloth={C.cloth2} s={1.0} />
        <g transform="translate(930 360)"><Cloud x={0} y={0} s={2.3} /></g>
      </In>
      <In t={t} cue={tBest} out={thinkOut}><Chip x={930} y={355} text="সবচেয়ে বড় বাজার" color={C.data} size={26} /></In>
      {t >= tAmerica && t < tBut + 0.3 && <g transform={`translate(0 ${Math.sin(t * 3) * 3})`}><Crown x={450} y={rowsTop(amr)} s={1.3} opacity={Math.min(prog(t, tAmerica, tAmerica + 0.3), 1 - prog(t, tBut, tBut + 0.3))} /></g>}
      {t >= tIndiaNow + 0.6 && <g transform={`translate(0 ${Math.sin(t * 3) * 3})`}><In t={t} cue={tIndiaNow + 0.6}><Crown x={1470} y={rowsTop(ind)} s={1.3} /></In></g>}
      <g opacity={1 - prog(t, tBut + 0.7, tBut + 1.1)}><Cross x={930} y={440} t={t} cue={tBut} s={1.6} /></g>
      {/* "but Sam Altman says ..." */}
      <In t={t} cue={tSam}><Quote x={960} y={225} /></In>
      <In t={t} cue={tIndiaNow + 0.2}><Chip x={1470} y={GROUND - 430} text="ভারতে" color={C.accent} size={28} /></In>
      {/* "but why?" -> "the story is amazing" */}
      <In t={t} cue={tWhy} out={tStory + 0.1}>
        <text x={960} y={560 + q * -10} textAnchor="middle" fontSize={230} fontWeight={700} fill={C.accent} fontFamily={FONT} stroke={C.text} strokeWidth={5}>?</text>
      </In>
      <In t={t} cue={tStory} dy={50}><Book x={960} y={520} s={1.4} /></In>
      {t >= tAmaz && [[780, 400, 14], [1150, 420, 18], [1040, 350, 11], [880, 330, 10]].map(([sx, sy, sr], i) => (
        <g key={i} opacity={Math.min(1, prog(t, tAmaz + i * 0.12, tAmaz + i * 0.12 + 0.3)) * (0.7 + 0.3 * Math.sin(t * 6 + i))}><Star x={sx} y={sy} r={sr * 1.6} /></g>
      ))}
    </Svg>
  );
};

/* ---------- shared 100-customer grid (chai shop scenes) ---------- */
const RET = [7, 23, 41, 66, 88]; // the five customers who come back (one in every 20)
const gridPos = (i: number) => ({ x: 420 + ((i % 10) - 4.5) * 56, y: GROUND - 30 - Math.floor(i / 10) * 52, s: 0.5 });
const rowPos = (i: number) => ({ x: 130 + (i % 20) * 50, y: 340 + Math.floor(i / 20) * 80, s: 0.62 });
const queuePos = (k: number) => ({ x: 880 + k * 56, y: GROUND - 8, s: 0.85 });

const Customers: React.FC<{ t: number; appearAt: number | null; walkAt: number | null; rowsAt: number | null; walked?: boolean }> = ({ t, appearAt, walkAt, rowsAt }) => {
  const cols: string[] = [C.data, C.cloth2, C.warn, C.flow];
  return (
    <g>
      {Array.from({ length: 100 }).map((_, i) => {
        const k = RET.indexOf(i);
        const ap = appearAt === null ? 1 : Math.min(1, Math.max(0, (t - (appearAt + i * 0.013)) / 0.3));
        if (ap <= 0) return null;
        const rp = rowsAt === null ? 0 : prog(t, rowsAt + hash(i) * 0.25, rowsAt + 0.9 + hash(i) * 0.25, INOUT);
        const g = gridPos(i), r = rowPos(i);
        let x = g.x, y = g.y, s = g.s, color: string = cols[i % 4], op = ap;
        if (k >= 0) {
          const wp = walkAt === null ? 0 : prog(t, walkAt + k * 0.12, walkAt + k * 0.12 + 1.2, INOUT);
          const q = queuePos(k);
          x = lerp(g.x, q.x, wp); y = lerp(g.y, q.y, wp); s = lerp(g.s, q.s, wp);
          if (wp > 0 && wp < 1) y -= Math.abs(Math.sin(t * 10 + k)) * 6;
          color = wp > 0.05 || walkAt !== null && t >= walkAt ? C.accent : color;
          x = lerp(x, r.x, rp); y = lerp(y, r.y, rp); s = lerp(s, r.s * 1.25, rp);
        } else {
          const dp = walkAt === null ? 0 : prog(t, walkAt + hash(i) * 0.4, walkAt + 0.5 + hash(i) * 0.4);
          color = dp > 0.5 ? C.muted : color;
          op = ap * lerp(1, 0.38, dp);
          x = lerp(x, r.x, rp); y = lerp(y, r.y, rp); s = lerp(s, r.s, rp);
        }
        return <Mini key={i} x={x} y={y} s={s} color={color} opacity={op} />;
      })}
    </g>
  );
};

/** 21.2-35.7  Step 1: chai shop, 100 customers, only 5 come back = retention */
export const SceneShopStart: React.FC<SceneProps> = ({ t }) => {
  const tShop = W("ধরুন,", 22), tOwner = W("আপনি", 24), tHun = W("১০০", 26), tDays = W("কিছুদিন", 29);
  const tFive = W("পাঁচ", 31), tRetBack = W("ফিরে", 32.9), tRetWord = W("retention", 34);
  const n = Math.min(100, Math.max(0, Math.floor(((t - tHun) / 1.4) * 100)));
  const loop = (t - tRetBack) * 0.9;
  return (
    <Svg>
      <Ground y={GROUND} />
      <In t={t} cue={tShop} dy={70}><Shop x={1560} y={GROUND} s={1.1} t={t} /></In>
      <In t={t} cue={tOwner} dy={50}>
        <Person x={1190} y={GROUND} s={0.95} pose={t < tHun ? "up" : "stand"} t={t} cloth={C.accent} style="short" />
      </In>
      <In t={t} cue={tOwner}><Chip x={1190} y={GROUND - 350} text="আপনি" color={C.accent} size={28} /></In>
      <Customers t={t} appearAt={tHun} walkAt={tFive} rowsAt={null} />
      {t >= tHun - 0.05 && t < tFive && <g opacity={prog(t, tHun, tHun + 0.2)}><Pill x={420} y={215} text={`${bn(n)} জন`} w={300} /></g>}
      <In t={t} cue={tDays} out={tFive - 0.1}><Chip x={960} y={300} text="কিছুদিন পর" color={C.warn} size={30} icon={<g><circle r={15} fill="none" stroke={C.text} strokeWidth={4} /><path d="M 0 -9 L 0 0 L 8 5" stroke={C.text} strokeWidth={4} fill="none" strokeLinecap="round" /></g>} /></In>
      <In t={t} cue={tFive}><Pill x={985} y={GROUND - 150} text="৫ জন" color={C.accent} size={40} w={190} /></In>
      <Ring x={985} y={GROUND - 40} t={t} cue={tFive + 0.9} r={80} />
      {t >= tRetBack && (
        <g opacity={prog(t, tRetBack, tRetBack + 0.4)} transform={`translate(985 ${GROUND - 300}) rotate(${loop * 60})`}>
          <path d="M 0 -70 A 70 70 0 1 1 -66 -24" fill="none" stroke={C.data} strokeWidth={9} strokeLinecap="round" />
          <path d="M -86 -12 L -62 -44 L -42 -8 Z" fill={C.data} transform="rotate(-6 -62 -26)" />
        </g>
      )}
      <In t={t} cue={tRetWord}><Chip x={985} y={GROUND - 400} text="retention" color={C.data} size={40} /></In>
    </Svg>
  );
};

/** 35.7-46.3  100 -> 5, one in every 20, no returning customers = shop cannot survive */
export const SceneShopRatio: React.FC<SceneProps> = ({ t }) => {
  const tHun = W("১০০", 36), tFive = W("পাঁচ", 37.4), tRule = W("হিসাব", 40), tPer = W("প্রতি", 41), tOne = W("একজন।", 42);
  const tBecause = W("কারণ", 43), tNo = W("না", 44.4), tShop = W("দোকান", 45), tStay = W("টেকে", 45.5);
  const dim = prog(t, tShop, tShop + 0.8);
  const arrP = prog(t, tBecause + 0.4, tNo, INOUT);
  const tRows = tRule;
  return (
    <Svg>
      <Ground y={GROUND} />
      <Shop x={1560} y={GROUND} s={1.1} t={t} dim={dim} />
      <Person x={1190} y={GROUND} s={0.95} pose="stand" t={t} cloth={C.accent} mood={dim > 0.5 ? "worry" : "smile"} />
      <Customers t={t} appearAt={null} walkAt={0} rowsAt={tRows} />
      {t < tRows + 0.2 && (
        <g opacity={Math.min(prog(t, tHun, tHun + 0.4), 1 - prog(t, tRows, tRows + 0.3))}>
          <rect x={130} y={238} width={580} height={540} rx={26} fill="none" stroke={C.data} strokeWidth={4} strokeDasharray="14 10" />
          <Pill x={420} y={210} text="১০০ জন" color={C.data} size={40} w={240} />
        </g>
      )}
      {t < tRows + 0.2 && <Ring x={985} y={GROUND - 40} t={t} cue={tFive} r={80} />}
      <In t={t} cue={tFive} out={tRows}><Pill x={985} y={GROUND - 150} text="৫ জন" color={C.accent} size={40} w={190} /></In>
      {t >= tPer && (
        <g opacity={prog(t, tPer, tPer + 0.3)}>
          <rect x={104} y={292} width={1000} height={60} rx={30} fill="none" stroke={C.accent} strokeWidth={5} strokeDasharray="12 8" />
          <Pill x={600} y={245} text="প্রতি ২০ জনে ১ জন" color={C.accent} size={42} w={520} />
        </g>
      )}
      {t >= tOne && <Ring x={130 + 7 * 50} y={340 - 20} t={t} cue={tOne} r={34} />}
      {arrP > 0 && <Arrow x1={1120} y1={420} x2={1330} y2={420} p={arrP} color={C.muted} w={8} />}
      <Cross x={1225} y={420} t={t} cue={tNo} s={1.1} />
      <In t={t} cue={tStay}><Chip x={1560} y={235} text="দোকান টেকে না" color={C.bad} size={34} /></In>
    </Svg>
  );
};
