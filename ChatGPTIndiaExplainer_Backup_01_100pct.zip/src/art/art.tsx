import React from "react";
import { theme as C } from "../theme";
import { FONT } from "../fonts";
import { cl, hash } from "../motion";

const OUT = C.text;
const sw = 4;

/** Icon-style full-body person. Feet at (0,0), natural height ~300. The whole figure animates (no limb rig). */
export type Pose = "stand" | "walk" | "hold" | "think" | "up" | "give" | "worry" | "point";
export const Person: React.FC<{
  x: number; y: number; s?: number; pose?: Pose; t?: number; cloth?: string; hair?: string;
  style?: "short" | "long" | "grad"; biz?: boolean; flip?: boolean; bob?: boolean; opacity?: number; mood?: "smile" | "flat" | "worry";
}> = ({ x, y, s = 1, pose = "stand", t = 0, cloth = C.cloth, hair = C.night, style = "short", biz = false, flip = false, bob = false, opacity = 1, mood }) => {
  const by = bob || pose === "walk" ? Math.abs(Math.sin(t * 7)) * -6 : 0;
  const legA = pose === "walk" ? Math.sin(t * 8) * 16 : 0;
  const m = mood ?? (pose === "worry" ? "worry" : pose === "think" ? "flat" : "smile");
  const arm = (side: 1 | -1) => {
    const sx = side * 44, sy = -210;
    let hx = side * 58, hy = -118;
    if (pose === "hold") { hx = side * 16; hy = -176; }
    if (pose === "think") { hx = side === 1 ? 24 : side * 58; hy = side === 1 ? -246 : -118; }
    if (pose === "up") { hx = side * 56; hy = -290; }
    if (pose === "give") { hx = side === 1 ? 128 : side * 58; hy = side === 1 ? -196 : -118; }
    if (pose === "point") { hx = side === 1 ? 118 : side * 58; hy = side === 1 ? -250 : -118; }
    if (pose === "worry") { hx = side * 34; hy = -262; }
    if (pose === "walk") { hx = side * 52 + Math.sin(t * 8) * side * -14; hy = -125; }
    return (
      <g>
        <line x1={sx} y1={sy} x2={hx} y2={hy} stroke={cloth} strokeWidth={24} strokeLinecap="round" />
        <circle cx={hx} cy={hy} r={13} fill={C.skin} stroke={OUT} strokeWidth={3} />
      </g>
    );
  };
  return (
    <g opacity={opacity} transform={`translate(${x} ${y + by}) scale(${flip ? -s : s} ${s})`}>
      <ellipse cx={0} cy={4 - by} rx={62} ry={9} fill="rgba(16,35,58,0.14)" />
      <g transform={`rotate(${legA} 0 -110)`}><rect x={-32} y={-112} width={26} height={112} rx={13} fill={C.night} stroke={OUT} strokeWidth={sw} /></g>
      <g transform={`rotate(${-legA} 0 -110)`}><rect x={6} y={-112} width={26} height={112} rx={13} fill={C.night} stroke={OUT} strokeWidth={sw} /></g>
      {arm(-1)}
      <rect x={-48} y={-234} width={96} height={150} rx={30} fill={cloth} stroke={OUT} strokeWidth={sw} />
      {biz && <path d="M -9 -232 L 9 -232 L 6 -170 L 0 -158 L -6 -170 Z" fill={C.bad} stroke={OUT} strokeWidth={3} strokeLinejoin="round" />}
      {biz && pose !== "hold" && (
        <g><rect x={-92} y={-112} width={52} height={40} rx={8} fill={C.warn} stroke={OUT} strokeWidth={3} /><path d="M -76 -112 L -76 -122 L -56 -122 L -56 -112" fill="none" stroke={OUT} strokeWidth={3} /></g>
      )}
      {arm(1)}
      {pose === "hold" && (
        <g><rect x={-15} y={-206} width={30} height={50} rx={7} fill={C.night} stroke={OUT} strokeWidth={3} /><rect x={-10} y={-200} width={20} height={36} rx={4} fill={C.data} /></g>
      )}
      <rect x={-12} y={-250} width={24} height={26} fill={C.skin} stroke={OUT} strokeWidth={3} />
      <circle cx={0} cy={-276} r={36} fill={C.skin} stroke={OUT} strokeWidth={sw} />
      {style !== "grad" && <path d="M -37 -278 A 37 37 0 0 1 37 -278 Q 20 -302 0 -300 Q -20 -302 -37 -278 Z" fill={hair} stroke={OUT} strokeWidth={3} strokeLinejoin="round" />}
      {style === "long" && <g><rect x={-44} y={-290} width={14} height={66} rx={7} fill={hair} stroke={OUT} strokeWidth={3} /><rect x={30} y={-290} width={14} height={66} rx={7} fill={hair} stroke={OUT} strokeWidth={3} /></g>}
      {style === "grad" && (
        <g>
          <path d="M -36 -290 A 36 30 0 0 1 36 -290 Z" fill={C.night} />
          <path d="M -58 -300 L 0 -326 L 58 -300 L 0 -278 Z" fill={C.night} stroke={OUT} strokeWidth={3} strokeLinejoin="round" />
          <line x1={46} y1={-304} x2={52} y2={-262} stroke={C.gold} strokeWidth={4} strokeLinecap="round" />
          <circle cx={52} cy={-258} r={6} fill={C.gold} />
        </g>
      )}
      <circle cx={-12} cy={-272} r={4} fill={OUT} />
      <circle cx={12} cy={-272} r={4} fill={OUT} />
      <path d={m === "smile" ? "M -9 -257 q 9 7 18 0" : m === "worry" ? "M -10 -250 q 10 -8 20 0" : "M -8 -253 L 8 -253"} stroke={OUT} strokeWidth={3} fill="none" strokeLinecap="round" />
      {pose === "worry" && <path d="M 52 -300 C 58 -290 62 -284 56 -278 C 50 -274 44 -280 48 -288 Z" fill={C.flow} stroke={OUT} strokeWidth={2} />}
    </g>
  );
};

/** Tiny person icon for crowds and customers. Feet at (0,0), height ~65. */
export const Mini: React.FC<{ x: number; y: number; s?: number; color?: string; opacity?: number }> = ({ x, y, s = 1, color = C.data, opacity = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={opacity}>
    <rect x={-15} y={-36} width={30} height={36} rx={14} fill={color} stroke={OUT} strokeWidth={3} />
    <circle cx={0} cy={-51} r={13} fill={C.skin} stroke={OUT} strokeWidth={3} />
  </g>
);

/** Grid of Mini people that grows one by one. count may be fractional. y = bottom row baseline. */
export const Crowd: React.FC<{ x: number; y: number; cols?: number; count: number; s?: number; gapX?: number; gapY?: number; colors?: string[]; opacity?: number; t?: number }> = ({
  x, y, cols = 3, count, s = 1, gapX = 78, gapY = 74, colors = [C.data, C.cloth2, C.warn, C.flow] as string[], opacity = 1, t = 0,
}) => (
  <g opacity={opacity}>
    {Array.from({ length: Math.max(0, Math.ceil(count)) }).map((_, i) => {
      const p = cl(count - i);
      const col = i % cols, row = Math.floor(i / cols);
      const bob = Math.sin(t * 3 + i * 1.7) * 2;
      return <Mini key={i} x={x + (col - (cols - 1) / 2) * gapX * s} y={y - row * gapY * s + bob} s={s * (0.4 + 0.6 * p)} opacity={p} color={colors[i % colors.length]} />;
    })}
  </g>
);

/** Smartphone with a chat on screen. Origin = bottom centre. */
export const Phone: React.FC<{ x: number; y: number; s?: number; t?: number }> = ({ x, y, s = 1, t = 0 }) => {
  const dots = [0, 1, 2].map((i) => 0.35 + 0.65 * Math.max(0, Math.sin(t * 5 - i * 0.9)));
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <rect x={-72} y={-256} width={144} height={256} rx={28} fill={C.night} stroke={OUT} strokeWidth={sw} />
      <rect x={-60} y={-240} width={120} height={218} rx={16} fill="#fff" />
      <rect x={-20} y={-248} width={40} height={6} rx={3} fill={C.muted} />
      <rect x={-48} y={-214} width={76} height={28} rx={14} fill={C.tint} />
      <rect x={-26} y={-168} width={76} height={28} rx={14} fill={C.data} />
      <rect x={-48} y={-122} width={90} height={28} rx={14} fill={C.tint} />
      <rect x={-26} y={-76} width={60} height={28} rx={14} fill={C.data} />
      {dots.map((o, i) => <circle key={i} cx={-30 + i * 18} cy={-36} r={5} fill={C.muted} opacity={o} />)}
    </g>
  );
};

/** Chat window used as the "ChatGPT" hero (text label only, no logo). Origin = centre. */
export const ChatWindow: React.FC<{ x: number; y: number; s?: number; t?: number }> = ({ x, y, s = 1, t = 0 }) => {
  const dots = [0, 1, 2].map((i) => 0.35 + 0.65 * Math.max(0, Math.sin(t * 5 - i * 0.9)));
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <rect x={-270} y={-160 + 8} width={540} height={330} rx={30} fill="rgba(16,35,58,0.10)" />
      <rect x={-270} y={-160} width={540} height={330} rx={30} fill="#fff" stroke={OUT} strokeWidth={sw} />
      <path d="M -270 -100 L -270 -130 Q -270 -160 -240 -160 L 240 -160 Q 270 -160 270 -130 L 270 -100 Z" fill={C.tint} stroke={OUT} strokeWidth={sw} />
      {[-236, -204, -172].map((cx, i) => <circle key={i} cx={cx} cy={-130} r={9} fill={[C.bad, C.warn, C.good][i]} stroke={OUT} strokeWidth={2} />)}
      <text x={20} y={-114} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={40} fill={C.text}>ChatGPT</text>
      <rect x={20} y={-70} width={220} height={52} rx={26} fill={C.data} />
      <rect x={-240} y={0} width={290} height={52} rx={26} fill={C.tint} />
      <rect x={-240} y={72} width={190} height={52} rx={26} fill={C.tint} />
      {dots.map((o, i) => <circle key={i} cx={-210 + i * 30} cy={98} r={8} fill={C.muted} opacity={o} />)}
    </g>
  );
};

/** Chai shop with awning, kettle and cups. Origin = bottom centre. dim 0..1 greys it out. */
export const Shop: React.FC<{ x: number; y: number; s?: number; t?: number; dim?: number; sign?: boolean }> = ({ x, y, s = 1, t = 0, dim = 0, sign = true }) => {
  const stripes = Array.from({ length: 8 });
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} style={{ filter: dim > 0 ? `grayscale(${dim}) opacity(${1 - 0.35 * dim})` : undefined }}>
      <rect x={-200} y={-310} width={400} height={310} rx={10} fill={C.tint} stroke={OUT} strokeWidth={sw} />
      <rect x={-170} y={-230} width={340} height={10} rx={5} fill={C.muted} />
      {[-120, -60, 0, 60, 120].map((cx) => <rect key={cx} x={cx - 14} y={-262} width={28} height={32} rx={6} fill="#fff" stroke={OUT} strokeWidth={3} />)}
      <rect x={-210} y={-130} width={420} height={130} rx={10} fill={C.gold} stroke={OUT} strokeWidth={sw} />
      <rect x={-210} y={-142} width={420} height={22} rx={8} fill={C.warn} stroke={OUT} strokeWidth={sw} />
      {/* kettle + steam */}
      <path d="M -150 -142 L -150 -180 Q -150 -214 -112 -214 Q -74 -214 -74 -180 L -74 -142 Z" fill={C.muted} stroke={OUT} strokeWidth={sw} strokeLinejoin="round" />
      <path d="M -74 -190 L -44 -214" stroke={OUT} strokeWidth={9} strokeLinecap="round" />
      <path d="M -150 -190 Q -176 -190 -166 -160" fill="none" stroke={OUT} strokeWidth={6} strokeLinecap="round" />
      {dim < 0.5 && [0, 1, 2].map((i) => {
        const p = (t * 0.7 + i / 3) % 1;
        return <path key={i} d={`M ${-40 + i * 6 + Math.sin(p * 6) * 6} ${-218 - p * 70} q 8 -10 0 -20`} stroke={C.muted} strokeWidth={5} fill="none" strokeLinecap="round" opacity={1 - p} />;
      })}
      {/* cups */}
      {[30, 90, 150].map((cx) => (
        <g key={cx}><path d={`M ${cx - 22} -142 L ${cx - 16} -178 L ${cx + 16} -178 L ${cx + 22} -142 Z`} fill="#fff" stroke={OUT} strokeWidth={3} strokeLinejoin="round" /><path d={`M ${cx + 16} -170 q 18 2 12 18 q -4 8 -14 6`} fill="none" stroke={OUT} strokeWidth={3} /></g>
      ))}
      {/* awning */}
      {stripes.map((_, i) => (
        <g key={i}>
          <path d={`M ${-224 + i * 56} -330 L ${-168 + i * 56} -330 L ${-168 + i * 56} -296 A 28 28 0 0 1 ${-224 + i * 56} -296 Z`} fill={i % 2 ? "#fff" : C.accent} stroke={OUT} strokeWidth={3} strokeLinejoin="round" />
        </g>
      ))}
      <rect x={-224} y={-344} width={448} height={18} rx={6} fill={C.accent} stroke={OUT} strokeWidth={sw} />
      <rect x={-226} y={-326} width={10} height={200} fill={OUT} opacity={0.0} />
      {sign && (
        <g>
          <rect x={-130} y={-412} width={260} height={56} rx={14} fill={C.data} stroke={OUT} strokeWidth={sw} />
          <text x={0} y={-373} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={36} fill="#fff">চায়ের দোকান</text>
        </g>
      )}
    </g>
  );
};

/** Square AI chip with pins. Origin = centre. glow 0..1 adds an accent halo. */
export const AIChip: React.FC<{ x: number; y: number; s?: number; glow?: number; t?: number; color?: string }> = ({ x, y, s = 1, glow = 0, t = 0, color = C.data }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    {glow > 0 && <circle r={96 + Math.sin(t * 4) * 5} fill={C.accent} opacity={0.22 * glow} />}
    {[-30, 0, 30].map((p) => (
      <g key={p} stroke={OUT} strokeWidth={5} strokeLinecap="round">
        <line x1={-74} y1={p} x2={-52} y2={p} /><line x1={74} y1={p} x2={52} y2={p} />
        <line x1={p} y1={-74} x2={p} y2={-52} /><line x1={p} y1={74} x2={p} y2={52} />
      </g>
    ))}
    <rect x={-52} y={-52} width={104} height={104} rx={24} fill={color} stroke={OUT} strokeWidth={sw} />
    <text x={0} y={20} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={58} fill="#fff">AI</text>
  </g>
);

/** Steering wheel (control). Origin = centre. */
export const Wheel: React.FC<{ x: number; y: number; r?: number; rot?: number; color?: string }> = ({ x, y, r = 64, rot = 0, color = C.accent }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot})`}>
    <circle r={r} fill="none" stroke={OUT} strokeWidth={26} />
    <circle r={r} fill="none" stroke={color} strokeWidth={16} />
    {[90, 210, 330].map((a) => <line key={a} x1={0} y1={0} x2={r * Math.cos((a * Math.PI) / 180)} y2={r * Math.sin((a * Math.PI) / 180)} stroke={OUT} strokeWidth={9} strokeLinecap="round" />)}
    <circle r={16} fill={C.surface} stroke={OUT} strokeWidth={4} />
  </g>
);

/** Office / company tower. Origin = bottom centre. grow 0..1 scales its height. */
export const Building: React.FC<{ x: number; y: number; w?: number; h?: number; grow?: number; t?: number; star?: boolean; seed?: number; glow?: number }> = ({ x, y, w = 220, h = 460, grow = 1, t = 0, star = false, seed = 1, glow = 0 }) => {
  const cols = Math.max(2, Math.floor(w / 56)), rows = Math.max(2, Math.floor((h - 110) / 62));
  return (
    <g transform={`translate(${x} ${y})`}>
      {glow > 0 && <ellipse cx={0} cy={-h * grow * 0.5} rx={w * 0.9} ry={h * grow * 0.62} fill={C.accent} opacity={0.16 * glow} />}
      <g transform={`scale(1 ${Math.max(0.001, grow)})`}>
        <rect x={-w / 2} y={-h} width={w} height={h} fill="#fff" stroke={OUT} strokeWidth={sw} />
        <rect x={-w / 2 - 10} y={-h - 18} width={w + 20} height={22} rx={6} fill={C.data} stroke={OUT} strokeWidth={sw} />
        {Array.from({ length: rows * cols }).map((_, i) => {
          const c = i % cols, r = Math.floor(i / cols);
          const lit = hash(i * 3 + seed * 17) > 0.72 + Math.sin(t * 1.2 + i) * 0.04;
          const gx = -w / 2 + (w / cols) * (c + 0.5);
          return <rect key={i} x={gx - 14} y={-h + 36 + r * 62} width={28} height={36} rx={5} fill={lit ? C.gold : C.tint} stroke={OUT} strokeWidth={2} />;
        })}
        <rect x={-24} y={-84} width={48} height={84} rx={22} fill={C.night} />
      </g>
      {star && grow > 0.9 && <g transform={`translate(0 ${-h * grow - 54})`}><path d="M 0 -30 L 9 -9 L 32 -8 L 14 7 L 20 30 L 0 17 L -20 30 L -14 7 L -32 -8 L -9 -9 Z" fill={C.gold} stroke={OUT} strokeWidth={3} strokeLinejoin="round" /></g>}
    </g>
  );
};

export const Heart: React.FC<{ x: number; y: number; s?: number; color?: string; opacity?: number }> = ({ x, y, s = 1, color = C.bad, opacity = 1 }) => (
  <path transform={`translate(${x} ${y}) scale(${s})`} opacity={opacity} d="M 0 16 C -40 -8 -30 -40 -11 -35 C -3 -33 0 -24 0 -20 C 0 -24 3 -33 11 -35 C 30 -40 40 -8 0 16 Z" fill={color} stroke={OUT} strokeWidth={3} strokeLinejoin="round" />
);

export const Smile: React.FC<{ x: number; y: number; s?: number; opacity?: number }> = ({ x, y, s = 1, opacity = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={opacity}>
    <circle r={28} fill={C.gold} stroke={OUT} strokeWidth={3} />
    <circle cx={-10} cy={-6} r={3.5} fill={OUT} /><circle cx={10} cy={-6} r={3.5} fill={OUT} />
    <path d="M -12 6 q 12 14 24 0" fill="none" stroke={OUT} strokeWidth={3} strokeLinecap="round" />
  </g>
);

export const Magnifier: React.FC<{ x: number; y: number; s?: number; rot?: number }> = ({ x, y, s = 1, rot = 0 }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <line x1={20} y1={20} x2={52} y2={52} stroke={OUT} strokeWidth={12} strokeLinecap="round" />
    <circle r={28} fill="rgba(255,255,255,0.6)" stroke={OUT} strokeWidth={7} />
  </g>
);

export const Crown: React.FC<{ x: number; y: number; s?: number; opacity?: number }> = ({ x, y, s = 1, opacity = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={opacity}>
    <path d="M -44 0 L -52 -48 L -24 -24 L 0 -62 L 24 -24 L 52 -48 L 44 0 Z" fill={C.gold} stroke={OUT} strokeWidth={4} strokeLinejoin="round" />
    <rect x={-44} y={-12} width={88} height={12} fill={C.warn} stroke={OUT} strokeWidth={3} />
  </g>
);

/** Clipboard checklist. Origin = bottom centre. ticks = how many rows are ticked (float ok). */
export const Checklist: React.FC<{ x: number; y: number; s?: number; ticks?: number }> = ({ x, y, s = 1, ticks = 0 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-90} y={-240} width={180} height={240} rx={16} fill="#fff" stroke={OUT} strokeWidth={sw} />
    <rect x={-34} y={-256} width={68} height={32} rx={10} fill={C.data} stroke={OUT} strokeWidth={sw} />
    {[0, 1, 2].map((i) => {
      const p = cl(ticks - i);
      return (
        <g key={i} transform={`translate(0 ${-186 + i * 62})`}>
          <rect x={-66} y={-4} width={36} height={36} rx={8} fill={C.surface} stroke={OUT} strokeWidth={3} />
          <rect x={-14} y={8} width={72} height={12} rx={6} fill={C.tint} />
          {p > 0 && <path d="M -60 14 L -52 24 L -36 2" fill="none" stroke={C.good} strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" strokeDasharray={60} strokeDashoffset={60 * (1 - p)} />}
        </g>
      );
    })}
  </g>
);

export const Wrench: React.FC<{ x: number; y: number; s?: number; rot?: number }> = ({ x, y, s = 1, rot = 0 }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <rect x={-13} y={-60} width={26} height={150} rx={13} fill={C.muted} stroke={OUT} strokeWidth={sw} />
    <circle cx={0} cy={-70} r={34} fill={C.muted} stroke={OUT} strokeWidth={sw} />
    <rect x={-13} y={-112} width={26} height={44} fill={C.bg} />
    <path d="M -13 -112 L -13 -70 M 13 -112 L 13 -70" stroke={OUT} strokeWidth={sw} />
  </g>
);

export const Coin: React.FC<{ x: number; y: number; r?: number; opacity?: number }> = ({ x, y, r = 22, opacity = 1 }) => (
  <g transform={`translate(${x} ${y})`} opacity={opacity}>
    <circle r={r} fill={C.gold} stroke={OUT} strokeWidth={3} />
    <circle r={r * 0.6} fill="none" stroke={C.warn} strokeWidth={3} />
  </g>
);

export const Chest: React.FC<{ x: number; y: number; s?: number; open?: number }> = ({ x, y, s = 1, open = 0 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-90} y={-80} width={180} height={80} rx={10} fill={C.accent} stroke={OUT} strokeWidth={sw} />
    {open > 0.2 && <ellipse cx={0} cy={-80} rx={78} ry={10} fill={C.night} />}
    <g transform={`rotate(${-open * 38} -90 -80)`}>
      <path d="M -90 -80 Q -90 -150 0 -150 Q 90 -150 90 -80 Z" fill={C.warn} stroke={OUT} strokeWidth={sw} />
    </g>
    <rect x={-14} y={-90} width={28} height={36} rx={6} fill={C.gold} stroke={OUT} strokeWidth={3} />
  </g>
);

export const Book: React.FC<{ x: number; y: number; s?: number; color?: string }> = ({ x, y, s = 1, color = C.good }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <path d="M -120 -80 Q -60 -100 0 -70 L 0 70 Q -60 40 -120 60 Z" fill={color} stroke={OUT} strokeWidth={sw} strokeLinejoin="round" />
    <path d="M 120 -80 Q 60 -100 0 -70 L 0 70 Q 60 40 120 60 Z" fill="#fff" stroke={OUT} strokeWidth={sw} strokeLinejoin="round" />
    {[-30, 0, 30].map((ly) => <line key={ly} x1={30} y1={ly - 20} x2={100} y2={ly - 20} stroke={C.muted} strokeWidth={4} strokeLinecap="round" />)}
  </g>
);

export const Cloud: React.FC<{ x: number; y: number; s?: number; color?: string }> = ({ x, y, s = 1, color = "#fff" }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} fill={color} stroke={OUT} strokeWidth={3}>
    <path d="M -70 0 Q -90 -30 -55 -38 Q -40 -75 0 -60 Q 30 -85 60 -50 Q 100 -50 90 -10 Q 90 10 60 10 L -55 10 Q -70 10 -70 0 Z" />
  </g>
);

export const Star: React.FC<{ x: number; y: number; r?: number; color?: string; opacity?: number }> = ({ x, y, r = 8, color = C.gold, opacity = 1 }) => (
  <path transform={`translate(${x} ${y})`} opacity={opacity} fill={color} d={`M 0 ${-r} L ${r * 0.3} ${-r * 0.3} L ${r} 0 L ${r * 0.3} ${r * 0.3} L 0 ${r} L ${-r * 0.3} ${r * 0.3} L ${-r} 0 L ${-r * 0.3} ${-r * 0.3} Z`} />
);

export const Footprint: React.FC<{ x: number; y: number; rot?: number; color?: string; opacity?: number }> = ({ x, y, rot = 0, color = C.data, opacity = 1 }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot})`} opacity={opacity} fill={color}>
    <ellipse cx={0} cy={0} rx={13} ry={20} />
    <ellipse cx={0} cy={26} rx={10} ry={8} />
  </g>
);

export const Flag: React.FC<{ x: number; y: number; s?: number; color?: string }> = ({ x, y, s = 1, color = C.accent }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <line x1={0} y1={0} x2={0} y2={-120} stroke={OUT} strokeWidth={6} strokeLinecap="round" />
    <path d="M 0 -120 L 62 -100 L 0 -78 Z" fill={color} stroke={OUT} strokeWidth={4} strokeLinejoin="round" />
  </g>
);

/** Rounded country badge: text only (no flags). */
export const Badge: React.FC<{ x: number; y: number; text: string; color?: string; size?: number }> = ({ x, y, text, color = C.data, size = 40 }) => {
  const w = text.length * size * 0.62 + 60;
  return (
    <g>
      <rect x={x - w / 2} y={y - size} width={w} height={size * 2} rx={size} fill={color} stroke={OUT} strokeWidth={4} />
      <text x={x} y={y + size * 0.36} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={size} fill="#fff">{text}</text>
    </g>
  );
};
