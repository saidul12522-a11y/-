import React from "react";
import { theme as C } from "../theme";
import { FONT } from "../fonts";
import { glen } from "../captions";
import { pop, prog, SMOOTH } from "../motion";

type Kids = { children?: React.ReactNode };

/** Reveal wrapper for SVG groups: fades + rises (+ optional spring scale) from `cue` seconds. */
export const In: React.FC<
  { t: number; cue: number; dy?: number; dx?: number; s0?: number; spring?: boolean; ox?: number; oy?: number; out?: number } & Kids
> = ({ t, cue, dy = 40, dx = 0, s0 = 0.9, spring = true, ox = 0, oy = 0, out, children }) => {
  const p = spring ? pop(t, cue) : prog(t, cue, cue + 0.45);
  const o = Math.min(1, prog(t, cue, cue + 0.3)) * (out === undefined ? 1 : 1 - prog(t, out, out + 0.3));
  if (o <= 0.001) return null;
  const s = s0 + (1 - s0) * p;
  const x = dx * (1 - p), y = dy * (1 - p);
  return (
    <g opacity={o} transform={`translate(${x} ${y}) translate(${ox} ${oy}) scale(${s}) translate(${-ox} ${-oy})`}>
      {children}
    </g>
  );
};

/** Rounded label chip centred at (x,y). */
export const Chip: React.FC<{ x: number; y: number; text: string; color?: string; fill?: string; size?: number; tc?: string; icon?: React.ReactNode }> = ({
  x, y, text, color = C.data, fill = C.surface, size: size0 = 30, tc = C.text, icon,
}) => {
  const size = Math.round(size0 * 1.3);
  const w = glen(text) * size * 0.6 + 44 + (icon ? size + 10 : 0);
  const h = size * 1.75;
  return (
    <g>
      <rect x={x - w / 2} y={y - h / 2 + 4} width={w} height={h} rx={h / 2} fill="rgba(16,35,58,0.10)" />
      <rect x={x - w / 2} y={y - h / 2} width={w} height={h} rx={h / 2} fill={fill} stroke={color} strokeWidth={3} />
      {icon ? <g transform={`translate(${x - w / 2 + 28} ${y})`}>{icon}</g> : null}
      <text x={x + (icon ? (size + 10) / 2 : 0)} y={y + size * 0.36} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={size} fill={tc}>{text}</text>
    </g>
  );
};

export const Label: React.FC<{ x: number; y: number; text: string; size?: number; color?: string; weight?: number; anchor?: "start" | "middle" | "end" }> = ({
  x, y, text, size = 28, color = C.text, weight = 700, anchor = "middle",
}) => (
  <text x={x} y={y} textAnchor={anchor} fontFamily={FONT} fontWeight={weight} fontSize={size} fill={color}>{text}</text>
);

export const Card: React.FC<{ x: number; y: number; w: number; h: number; color?: string; fill?: string } & Kids> = ({ x, y, w, h, color = C.border, fill = C.surface, children }) => (
  <g>
    <rect x={x} y={y + 8} width={w} height={h} rx={28} fill="rgba(16,35,58,0.10)" />
    <rect x={x} y={y} width={w} height={h} rx={28} fill={fill} stroke={color} strokeWidth={3} />
    {children}
  </g>
);

/** pulsing ring for emphasis */
export const Ring: React.FC<{ x: number; y: number; t: number; cue: number; r?: number; color?: string; loop?: boolean }> = ({ x, y, t, cue, r = 60, color = C.accent, loop = false }) => {
  if (t < cue) return null;
  let p = (t - cue) / 1.2;
  if (loop) p = p % 1; else if (p > 1) return null;
  return <circle cx={x} cy={y} r={r * (1 + 1.2 * p)} fill="none" stroke={color} strokeWidth={5} opacity={0.7 * (1 - p)} />;
};

export const Check: React.FC<{ x: number; y: number; t: number; cue: number; s?: number; color?: string }> = ({ x, y, t, cue, s = 1, color = C.good }) => {
  const p = pop(t, cue, "snap");
  if (p <= 0) return null;
  return (
    <g transform={`translate(${x} ${y}) scale(${s * p})`}>
      <circle r={34} fill={color} />
      <path d="M -16 2 L -4 14 L 18 -12" stroke="#fff" strokeWidth={9} fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </g>
  );
};

export const Cross: React.FC<{ x: number; y: number; t: number; cue: number; s?: number; color?: string }> = ({ x, y, t, cue, s = 1, color = C.bad }) => {
  const p = pop(t, cue, "snap");
  if (p <= 0) return null;
  return (
    <g transform={`translate(${x} ${y}) scale(${s * p})`}>
      <circle r={34} fill={color} />
      <path d="M -14 -14 L 14 14 M 14 -14 L -14 14" stroke="#fff" strokeWidth={9} strokeLinecap="round" />
    </g>
  );
};

/** soft ground strip with grass-like highlight */
export const Ground: React.FC<{ y: number; color?: string; from?: number; to?: number }> = ({ y, color = C.tint, from = 0, to = 1920 }) => (
  <g>
    <rect x={from} y={y} width={to - from} height={1080 - y} fill={color} />
    <rect x={from} y={y} width={to - from} height={6} fill={C.border} />
  </g>
);

export const Arrow: React.FC<{ x1: number; y1: number; x2: number; y2: number; p: number; color?: string; w?: number }> = ({ x1, y1, x2, y2, p, color = C.data, w = 8 }) => {
  if (p <= 0) return null;
  const ex = x1 + (x2 - x1) * p, ey = y1 + (y2 - y1) * p;
  const a = Math.atan2(y2 - y1, x2 - x1);
  const hs = 26;
  return (
    <g opacity={Math.min(1, p * 3)}>
      <line x1={x1} y1={y1} x2={ex} y2={ey} stroke={color} strokeWidth={w} strokeLinecap="round" />
      {p > 0.95 && (
        <path d={`M ${x2} ${y2} L ${x2 - hs * Math.cos(a - 0.5)} ${y2 - hs * Math.sin(a - 0.5)} L ${x2 - hs * Math.cos(a + 0.5)} ${y2 - hs * Math.sin(a + 0.5)} Z`} fill={color} />
      )}
    </g>
  );
};
export { SMOOTH };

/** Bengali numerals: bn(10) -> "১০" */
export const bn = (n: number | string) => String(n).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[+d]);

/** Step tab bar (HTML overlay) shown while the voiceover walks through "ধাপ এক ... ধাপ চার". */
const TABS = [
  { n: "১", text: "শুরুর সমস্যা", at: 21.42 },
  { n: "২", text: "ভারত কেন এগিয়ে?", at: 64.67 },
  { n: "৩", text: "Altman এর ভয়", at: 113.47 },
  { n: "৪", text: "আমাদের করণীয়", at: 136.91 },
];
export const StepTabs: React.FC<{ t: number }> = ({ t }) => {
  const op = Math.min(prog(t, 21.0, 21.5), 1 - prog(t, 162.7, 163.2));
  if (op <= 0.001) return null;
  let active = 0;
  TABS.forEach((s, i) => { if (t >= s.at - 0.05) active = i; });
  return (
    <div style={{ position: "absolute", left: 0, right: 0, top: 40, display: "flex", justifyContent: "center", gap: 16, opacity: op, transform: `translateY(${(1 - op) * -16}px)`, paddingRight: 120 }}>
      {TABS.map((s, i) => {
        const on = i === active;
        return (
          <div key={i} style={{ width: 330, height: 58, borderRadius: 29, display: "flex", alignItems: "center", justifyContent: "center", gap: 12, fontFamily: FONT, fontWeight: 700, fontSize: 28, background: on ? C.accent : C.surface, color: on ? C.onAccent : C.muted, border: `2px solid ${on ? C.accent : C.border}`, boxShadow: on ? "0 6px 16px rgba(224,122,31,0.30)" : "none", whiteSpace: "nowrap" }}>
            <span style={{ width: 34, height: 34, borderRadius: 17, background: on ? C.onAccent : C.tint, color: on ? "#fff" : C.muted, display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 24 }}>{s.n}</span>
            {s.text}
          </div>
        );
      })}
    </div>
  );
};

/** Quote card for "Sam Altman says ...": name on a card with a big quote mark. No portrait is drawn. */
export const Quote: React.FC<{ x: number; y: number; w?: number; name?: string; lit?: boolean }> = ({ x, y, w = 520, name = "Sam Altman", lit = false }) => (
  <g>
    <rect x={x - w / 2} y={y - 52 + 8} width={w} height={104} rx={30} fill="rgba(16,35,58,0.10)" />
    <rect x={x - w / 2} y={y - 52} width={w} height={104} rx={30} fill={C.surface} stroke={lit ? C.accent : C.data} strokeWidth={4} />
    <text x={x - w / 2 + 58} y={y + 40} textAnchor="middle" fontFamily="Georgia, serif" fontWeight={700} fontSize={120} fill={C.accent}>“</text>
    <text x={x + 36} y={y + 16} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={52} fill={C.text}>{name}</text>
  </g>
);

/** Tiny label bubble with tail, e.g. thought / speech text. */
export const Bubble: React.FC<{ x: number; y: number; w: number; h: number; tail?: "l" | "r" | "d"; color?: string; fill?: string } & Kids> = ({ x, y, w, h, tail = "d", color = C.data, fill = C.surface, children }) => (
  <g>
    <rect x={x - w / 2} y={y - h / 2} width={w} height={h} rx={h / 2.6} fill={fill} stroke={color} strokeWidth={4} />
    {tail === "d" && <path d={`M ${x - 22} ${y + h / 2 - 2} L ${x - 8} ${y + h / 2 + 30} L ${x + 22} ${y + h / 2 - 2}`} fill={fill} stroke={color} strokeWidth={4} strokeLinejoin="round" />}
    {tail === "d" && <rect x={x - 20} y={y + h / 2 - 7} width={40} height={10} fill={fill} />}
    {children}
  </g>
);
