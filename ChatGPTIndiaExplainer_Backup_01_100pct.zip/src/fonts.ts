import { continueRender, delayRender, staticFile } from "remotion";

// Hind Siliguri (Bengali + Latin subsets) is bundled in public/fonts, so no internet is needed to render.
const handle = delayRender("loading Hind Siliguri");
const BN = "U+0980-09FF,U+0964-0965,U+200C-200D,U+25CC";
const LAT = "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+20AC,U+2122,U+2212";
const defs: [string, string, string][] = [
  ["latin", "600", LAT], ["latin", "700", LAT], ["bengali", "600", BN], ["bengali", "700", BN],
];
Promise.all(
  defs.map(async ([subset, weight, range]) => {
    const face = new FontFace("Hind Siliguri", `url(${staticFile(`fonts/hind-siliguri-${subset}-${weight}-normal.woff2`)})`, { weight, unicodeRange: range });
    await face.load();
    (document.fonts as unknown as { add: (f: FontFace) => void }).add(face);
  }),
)
  .then(() => continueRender(handle))
  .catch((e) => { console.error("font load failed", e); continueRender(handle); });

export const FONT = `"Hind Siliguri", "Noto Sans Bengali", "Nirmala UI", sans-serif`;
