# ChatGPT India Explainer (SUL channel) - Remotion project

16:9, 1920x1080, 30 FPS, MP4. Bengali voiceover (178.76 s) + in-video word-synced captions + 15 animated 2D diagram scenes + SUL channel logo.
Theme: light "Frosty" (same as the WinterDawnExplainer project): bg #EEF4FA, primary #2B6CB0, accent #E07A1F, text #10233A. Font: Hind Siliguri (bundled in `public/fonts`, no internet needed for the font).

## Windows PC setup
1. Install Node.js LTS (v20 or v22) from https://nodejs.org . Chrome/Chromium is found or downloaded by Remotion automatically
   (internet is needed on the first run for `npm install` and, if no Chrome is found, for Remotion's own browser download).
2. Open a terminal (PowerShell or cmd) in this folder (the one that contains `package.json`).

First time only:

    npm install

Preview in Remotion Studio:

    npm run dev

Render the MP4 (output: `out/chatgpt-india.mp4`):

    npm run render

Composition id: `ChatGPTIndia`, entry point: `src/index.ts`.
Render a single check frame: `npm run still` (writes `out/frame.png`).

## Structure
- `public/voice.mp3` voiceover, `public/logo.jpg` SUL logo, `public/fonts/` Hind Siliguri (OFL license included)
- `public/subtitles/original.srt` (untouched) and `corrected.srt` (fixed)
- `src/sceneList.ts` scene timings + storyboard, `src/scenes/s1..s5.tsx` the 15 scenes, `src/art/art.tsx` icon-style art
- `src/components/` Caption, Background, kit (Chip, Card, Quote, StepTabs, ...), `src/timing.json` word timing, `src/corrections.json` SRT fix log
- `scripts/build-timing.mjs` rebuilds corrected SRT + word timing from original.srt (`npm run timing`; uses `scripts/silences.json`)
- `scripts/preview-frames.mjs`, `scripts/smoke-test.tsx` optional developer checks
- `PROGRESS.md` full work log

## Notes
- Captions: word timing = SRT cue time spread over the speech part of each cue (pauses from ffmpeg silencedetect are skipped). No speech recognition was available, so word times are estimates; cue starts match the audio.
- "ChatGPT's" / "AI's" are kept exactly as in the SRT (spoken form unverified). To turn them into "ChatGPT-র" / "AI-র", set `FIX_POSSESSIVE = true` in `scripts/build-timing.mjs` and run `npm run timing`.
- No sound effects were supplied, so none are used. The voiceover is untouched.
