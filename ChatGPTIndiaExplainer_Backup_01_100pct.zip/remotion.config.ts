import { Config } from "@remotion/cli/config";

// Chrome/Chromium is located automatically by Remotion (it downloads its own if needed).
Config.setVideoImageFormat("jpeg");
Config.setJpegQuality(95);
Config.setCodec("h264");
Config.setCrf(18);
Config.setPixelFormat("yuv420p");
Config.setOverwriteOutput(true);
